<?php

namespace App\Observers;

use App\Jobs\SendQuotaNotificationJob;
use App\Models\Invoice;
use Illuminate\Support\Facades\Log;

class InvoiceObserver
{
    public function created(Invoice $invoice): void
    {
        Log::info('InvoiceObserver: START', [
            'invoice_id' => $invoice->id,
        ]);

        $company = auth()->user()?->company;

        Log::info('InvoiceObserver: Company fetched from auth', [
            'company' => $company,
            'auth_user_id' => auth()->id(),
        ]);

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();

            Log::info('InvoiceObserver: Company collection converted', [
                'company_id' => $company?->id,
            ]);
        }

        if (!$company) {
            Log::warning('InvoiceObserver: No company found');
            return;
        }

        $subscription = $company->user?->subscriptionDetails;

        Log::info('InvoiceObserver: Subscription details', [
            'subscription_id' => $subscription?->id,
            'start_date' => $subscription?->start_date,
            'end_date' => $subscription?->end_date,
        ]);

        if (!$subscription) {
            Log::warning('InvoiceObserver: No subscription found');
            return;
        }

        $limit = $subscription->invoices
            ?? $subscription->subscription?->invoices
            ?? null;

        Log::info('InvoiceObserver: Limit calculated', [
            'limit' => $limit,
            'subscription_invoices' => $subscription->invoices,
            'plan_invoices' => $subscription->subscription?->invoices,
        ]);

        // Unlimited
        if (is_null($limit) || $limit <= 0) {
            Log::warning('InvoiceObserver: Unlimited or invalid limit', [
                'limit' => $limit,
            ]);
            return;
        }

        if (
            empty($subscription->start_date) ||
            empty($subscription->end_date)
        ) {
            Log::warning('InvoiceObserver: Missing subscription dates', [
                'start_date' => $subscription->start_date,
                'end_date' => $subscription->end_date,
            ]);
            return;
        }

        $used = Invoice::forUsers($company->id)
            ->whereBetween('issue_date', [
                $subscription->start_date,
                $subscription->end_date,
            ])
            ->count();

        Log::info('InvoiceObserver: Invoice count calculated', [
            'used' => $used,
            'company_id' => $company->id,
            'start_date' => $subscription->start_date,
            'end_date' => $subscription->end_date,
        ]);

        $percent = min(
            (int) floor(($used / $limit) * 100),
            100
        );

        Log::info('InvoiceObserver: Percentage calculated', [
            'used' => $used,
            'limit' => $limit,
            'percent' => $percent,
        ]);

        if ($percent < 90) {
            Log::info('InvoiceObserver: Percentage below threshold', [
                'percent' => $percent,
            ]);
            return;
        }

        $periodKey = $subscription->start_date . '_' . $subscription->end_date;

        Log::info('InvoiceObserver: Period key', [
            'period_key' => $periodKey,
        ]);

        $extra = $subscription->extra ?? [];

        Log::info('InvoiceObserver: Extra data', [
            'extra' => $extra,
        ]);

        $lastSentPercent =
            $extra['invoice_notifications'][$periodKey] ?? 89;

        Log::info('InvoiceObserver: Last sent percentage', [
            'last_sent_percent' => $lastSentPercent,
            'current_percent' => $percent,
        ]);

        if ($percent <= $lastSentPercent) {
            Log::info('InvoiceObserver: Notification already sent', [
                'current_percent' => $percent,
                'last_sent_percent' => $lastSentPercent,
            ]);
            return;
        }

        Log::info('InvoiceObserver: Dispatching quota notification job', [
            'company_id' => $company->id,
            'type' => 'invoice',
            'used' => $used,
            'limit' => $limit,
            'percent' => $percent,
        ]);

        SendQuotaNotificationJob::dispatch(
            $company,
            'invoice',
            $used,
            $limit,
            $percent
        );

        $extra['invoice_notifications'][$periodKey] = $percent;

        Log::info('InvoiceObserver: Updating subscription extra', [
            'period_key' => $periodKey,
            'new_percent' => $percent,
        ]);

        $subscription->update([
            'extra' => $extra,
        ]);

        Log::info('InvoiceObserver: COMPLETED SUCCESSFULLY', [
            'invoice_id' => $invoice->id,
            'percent' => $percent,
        ]);
    }
}