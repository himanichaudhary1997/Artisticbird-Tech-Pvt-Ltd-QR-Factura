<?php

namespace App\Observers;

use App\Jobs\SendQuotaNotificationJob;
use App\Models\Receipts;
use Illuminate\Support\Facades\Log;

class ReceiptObserver
{
    public function created(Receipts $receipt): void
    {
        Log::info('ReceiptObserver: START', [
            'receipt_id' => $receipt->id,
        ]);

        $company = auth()->user()?->company;

        Log::info('ReceiptObserver: Company fetched from auth', [
            'company' => $company,
            'auth_user_id' => auth()->id(),
        ]);

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();

            Log::info('ReceiptObserver: Company collection converted', [
                'company_id' => $company?->id,
            ]);
        }

        if (!$company) {
            Log::warning('ReceiptObserver: No company found');
            return;
        }

        $subscription = $company->user?->subscriptionDetails;

        Log::info('ReceiptObserver: Subscription details', [
            'subscription_id' => $subscription?->id,
            'start_date' => $subscription?->start_date,
            'end_date' => $subscription?->end_date,
        ]);

        if (!$subscription) {
            Log::warning('ReceiptObserver: No subscription found');
            return;
        }

        $limit = $subscription->receipts
            ?? $subscription->subscription?->receipts
            ?? null;

        Log::info('ReceiptObserver: Limit calculated', [
            'limit' => $limit,
            'subscription_receipts' => $subscription->receipts,
            'plan_receipts' => $subscription->subscription?->receipts,
        ]);

        if (is_null($limit) || $limit <= 0) {
            Log::warning('ReceiptObserver: Unlimited or invalid limit', [
                'limit' => $limit,
            ]);
            return;
        }

        if (
            empty($subscription->start_date) ||
            empty($subscription->end_date)
        ) {
            Log::warning('ReceiptObserver: Missing subscription dates', [
                'start_date' => $subscription->start_date,
                'end_date' => $subscription->end_date,
            ]);
            return;
        }

        $used = Receipts::forUsers($company->id)
            ->whereBetween('created_at', [
                $subscription->start_date,
                $subscription->end_date,
            ])
            ->count();

        Log::info('ReceiptObserver: Receipt count calculated', [
            'used' => $used,
            'company_id' => $company->id,
            'start_date' => $subscription->start_date,
            'end_date' => $subscription->end_date,
        ]);

        $percent = min(
            (int) floor(($used / $limit) * 100),
            100
        );

        Log::info('ReceiptObserver: Percentage calculated', [
            'used' => $used,
            'limit' => $limit,
            'percent' => $percent,
        ]);

        if ($percent < 90) {
            Log::info('ReceiptObserver: Percentage below threshold', [
                'percent' => $percent,
            ]);
            return;
        }

        $periodKey = $subscription->start_date . '_' . $subscription->end_date;

        Log::info('ReceiptObserver: Period key', [
            'period_key' => $periodKey,
        ]);

        $extra = $subscription->extra ?? [];

        Log::info('ReceiptObserver: Extra data', [
            'extra' => $extra,
        ]);

        $lastSentPercent =
            $extra['receipt_notifications'][$periodKey] ?? 89;

        Log::info('ReceiptObserver: Last sent percentage', [
            'last_sent_percent' => $lastSentPercent,
            'current_percent' => $percent,
        ]);

        if ($percent <= $lastSentPercent) {
            Log::info('ReceiptObserver: Notification already sent', [
                'current_percent' => $percent,
                'last_sent_percent' => $lastSentPercent,
            ]);
            return;
        }

        Log::info('ReceiptObserver: Dispatching job', [
            'company_id' => $company->id,
            'type' => 'receipt',
            'used' => $used,
            'limit' => $limit,
            'percent' => $percent,
        ]);

        SendQuotaNotificationJob::dispatch(
            $company,
            'receipt',
            $used,
            $limit,
            $percent
        );

        $extra['receipt_notifications'][$periodKey] = $percent;

        Log::info('ReceiptObserver: Updating subscription extra', [
            'period_key' => $periodKey,
            'new_percent' => $percent,
        ]);

        $subscription->update([
            'extra' => $extra,
        ]);

        Log::info('ReceiptObserver: COMPLETED SUCCESSFULLY', [
            'receipt_id' => $receipt->id,
            'percent' => $percent,
        ]);
    }
}