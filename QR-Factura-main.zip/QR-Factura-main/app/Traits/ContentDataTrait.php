<?php

namespace App\Traits;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\ClientAccountantRelation;

trait ContentDataTrait
{

    public function contentData(Request $request, $model, $searchModule = 'invoice')
    {
        $allUserPermissions = auth()->user()->getAllUserPermissions();
        // dd($allUserPermissions);
        $user = auth()->user();
        $role = $user->roles->pluck('id')->first();
        $draw = $request->get('draw');
        $start = $request->get('start');
        $rowPerPage = $request->get('length') ? $request->get('length') : 20;

        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');

        $columnIndex = $columnIndex_arr[0]['column'] ?? 0;

        $columnName = $columnName_arr[$columnIndex]['data']  ?? '';
        $columnSortOrder = $order_arr[0]['dir'] ?? 'desc';
        $searchValue = $search_arr['value'] ?? '';

        $formdata = $request->all();


        $totalRecords = $model::count(); // Get total records before filtering

        $filteredQuery = $model::query();
        if ($searchModule == 'invoice') {
            $filteredQuery = $this->applyInvoiceFilters($filteredQuery, $formdata, $role, $user);
        }
        $totalRecordsWithFilter = $filteredQuery->count(); // Get the filtered count after applying conditions


        $recordsQuery = $model::query();

        if ($searchModule == 'invoice') {
            $recordsQuery = $this->applyInvoiceFilters($recordsQuery, $formdata, $role, $user);

            
        }

        $records = $recordsQuery
            ->orderBy($columnName, $columnSortOrder)
            ->skip($start)
            ->take($rowPerPage)
            ->get();



        $dataArr = [];
        foreach ($records as $record) {
            $row = $this->getColumnData($record, $columnName_arr);
            $dataArr[] = $row;
        }

        $response = [
            "draw" => intval($draw),
            "recordsTotal" => $totalRecords,
            "recordsFiltered" => $totalRecordsWithFilter,
            "data" => $dataArr,
            'success' => true,
            'message' => 'Data retrived Successfully'
        ];

        return response()->json($response);
    }


    private function getColumnData($record, $columnsList)
    {
        $row = [];
        $allUserPermissions = auth()->user()->getAllUserPermissions();

        foreach ($columnsList as $column) {
            switch ($column['data']) {
                case 'id':
                    $row['id'] = $record->id;
                    break;
                case 'client_name':
                    $row['client_name'] = $record->client->name ?? 'NA';
                    break;
                case 'invoice_type_name':
                    $row['invoice_type_name'] = $record->invoiceType->name ?? 'NA';
                    break;
                case 'payment_method_name':
                    $row['payment_method_name'] = $record->paymentMethod->name ?? 'NA';
                    break;
                case 'status':
                    $row['status'] = $this->getStatus($record);
                    break;
                case 'invoice_status':
                    $row['invoice_status'] = $this->getInvoiceStatus($record);
                    break;
                case 'id_checkbox':
                    $row['id_checkbox'] = $this->getIdCheckBox($record);
                    break;
                case 'invoice_action_buttons':
                    $row['invoice_action_buttons'] = $this->getInvoiceActionButtons($record,$allUserPermissions);
                    break;
                default:
                    $row[$column['data']] = $record->{$column['data']} ?? 'NA';
                    break;
            }
        }

        return $row;
    }




    private function getStatus($record)
    {
        return "<div class='form-check form-switch ps-5'>
                    <input class='form-check-input' id='status" . $record->id . "' data-rowid='" . $record->id . "' " . ($record->status == 1 ? 'checked' : '') . " name='status" . $record->id . "' type='checkbox' onchange='updateStatus(" . $record->id . ")'>
                    <label class='form-check-label' for='status" . $record->id . "'></label>
                </div>";
    }



    private function getInvoiceStatus($record)
    {
        return '<select id="status_id_' . $record->id . '" onchange="statusChange(' . $record->id . ')" class="form-control">
                    <option value="0" ' . ($record->status == 0 ? "selected" : "") . '>Draft</option>
                    <option value="1" ' . ($record->status == 1 ? "selected" : "") . '>Paid</option>
                    <option value="2" ' . ($record->status == 2 ? "selected" : "") . '>Sent</option>
                    <option value="3" ' . ($record->status == 3 ? "selected" : "") . '>Partially Paid</option>
                    <option value="4" ' . ($record->status == 4 ? "selected" : "") . '>Cancel</option>
                    <option value="5" ' . ($record->status == 5 ? "selected" : "") . '>Negative</option>
                </select>';
    }


    private function getInvoiceActionButtons($record, $allUserPermissions)
    {
        $actionButtons = '';

        if (empty($allUserPermissions['invoices']['children'])) {
            $actionButtons .= '<a href="/admin/invoices/edit-invoice/' . $record->id . '" class="btn btn-primary btn-sm">
                                    <img src="' . asset('/uploads/images/icons/pen-square.svg') . '" width="16px" alt="Edit">
                                </a>
                                <a target="_blank" href="/admin/invoices/preview/' . $record->id . '" class="btn btn-info btn-sm">Preview</a>
                                <a href="/admin/invoices/download-invoice/' . $record->id . '" class="btn btn-warning">Download PDF</a>
                                <button onclick="deleteInvoices(' . $record->id . ')" class="btn btn-danger">
                                    <img src="' . asset('/uploads/images/icons/nfc-trash.svg') . '" width="16px" alt="Delete">
                                </button>
                                <button onclick="showEmailPopup(' . $record->id . ')" class="btn btn-warning btn-sm">Send Email</button>';
        } else {
            if (in_array('edit invoice', $allUserPermissions['invoices']['children'])) {
                $actionButtons .= '<a href="/admin/invoices/edit-invoice/' . $record->id . '" class="btn btn-primary btn-sm">
                                        <img src="' . asset('/uploads/images/icons/pen-square.svg') . '" width="16px" alt="Edit">
                                    </a>';
            }

            if (in_array('preview invoice', $allUserPermissions['invoices']['children'])) {
                $actionButtons .= '<a target="_blank" href="/admin/invoices/preview/' . $record->id . '" class="btn btn-info btn-sm">Preview</a>';
            }

            if (in_array('download invoice', $allUserPermissions['invoices']['children'])) {
                $actionButtons .= '<a href="/admin/invoices/download-invoice/' . $record->id . '" class="btn btn-warning btn-sm">Download PDF</a>';
            }

            if (in_array('delete invoice', $allUserPermissions['invoices']['children'])) {
                $actionButtons .= '<button onclick="deleteInvoices(' . $record->id . ')" class="btn btn-danger btn-sm">
                                        <img src="' . asset('/uploads/images/icons/nfc-trash.svg') . '" width="16px" alt="Delete">
                                    </button>';
            }

            if (in_array('send invoices', $allUserPermissions['invoices']['children'])) {
                $actionButtons .= '<button onclick="showEmailPopup(' . $record->id . ')" class="btn btn-warning btn-sm">Send Email</button>';
            }
        }

        return $actionButtons;
    }


    private function getIdCheckBox($record){
        return '<input type="checkbox" class="invoice-checkbox" value="'.$record->id.'" onchange="toggleInvoiceSelection('.$record->id.')">';
    }
    
    private function applyInvoiceFilters($query, $formdata, $role, $user)
    {
        if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
            return response()->json([
                'success' => false,
                'message' => 'The to date must be greater than or equal to from date.',
            ], 200);
        }

        // Apply search filter
        if (isset($formdata['search']) && !empty($formdata['search'])) {
            $query->where(function ($q) use ($formdata) {
                $q->where('invoice_id', 'like', '%' . $formdata['search'] . '%')
                    ->orWhereHas('client', function ($recordsQuery) use ($formdata) {
                        $recordsQuery->where('name', 'like', '%' . $formdata['search'] . '%');
                    });
            });
        }

        // Apply status filter
        if (isset($formdata['status']) && !is_null($formdata['status'])) {
            $query->where('status', $formdata['status']);
        }

        // Apply invoice type filter
        if (isset($formdata['invoice_type']) && !is_null($formdata['invoice_type'])) {
            $query->where('invoice_type', $formdata['invoice_type']);
        }

        // Apply date range filters
        if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
            $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
        } elseif (!empty($formdata['from_date'])) {
            $query->where('issue_date', '>=', $formdata['from_date']);
        } elseif (!empty($formdata['to_date'])) {
            $query->where('issue_date', '<=', $formdata['to_date']);
        }

        // Restrict to user's own records for non-admin roles
        if($role == 3){
            $query->where('created_by',$user->id);
        }elseif($role == 4){
            $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
            ->pluck('client_id')
            ->toArray();

            $query->whereIn('client_id',$currentAccountantClients);
        }

        return $query;
    }
}
