<?php

namespace App\Exports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class UsersExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return User::with(['singleCompany', 'subscriptionDetails'])
        ->whereHas('roles', function($query) {
            $query->where('name', 'Company');
        })
        ->get();
    }

    public function map($user): array
    {
        return [
            $user->id,
            $user->name,
            $user->email,
            $user->phone,
            $user->status,
            $user->company->company_name ?? 'N/A',
            $user->company->company_slug ?? 'N/A',
            $user->company->company_email ?? 'N/A',
            $user->company->gst_no ?? 'N/A',
            $user->company->extra['company_logo'] ?? 'N/A',
            $user->company->extra['profile_picture'] ?? 'N/A',
            $user->company->extra['company_address'] ?? 'N/A',
            $user->subscriptionDetails->subscription_id ?? 'N/A',
            $user->subscriptionDetails->time ?? 'N/A',
            $user->subscriptionDetails->start_date ?? 'N/A',
            $user->subscriptionDetails->end_date ?? 'N/A',
        ];
    }

    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Email',
            'Phone',
            'Status',
            'Company Name',
            'Company Slug',
            'Company Email',
            'Gst No',
            'Company Logo',
            'Profile Picture',
            'Company Address',
            'Subscription ID',
            'Time',
            'Start Date',
            'End Date',
        ];
    }
}
