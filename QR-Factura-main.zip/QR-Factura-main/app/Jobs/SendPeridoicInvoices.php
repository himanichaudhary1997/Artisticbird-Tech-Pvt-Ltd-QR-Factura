<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Invoice;
use App\Models\User;    
use App\Models\Company;
use App\Models\Clients;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use App\Models\Templates;
use PDF;
use App\Models\ActivityLog;

class SendPeridoicInvoices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */

    protected $comment;
    protected $selectedIds;
    protected $fiskaly;
    protected $invoiceService;
    
    public function __construct($comment, $selectedIds,$fiskaly,$invoiceService)
    {
        $this->comment = $comment;
        $this->selectedIds = $selectedIds;
        $this->fiskaly = $fiskaly;
        $this->invoiceService = $invoiceService;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $currentMonth = date('m');
        $currentYear = date('Y');

        $user = auth()->user();
        $company = $user->company;

        if (is_array($this->selectedIds)) {
            $selectedInvoices = array_filter($this->selectedIds); // Removes empty values
        } elseif (is_string($this->selectedIds)) {
            $selectedInvoices = array_filter(explode(',', $this->selectedIds)); // Safely explode and clean
        } else {
            $selectedInvoices = []; // Fallback
        }
        $adminUser = User::where('id', $company->admin_id)->first();
        // if($company && $company->is_verifactu){
        //     $invoices = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)->where('is_verified',1)
        //         ->whereMonth('issue_date', $currentMonth)
        //         ->whereYear('issue_date', $currentYear)
        //         ->when(!empty($selectedInvoices), function ($q) use ($selectedInvoices) {
        //             $q->whereIn('id', $selectedInvoices);
        //         })
        //         ->get();
        // }else{
            $invoices = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)
                    ->whereMonth('issue_date', $currentMonth)
                    ->whereYear('issue_date', $currentYear)
                    ->when(!empty($selectedInvoices), function ($q) use ($selectedInvoices) {
                        $q->whereIn('id', $selectedInvoices);
                    })
                    ->get();
        // }

        

        $totalSentInvoices = 0;
        foreach ($invoices as $invoice) {
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }
            // if($company && !$company->is_verifactu && $company->extra['country_code'] == 'ES'){
            //     $invoice->generateInvoiceQrCode();
            // }
            
            if (empty($invoice->qr_code)) {
                try {
                    if ($company->is_verifactu && !$invoice->is_verified) {
                        // $this->fiskaly->createInvoice($company, $invoice);

                        // ActivityLog::create([
                        //     'user_id' => $authUser->id,
                        //     'company_id' => $company->id ?? null,
                        //     'action' => 'Verified Invoice ' . $invoice->invoice_id,
                        //     'ip_address' => null, // can't use $request in job
                        // ]);

                        $response = $this->fiskaly->createInvoice($company, $invoice);
                
                        $error = $this->invoiceService->handleVerifactuError($response, $invoice, false);
                        

                        $this->invoiceService->saveQrAndVerificationData(
                            $response,
                            $company,
                            $invoice, $invoice->invoice_id
                        );
                    } else {
                        $invoice->generateInvoiceQrCode();
                    }
                } catch (\Exception $e) {
                    \Log::error("Fiskaly invoice failed", [
                        'invoice_id' => $invoice->invoice_id,
                        'company_id' => $company->id,
                        'error' => $e->getMessage()
                    ]);
                }
            }
            $invoice->refresh();
            // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
            $templateId = getTemplateId(!empty($company) ? $company : $user);
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);


            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $invoice->client->name ?? null,
                'comment'=>$this->comment ?? null,
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

            // Get the base URL dynamically
            $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );

            // Generate PDF from the modified HTML
            $pdfContent = PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $altEmails = $invoice->client->extra['alternative_email'] ?? null;
            }else{
                $clientCompany = Company::where('admin_id',$invoice->client->id)->first();
                $altEmails = $clientCompany->extra['alternative_email'] ?? null;
            }

            if (is_string($altEmails)) {
                $emails = array_filter(array_map('trim', explode(',', $altEmails)));
            } elseif (is_array($altEmails)) {
                $emails = array_filter(array_map('trim', $altEmails));
            } else {
                $emails = [];
            }

            if (empty($emails)) {
                $emails = [$invoice->client->email];
            }


            
            $emails = array_unique(array_filter($emails));
            
            foreach ($emails as $email) {
                Mail::to($email)->send(new SystemEmail(
                    __('Please check your invoice'),
                    'emails.invoice-template',
                    $data,
                    $pdfContent,
                    "invoice-{$invoice->id}.pdf",
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'] 
                ));

            }

            // if (!empty($email)) {
            //     Mail::to($email)->send(new SystemEmail(
            //         __('Please check your invoice'),
            //         'emails.invoice-template',
            //         $data,
            //         $pdfContent,
            //         "invoice-{$invoice->id}.pdf",
            //         'info@artisticbird.com',
            //         $company->company_name ?? $user->extra['company_name'],
            //         null,
            //         $company->user->email ?? 'info@artisticbird.com',
            //         $company->company_name ?? $user->extra['company_name'] 
            //     ));
            // }

            if($invoice->status != Invoice::PAID_INVOICE && $invoice->status != Invoice::NEGATIVE_INVOICE){
                $invoice->status = Invoice::SEND_INVOICE; //2 represents 'sent'
            }

            $invoice->save();
            $totalSentInvoices++;

            
        }
        $subject = "Peridoic Invoices Sent";
        $view = 'emails.invoices-sent'; // View file path without .blade.php
        $data = [
            'name' => $adminUser->name,
            'email' => $adminUser->email,
            'totalSentInvoices' => $totalSentInvoices,
        ];

        Mail::to($adminUser->email)->send(new SystemEmail($subject, $view, $data));
    }
}
