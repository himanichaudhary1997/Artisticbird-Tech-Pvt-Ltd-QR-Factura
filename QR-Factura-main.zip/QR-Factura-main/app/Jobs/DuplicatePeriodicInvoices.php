<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Log;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Invoice;
use App\Models\User;    
use App\Models\Company;
use App\Models\Clients;

use App\Models\Services;
use App\Models\Inventory;
use App\Mail\SystemEmail;

use App\Services\InvoiceService;

use Illuminate\Support\Facades\Mail;

class DuplicatePeriodicInvoices implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */

    protected $userId;
    protected $issueDate;
    protected $dueDate;
    protected $selectedIds;

    public function __construct($userId, $issueDate, $dueDate, $selectedIds)
    {
        $this->userId = $userId;
        $this->issueDate = $issueDate;
        $this->dueDate = $dueDate;
        $this->selectedIds = $selectedIds;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $user = User::find($this->userId);
        $role = $user->roles->pluck('id')->first();

        $company = $user->company;
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();
        }

        if($company){
            $adminUser = User::where('id', $company->admin_id)->first();
        }else{
            $adminUser = User::where('id', $user->id)->first();
        }
        $companyname = $company->company_name ?? $user->extra['company_name'] ?? null;

        $issueDate = $this->issueDate;
        $dueDate = $this->dueDate;
        $currentYear = date('Y', strtotime($issueDate));
        $currentMonth = date('m', strtotime($issueDate));
        $companyInitials = strtoupper(substr($companyname, 0, 2));

        $previousDate = now()->subMonthNoOverflow();
        $previousMonth = $previousDate->month;
        $previousYear = $previousDate->year;
        if (is_array($this->selectedIds)) {
            $selectedInvoices = array_filter($this->selectedIds); // Removes empty values
        } elseif (is_string($this->selectedIds)) {
            $selectedInvoices = array_filter(explode(',', $this->selectedIds)); // Safely explode and clean
        } else {
            $selectedInvoices = []; // Fallback
        }

        if ($selectedInvoices == null) {
            $selectedInvoices = [];
        }

        if($company && $company->is_verifactu){
            $query = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)->where('is_verified',1)
                ->whereMonth('issue_date', $previousMonth)
                ->whereYear('issue_date', $previousYear)
                ->where('status', '!=', Invoice::NEGATIVE_INVOICE)
                ->when(!empty($selectedInvoices), function ($q) use ($selectedInvoices) {
                    $q->whereIn('id', $selectedInvoices);
                });
        }else{
            $query = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)
                ->whereMonth('issue_date', $previousMonth)
                ->whereYear('issue_date', $previousYear)
                ->where('status', '!=', Invoice::NEGATIVE_INVOICE)
                ->when(!empty($selectedInvoices), function ($q) use ($selectedInvoices) {
                    $q->whereIn('id', $selectedInvoices);
                });

        }

        // if ($role != 1 && $role != 2) {
        //     $query->where('created_by', $user->id);
        // } 
        \Log::info('Found invoices', ['count' => $query->count(),'selectedInvoices' => $selectedInvoices, 'invoice_type' => Invoice::INVOICE_TYPE_PERIODIC]);
        // dd('test');
        $invoices = $query->get();
        $totalDuplicatedInvoice = 0;
        foreach ($invoices as $invoice) {
            $alreadyExists = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)
                ->where('reference_id', $invoice->id)
                ->whereMonth('issue_date', $currentMonth)
                ->whereYear('issue_date', $currentYear)
                ->exists();

            if ($alreadyExists) continue;

            // $parts = explode('/', $invoice->invoice_id);
            // $previousInitials = $parts[1] ?? $companyInitials;
            // preg_match('/(\d+)$/', $parts[2] ?? '0000', $matches);
            // $lastNumber = isset($matches[1]) ? (int) $matches[1] : 0;

            // $nextNumber = $lastNumber + 1;
            do {
                // $newId = $currentYear . '/' . $previousInitials . '/' . str_pad($nextNumber++, 4, '0', STR_PAD_LEFT);

                $invoiceService = new InvoiceService();
                $newId = $invoiceService->generateInvoiceId($issueDate, $company, 'invoice');
                // \Log::info('Found invoices', ['newId' =>$newId]);
                // dd('test');


            } while (Invoice::where('invoice_id', $newId)->exists());

            // $items = json_decode($invoice->items, true);
            $calculated = $this->recalculate($invoice);
            // dd('test');
            // $newInvoice = $invoice->replicate();
            // $newInvoice->invoice_id = $newId;
            // $newInvoice->issue_date = $issueDate;
            // $newInvoice->due_date = $dueDate;
            // $newInvoice->status = 0;
            // $newInvoice->reference_id = $invoice->id;
            // $newInvoice->created_by = $user->id;
            // $newInvoice->save();

            $newInvoice = $invoice->replicate();
            $newInvoice->invoice_id = $newId;
            $newInvoice->issue_date = $issueDate;
            $newInvoice->due_date = $dueDate;
            $newInvoice->status = 0;
            $newInvoice->reference_id = $invoice->id;
            $newInvoice->created_by = $user->id;

            $newInvoice->items = $calculated['items'];
            $newInvoice->subtotal = $calculated['totals']['subtotal'];
            $newInvoice->totalDiscount = $calculated['totals']['totalDiscount'];
            $newInvoice->totalTax = $calculated['totals']['totalTax'];
            $newInvoice->extraTax = $calculated['totals']['extraTax'];
            $newInvoice->grandTotal = $calculated['totals']['grandTotal'];

            $newInvoice->save();

            // Log::info('Decoded invoice items', [
            //     'invoice_id' => $invoice->id,
            //     'items' => $invoice->items,
            //     'items_array' => $calculated['items'],
            // ]);

            // dd('test');

            $totalDuplicatedInvoice++;
        }

        $subject = "Peridoic Invoices Duplicated";
        $view = 'emails.periodic-invoices'; // View file path without .blade.php
        $data = [
            'name' => $adminUser->name,
            'email' => $adminUser->email,
            'totalDuplicatedInvoice' => $totalDuplicatedInvoice,
        ];

        Mail::to($adminUser->email)->send(new SystemEmail($subject, $view, $data));
    }

    public static function recalculate(Invoice $invoice): array
    {
        $subtotal = 0;
        $totalDiscount = 0;
        $totalTax = 0;
        $extraTax = 0;

        $items = $invoice->items;
        $extra = $invoice->extra;

        // Log::info('Decoded invoice items', [
        //     'invoice_id' => $invoice->id,
        //     'items' => $items,
        //     'extra' => $extra,
        // ]);

        foreach ($items as &$item) {

            // 1️⃣ Fetch latest price
            $price = self::getLatestPrice($item, $extra);

            // if($invoice->id=='8898'){
            //     Log::info('Decoded invoice price', [
            //             'price' => $price,
            //         ]);
            // }

            if ($price === null) {
                continue;
            }

            // 2️⃣ Normalize values
            $quantity = self::toFloat($item['quantity'] ?? 1);
            $discount = self::toFloat($item['discount'] ?? 0);
            $taxRate = self::toFloat($item['tax'] ?? 0);
            $additionalTax = self::toFloat($item['additionaltaxvalue'] ?? 0);

            // 3️⃣ Calculations
            $lineSubtotal = $price * $quantity;
            $lineAfterDiscount = $lineSubtotal - $discount;
            $taxAmount = ($lineAfterDiscount * $taxRate) / 100;
            $lineTotal = $lineAfterDiscount + $taxAmount + $additionalTax;

            // 4️⃣ Update item
            $item['price'] = self::format($price);
            $item['amount'] = self::format($lineTotal);

            // 5️⃣ Accumulate totals
            $subtotal += $lineSubtotal;
            $totalDiscount += $discount;
            $totalTax += $taxAmount;
            $extraTax += $additionalTax;
        }

        $grandTotal = $subtotal - $totalDiscount + $totalTax + $extraTax;

        // if($invoice->id=='8898'){
        //     Log::info('Decoded invoice items', [
        //             'invoice_id' => $invoice->id,
        //             'grandTotal' => $grandTotal,
        //             'subtotal' => $subtotal,
        //             'totalDiscount' => $totalDiscount,
        //             'totalTax' => $totalTax,
        //             'extraTax' => $extraTax,
        //         ]);
        // }

        return [
            'items' => $items,
            'totals' => [
                'subtotal' => self::format($subtotal),
                'totalDiscount' => self::format($totalDiscount),
                'totalTax' => self::format($totalTax),
                'extraTax' => self::format($extraTax),
                'grandTotal' => self::format($grandTotal),
            ]
        ];
    }

    private static function getLatestPrice(array $item, array $extra): ?float
    {
        // Log::info('Decoded invoice items', [
        //     'item'  => $item,
        //     'extra' => $extra,
        // ]);

        $price = null;
        switch ($item['item_type'] ?? $extra['item_type'] ?? null) {

            case 'inventory':
            case 'product':
                $price =  !empty($item['item_id'])
                    ? Inventory::find($item['item_id'])?->price
                    : Inventory::where('name', $item['name'])->value('price');
                break;

            case 'service':
                $price =  !empty($item['item_id'])
                    ? Services::find($item['item_id'])?->price
                    : Services::where('name', $item['name'])->value('price'); 
                break;
        }

        if ($price === null) {
            return null;
        }

        // Log::info('Decoded invoice price', [
        //             'priceOLD' =>$price,
        //             'priceNew' => normalizePrice($price, 2, 'EN'),
        //         ]);
        return normalizePrice($price, 2, 'EN');
        // return $price;
    }



    private static function toFloat($value): float
    {
        return (float) str_replace(',', '.', $value);
    }

    private static function format(float $value): string
    {
        return number_format($value, 2, '.', '');
    }
}
