<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\User;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;

class SubscriptionReminderJob  implements ShouldQueue
{
    
    use Queueable, Dispatchable, SerializesModels;

    protected $userIds;

    /**
     * Create a new job instance.
     *
     * @param array|int|null $userIds
     */
    public function __construct($userIds = null)
    {
        $this->userIds = $userIds;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // Determine the users to process
        $query = User::query();

        if ($this->userIds) {
            $query->whereIn('id', (array) $this->userIds);
        }

        $users = $query->with('subscriptionDetails') // Assuming `subscription` is a relationship on User
            ->get();

        $today = Carbon::today();
        $fiveDaysLater = $today->copy()->addDays(5);
        $tenDaysLater = $today->copy()->addDays(10);
        foreach ($users as $user) {
            $subscription = $user->subscriptionDetails; // Adjust based on your DB structure

            if ($subscription && $subscription->end_date) {
                $endDate = Carbon::parse($subscription->end_date);
        
                if ($endDate->isFuture()) {
                    // Check if the subscription ends in exactly 10 days
                    if ($endDate->diffInDays($today) === 10) {
                        $this->sendReminderEmail($user);
                    }
        
                    // Send daily reminder if the subscription expires within the next 10 days
                    if ($endDate->diffInDays($today) <= 10) {
                        $this->sendReminderEmail($user);
                    }
                }
            }
        }
    }

    public function sendReminderEmail(User $user){
        $subject = "Your subscription plan is expiring soon";
        $view = 'emails.subscription-reminder'; // Path to the email view
        $data = [
            'name' => $user->name,
            'end_date' => date('j M, Y', strtotime($user->subscriptionDetails->end_date))
        ];

        Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));
    }
}
