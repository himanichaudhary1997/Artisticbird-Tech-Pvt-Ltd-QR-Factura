<?php

namespace App\Jobs;

use App\Services\PrestashopInvoicePdf;
use App\Models\Invoice;
use App\Mail\SystemEmail;
use App\Models\Clients;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Mail;
use App\Models\Templates;
use PDF;
use App\Models\Services;
use GuzzleHttp\Client;
use App\Models\User;

class SendBulkInvoiceEmailsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $invoices;
    protected $user;
    protected $company;
    protected $comment;

    public function __construct($invoices, $user, $company, $comment)
    {
        $this->invoices = $invoices;
        $this->user = $user;
        $this->company = $company;
        $this->comment = $comment;
    }

    public function handle()
    {
        $emailsSent = 0;
        // dd($this->invoices);
        foreach ($this->invoices as $invoice) {
            // if ($emailsSent >= 1) {
            //     break;
            // }
            
            // Logic to process each email
            if (!isset($invoice->extra['template_id']) || empty($invoice->extra['template_id'])) {
                continue;
            }

            $template = Templates::find($invoice->extra['template_id']);
            if (!$template) {
                continue;
            }
            $role = $this->user->roles->first();
            $authUserCompany = $this->user->company($this->user,$role);
            if ($authUserCompany instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $authUserCompany = $authUserCompany->first();
            }

            if(empty($company)){
                $client = User::where('id',$invoice->client_id)->first();
            }else{
                $client = Clients::where('id',$invoice->client_id)->first();
            }
            $data = [
                // 'invoice_name' => $invoice->name,
                'invoice_no'=>$invoice->invoice_id,
                'currency' => $invoice->currency,
                'issue_date' => date('j M, Y', strtotime($invoice->issue_date)),
                'due_date' => date('j M, Y', strtotime($invoice->due_date)),
                'ref_no' => $invoice->ref_no,
                'items' => $invoice->items,
                'subtotal' => $invoice->extra['subtotal'] ?? null,
                'totalDiscount' => $invoice->extra['totalDiscount'] ?? null,
                'totalTax' => $invoice->extra['totalTax'] ?? null,
                'grandTotal' => $invoice->extra['grandTotal'] ?? null,
                'customer_name'=>$client->name ?? null,
                'customer_email'=>$client->email ?? null ,
                'customer_mobile_no'=>$client->phone ?? null ,
                'customer_gst_no'=>$client->company->gst_no ?? null ,
                'customer_address'=>$client->extra['address'] ?? $client->company->extra['company_address'] ?? null ,
                'payment_method' => $invoice->paymentMethod->name ?? null,
                'invoice_type' => $invoice->invoiceType->name ?? null,
                'company_id' => $this->company->id ?? null,
                'user_name' => $this->user->name ?? null,
                'user_email' => $this->user->email ?? null,
                'user_mobile' => $this->user->phone ?? null,
                'user_company_name' => $this->company->company_name ?? $this->user->extra['company_name'] ?? null,
                'user_company_email' => $this->company->company_email ?? $this->user->email,
                'user_company_gst_no' => $this->company->gst_no ?? $this->user->extra['gst_no'] ?? null,
                'user_company_address' => $this->company->extra['company_address'] ?? $this->user->extra['company_address'] ?? null,
                'user_company_logo' => isset($this->company->extra['company_logo'])
                ? (filter_var($this->company->extra['company_logo'], FILTER_VALIDATE_URL) 
                    ? str_replace(asset('storage') . '/', public_path('storage/') . '/', $this->company->extra['company_logo']) // Convert URL to filesystem path
                    : public_path('storage/' . $this->company->extra['company_logo'])) // Convert relative path to filesystem path
                : (isset($this->user->extra['company_logo']) 
                    ? (filter_var($this->user->extra['company_logo'], FILTER_VALIDATE_URL) 
                        ? str_replace(asset('storage') . '/', public_path('storage/') . '/', $this->user->extra['company_logo']) // Convert URL to filesystem path
                        : public_path('storage/' . $this->user->extra['company_logo'])) // Convert relative path to filesystem path
                    : null),
                'services'=>Services::all()->toArray(),
                'comment'=>$comment ?? null
            ];

            $templateHtml = app()->make('App\Http\Controllers\InvoiceController')->renderTemplate($template->template_html, $data);
            // The shop's own PDF for PrestaShop invoices
            $pdfContent = PrestashopInvoicePdf::pdfFor($invoice, $this->company) ?? PDF::loadHTML($templateHtml)->output();

            $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

            // Get the base URL dynamically
            $baseUrl = asset('storage'); // Example: "https://phplaravel-1438367-5377924.cloudwaysapps.com/storage"
            // dd($baseUrl);
            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            // Replace local storage paths with absolute URLs
            $data['templateHtml'] = preg_replace_callback(
                '#' . preg_quote($storagePath, '#') . '([^"\s]+)#',
                function ($matches) use ($baseUrl) {
                    return $baseUrl . ltrim($matches[1], '/');
                },
                $templateHtml
            );

            $data['templateHtml'] = PrestashopInvoicePdf::emailHtml($invoice, $this->company)
                ?? preg_replace('/\s+/', ' ', $data['templateHtml']);

            if (!empty($client->email)) {
                Mail::to($client->email)->send(new SystemEmail(
                    __('Please check your invoice'),
                    'emails.invoice-template',
                    $data,
                    $pdfContent,
                    "invoice-{$invoice->id}.pdf",
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'] 
                ));
            }

            // Update invoice status to "Sent"
            $invoice->status = 2; // Assuming '2' means 'sent'
            $invoice->save();

            // $emailsSent++;
        }
    }
}
