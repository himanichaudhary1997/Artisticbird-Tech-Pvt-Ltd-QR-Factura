<?php

namespace App\Jobs;

use App\Services\PrestashopInvoicePdf;
use App\Models\Invoice;
use App\Models\Templates;
use App\Models\User;
use App\Models\Company;
use App\Models\BulkDownload;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Foundation\Bus\Dispatchable;
use iio\libmergepdf\Merger;
use DOMDocument;
use DOMXPath;

class GenerateBulkInvoicesPdfJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 600; // bump supervisor timeout for this queue accordingly

    protected array $invoiceIds;
    protected int $userId;
    protected int $bulkDownloadId;
    protected ?int $companyId;

    public function __construct(array $invoiceIds, int $userId, int $bulkDownloadId, ?int $companyId)
    {
        $this->invoiceIds = $invoiceIds;
        $this->userId = $userId;
        $this->bulkDownloadId = $bulkDownloadId;
        $this->companyId = $companyId;
    }

    public function handle()
    {
        $record = BulkDownload::find($this->bulkDownloadId);
        $tempFiles = [];
        $tmpDir = null;

        try {
            $user = User::findOrFail($this->userId);
            $company = $this->companyId ? Company::find($this->companyId) : null;

            $templateId = getTemplateId($company ?? $user);
            $template = Templates::find($templateId);
            if (!$template) {
                throw new \RuntimeException('Invoice template missing');
            }

            $storagePath = rtrim(public_path('storage/'), '/') . '/';
            $baseUrl = rtrim(asset('storage'), '/') . '/';

            $tmpDir = storage_path('app/tmp/bulk-' . $this->bulkDownloadId);
            if (!is_dir($tmpDir)) {
                mkdir($tmpDir, 0755, true);
            }

            $invoiceModel = new Invoice();
            if ($this->companyId) {
                $invoiceModel->setDynamicTableName($this->companyId);
            }

            // Process in chunks so we never hold more than N invoices' HTML in memory at once
            $chunks = array_chunk($this->invoiceIds, 25);
            $page = 0;

            foreach ($chunks as $chunk) {
                $invoices = (clone $invoiceModel)->whereIn('id', $chunk)->get();

                foreach ($invoices as $invoice) {
                    $negatives = (clone $invoiceModel)
                        ->where('ref_invoice_number', $invoice->invoice_id)
                        ->get();

                    $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
                    $datahtml = preg_replace_callback(
                        '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                        fn ($m) => $storagePath . ltrim($m[1], '/'),
                        $datahtml
                    );

                    $negativeBodies = [];
                    foreach ($negatives as $negative) {
                        $negHtml = parseInvoiceSortcodes($template->template_html, $negative, $company);
                        $negHtml = preg_replace_callback(
                            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                            fn ($m) => $storagePath . ltrim($m[1], '/'),
                            $negHtml
                        );
                        $sections = $this->extractTables($negHtml, ['header', 'footer', 'body']);
                        if (!empty($sections['body'])) {
                            $negativeBodies[] = ['invoice' => $negative, 'body' => $sections['body']];
                        }
                    }

                    $privacyText = (($invoice['extra']['privacy'] ?? null) === 'on')
                        ? ($company->privacy ?? null)
                        : null;

                    $file = $tmpDir . '/' . (++$page) . '.pdf';

                    // The shop's own PDF, when the PrestaShop module has uploaded it
                    $storedPdf = PrestashopInvoicePdf::storedPdfWith($invoice, $negativeBodies, $privacyText);
                    if ($storedPdf !== null) {
                        file_put_contents($file, $storedPdf);
                        $tempFiles[] = $file;
                        unset($storedPdf, $datahtml);
                        continue;
                    }

                    if (PrestashopInvoicePdf::supports($invoice)) {
                        $html = PrestashopInvoicePdf::html($invoice, $company, $negativeBodies, $privacyText);
                    } else {
                        $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
                        $html = view('pdf.invoice', compact('invoiceData', 'negativeBodies', 'privacyText'))->render();
                    }
                    $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

                    // One invoice per single-invoice PDF file — small, bounded memory
                    $pdf = Pdf::loadHTML('<style>@page{margin:20px;}</style>' . $html)->setPaper('a4', 'portrait');
                    file_put_contents($file, $pdf->output());
                    $tempFiles[] = $file;

                    unset($pdf, $html, $datahtml, $invoiceData);
                }

                unset($invoices);
                gc_collect_cycles();
            }

            if (empty($tempFiles)) {
                throw new \RuntimeException('No invoice PDFs were generated');
            }

            $merger = new Merger();
            foreach ($tempFiles as $file) {
                $merger->addFile($file);
            }

            $finalRelativePath = 'bulk-downloads-pdf/invoices-' . $this->bulkDownloadId . '.pdf';
            Storage::disk('public')->put($finalRelativePath, $merger->merge());

            $record->update(['status' => 'ready', 'file_path' => $finalRelativePath]);

            Log::info('Bulk invoice PDF ready', [
                'bulk_download_id' => $this->bulkDownloadId,
                'company_id' => $this->companyId,
                'count' => count($this->invoiceIds),
            ]);
        } catch (\Throwable $e) {
            Log::error('Bulk Invoice PDF Job Failed', [
                'error' => $e->getMessage(),
                'bulk_download_id' => $this->bulkDownloadId,
                'company_id' => $this->companyId,
                'trace' => $e->getTraceAsString(),
            ]);
            $record?->update(['status' => 'failed', 'error' => $e->getMessage()]);
            $this->fail($e);
        } finally {
            foreach ($tempFiles as $file) {
                @unlink($file);
            }
            if ($tmpDir && is_dir($tmpDir)) {
                @rmdir($tmpDir);
            }
        }
    }

    public function extractTables(string $html, array $ids): array
    {
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);
        $html = '<?xml version="1.0" encoding="UTF-8"?>' . $html;
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $results = [];

        foreach ($ids as $id) {
            $node = $xpath->query("//*[@id='{$id}']")->item(0);
            if ($node) {
                $results[$id] = $dom->saveHTML($node);
                $node->parentNode->removeChild($node);
            } else {
                $results[$id] = '';
            }
        }

        $results['body'] = $results['body'] ?: $dom->saveHTML();
        return $results;
    }
}