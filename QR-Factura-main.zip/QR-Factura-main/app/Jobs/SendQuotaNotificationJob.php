<?php

namespace App\Jobs;

use App\Mail\AdminQuotaNotificationMail;
use App\Mail\UserQuotaNotificationMail;
use App\Models\Company;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use App\Mail\MailContext;

class SendQuotaNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        public Company $company,
        public string $type,
        public int $used,
        public int $limit,
        public int $percent
    ) {
    }

    public function handle(): void
    {
        $data = [
            'company_name' => $this->company->company_name,
            'company_email' => $this->company->user?->email,
            'type' => ucfirst($this->type),
            'used' => $this->used,
            'limit' => $this->limit,
            'remaining' => max(0, $this->limit - $this->used),
            'percent' => $this->percent,
        ];

        $data['ownerAdmin'] = User::find(1);
        MailContext::useAdminBranding();
        if (!empty($this->company->user?->email)) {
            Mail::to([$this->company->user?->email,'emilio@entraenlared.com','aurelio@entraenlared.com','info@artisticbird.com'])
                ->queue(new UserQuotaNotificationMail($data));
        }

        Mail::to(['emilio@entraenlared.com','aurelio@entraenlared.com','info@artisticbird.com'])
            ->queue(new AdminQuotaNotificationMail($data));
        MailContext::resetBranding();
    }
}