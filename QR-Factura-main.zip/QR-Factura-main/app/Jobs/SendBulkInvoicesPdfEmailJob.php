<?php

namespace App\Jobs;

use App\Services\PrestashopInvoicePdf;
use App\Models\Invoice;
use App\Models\Templates;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Mail\BulkInvoicesEmail;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;

use DOMDocument;
use DOMXPath;

class SendBulkInvoicesPdfEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $invoiceIds;
    protected $userId;

    public function __construct(array $invoiceIds, int $userId)
    {
        $this->invoiceIds = $invoiceIds;
        $this->userId = $userId;
    }

    public function handle()
    {
        try {
            $user = User::findOrFail($this->userId);
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            $adminUser = $company ? User::find($company->admin_id) : User::find(1);
            $allInvoicesHtml = '<style>@page { margin: 20px; }</style>';
            $firstInvoice = true;

            Log::info("✅ Download invoice is intitiated!", [
                'total_invoices' => count($this->invoiceIds)
            ]);

            $totalInvoices = 0;
            foreach ($this->invoiceIds as $invoiceId) {
                // $invoice = Invoice::where('id', $invoiceId)->first();
                $invoice = Invoice::find($invoiceId);
                if (!$invoice) {
                    Log::warning("Invoice not found", ['invoice_id' => $invoiceId]);
                    continue;
                }
                $negatives = Invoice::where('ref_invoice_number', $invoice->invoice_id)->get();


                // $templateId = $company->extra['favouraite_template'] ?? $adminUser->extra['favouraite_template'] ?? Templates::where('status', 1)->value('id');
                // $template = Templates::find($templateId) ?? Templates::where('status', 1)->first();
                // $templateId =
                //         data_get($company, 'extra.favouraite_template')
                //         ?? data_get($adminUser, 'extra.favouraite_template')
                //         ?? Templates::where('status', 1)->value('id');

                $templateId = getTemplateId(!empty($company) ? $company : $adminUser);

                $template = Templates::find($templateId);

                    if (!$template) {
                        Log::error('Invoice template missing');
                        continue;
                    }

                $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
                $storagePath = public_path('storage/');
                $baseUrl = asset('storage');

                $storagePath = rtrim($storagePath, '/') . '/';
                $baseUrl = rtrim($baseUrl, '/') . '/';

                $datahtml = preg_replace_callback(
                    '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                    function ($matches) use ($storagePath) {
                        return $storagePath . ltrim($matches[1], '/');
                    },
                    $datahtml
                );

                // $datahtml = mb_convert_encoding($datahtml, 'UTF-8', 'auto');

                // $html = '<div>' . $datahtml . '</div>';
                // if (!$firstInvoice) {
                //     $html = '<div style="page-break-before: always;">' . $datahtml . '</div>';
                // }

                //////////Anurag Updates/////////


                $negativeBodies = [];
                if ($negatives && $negatives->count()) {
                    foreach ($negatives as $negative) {

                        $negHtml = parseInvoiceSortcodes(
                            $template->template_html,
                            $negative,
                            $company
                        );

                        $negHtml = preg_replace_callback(
                            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                            fn ($m) => $storagePath . ltrim($m[1], '/'),
                            $negHtml
                        );

                        $sections = $this->extractTables($negHtml, ['header', 'footer', 'body']);

                        if (!empty($sections['body'])) {
                            $negativeBodies[] = [
                                'invoice' => $negative,
                                'body'    => $sections['body'],
                            ];
                        }
                    }
                }
                $privacyChecked = $invoice['extra']['privacy'] ?? null;

                $privacyText = $privacyChecked === 'on'
                    ? ($company->privacy ?? null)
                    : null;

                
                if (PrestashopInvoicePdf::supports($invoice)) {
                    $html = PrestashopInvoicePdf::html($invoice, $company, $negativeBodies, $privacyText);
                } else {
                    $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
                    $html = view('pdf.invoice', compact('invoiceData', 'negativeBodies', 'privacyText'))->render();
                }
                $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');
                //////////Anurag Updates/////////


                $allInvoicesHtml .= '<div style="page-break-after: always;">' . $html . '</div>';
                // $allInvoicesHtml .= $html;
                // $firstInvoice = false;
                $totalInvoices++;
            }


            // Generate PDF content in memory
            $pdf = Pdf::loadHTML($allInvoicesHtml)->setPaper('a4', 'portrait');
            $pdfContent = $pdf->output(); // This gets raw binary content

            $subject = 'Bulk Invoices Download';
            $view = 'emails.bulk_invoice'; // Replace with your actual Markdown view
            $data = [
                'name' => $adminUser->name,
                'email' => $adminUser->email,
                'totalInvoices' => $totalInvoices,
            ];

            // $emails = [
            //     // $adminUser->email,
            //     'anurag@entraenlared.com',
            //     // 'emilio@entraenlared.com',
            // ];
            $emails = [
                $adminUser->email,
                // 'anruag@entraenlared.com',
                // 'emilio@entraenlared.com',
            ];
            Mail::to($emails)->send(new SystemEmail(
                $subject,
                $view,
                $data,
                $pdfContent,
                'bulk-invoices.pdf',
                'info@artisticbird.com',
                $company->company_name ?? $user->extra['company_name']
            ));
            // Mail::to($adminUser->email)->send(new SystemEmail(
            //     $subject,
            //     $view,
            //     $data,
            //     $pdfContent,
            //     'bulk-invoices.pdf',
            //     'info@artisticbird.com',
            //     'anurag@entraenlared.com'
            // ));

            Log::info("✅ Job Completed Successfully", [
                'sent_to' => $emails,
                // 'sent_to' => $adminUser->email,
                'total_invoices' => $totalInvoices
            ]);
      
        } catch (\Throwable $e) {

            // Log error
            Log::error("Bulk Invoice Job Failed", [
                'error' => $e->getMessage(),
                'invoice_ids' => $this->invoiceIds,
                'user_id' => $this->userId,
                'trace' => $e->getTraceAsString(),
            ]);

            // Send email to you or admin
            Mail::to('anurag@entraenlared.com')->send(
                new SystemEmail(
                    '❌ Bulk Invoice Job Failed',
                    'emails.system_error',
                    [
                        'title' => 'Bulk Invoices Job Failed',
                        'message' => $e->getMessage(),
                        'invoice_ids' => implode(', ', $this->invoiceIds),
                        'user_id' => $this->userId,
                        'stack' => $e->getTraceAsString(),
                    ],
                    null,
                    null,
                    'info@artisticbird.com',
                    'Error Monitoring'
                )
            );

            // Mark job as failed but prevent infinite retry loops
            $this->fail($e);
        }
    }


    public function extractTables(string $html, array $ids): array
    {
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);

        // Force UTF-8 encoding
        $html = '<?xml version="1.0" encoding="UTF-8"?>' . $html;
        
        // $dom = new DOMDocument();
        // libxml_use_internal_errors(true);
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $results = [];

        foreach ($ids as $id) {
            $node = $xpath->query("//*[@id='{$id}']")->item(0);
            if ($node) {
                $results[$id] = $dom->saveHTML($node);
                // Remove this node from DOM so it won’t appear in body
                $node->parentNode->removeChild($node);
            } else {
                $results[$id] = '';
            }
        }

        // Whatever remains is the clean "body" (without header/footer)
        $cleanBody = $dom->saveHTML();
        $results['body'] = $results['body'] ?: $cleanBody;

        return $results;
    }
}

