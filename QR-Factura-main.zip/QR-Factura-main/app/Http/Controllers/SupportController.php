<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Issues;
use App\Models\Messages;    
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use App\Models\Company;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Events\NewMessage;
use App\Mail\SystemEmail;
use App\Mail\SendTicketEmails;
use Illuminate\Support\Facades\Mail;

class SupportController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index(Request $request){

        // $allUserPermissions = auth()->user()->getAllUserPermissions();
        // if(!isset($allUserPermissions['support'])){
        //     return redirect(route('access.denied'));
        // }
        // $user = Auth::user();
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Issues::query();
            if($company){
                $query->where('company_id',$company->id);
            }
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('title', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            if (isset($formdata['scope']) && !is_null($formdata['scope'])) {
                $query->where('company_id', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $issues = $query->orderBy('id','DESC')->with('company')->paginate($limit);
            $companies = Company::all();

            if($request->ajax())
            {
                 return view('panel.supports.partial-support',compact('issues'));
            }
            return view('panel.supports.index',compact('companies','issues'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }

    }


    public function getIssues(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Issues::query();
            if($company){
                $query->where('company_id',$company->id);
            }
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('title', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            if (isset($formdata['scope']) && !is_null($formdata['scope'])) {
                $query->where('company_id', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $issues = $query->orderBy('id','DESC')->with('company')->paginate($limit);

            

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Issues retrieved successfully.',
                'data' => $issues,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Issues.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function getMessages(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Messages::where('issue_id', $formdata['issue_id']);

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('message', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Fetch paginated results with related data
            $messages = $query->orderBy('id','DESC')->paginate($limit);

            $messages->getCollection()->transform(function ($message) use ($user) {
                if (!empty($message->attachments)) {
                    $attachments = is_array($message->attachments) 
                        ? $message->attachments 
                        : json_decode($message->attachments, true);
    
                    $attachmentLinks = '';
                    foreach ($attachments as $index => $url) {
                        $attachmentLinks .= '<a target="_blank" href="' . $url . '">Attachment ' . ($index + 1);
                        if ($index !== array_key_last($attachments)) {
                            $attachmentLinks .= ',';
                        }
                        $attachmentLinks .= '</a> ';
                    }
                    
                    $message->attachment_links = $attachmentLinks;
                } else {
                    $message->attachment_links = 'No Attachments';
                }
                // dd($user->company);

                $message->showAction = $user->id == $message->user_id ? false : true;
                if($message->user_id != null){
                   
                    $message->user = User::find($message->user_id);
                }else{
                    $message->user = User::find(1);
                }
                
                $message->by = $message->user_id == $user->id ? 'You' : 'By: ' . $message->user->name;

                $message->date = date('j M, Y h:i a', strtotime($message->created_at));
                $message->current_user = $user->id == $message->user->id ? true : false;
                return $message;
            });

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Messages retrieved successfully.',
                'data' => $messages,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Messages.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


     public function editIssue(Request $request, $id){
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Messages::where('issue_id',$id);

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('message', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Fetch paginated results with related data
            $messages = $query->orderBy('id','DESC')->paginate($limit);

            $messages->getCollection()->transform(function ($message) use ($user) {
                if (!empty($message->attachments)) {
                    $attachments = is_array($message->attachments) 
                        ? $message->attachments 
                        : json_decode($message->attachments, true);
    
                    $attachmentLinks = '';
                    foreach ($attachments as $index => $url) {
                        $attachmentLinks .= '<a target="_blank" href="' . $url . '" ">Attachment ' . ($index + 1);
                        if ($index !== array_key_last($attachments)) {
                            $attachmentLinks .= ',';
                        }
                        $attachmentLinks .= '</a> ';
                    }
                    
                    $message->attachment_links = $attachmentLinks;
                } else {
                    $message->attachment_links = 'No Attachments';
                }
                // dd($user->company);

                $message->showAction = $user->id == $message->user_id ? false : true;
                if($message->user_id != null){
                   
                    $message->user = User::find($message->user_id);
                }else{
                    $message->user = User::find(1);
                }
                
                $message->by = $message->user_id == $user->id ? 'You' : 'By: ' . $message->user->name;

                $message->date = date('j M, Y h:i a', strtotime($message->created_at));
                $message->current_user = $user->id == $message->user->id ? true : false;
                return $message;
            });

         
            $issue = Issues::find($id);
            // $messages = Messages::where('issue_id',$id)->get();
        
            if($request->ajax())
            {
                 return view('panel.supports.partial-edit',compact('messages','issue'));
            }
            return view('panel.supports.edit-issue',compact('issue','messages'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        
        // $issue = Issues::find($id);
        // $messages = Messages::where('issue_id',$id)->get();
        // return view('panel.supports.edit-issue',compact('issue','messages'));
    }

    public function allNotifications(){
    try{
        return view('panel.supports.all-notifications');
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function addIssue(){
    try{
        $companies = Company::all();
        return view('panel.supports.add-issue',compact('companies'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }


    public function createIssue(Request $request){
        try {
            // Extract form data
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // dd($formdata);  
            $issue_id = $formdata['id'] ?? null;
            $scope = $formdata['company_id'] ?? null;
            
            // dd($dynamicTableName);
            // Validation rules
            $rules = [
                'title' => 'required|string|max:255',
                'message'=>'required',
                'attachments'=>'sometimes',
            ];
            // Validate the input data  
            

            // $Issues = new Issues();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // dd($formdata);
            

            $issue_data = [
                'title'=> $formdata['title'],
                'company_id'=>$company->id ?? null,
                'status'=> 0,
            ];
            


            $issue = Issues::create($issue_data);

            if($issue){
                $message_data = [
                    'issue_id'=> $issue->id,
                    'user_id'=>$user->id ?? null,
                    'message'=> $formdata['message'],
                    'attachments' => !empty(array_filter($formdata['attachments'])) ? $formdata['attachments'] : null,
                ];

                $message = Messages::create($message_data);
            }

            $data = [
                'issue_id' => $issue->id,
                'title' => $issue->title,
                'message' => $message->message,
                'attachments' => $message->attachments,
                'company' => $company->name,
                'created_at' => date('j M, Y h:i a', strtotime($issue->created_at)),
                'user'=>$user 
            ];

            // Ensure that attachments are passed as an array of arrays with the correct structure
            $attachments = is_array($message->attachments) ? $message->attachments : [$message->attachments];
            // dd($attachments);
            // Prepare the array for attachments to pass to Mailable
            $formattedAttachments = [];
            foreach ($attachments as $index => $attachmentUrl) {
                if (strpos($attachmentUrl, 'storage') !== false) {
                    // Extract the relative path after 'storage/'
                    $relativePath = str_replace(asset('storage') . '/', '', $attachmentUrl);

                    // Convert to the local file path
                    $filePath = storage_path('app/public/' . $relativePath);

                    // Ensure the file exists before proceeding
                    if (file_exists($filePath)) {
                        $file = 'storage/' . $relativePath;
                        // dd($file);$relativePath = 'uploads/sample.jpg'; // Example relative path

                        // Check if the file exists before adding it
                        if (file_exists($file)) {
                            $formattedAttachments[] = $file;
                        } else {
                            Log::error("File not found: " . $file);
                        }

                    }
                }
            }

            $staffUsers = User::whereHas('roles', function ($query) {
                $query->where('name', 'Support'); // Filter by role ID 3
            })
            ->get();
            

            if(!$staffUsers->isEmpty()){
                foreach($staffUsers as $staff){
                    $adminEmails[]= $staff->email;
                }
            }

            $superAdminUser = User::where('id',1)->first();
            $data['currentUser'] = $superAdminUser;
            Mail::to($superAdminUser->email)->send(new SendTicketEmails(
                'Hi '.$superAdminUser->name.', there is a new issue', 
                'emails.issue-template', 
                $data, 
                $formattedAttachments
            ));

            foreach($staffUsers as $staff){
                $data['currentUser'] = $staff;
                Mail::to($staff->email)->send(new SendTicketEmails(
                    'Hi '.$staff->name.', there is a new issue', 
                    'emails.issue-template', 
                    $data, 
                    $formattedAttachments
                ));
            }


            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Issue updated successfully.') 
                    : __('Issue created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditIssue: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }


    public function addReply(Request $request){
        try {
            // Extract form data
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            $formdata = $request->all();
            $authCompany = $user->company;

            if ($authCompany instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $authCompany = $authCompany->first();
            }
            // dd($formdata);  
            $issue_id = $formdata['id'] ?? null;
            $scope = $formdata['company_id'] ?? null;
            
            // dd($dynamicTableName);
            // Validation rules
            $rules = [
                'issue_id' => 'required',
                'message'=>'required',
                'attachments'=>'sometimes',
            ];
            // Validate the input data  
            

            // $Issues = new Issues();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // dd($formdata);
            

            $message_data = [
                'issue_id'=> $formdata['issue_id'],
                'user_id'=>$user->id ?? null,
                'message'=> $formdata['message'],
                'attachments' => !empty(array_filter($formdata['attachments'])) ? $formdata['attachments'] : null,
            ];

            $message = Messages::create($message_data);
            $company = Company::find($message->issue->company_id);

            if(!empty($authCompany)){
                Issues::where('id',$formdata['issue_id'])->update(['status'=>0]);
            }else{
                Issues::where('id',$formdata['issue_id'])->update(['status'=>$formdata['status'] ?? 0]);
            }
            $data = [
                'issue_id' => $message->issue_id,
                'title' => $message->issue->title,
                'message' => $message->message,
                'attachments' => $message->attachments,
                'company' => $company ?? null,
                'created_at' => date('j M, Y h:i a', strtotime($message->created_at)),
                'user'=>$company->user ?? User::find(1)
            ];

            $attachments = is_array($message->attachments) ? $message->attachments : [$message->attachments];
            // dd($attachments);
            // Prepare the array for attachments to pass to Mailable
            $formattedAttachments = [];
            foreach ($attachments as $index => $attachmentUrl) {
                if (strpos($attachmentUrl, 'storage') !== false) {
                    // Extract the relative path after 'storage/'
                    $relativePath = str_replace(asset('storage') . '/', '', $attachmentUrl);

                    // Convert to the local file path
                    $filePath = storage_path('app/public/' . $relativePath);

                    // Ensure the file exists before proceeding
                    if (file_exists($filePath)) {
                        $file = 'storage/' . $relativePath;
                        // dd($file);$relativePath = 'uploads/sample.jpg'; // Example relative path

                        // Check if the file exists before adding it
                        if (file_exists($file)) {
                            $formattedAttachments[] = $file;
                        } else {
                            Log::error("File not found: " . $file);
                        }

                    }
                }
            }
            if(empty($authCompany)){
                $company = Company::find($message->issue->company_id);
                $email = $company->user->email;
                $data['currentUser']=$company->user;
                $subject = 'Hi '. $company->user->name .', there is reply on issue #issue'.$data['issue_id'];
                $view = 'emails.reply-user';
            }else{
                $adminUser = User::where('id',1)->first();
                $data['currentUser']=$adminUser;
                $email = $adminUser->email;
                $subject = 'Hi Super Admin, there is reply on issue #issue'.$data['issue_id'];
                $view = 'emails.reply-admin';
            }

            Mail::to($email)->send(new SendTicketEmails(
                $subject, // Dynamic subject
                $view, // Replace with your Blade view path,
                $data, // Dynamic data
                $formattedAttachments
            ));

            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Replied successfully.') 
                    : __('Replied successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditIssue: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function readMessage($id){
        try{
        if(empty($id)){
            return response()->json([
                'success'=>false,
                'message'=>'Please provide message id',
            ]);
        }

        Messages::where('id',$id)->update(['is_read'=>true]);

        $message = Messages::where('id',$id)->first();

        return redirect()->route('editIssue',$message->issue_id);
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }


    public function changeMessageStatus(Request $request){
        try {
        $formdata = $request->all();
        if(!isset($formdata['id']) || empty($formdata['id'])){
            return response()->json([
                'success' => false,
                'message' =>  __('Please provide message id')
            ], 200);
        }

        if(!isset($formdata['status'])){
            return response()->json([
                'success' => false,
                'message' =>  __('Please provide status')
            ], 200);
        }

        Messages::where('id',$formdata['id'])->update(['is_read'=>$formdata['status'] ?? false]);

        return response()->json([
            'success' => true,
            'message' =>  __('Updated Successfully.')
        ], 200);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => __('Something went wrong.')
        ], 500);
    }
    }


    public function supportstatusupdate(Request $request, $id)
    {
       try {
           // Validate the request
           $request->validate([
               'status' => 'required|string'
           ]);
           $user = auth()->user();
           $formdata = $request->all();
           $company = $user->company;

           if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
               // If it's a collection, take the first item
               $company = $company->first();
           }
   
           $issue = Issues::findOrFail($id);
           $issue->status = $request->status;
           $issue->save();
   
           // Return success response
           return response()->json([
               'success' => true, 
               'message' => __('support status updated successfully')
           ], 200);
       } catch (\Exception $e) {
           // Log the exception for debugging
           Log::error('Error updating Clients status: ' . $e->getMessage());
   
           // Return error response
           return response()->json([
               'success' => false, 
               'message' => __('Failed to update status. Please try again.')
           ], 500);
       }
    }

    
}
