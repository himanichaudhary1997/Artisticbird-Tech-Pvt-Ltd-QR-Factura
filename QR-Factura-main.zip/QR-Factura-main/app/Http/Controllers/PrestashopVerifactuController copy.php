<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VerifactuApiKeysModel;
use App\Services\FiskalyInvoiceService;
use Exception;
use App\Models\ActivityLog;
use App\Models\Invoice;
use App\Models\Clients;
use App\Models\VerifactuSystemRecord;
use Illuminate\Support\Facades\Validator;
use App\Models\TokenOrigin;
use Illuminate\Validation\Rule;
use App\Models\Receipts;
use App\Models\PaymentMethods;
use App\Models\User; 
use App\Services\InvoiceService;
use App\Traits\ContentDataTrait;
use App\Models\Providers;
use App\Models\TaxRules;

use Illuminate\Support\Facades\DB;

class PrestashopVerifactuController extends Controller
{
    use ContentDataTrait;
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
    }


    public function login(Request $request)
    {
        try {
            $apiKey = $request->input('api_key');
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;

            if (!$apiKey) {
                return response()->json([
                    'success' => false,
                    'message' => __('API key required'),
                ], $successCode ?? 400);
            }

            // Check if API key exists and is active
            $apiKeyRecord = VerifactuApiKeysModel::with('company.user')
                ->where('api_key', $apiKey)
                ->where('status', 1)
                ->first();

            if (!$apiKeyRecord) {
                return response()->json([
                    'success' => false,
                    'message' => __('Invalid API key'),
                ],$successCode ?? 401);
            }

            // 🔹 Check allowed URL
            $allowedUrl = $apiKeyRecord->allowed_url; // assuming you have this column
            $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');

            if ($allowedUrl && !$this->checkAllowedUrl($requestOrigin, $allowedUrl)) {
                return response()->json([
                    'success' => false,
                    'message' => __('Unauthorized URL'),
                ], $successCode ?? 403);
            }

            $user = $apiKeyRecord->company->user ?? null; // safeguard

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => __('No user linked to company'),
                ], $successCode ?? 404);
            }

            // 🔹 Create Passport access token
            $tokenResult = $user->createToken('Verifactu API Access');
            $token = $tokenResult->accessToken;
            // set expiry (example: 1 day)
            // $tokenResult->token->expires_at = now()->addDays(1);
            // $tokenResult->token->save();

            TokenOrigin::create([
                'token_id' => $tokenResult->token->id,
                'origin'   => $requestOrigin,
            ]);

            return response()->json([
                'success' => true,
                'token' => $token,
                'token_type' => __('Bearer'),
                'expires_at' => $tokenResult->token->expires_at,
                'message'=>__('Logged in Successfully')
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], $successCode ?? 500);
        }
    }


    public function invoice(Request $request, InvoiceService $invoiceService)
    {
        try {
            $user = $request->user(); // ✅ authenticated user from Bearer token
            $company = $user->company;
            $formdata = $request->all();
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;



            $dynamicTableName = (new Invoice())->getTable();

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => __('Company not found for user'),
                ], $successCode ?? 404);
            }

            $validator = Validator::make($formdata, [

                // Invoice validations
                'invoice.invoice_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',
                    // Rule::unique($dynamicTableName, 'invoice_id'),

                        // function ($attribute, $value, $fail) use ($dynamicTableName) {
                        //     $exists = DB::table($dynamicTableName)
                        //         ->where('invoice_id', $value)
                        //         ->orWhere('ref_no', $value)
                        //         ->exists();

                        //     if ($exists) {
                        //         $fail(__("The $attribute value $value already exists as an invoice ID."));
                        //     }
                        // },   
                        function ($attribute, $value, $fail) {
                            $sequence = $this->existsInInvoiceOrReceipt($value);

                            if (!$sequence['valid']) {
                                $fail($sequence['message']);
                            }
                        }
                        // function ($attribute, $value, $fail){
                        //     if ($this->existsInInvoiceOrReceipt($value)) {
                        //         $fail("The $attribute '$value' already exists.");
                        //     }
                        // }
                ],

                'invoice.issue_date'            => 'required|date',
                'invoice.due_date'              => 'required|date',
                'invoice.payment_method'        => ['required','string','in:TPV,Domiciliación bancaria,Transferencia bancaria'],
                'invoice.items'                 => 'required|array|min:1',
                'invoice.items.*.name'          => 'required|string',
                'invoice.items.*.quantity'      => ['required'],
                'invoice.items.*.price'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/'],
                'invoice.items.*.discount'      => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.items.*.tax_percentage'=> ['required', 'string','in:0,2,4,5,7,7.5,8,10,16,18,21'],
                'invoice.items.*.amount'        => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],

                'invoice.subtotal'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.totalDiscount'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.totalTax'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.grandTotal'            => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],

                // Client validations
                'client.name'                   => 'required|string',
                'client.email'                  => 'required|email',
                'client.mobile_no'              => 'nullable|string',
                'client.cif'                    => 'required|min:9|max:9|string',
                'client.surname'                => 'nullable|string',
                'client.company_name'           => 'nullable|string',
                'client.address'                => 'required|string',
                'client.locality'               => 'required|string',
                'client.postal_code'            => 'required|string',
                'client.state_name' => [
                    'required',
                    'string',
                    Rule::exists('states', 'name')->where(function ($query) {
                        $query->where('country_id', 1);
                    }),
                ],
            ]);

            
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            $errors = $invoiceService->validateCalculations($formdata, 'invoice');

            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'errors' => $errors,
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }
            


            $email = $formdata['client']['email'];
            $gst_no = $formdata['client']['cif'];
            $existingByGst   = Clients::where('gst_no', $gst_no)->first();

            if ($existingByGst && $existingByGst->email != $email) {
                return response()->json([
                    'success' => false,
                    'message' => __('GST number is already in use with another email.'),
                ], $successCode ?? 409);
            }

            $companyName = $formdata['client']['company_name'] ?? null;
            // dd($formdata['client']);

            if ($companyName) {
                $existingCompany = Clients::whereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))   LIKE ?", ['%' . $companyName . '%'])->where('gst_no','!=',$gst_no)->first();
                if ($existingCompany) {
                    return response()->json([
                        'success' => false,
                        'message' => __('Company name is already in use with another GST Number'),
                    ], $successCode ?? 409);
                }
            }

            $client = Clients::where('email', $email)
                            ->where('gst_no', $gst_no)
                            ->first();

            if (!$client) {
                $client = Clients::create([
                    "name"      => $formdata['client']['name'],
                    "email"     => $email,
                    "mobile_no" => $formdata['client']['mobile_no'] ?? null,
                    "gst_no"    => $gst_no,
                    'extra'     => [
                        "company_name" => $formdata['client']['company_name'] ?? null,
                        "address"      => $formdata['client']['address'] ?? null,
                        "locality"     => $formdata['client']['locality'] ?? null,
                        "state_name"   => $formdata['client']['state_name'] ?? null,
                        "country_code" => "ES",
                        "zip_code"     => $formdata['client']['postal_code'] ?? null,
                        "surname"      => $formdata['client']['surname'] ?? null,
                    ]
                ]);
            }

            $invoiceItems = $invoiceService->invoiceItems($formdata['invoice']['items']);
            $paymentMethod = PaymentMethods::where('name',$formdata['invoice']['payment_method'])->first();

            $extra = [];

            $totalAdditionalTax = normalizePrice($formdata['invoice']['totalAdditionalTax'] ?? 0, 2,'IN');
            if($totalAdditionalTax > 0){
                $rule = $invoiceService->getLastUsedTaxRule();;
                $extra['extraTax'] = "on";
                $extra['taxSlab'] = $rule->id;
            }

            $invoiceData = [
                'client_id'      => $client->id,
                'issue_date'     => $formdata['invoice']['issue_date'],
                'due_date'       => $formdata['invoice']['due_date'],
                'currency'       => '€',
                'invoice_type'   => 1,
                'payment_method' => $paymentMethod->id,
                'items'          => $invoiceItems,
                'subtotal'       => normalizePrice($formdata['invoice']['subtotal'], 2,'IN'),
                'totalDiscount'  => normalizePrice($formdata['invoice']['totalDiscount'], 2,'IN'),
                'totalTax'       => normalizePrice($formdata['invoice']['totalTax'], 2,'IN'),
                'grandTotal'     => normalizePrice($formdata['invoice']['grandTotal'], 2,'IN'),
                'extraTax'    => $totalAdditionalTax,
                'invoice_id'     => $invoiceService->generateInvoiceId($formdata['invoice']['issue_date'],$company),
                'ref_no'         => $formdata['invoice']['invoice_number'],
                "extra"          => $extra,
                'status'=>2
            ];
            
            
            $invoice = Invoice::create($invoiceData);

            if($company->is_verifactu){
                $response = $this->fiskaly->createInvoice($company, $invoice);
                if (isset($response['content']['error'])) {
                    // $invoiceService->handleVerifactuError($response, $invoice);
                    $error = $invoiceService->handleVerifactuError($response, $invoice, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $invoice, ($invoice->ref_no ?? $invoice->invoice_id));
                }
                // if (isset($response['content']['error']) || 
                //     (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                //     $invoice->delete();
                //     return response()->json([
                //         'success' => false,
                //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                //         'message' => __('Validation Failed'),
                //         ], $successCode ?? 422);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $invoice, ($invoice->ref_no ?? $invoice->invoice_id));
                // }
            }else{
                $invoice->generateInvoiceQrCode();
            }

            $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');
            VerifactuSystemRecord::create([
                'invoice_id'=>$invoice->id,
                'origin' => $requestOrigin,
            ]);
            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Invoice '. $invoice->invoice_id,
                'ip_address' => $request->ip()
            ]);

            $invoice->refresh();
            return response()->json([
                'success'=>true,
                'message'=>__('Invoice Created Successfully'),
                'invoice_number'=>$invoice->ref_no ?? $invoice->invoice_id,
                'qr_code_url'=>asset('storage/' . $invoice->qr_code)
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], $successCode ?? 500);
        }
    }

    // public function existsInInvoiceOrReceiptOLD($value)
    // {
    //     $invoiceTable = (new Invoice())->getTable();
    //     $receiptTable = (new Receipts())->getTable();

    //     return DB::table($invoiceTable)
    //         ->where('invoice_id', $value)
    //         ->orWhere('ref_no', $value)
    //         ->exists()
    //         ||
    //         DB::table($receiptTable)
    //         ->where('receipt_id', $value)
    //         ->orWhere('ref_no', $value)
    //         ->exists();
    // }

    public function existsInInvoiceOrReceipt(string $invoiceNumber)
    {
        $invoiceTable = (new Invoice())->getTable();
        $receiptTable = (new Receipts())->getTable();

        // 1. Extract prefix and numeric part (prefix = all chars before first digit)
        if (!preg_match('/^([^0-9]+)(\d+)$/', $invoiceNumber, $matches)) {
            return [
                'valid' => false,
                'message' => "Invalid invoice format. Must be like F0000123"
            ];
        }

        $prefix = $matches[1];
        $number = intval($matches[2]);
        $numberLength = strlen($matches[2]);

        // 2. Check exact ref_no duplicate (both tables)
        $exists = DB::table($invoiceTable)->where('invoice_id', $invoiceNumber)->orWhere('ref_no', $invoiceNumber)->exists()
            || DB::table($receiptTable)->where('receipt_id', $invoiceNumber)->orWhere('ref_no', $invoiceNumber)->exists();

        if ($exists) {
            return [
                'valid' => false,
                'message' => "The reference number '{$invoiceNumber}' already exists."
            ];
        }

        $escapedPrefix = preg_quote($prefix, '/');
        $regexp = '^' . $escapedPrefix . '[0-9]+';

        $lastInvoiceRef = DB::table($invoiceTable)
            ->whereRaw("(invoice_id REGEXP ? OR ref_no REGEXP ?)", [$regexp, $regexp])
            ->orderByRaw("
                LPAD(
                    REGEXP_REPLACE(
                        COALESCE(ref_no, invoice_id) COLLATE utf8mb3_unicode_ci,
                        '[^0-9]', ''
                    ),
                    20,
                    '0'
                ) DESC
            ")
            ->value(DB::raw("COALESCE(ref_no, invoice_id)"));

        $lastReceiptRef = DB::table($receiptTable)
            ->whereRaw("(receipt_id REGEXP ? OR ref_no REGEXP ?)", [$regexp, $regexp])
            ->orderByRaw("
                LPAD(
                    REGEXP_REPLACE(
                        COALESCE(ref_no, receipt_id) COLLATE utf8mb3_unicode_ci,
                        '[^0-9]', ''
                    ),
                    20,
                    '0'
                ) DESC
            ")
            ->value(DB::raw("COALESCE(ref_no, receipt_id)"));



        // 5. Parse last numeric parts using the same pattern (prefix then digits)
        $last = null;

        if ($lastInvoiceRef && preg_match('/^([^0-9]+)(\d+)$/', $lastInvoiceRef, $m)) {
            $last = intval($m[2]);
        }

        if ($lastReceiptRef && preg_match('/^([^0-9]+)(\d+)$/', $lastReceiptRef, $m)) {
            $last = max($last ?? 0, intval($m[2]));
        }

        // 6. If no previous number in the series -> must start at 1
        if ($last === null) {
            if ($number !== 1) {
                return [
                    'valid' => false,
                    'message' => "New series '{$prefix}' must start at 1.",
                    'expected_next' => $prefix . str_pad(1, $numberLength, '0', STR_PAD_LEFT)
                ];
            }

            return ['valid' => true];
        }

        // 7. Must be last + 1
        $expected = $last + 1;
        if ($number !== $expected) {
            return [
                'valid' => false,
                'message' => "Invalid sequence. Expected next number: {$prefix}" . str_pad($expected, $numberLength, '0', STR_PAD_LEFT),
                'expected_next' => $prefix . str_pad($expected, $numberLength, '0', STR_PAD_LEFT),
                'last_number' => $prefix . str_pad($last, $numberLength, '0', STR_PAD_LEFT)
            ];
        }

        return ['valid' => true];
    }




    public function invoiceNegative(Request $request, InvoiceService $invoiceService)
    {
        // dd("aa");
        try {
            $user = $request->user();
            $company = $user->company;
            $formdata = $request->all();
            $dynamicTableName = (new Invoice())->getTable();
            $invoiceTable = (new Invoice())->getTable();
            $receiptTable = (new Receipts())->getTable();
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;

            // 🔹 Validation
            $validator = Validator::make($formdata, [
                'invoice_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',
                    // Rule::unique($dynamicTableName, 'invoice_id'),

                        // function ($attribute, $value, $fail) use ($dynamicTableName) {
                        //     $exists = DB::table($dynamicTableName)
                        //         ->where('invoice_id', $value)
                        //         ->orWhere('ref_no', $value)
                        //         ->exists();

                        //     if ($exists) {
                        //         $fail(__("The $attribute value $value already exists as an invoice ID."));
                        //     }
                        // },     

                        // function ($attribute, $value, $fail){
                        //     if ($this->existsInInvoiceOrReceipt($value)) {
                        //         $fail("The $attribute '$value' already exists.");
                        //     }
                        // }

                        function ($attribute, $value, $fail) {
                            $sequence = $this->existsInInvoiceOrReceipt($value);

                            if (!$sequence['valid']) {
                                $fail($sequence['message']);
                            }
                        }
                        
                               
                ],
                'abono_invoice_id'              => 'required|string',
                'issue_date'                    => 'required|date',
                'method'                        => ['required', 'string','in:SUBSTITUTION,DIFFERENCES'],
                'note'                          => 'nullable|string|max:250',
                'invoice.items.*.name'          => 'required|string',
                'invoice.items.*.quantity'      => ['required'],
                'invoice.items.*.price'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/'],
                'invoice.items.*.discount'      => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.items.*.tax_percentage'=> ['required', 'string','in:0,2,4,5,7,7.5,8,10,16,18,21'],
                'invoice.items.*.amount'        => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],

                'invoice.subtotal'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.totalDiscount'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.totalTax'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'invoice.grandTotal'            => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
            ]);
    
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }
            // 🔹 Check original invoice
            $invoice = Invoice::where('status', '!=', Invoice::NEGATIVE_INVOICE)
            ->whereNotNull('verifactu_id')
            ->where(function ($query) use ($formdata) {
                $query->where('invoice_id', $formdata['abono_invoice_id'])
                    ->orWhere('ref_no', $formdata['abono_invoice_id']);
            })
            ->first();
            if (empty($invoice)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invoice Not Found, please enter a correct ID.',
                ], 404);
            }

            $originalDate = \Carbon\Carbon::parse($invoice->issue_date);
            $newDate = \Carbon\Carbon::parse($formdata['issue_date']);

            if ($newDate->lt($originalDate)) {
                return response()->json([
                    'success' => false,
                    'message' => 'The issue date must be the same as or later than the original invoice issue date.',
                ], $successCode ?? 500);
            }
            // if ($invoice->issue_date >= $formdata['issue_date']) {
            //     return response()->json([
            //         'success' => false,
            //         'message' => 'Issue date will be same and after the original invoice issue date.',
            //     ], $successCode ?? 500);
            // }

            if($invoice->extraTax > 0 && !isset($formdata['invoice']['totalAdditionalTax'])){
                return response()->json([
                    'success' => false,
                    'errors' => ['invoice.totalAdditionalTax' => ['Additional tax amount is required as original invoice contain additional tax.']],
                    'message' => 'Additional tax amount is required.',
                ], $successCode ?? 422);
            }


            if($invoice->extraTax == 0 && isset($formdata['invoice']['totalAdditionalTax'])){
                return response()->json([
                    'success' => false,
                    'errors' => ['invoice.totalAdditionalTax' => ['Remove additional tax as not provide in original invoice.']],
                    'message' => 'Additional tax amount is required.',
                ], $successCode ?? 422);
            }
            $invoiceService->validateWithOriginal($invoice, $formdata);
            $errors = $invoiceService->validateCalculations($formdata, 'invoice');
    

            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'errors' => $errors,
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            

            $extra = [];

            $extra['note'] = $formdata['note'];

            $totalAdditionalTax = normalizePrice($formdata['invoice']['totalAdditionalTax'] ?? 0, 2,'IN');
            if($totalAdditionalTax > 0){
                $rule = $invoiceService->getLastUsedTaxRule();;
                $extra['extraTax'] = "on";
                $extra['taxSlab'] = $rule->id;
            }
    
        //    dd($formdata['invoice']['items'],$invoiceService->invoiceItems($formdata['invoice']['items']));
            // 🔹 Get admin user
            $adminUser = $company
                ? User::find($company->admin_id)
                : User::find($user->id);
            $invoiceData = [];
            $invoiceData['reference_id'] = $invoice->id;
            $invoiceData['ref_no'] = $formdata['invoice_number'] ?? null;
            $invoiceData['invoice_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'], $company, 'negative-invoice');
            $invoiceData['issue_date'] = $formdata['issue_date'];
            $invoiceData['due_date'] = $formdata['issue_date'];
            $invoiceData['items'] = $invoiceService->invoiceItems($formdata['invoice']['items']);
            $invoiceData['subtotal']       = normalizePrice($formdata['invoice']['subtotal'], 2,'IN');
            $invoiceData['totalDiscount']  = normalizePrice($formdata['invoice']['totalDiscount'], 2,'IN');
            $invoiceData['totalTax']       = normalizePrice($formdata['invoice']['totalTax'], 2,'IN');
            $invoiceData['grandTotal'] = normalizePrice($formdata['invoice']['grandTotal'], 2,'IN');
            $invoiceData['extraTax']    = normalizePrice($formdata['invoice']['totalAdditionalTax'] ?? null, 2,'IN');
            $invoiceData['currency'] = $invoice->currency;
            $invoiceData['invoice_type'] = $invoice->invoice_type;
            // $invoiceData['extra'] = $invoice->extra;
            $invoiceData['client_id'] = $invoice->client_id;
            $invoiceData['payment_method'] = $invoice->payment_method;
            $invoiceData['extra'] = $extra;
            $invoiceData['status'] = Invoice::NEGATIVE_INVOICE;
            $invoiceData['is_verified'] = 0;
            $invoiceData['created_by'] = $company->admin_id;

            $corrected = $invoiceService->generateCorrectedInvoice($invoiceData, $formdata['method']);
            // dd($corrected);
                // $newInvoice->save();
            $newInvoice= Invoice::create($corrected);

            // 🔹 Handle verifactu or QR
            if($company->is_verifactu){
                $count = Invoice::where('reference_id', $invoice->id)
                    ->where('status', Invoice::NEGATIVE_INVOICE)
                    ->count();
                if($count > 1){
                    $correction = 'CORRECTION_2';
                }else{
                    $correction = 'CORRECTION_1';
                }

                $response = $this->fiskaly->createNegativeInvoice($company, $newInvoice, $invoice, $formdata['method'],$correction);
                // dd($response->json());
                if (isset($response['content']['error'])) {
                    $error = $invoiceService->handleVerifactuError($response, $newInvoice, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $newInvoice,$newInvoice->ref_no ?? $newInvoice->invoice_id);
                }
            }else{
                $newInvoice->generateInvoiceQrCode();
            }

            $apiResponse = [
                'success' => true,
                'message' => __('Negative Invoice Created Successfully'),
                'invoice_number' => 
                                    (isset($newInvoice->ref_no) && $newInvoice->ref_no !== '') 
                                        ? $newInvoice->ref_no 
                                        : $newInvoice->invoice_id,

                'qr_code_url'=>asset('storage/' . $newInvoice->qr_code ?? null)
            ];

            if($newInvoice->needs_validation == true){
                $validatedResponse = $this->fiskaly->getInvoice($company,$newInvoice->verifactu_id);
                $validations = $validatedResponse['content']['validations'] ?? [];
                $apiResponse['validations'] = $validations;
            }

            // ✅ Success response
            return response()->json($apiResponse);
    
        }catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors'  => $e->errors(),
                'message' => 'Validation Failed'
            ], $successCode ?? 422);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                // 'line'=>$e->getLine(),
                // 'file'=>$e->getFile()
            ], $successCode ?? 500);
        }
    }

    public function receipt(Request $request, InvoiceService $invoiceService)
    {
        try {
            $user = $request->user(); // ✅ authenticated user from Bearer token
            $company = $user->company;
            $formdata = $request->all();
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;
            
            $dynamicTableName = (new Receipts())->getTable();
            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => __('Company not found for user'),
                ], $successCode ?? 404);
            }

            // 🔹 Validation rules
            $validator = Validator::make($formdata, [
                'receipt.receipt_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',
                    // Rule::unique($dynamicTableName, 'receipt_id'),

                    // function ($attribute, $value, $fail) use ($dynamicTableName) {
                    //     $exists = DB::table($dynamicTableName)
                    //         ->where('receipt_id', $value)
                    //         ->orWhere('ref_no', $value)
                    //         ->exists();

                    //     if ($exists) {
                    //         $fail(__("The $attribute value $value already exists as an receipts ID."));
                    //     }
                    // },      

                    // function ($attribute, $value, $fail){
                    //     if ($this->existsInInvoiceOrReceipt($value)) {
                    //         $fail("The $attribute '$value' already exists.");
                    //     }
                    // }

                    function ($attribute, $value, $fail) {
                        $sequence = $this->existsInInvoiceOrReceipt($value);

                        if (!$sequence['valid']) {
                            $fail($sequence['message']);
                        }
                    }
                ],
                'receipt.items'                 => 'required|array|min:1',
                'receipt.items.*.name'          => 'required|string',
                'receipt.items.*.quantity'      => ['required'],
                'receipt.items.*.price'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/'],
                'receipt.items.*.tax_percentage'=> ['required','string','in:0,2,4,5,7,7.5,8,10,16,18,21'],
                'receipt.items.*.amount'        => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.subtotal'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.totalTax'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.grandTotal'            => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],

            ]);

            $validator->sometimes([
                'client.name',
                'client.email',
                'client.cif',
                'client.company_name',
                'client.address',
                'client.locality',
                'client.postal_code',
                'client.state_name',
            ], 'required', function () use ($formdata) {

                $grandTotal = normalizePrice($formdata['receipt']['grandTotal'], 2, 'IN');

                return $grandTotal >= 3000;
            });


            $validator->addRules([

                'client.name'         => 'string',
                'client.email'        => 'email',
                'client.mobile_no'    => 'nullable|string',

                'client.cif'          => 'string|min:9|max:9',

                'client.surname'      => 'nullable|string',
                'client.company_name' => 'string',
                'client.address'      => 'string',
                'client.locality'     => 'string',
                'client.postal_code'  => 'string',

                'client.state_name'   => [
                    'string',
                    Rule::exists('states', 'name')->where(fn($q) => $q->where('country_id', 1)),
                ],
            ]);


            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            // $errors = $this->validateCalculations($formdata, 'receipt'); // or 'invoice'
            // dd($formdata);

            $errors = $invoiceService->validateCalculations($formdata, 'receipt');

            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'errors' => $errors,
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }


            $grandTotal = normalizePrice($formdata['receipt']['grandTotal'], 2, 'IN');

            if($grandTotal >= 3000)
            {
                $email = $formdata['client']['email'];
                $gst_no = $formdata['client']['cif'];
                $existingByGst   = Clients::where('gst_no', $gst_no)->first();

                if ($existingByGst && $existingByGst->email != $email) {
                    return response()->json([
                        'success' => false,
                        'message' => __('GST number is already in use with another email.'),
                    ], $successCode ?? 409);
                }


                $client = Clients::where('email', $email)
                            ->where('gst_no', $gst_no)
                            ->first();

                if (!$client) {
                    $client = Clients::create([
                        "name"      => $formdata['client']['name'],
                        "email"     => $email,
                        "mobile_no" => $formdata['client']['mobile_no'] ?? null,
                        "gst_no"    => $gst_no,
                        'extra'     => [
                            "company_name" => $formdata['client']['company_name'] ?? null,
                            "address"      => $formdata['client']['address'] ?? null,
                            "locality"     => $formdata['client']['locality'] ?? null,
                            "state_name"   => $formdata['client']['state_name'] ?? null,
                            "country_code" => "ES",
                            "zip_code"     => $formdata['client']['postal_code'] ?? null,
                            "surname"      => $formdata['client']['surname'] ?? null,
                        ]
                    ]);
                }
            }
            

            $receiptData = [
                'client_id'      => $grandTotal >= 3000 ? ($client->id ?? null) : null,
                'items'          => $invoiceService->invoiceItems($formdata['receipt']['items']),
                'subtotal'       => normalizePrice($formdata['receipt']['subtotal'], 2,'IN'),
                'totalTax'       => normalizePrice($formdata['receipt']['totalTax'], 2,'IN'),
                'grandTotal'     => normalizePrice($formdata['receipt']['grandTotal'], 2,'IN'),
                'receipt_id'     => $invoiceService->generateInvoiceId(now(), $company, 'ticket'),
                'ref_no'         => $formdata['receipt']['receipt_number'],
                'status'=>0
            ];


            $receipt = Receipts::create($receiptData);
            if($company->is_verifactu){
                $response = $this->fiskaly->createInvoice($company, $receipt);
                if (isset($response['content']['error'])) {
                    // $invoiceService->handleVerifactuError($response, $receipt);
                    $error = $invoiceService->handleVerifactuError($response, $receipt, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $receipt, ($receipt->ref_no ?? $receipt->receipt_id));
                }
                // if (isset($response['content']['error']) || 
                //     (isset($response['content']['status']) && $createInvoice['content']['status'] >= 400)) {
                //     $receipt->delete();
                //     return response()->json([
                //         'success' => false,
                //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                //         'message' => __('Validation Failed'),
                //         ], $successCode ?? 422);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $receipt, ($receipt->ref_no ?? $receipt->receipt_id));
                // }
               
            }else{
                $receipt->generateReceiptsQrCode();
            }

            $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');
            VerifactuSystemRecord::create([
                'invoice_id'=>$receipt->id,
                'origin' => $requestOrigin,
                'type'=>'receipt'
            ]);
            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Receipt '. $receipt->receipt_id,
                'ip_address' => $request->ip()
            ]);

            $receipt->refresh();
            return response()->json([
                'success'=>true,
                'message'=>__('Receipt Created Successfully'),
                'receipt_number'=>$receipt->ref_no ?? $receipt->receipt_id,
                'qr_code_url'=>asset('storage/' . $receipt->qr_code ?? null)
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                // 'file' => $e->getFile(),     // file where error occurred
                // 'line' => $e->getLine(),     // line number of the error
                // 'trace' => $e->getTraceAsString(), // optional full stack trace
            ], $successCode ?? 500);
        }

    }

    public function receiptNegative(Request $request, InvoiceService $invoiceService)
    {
        try {
            $user = $request->user();
            $company = $user->company;
            $formdata = $dataValidate = $request->all();
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;
            $dynamicTableName = (new Receipts())->getTable();
            // 🔹 Validation
            $validator = Validator::make($formdata, [
                'abono_receipt_id' => 'required|string',
                'note' => 'nullable|string|max:250',
                'receipt_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',
                    // Rule::unique($dynamicTableName, 'receipt_id'),

                    // function ($attribute, $value, $fail) use ($dynamicTableName) {
                    //     $exists = DB::table($dynamicTableName)
                    //         ->where('receipt_id', $value)
                    //         ->orWhere('ref_no', $value)
                    //         ->exists();

                    //     if ($exists) {
                    //         $fail(__("The $attribute value $value already exists as an receipts ID."));
                    //     }
                    // },   
                    
                    // function ($attribute, $value, $fail){
                    //     if ($this->existsInInvoiceOrReceipt($value)) {
                    //         $fail("The $attribute '$value' already exists.");
                    //     }
                    // }

                    function ($attribute, $value, $fail) {
                        $sequence = $this->existsInInvoiceOrReceipt($value);

                        if (!$sequence['valid']) {
                            $fail($sequence['message']);
                        }
                    }
                ],
                'client' => ['sometimes', 'array', 'min:1'],
                // Client validations
                'client.*.name'         => ['required', 'string', 'max:255'],
                'client.*.surname'      => ['nullable', 'string', 'max:255'],
                'client.*.email'        => ['required', 'email', 'max:255'],
                'client.*.mobile_no'    => ['nullable', 'string', 'max:20'],
                'client.*.cif'          => ['required', 'string', 'size:9'],
                
                'client.*.company_name' => ['nullable', 'string', 'max:255'],
                'client.*.address'      => ['required', 'string'],
                'client.*.locality'     => ['required', 'string', 'max:255'],
                'client.*.postal_code'  => ['required', 'string', 'max:10'],

                'client.*.state_name' => [
                    'required',
                    'string',
                    Rule::exists('states', 'name')->where(fn ($query) =>
                        $query->where('country_id', 1)
                    ),
                ],
            ]);
    
            if ($validator->fails()) {
                return response()->json([
                    // 'success' => false,
                    // 'message' => implode(' ', $validator->errors()->all()),
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

    
            // 🔹 Find the original receipt
            $receipt = Receipts::whereNotNull('verifactu_id')
            ->where(function ($query) use ($formdata) {
                $query->where('receipt_id', $formdata['abono_receipt_id'])
                    ->orWhere('ref_no', $formdata['abono_receipt_id']);
            })
            ->first();

            if (empty($receipt)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Receipt Not Found, please enter a correct ID.',
                ], $successCode ?? 404);
            }

            $receiptToInvoice = Invoice::where('reference_id',$receipt->receipt_id)->first();
            if(!empty($receiptToInvoice)){
                return response()->json([
                    'success' => false,
                    'message' => 'Enrichment already done you don\'t create a negative ticket for this ticket.',
                ], $successCode ?? 422);
            }
    
            // 🔹 Prevent duplicate negative receipt
            $alreadyExists = Receipts::where('reference_id', $receipt->id)->first();
            if ($alreadyExists) {
                return response()->json([
                    'success' => false,
                    'message' => __('Negative receipt already created'),
                ], $successCode ?? 409);
            }
            
            $client = [];
            if(isset($formdata['client'][0])){
                $clientData = $formdata['client'][0];
                $clientResult = $invoiceService->createOrGetClient($clientData);

                if (!$clientResult['success']) {
                    return response()->json($result, 409);
                }
                $client = $clientResult['client'];
            }


            $invoiceService->validateWithOriginal($receipt, $formdata,'receipt');

            $errors = $invoiceService->validateCalculations($dataValidate, 'receipt');
            
            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'errors' => $errors,
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            // 🔹 Get admin user
            $adminUser = $company
                ? User::find($company->admin_id)
                : User::find($user->id);
    
            
            $invoiceData = [];
            $invoiceData['reference_id'] = $receipt->id;
            $invoiceData['ref_no'] = $formdata['receipt_number'] ?? null;
            $invoiceData['receipt_id'] = $invoiceService->generateInvoiceId(now(), $company, 'negative-ticket');
            $invoiceData['issue_date'] = $receipt->issue_date;
            $invoiceData['due_date'] = $receipt->issue_date;
            $invoiceData['items'] = $invoiceService->invoiceItems($formdata['receipt']['items']);
            $invoiceData['subtotal']       = normalizePrice($formdata['receipt']['subtotal'], 2,'IN');
            $invoiceData['totalTax']       = normalizePrice($formdata['receipt']['totalTax'], 2,'IN');
            $invoiceData['grandTotal'] = normalizePrice($formdata['receipt']['grandTotal'], 2,'IN');
            $invoiceData['client_id'] = $client->id ?? $receipt->client_id ?? null;
            $invoiceData['extra'] = ['note' => $formdata['note']];
            $invoiceData['currency'] = $receipt->currency;
            $invoiceData['invoice_type'] = $receipt->invoice_type;
            $invoiceData['is_verified'] = 0;
            $invoiceData['created_by'] = $company->admin_id;



            $corrected = $invoiceService->generateCorrectedInvoice($invoiceData, $formdata['method'], $type = 'receipt');
            $newReceipt= Receipts::create($corrected);
            
            if($company->is_verifactu){
                $count = Receipts::where('reference_id', $receipt->id)
                ->count();
                if($count > 1){
                    $correction = 'CORRECTION_2';
                }else{
                    $correction = 'CORRECTION_1';
                }
                $response = $this->fiskaly->createNegativeInvoice($company, $newReceipt, $receipt, $formdata['method'],$correction);
                if (isset($response['content']['error'])) {
                    $error = $invoiceService->handleVerifactuError($response, $newReceipt, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $newReceipt, $newReceipt->ref_no ?? $newReceipt->receipt_id );
                }
                // if (isset($response['content']['error']) || 
                //     (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                //     $newReceipt->delete();
                //     return response()->json([
                //         'success' => false,
                //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                //         'message' => __('Validation Failed'),
                //         ], $successCode ?? 422);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $newReceipt, ($newReceipt->ref_no ?? $newReceipt->invoice_id));
                // }
            }else{
                $newReceipt->generateReceiptsQrCode();
            }
    
            // ✅ Success response
            return response()->json([
                'success' => true,
                'message' => __('Negative Receipt Created Successfully'),
                'receipt_number' => $newReceipt->ref_no ?? $newReceipt->receipt_id,
                'qr_code_url'=>asset('storage/' . $newReceipt->qr_code ?? null)
            ]);
    
        }catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors'  => $e->errors(),
                'message' => 'Validation Failed'
            ], $successCode ?? 422);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], $successCode ?? 500);
        }
    }

    

    public function receiptInternational(Request $request, InvoiceService $invoiceService)
    {
        try {
            // dd(array_keys(getProviderCountries()));
            $user = $request->user(); // ✅ authenticated user from Bearer token
            $company = $user->company;
            $formdata = $request->all();
            $program =$request->headers->get('program');
            $successCode = in_array($program,getAllowedPrograms()) ? 200 : null;
            
            $dynamicTableName = (new Receipts())->getTable();
            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => __('Company not found for user'),
                ], $successCode ?? 404);
            }

            // 🔹 Validation rules
            $validator = Validator::make($formdata, [
                'receipt.receipt_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',
                    // Rule::unique($dynamicTableName, 'receipt_id'),

                    // function ($attribute, $value, $fail) use ($dynamicTableName) {
                    //     $exists = DB::table($dynamicTableName)
                    //         ->where('receipt_id', $value)
                    //         ->orWhere('ref_no', $value)
                    //         ->exists();

                    //     if ($exists) {
                    //         $fail(__("The $attribute value $value already exists as an receipts ID."));
                    //     }
                    // },   
                    
                    // function ($attribute, $value, $fail){
                    //     if ($this->existsInInvoiceOrReceipt($value)) {
                    //         $fail("The $attribute '$value' already exists.");
                    //     }
                    // }

                    function ($attribute, $value, $fail) {
                        $sequence = $this->existsInInvoiceOrReceipt($value);

                        if (!$sequence['valid']) {
                            $fail($sequence['message']);
                        }
                    }
                ],
                'receipt.items'                 => 'required|array|min:1',
                'receipt.items.*.name'          => 'required|string',
                'receipt.items.*.quantity'      => ['required'],
                'receipt.items.*.price'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/'],
                'receipt.items.*.tax_percentage'=> ['required','string','in:0,2,4,5,7,7.5,8,10,16,18,21'],
                'receipt.items.*.amount'        => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.subtotal'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.totalTax'              => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'receipt.grandTotal'            => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],

            ]);

            $validator->sometimes([
                'client.name',
                'client.cif',
                'client.address',
                'client.locality',
                'client.postal_code',
                'client.state_name',
                'client.country_code',
            ], 'required', function () use ($formdata) {

                $grandTotal = normalizePrice($formdata['receipt']['grandTotal'], 2, 'IN');

                return $grandTotal >= 3000;
            });


            $validator->addRules([

                'client.name'         => 'string',
                'client.cif'          => 'string',
                'client.address'      => 'string',
                'client.locality'     => 'string',
                'client.postal_code'  => 'string',

                'client.state_name'   => [
                    'string'
                ],

                'client.country_code' => [
                    'string',
                    Rule::in(array_keys(getProviderCountries())),
                ],

            ]);


            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            // $errors = $this->validateCalculations($formdata, 'receipt'); // or 'invoice'
            // dd($formdata);

            $errors = $invoiceService->validateCalculations($formdata, 'receipt');

            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'errors' => $errors,
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }


            $grandTotal = normalizePrice($formdata['receipt']['grandTotal'], 2, 'IN');

            if($grandTotal >= 3000)
            {
                // $email = $formdata['client']['email'];
                $gst_no = $formdata['client']['cif'];
                $client   = Providers::where('gst_no', $gst_no)->first();

                if (!$client) {
                    $client = Providers::create([
                        "name"      => $formdata['client']['name'],
                        "gst_no"    => $gst_no,
                        'extra'     => [
                            "address"      => $formdata['client']['address'] ?? null,
                            "locality"     => $formdata['client']['locality'] ?? null,
                            "state_name"   => $formdata['client']['state_name'] ?? null,
                            "country_code" => $formdata['client']['country_code'] ?? null,
                            "zip_code"     => $formdata['client']['postal_code'] ?? null,
                        ]
                    ]);
                }
            }
            

            $receiptData = [
                'provider_id'      => $grandTotal >= 3000 ? ($client->id ?? null) : null,
                'items'          => $invoiceService->invoiceItems($formdata['receipt']['items']),
                'subtotal'       => normalizePrice($formdata['receipt']['subtotal'], 2,'IN'),
                'totalTax'       => normalizePrice($formdata['receipt']['totalTax'], 2,'IN'),
                'grandTotal'     => normalizePrice($formdata['receipt']['grandTotal'], 2,'IN'),
                'receipt_id'     => $invoiceService->generateInvoiceId(now(), $company, 'ticket'),
                'ref_no'         => $formdata['receipt']['receipt_number'],
                'status'=>0
            ];


            $receipt = Receipts::create($receiptData);
            if($company->is_verifactu){
                $response = $this->fiskaly->createAutoReceipt($company, $receipt);
                if (isset($response['content']['error'])) {
                    // $invoiceService->handleVerifactuError($response, $receipt);
                    $error = $invoiceService->handleVerifactuError($response, $receipt, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $receipt, ($receipt->ref_no ?? $receipt->receipt_id));
                }
                // if (isset($response['content']['error']) || 
                //     (isset($response['content']['status']) && $createInvoice['content']['status'] >= 400)) {
                //     $receipt->delete();
                //     return response()->json([
                //         'success' => false,
                //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                //         'message' => __('Validation Failed'),
                //         ], $successCode ?? 422);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $receipt, ($receipt->ref_no ?? $receipt->receipt_id));
                // }
               
            }else{
                $receipt->generateReceiptsQrCode();
            }

            $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');
            VerifactuSystemRecord::create([
                'invoice_id'=>$receipt->id,
                'origin' => $requestOrigin,
                'type'=>'receipt'
            ]);
            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Receipt '. $receipt->receipt_id,
                'ip_address' => $request->ip()
            ]);

            $receipt->refresh();
            return response()->json([
                'success'=>true,
                'message'=>__('Receipt Created Successfully'),
                'receipt_number'=>$receipt->ref_no ?? $receipt->receipt_id,
                'qr_code_url'=>asset('storage/' . $receipt->qr_code ?? null)
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                // 'file' => $e->getFile(),     // file where error occurred
                // 'line' => $e->getLine(),     // line number of the error
                // 'trace' => $e->getTraceAsString(), // optional full stack trace
            ], $successCode ?? 500);
        }

    }

    public function enrichment(Request $request, InvoiceService $invoiceService){

        try {
            $user = $request->user();
            $company = $user->company;
            $formdata = $request->all();

            $dynamicTableName = (new Invoice())->getTable();
            // 🔹 Validation
            $validator = Validator::make($formdata, [
                'receipt_id'              => 'required|string',
                'invoice_number' => [
                    'required',
                    'string',
                     'regex:/^[0-9A-Z_\/\-.]{1,20}$/',

                        // function ($attribute, $value, $fail) use ($dynamicTableName) {
                        //     $exists = DB::table($dynamicTableName)
                        //         ->where('invoice_id', $value)
                        //         ->orWhere('ref_no', $value)
                        //         ->exists();

                        //     if ($exists) {
                        //         $fail(__("The $attribute value $value already exists as an invoice ID."));
                        //     }
                        // },  
                        
                        function ($attribute, $value, $fail) {
                            $sequence = $this->existsInInvoiceOrReceipt($value);

                            if (!$sequence['valid']) {
                                $fail($sequence['message']);
                            }
                        }
                ],


                'client' => ['required', 'array', 'min:1'],
                // Client validations
                'client.*.name'         => ['required', 'string', 'max:255'],
                'client.*.surname'      => ['nullable', 'string', 'max:255'],
                'client.*.email'        => ['required', 'email', 'max:255'],
                'client.*.mobile_no'    => ['nullable', 'string', 'max:20'],
                'client.*.cif'          => ['required', 'string', 'size:9'],
                
                'client.*.company_name' => ['nullable', 'string', 'max:255'],
                'client.*.address'      => ['required', 'string'],
                'client.*.locality'     => ['required', 'string', 'max:255'],
                'client.*.postal_code'  => ['required', 'string', 'max:10'],

                'client.*.state_name' => [
                    'required',
                    'string',
                    Rule::exists('states', 'name')->where(fn ($query) =>
                        $query->where('country_id', 1)
                    ),
                ],


               
            ]);

            
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors(),
                    'message' => __('Validation Failed'),
                ], $successCode ?? 422);
            }

            $receipt = Receipts::whereNotNull('verifactu_id')->whereNull('client_id')->whereNull('reference_id')
            ->where(function ($query) use ($formdata) {
                $query->where('receipt_id', $formdata['receipt_id'])
                    ->orWhere('ref_no', $formdata['receipt_id']);
            })
            ->first();
            // $query = Receipts::whereNotNull('verifactu_id')
            //     ->whereNull('client_id')
            //     ->whereNull('reference_id')
            //     ->where(function ($query) use ($formdata) {
            //         $query->where('receipt_id', $formdata['receipt_id'])
            //             ->orWhere('ref_no', $formdata['receipt_id']);
            //     });
            // dd($query->toSql(), $query->getBindings());

            if (empty($receipt)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Receipt Not Found, please enter a correct ID.',
                ], 404);
            }
            
            
            // Find negative receipt linked to this positive receipt
            $negativeReceipt = Receipts::where('reference_id', $receipt->id)->first();

            // If negative exists AND has no client → block
            if ($negativeReceipt && empty($negativeReceipt->client_id)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot create invoice because the negative receipt has no client data.'
                ], 422);
            }

            if ($negativeReceipt && !empty($negativeReceipt->client_id)) {

                
                $createdMain = $invoiceService->createInvoiceFromReceipt($receipt, null);
                $createdNegative = $invoiceService->createInvoiceFromReceipt($negativeReceipt, $createdMain->id);

                return response()->json([
                    'success'=>true,
                    'message'=>__('Invoice Created Successfully'),
                    'invoice_number'=> [$createdMain->ref_no, $createdNegative->ref_no],
                    'qr_code_url'   =>  [asset('storage/' . $createdMain->qr_code), asset('storage/' . $createdNegative->qr_code)]
                ]);
            }

            
            $clientData = $formdata['client'][0];
            $clientResult = $invoiceService->createOrGetClient($clientData);

            if (!$clientResult['success']) {
                return response()->json($result, 409);
            }
            $client = $clientResult['client'];
            
            // $itemlist = $receipt->items;
            $invoiceData = $invoiceService->getEnrichmentItems($receipt, $company, $client, $formdata);
            $method = isset($invoiceData['method'])? $invoiceData['method'] : 'enrichment';
         
            $newInvoice= Invoice::create($invoiceData);
            if($company->is_verifactu){
                $response = $this->fiskaly->createEnrichmentInvoice($company, $newInvoice, $receipt, $method);
                if (isset($response['content']['error'])) {
                    // $invoiceService->handleVerifactuError($response, $newInvoice);
                    $error = $invoiceService->handleVerifactuError($response, $newInvoice, true);
                    if (!empty($error)) {
                        return response()->json([
                            'success' => false,
                            'errors'  => $error['error'] ?? 'Bad request',
                            'message' => $error['message'] ?? 'Validation Failed',
                        ], 200);
                    }
                    
                }else{
                    $invoiceService->saveQrAndVerificationData($response, $company, $newInvoice, ($newInvoice->ref_no ?? $newInvoice->receipt_id));
                }
                // if (isset($response['content']['error']) || 
                //     (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                //     $newInvoice->delete();
                //     // dd($response['content']);
                //     return response()->json([
                //         'success' => false,
                //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                //         'message' => __('Validation Failed'),
                //         ], $successCode ?? 422);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $newInvoice, ($newInvoice->ref_no ?? $newInvoice->invoice_id));
                // }
            }else{
                $invoice->generateInvoiceQrCode();
            }

            $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');
            VerifactuSystemRecord::create([
                'invoice_id'=>$newInvoice->id,
                'origin' => $requestOrigin,
            ]);
            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Invoice '. $newInvoice->invoice_id,
                'ip_address' => $request->ip()
            ]);

            $newInvoice->refresh();
            return response()->json([
                'success'=>true,
                'message'=>__('Invoice Created Successfully'),
                'invoice_number'=>$newInvoice->ref_no ?? $newInvoice->invoice_id,
                'qr_code_url'=>asset('storage/' . $newInvoice->qr_code)
            ]);
    
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    

    

    protected function checkAllowedUrl($requestOrigin, $allowedUrl)
    {
        if (!$requestOrigin) return false;

        $requestHost = parse_url($requestOrigin, PHP_URL_HOST);
        $allowedHost = parse_url($allowedUrl, PHP_URL_HOST);

        return $requestHost === $allowedHost;
    }
    


}
