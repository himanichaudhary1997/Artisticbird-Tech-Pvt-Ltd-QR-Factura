<?php

namespace App\Http\Controllers;

use App\Services\PrestashopInvoicePdf;
use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Document;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\Company;
use App\Models\InvoiceType;
use App\Models\User;
use App\Models\ClientAccountantRelation;
use App\Models\Templates;
use App\Models\Clients;
use PDF;
use App\Models\DocuemntsModel;
use App\Models\DocumentCategories;
use App\Models\DocumentCategoriesRelation;

class AccountantController extends Controller
{
    /**
     * Accountant Dashboard
     */

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function indexcompanyDocuments(Request $request,$company_slug)
    {
        try {
                if ($company_slug != 'artisticbird') {
                    $company = Company::where('company_slug', $company_slug)->first();
                } else {
                    $company = null;
                }
                // $this->checkCompanyValidation($company_slug);
                $authUser = auth()->user();

                $companyId = $company->id ?? null;

                $admin_id = $company->admin_id ?? 1;
                $formdata = $request->all();
                if($company_slug != 'artisticbird'){
                    $totalClientsIds = (new ClientAccountantRelation())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->where('accountant_id', $authUser->id)
                        ->pluck('client_id')
                        ->toArray();
                    $totalClients = (new Clients())->setDynamicTableName($companyId)->newQuery()->whereIn('id',$totalClientsIds)->get();
                }else{
                    $totalClientsIds = ClientAccountantRelation::where('accountant_id',$authUser->id)->pluck('client_id')->toArray();
                    $totalClients = User::whereIn('id',$totalClientsIds)->get();
                }
                // Initialize the Invoice Query with Dynamic Table Name
                $query = (new DocuemntsModel())->setDynamicTableName($companyId)->newQuery();


                // Apply Search Filter
                if (!empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata, $companyId) {
                        $q->where('title', 'like', '%' . $formdata['search'] . '%');
                    });
                }
                if (!empty($formdata['category_id'])) {
                    $query->whereHas('accountantCategories', function ($q) use ($formdata) {
                        $q->where('category_id', $formdata['category_id']);
                    });
                }
                // if (!empty($formdata['category_id'])) {
                //     $relation_table_name = 'document_categories_relation_' . $companyId;
                //     $categories_table_name = 'document_categories_' . $companyId;
                
                //     $query->whereHas('categories', function ($q) use ($formdata, $relation_table_name, $categories_table_name) {
                //         $q->join($categories_table_name, "$categories_table_name.id", '=', "$relation_table_name.category_id")
                //           ->whereIn("$relation_table_name.category_id", (array) $formdata['category_id']);
                //     });
                // }
                // Apply Status Filter
                if (!is_null($formdata['status'] ?? null)) {
                    $query->where('status', $formdata['status']);
                }

                // Fetch Accountant Clients
                $currentAccountantClients = (new ClientAccountantRelation())
                ->setDynamicTableName($companyId) // Set dynamic table
                ->newQuery() // Get a new query builder instance
                ->where('accountant_id', $authUser->id) // Apply condition
                ->pluck('client_id') // Get the client IDs
                ->toArray(); // Convert to array
            
                // dd($currentAccountantClients);
                if(isset($formdata['client_id']) && !empty($formdata['client_id'])){
                    $query->orWhereJsonContains('client_id', $formdata['client_id']);
                }else{
                    $query->where(function ($q) use ($currentAccountantClients) {
                        foreach ($currentAccountantClients as $clientId) {
                            $q->orWhereJsonContains('client_id', $clientId);
                        }
                    });
                }

                // Fetch Invoices with Pagination
                $documents = $query->orderBy('id', 'DESC')->paginate(10);
                $categories = (new DocumentCategories())->setDynamicTableName($companyId)->where('status',1)->get();

                if($request->ajax()){
                    return view('panel.accountant-document.partial_data', compact('company', 'documents','categories','totalClients'));
                }

                return view('panel.accountant-document.company-document', compact('company', 'documents','categories','totalClients'));
            }
            catch (\Throwable $e) {
                
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
        }


    public function seeCategoryDocuments(Request $request,$company_slug,$category_id)
    {
        try {
                if ($company_slug != 'artisticbird') {
                    $company = Company::where('company_slug', $company_slug)->first();
                } else {
                    $company = null;
                }
                // $this->checkCompanyValidation($company_slug);
                $authUser = auth()->user();

                $companyId = $company->id ?? null;

                $admin_id = $company->admin_id ?? 1;
                $formdata = $request->all();

                // Initialize the Invoice Query with Dynamic Table Name
                $query = (new DocuemntsModel())->setDynamicTableName($companyId)->newQuery();
                $documentCategoriesRelation = (new DocumentCategoriesRelation())->setDynamicTableName($companyId)->newQuery();
                if (!empty($category_id)) {
                    if(!empty($companyId)){
                        $relationTableName = 'document_categories_relation_' . $companyId;
                    }else{
                        $relationTableName = 'document_categories_relation';
                    }
                    $query->whereIn('id', function ($subQuery) use ($category_id, $relationTableName) {
                        $subQuery->select('document_id')
                            ->from($relationTableName)
                            ->where('category_id', $category_id);
                    });
                }
                // Apply Search Filter
                if (!empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata, $companyId) {
                        $q->where('title', 'like', '%' . $formdata['search'] . '%');
                    });
                }
                if (!empty($formdata['category_id'])) {
                    $query->whereHas('accountantCategories', function ($q) use ($formdata) {
                        $q->where('category_id', $formdata['category_id']);
                    });
                }
                // if (!empty($formdata['category_id'])) {
                //     $relation_table_name = 'document_categories_relation_' . $companyId;
                //     $categories_table_name = 'document_categories_' . $companyId;
                
                //     $query->whereHas('categories', function ($q) use ($formdata, $relation_table_name, $categories_table_name) {
                //         $q->join($categories_table_name, "$categories_table_name.id", '=', "$relation_table_name.category_id")
                //           ->whereIn("$relation_table_name.category_id", (array) $formdata['category_id']);
                //     });
                // }
                // Apply Status Filter
                if (!is_null($formdata['status'] ?? null)) {
                    $query->where('status', $formdata['status']);
                }

                // Fetch Accountant Clients
                $currentAccountantClients = (new ClientAccountantRelation())
                ->setDynamicTableName($companyId) // Set dynamic table
                ->newQuery() // Get a new query builder instance
                ->where('accountant_id', $authUser->id) // Apply condition
                ->pluck('client_id') // Get the client IDs
                ->toArray(); // Convert to array
            
                // dd($currentAccountantClients);
                $query->where(function ($q) use ($currentAccountantClients) {
                    foreach ($currentAccountantClients as $clientId) {
                        $q->orWhereJsonContains('client_id', $clientId);
                    }
                });

                // Fetch Invoices with Pagination
                $documents = $query->orderBy('id', 'DESC')->paginate(10);
                $categories = (new DocumentCategories())->setDynamicTableName($companyId)->where('status',1)->get();

                if($request->ajax()){
                    return view('panel.accountant-document.partial_category_document_data', compact('company', 'documents','categories','category_id'));
                }

                return view('panel.accountant-document.company-category-document', compact('company', 'documents','categories','category_id'));
            }
            catch (\Throwable $e) {
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
        }

    public function indexcompanyDocumentsCategories(Request $request,$company_slug)
    {
        try {
                if ($company_slug != 'artisticbird') {
                    $company = Company::where('company_slug', $company_slug)->first();
                } else {
                    $company = null;
                }
                // $this->checkCompanyValidation($company_slug);
                $authUser = auth()->user();

                $companyId = $company->id ?? null;

                $admin_id = $company->admin_id ?? 1;
                $formdata = $request->all();

                // Initialize the Invoice Query with Dynamic Table Name
                $query = (new DocumentCategories())->setDynamicTableName($companyId)->newQuery();
                $categoriesTable = $companyId ? "document_categories_{$companyId}" : "document_categories";
                $documentsTable = $companyId ? "documents_{$companyId}" : "documents";
                $relationTable = $companyId ? "document_categories_relation_{$companyId}" : "document_categories_relation";

                // Apply Search Filter
                if (!empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata, $companyId) {
                        $q->where('title', 'like', '%' . $formdata['search'] . '%');
                    });
                }

                // Apply Status Filter
                if (!is_null($formdata['status'] ?? null)) {
                    $query->where('status', $formdata['status']);
                }

                // Fetch Invoices with Pagination
                // $documentCategories = $query->orderBy('id', 'DESC')->paginate(10);
                $documentCategories = $query
                ->leftJoin("{$relationTable} as dcr", "dcr.category_id", "=", "{$categoriesTable}.id")
                ->leftJoin("{$documentsTable} as docs", "docs.id", "=", "dcr.document_id")
                ->selectRaw("{$categoriesTable}.*, COUNT(docs.id) as document_count")
                ->groupBy("{$categoriesTable}.id")
                ->orderBy("{$categoriesTable}.id", "DESC")
                ->paginate(10);
                // $categories = (new DocumentCategories())->setDynamicTableName($companyId)->where('status',1)->get();

                if($request->ajax()){
                    return view('panel.accountant-document-categories.partial_data', compact('company', 'documentCategories'));
                }

                return view('panel.accountant-document-categories.company-categories', compact('company', 'documentCategories'));
            }
            catch (\Throwable $e) {
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
        }
    public function indexCompanyInvoice(Request $request, $company_slug)
    {
        try {
                if ($company_slug != 'artisticbird') {
                    $company = Company::where('company_slug', $company_slug)->first();
                } else {
                    $company = null;
                }
                // $this->checkCompanyValidation($company_slug);

                
                // Fetch Accountant Clients
                

                $statuses = getStatuses();
                $invoicesTypes = InvoiceType::all();
                $authUser = auth()->user();
                $companyId = $company->id ?? null;
                $admin_id = $company->admin_id ?? 1;
                $formdata = $request->all();

                if($company_slug != 'artisticbird'){
                    $totalClientsIds = (new ClientAccountantRelation())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->where('accountant_id', $authUser->id)
                        ->pluck('client_id')
                        ->toArray();
                    $totalClients = (new Clients())->setDynamicTableName($companyId)->newQuery()->whereIn('id',$totalClientsIds)->get();
                }else{
                    $totalClientsIds = ClientAccountantRelation::where('accountant_id',$authUser->id)->pluck('client_id')->toArray();
                    $totalClients = User::whereIn('id',$totalClientsIds)->get();
                }

                $currentAccountantClients = (new ClientAccountantRelation())
                ->setDynamicTableName($companyId) // Set dynamic table
                ->newQuery() // Get a new query builder instance
                ->where('accountant_id', $authUser->id) // Apply condition
                ->pluck('client_id') // Get the client IDs
                ->toArray(); // Convert to array
                // Initialize the Invoice Query with Dynamic Table Name
                $query = (new Invoice())->setDynamicTableName($companyId)->newQuery();

                // Date Validation
                if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                    return response()->json([
                        'success' => false,
                        'message' => 'The to date must be greater than or equal to from date.',
                    ], 200);
                }
                $clientsTable = !empty($companyId) ? "clients_{$companyId}" : "users";
                $invoicesTable = !empty($companyId) ? "invoices_{$companyId}" : "invoices";
                // Apply Search Filter
                if (!empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata, $companyId) {
                        $q->where('invoice_id', 'like', '%' . $formdata['search'] . '%');
                    });
                }
                
                
                
                

                // Apply Status Filter
                if (!is_null($formdata['client_id'] ?? null)) {
                    $query->where('client_id', $formdata['client_id']);
                }

                if (!is_null($formdata['status'] ?? null)) {
                    $query->where('status', $formdata['status']);
                }
                
                if (isset($formdata['invoice_type']) && !is_null($formdata['invoice_type'])) {
                    // dd($formdata);
                    $query->where('invoice_type', $formdata['invoice_type']); 
                }

                if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                    $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
                } elseif (!empty($formdata['from_date'])) {
                    $query->where('issue_date', '>=', $formdata['from_date']);
                } elseif (!empty($formdata['to_date'])) {
                    $query->where('issue_date', '<=', $formdata['to_date']);
                }
                
                // Apply Date Filters
            
                
            
                // dd($currentAccountantClients);
                $query->whereIn('client_id', $currentAccountantClients);

                // Fetch Invoices with Pagination
                // dd($query->toSql(),$query->getBindings());
                $invoices = $query->where('status','!=',4)->orderBy('id', 'DESC')->paginate(10);
                if($request->ajax()){
                    return view('panel.accountant-invoice.partial_data', compact('company', 'invoices', 'invoicesTypes','statuses','totalClients'));
                }

                return view('panel.accountant-invoice.company-invoice', compact('company', 'invoices', 'invoicesTypes','statuses','totalClients'));
            }
            
            catch (\Throwable $e) {
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
    }

    public function previewCompanyInvoice(Request $request,$company_slug,$invoice_id){
        try {
            $authUser = auth()->user();
            if($company_slug != 'artisticbird'){
                $company = Company::where('company_slug',$company_slug)->first();
                $user = User::where('id', $company->admin_id)->first();
            }else{
                $company = [];
                $user = User::where('id', 1)->first();
            }
            // $this->checkCompanyValidation($company_slug);
            // if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            //     // If it's a collection, take the first item
            //     $company = $company->first();
            // }
            

            $invoice = (new Invoice())
            ->setDynamicTableName($company->id ?? null) // Set dynamic table
            ->newQuery()->findOrFail($invoice_id);
            // dd($invoice);
            // $invoice = Invoice::findOrFail($invoiceId);
            // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ?? 1;
            $templateId = getTemplateId(!empty($company) ? $company : $user);
            $template = Templates::where('id', $templateId)->first();

            $datahtml = PrestashopInvoicePdf::previewHtml($invoice, $company)
                ?? parseInvoiceSortcodes($template->template_html, $invoice, $company);
            if(isset($company->admin_id)){
                $client = (new Clients())
                ->setDynamicTableName($company->id) // Set dynamic table
                ->newQuery() // Get a new query builder instance
                ->where('id',$invoice->client_id)->first();
            }else{
                $client = User::where('id',$invoice->client_id)->first();
            }

            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $client->name ?? null,
            ];



            return view('invoice.company-preview', ['templateHtml' => $datahtml, 'data' => $data]);
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function downloadCompanyInvoice(Request $request,$company_slug, $invoice_id)
    {
        try {
        $authUser = auth()->user();
        if($company_slug != 'artisticbird'){
            $company = Company::where('company_slug',$company_slug)->first();
            $user = User::where('id', $company->admin_id)->first();
        }else{
            $company = [];
            $user = User::where('id', 1)->first();
        }
        // $this->checkCompanyValidation($company_slug);
        // if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
        //     // If it's a collection, take the first item
        //     $company = $company->first();
        // }
        

        $invoice = (new Invoice())
        ->setDynamicTableName($company->id ?? null) // Set dynamic table
        ->newQuery()->findOrFail($invoice_id);
        // dd($invoice);
        // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ?? 1;
        $templateId = getTemplateId(!empty($company) ? $company : $user);
        $template = Templates::where('id', $templateId)->first();

        $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
        if(isset($company->admin_id)){
            $client = (new Clients())
            ->setDynamicTableName($company->id) // Set dynamic table
            ->newQuery() // Get a new query builder instance
            ->where('id',$invoice->client_id)->first();
        }else{
            $client = User::where('id',$invoice->client_id)->first();
        }

        if (isset($invoice->extra['template_id']) && !empty($invoice->extra['template_id'])) {
            $template = Templates::where('id', $invoice->extra['template_id'])->first();
        }


        $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
        // Get the storage path dynamically
        $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

        // Get the base URL dynamically
        $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

        // Ensure correct trailing slashes
        $storagePath = rtrim($storagePath, '/') . '/';
        $baseUrl = rtrim($baseUrl, '/') . '/';


        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );
        // dd($datahtml);
        // Generate PDF from the rendered template
        // The shop's own PDF (or PrestaShop layout) for invoices from the PrestaShop module
        $prestashopPdf = PrestashopInvoicePdf::pdfFor($invoice, $company);
        if ($prestashopPdf !== null) {
            return PrestashopInvoicePdf::downloadResponse($prestashopPdf, "invoice-{$invoice_id}-{$invoice->issue_date}.pdf");
        }

        $pdf = PDF::loadHTML($datahtml)->setPaper('a4', 'portrait');

        return $pdf->download("invoice-{$invoice_id}-{$invoice->issue_date}.pdf");
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function checkCompanyValidation($company_slug){
        try {
            $user = auth()->user();
            $companySlugs = auth()->user()->company()
            ->join('users', 'companies.admin_id', '=', 'users.id') // join with users
            ->where('users.status', 1)
                ->whereIn('companies.admin_id', function ($query) {
                    $query->select('user_id')
                        ->from('user_subscriptions')
                        ->where(function ($q) {
                            $q->whereNull('end_date')
                                ->orWhere('end_date', '>=', now());
                        });
                })
                ->pluck('companies.company_slug') // Get just the slugs
                ->toArray();
            
            if($company_slug == 'artisticbird'){
                $hasAccountantRole = $user->hasRole('Accountant');
                if(!$hasAccountantRole){
                    abort(403, 'Unauthorized action.');
                }
            }elseif(in_array($company_slug, $companySlugs)){
                $company = Company::where('company_slug', $company_slug)->first();
            }else{
                abort(403, 'Unauthorized action.');
            }
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
}
