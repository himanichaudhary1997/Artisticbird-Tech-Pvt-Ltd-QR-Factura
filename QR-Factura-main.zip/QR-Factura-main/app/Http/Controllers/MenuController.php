<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Auth;

class MenuController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
     
    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Menu::query();
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }
            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['parent_id']) && !empty($formdata['parent_id'])) {

                if($formdata['parent_id'] == 'parent'){
                    $query->where('parent_id', $formdata['parent_id']); // Assuming `status` is a column in the `users` table
                }else{
                    $query->where('parent_id',$formdata['parent_id']);
                }

            }
            // $query->where('parent_id', 0)->orderBy('order','asc');
            // Fetch paginated results with related data
            $menus = $query->with('parent')->orderBy('order','asc')->paginate($limit);
            $parentMenus = Menu::where('parent_id',0)->get();

            if($request->ajax())
            {
            return view('panel.menus.partial_menu',compact('menus'));
            }
        
            return view('panel.menus.index-menu', compact('menus','parentMenus'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));    }
        }
     
    public function destroy($id)
    {
        try {
            $menu = Menu::where('id',$id)->first();
            $permission  = Permission::where('name',strtolower($menu->name))->delete();
            Menu::destroy($id);
            return response()->json(['success'=>true,'message' => 'Menu deleted successfully']);
            } 
        catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete menu: ' . $e->getMessage()
            ], 500);
        }
    }

    public function addMenu()
    {
        try {
        $parentMenus = Menu::where('parent_id',0)->get();
        return view('panel.menus.add-menu',compact('parentMenus'));
        } 
        catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    // public function indexMenu()
    // {
        
    // }

    public function editMenu($id)
    {
        try {
        $menu = Menu::findOrFail($id);
        $parentMenus = Menu::where('parent_id',0)->get();
        return view('panel.menus.edit-menu', compact('menu','parentMenus'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditMenu(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            $menu_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:menus,name,' . $menu_id,
                'url' => 'required',
                'status' => 'required|boolean',
                'order' => 'nullable|integer',
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $menu_data = [
                'name'=> $formdata['name'],
                'url'=> $formdata['url'],
                'icon'=> $formdata['icon'],
                'parent_id'=>$formdata['parent_id'] ?? 0,
                'order'=> $formdata['order'] ?? null,
                'status'=> $formdata['status'],

            ];

            if (!empty($menu_id)) {
                $menuData = Menu::where('id',$menu_id)->first();
                Menu::where('id', $menu_id)->update($menu_data);
                $menu = Menu::where('id',$menu_id)->first();
                  
                // Get the existing permission associated with this menu
                // $permission = Permission::where('name', strtolower($menuData->name))->first();
    
                // if ($permission) {
                //     // If the permission exists and the menu name has changed, update the permission name
                //     if ($permission->name !== strtolower($formdata['name'])) {
                //         $permission->name = strtolower($formdata['name']);
                //         $permission->save();
                //     }
                // }

                // Check if the parent has changed
                // if ($menuData->parent_id != $formdata['parent_id']) {
                //     // If parent has changed, update the parent permission
                //     if ($formdata['parent_id'] != 0) {
                //         // If a new parent is set (not 0 or null)
                //         $newParentMenu = Menu::find($formdata['parent_id']);
                //         $newParentPermission = Permission::where('name', strtolower($newParentMenu->name))->first();
            
                //         // Update the permission's parent_id to the new parent permission id
                //         if ($newParentPermission) {
                //             $permission->parent_id = $newParentPermission->id;
                //             $permission->save();
                //         }
                //     } else {
                //         // If parent is removed (parent_id is set to 0 or null)
                //         $permission->parent_id = null;  // Set to null if no parent
                //         $permission->save();
                //     }
                // }

            } else {
                // Create a new menu
                $menu = Menu::create($menu_data);
                
                // Create a permission for the new menu
                // dd($menu->parent->isEmtpy());
                // if(!empty($menu->parent)){
                //     $parentPermission = Permission::where('name', strtolower($menu->parent->name))->first();
                //     $permission = Permission::firstOrCreate([
                //         'name' => strtolower($formdata['name']),
                //         'guard_name' => 'web',
                //         'parent_id'=>$parentPermission->id
                //     ]);
                // }else{
                //     $permission = Permission::firstOrCreate([
                //         'name' => strtolower($formdata['name']),
                //         'guard_name' => 'web',
                //     ]);
                // }
                
            }

            // $superAdminRole = Role::where('name', 'Admin')->first();
            // if ($superAdminRole) {
            //     $superAdminRole->givePermissionTo($permission);
            // }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Menu updated successfully.') 
                    : __('Menu created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditMenu: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(), // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function getMenus(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Menu::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }
             
            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['parent_id']) && !empty($formdata['parent_id'])) {
                $query->where('parent_id', $formdata['parent_id']); // Assuming `status` is a column in the `users` table
            }
            // $query->where('parent_id', 0)->orderBy('order','asc');
            

            // Fetch paginated results with related data
            $menus = $query->with('parent')->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Menus retrieved successfully.',
                'data' => $menus,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Menus.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }



    public function menuupdateStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
    
            // Find the inventory item
            $menus = Menu::findOrFail($id);
            $menus->status = $request->status;
            $menus->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Menus status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating services status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
}

