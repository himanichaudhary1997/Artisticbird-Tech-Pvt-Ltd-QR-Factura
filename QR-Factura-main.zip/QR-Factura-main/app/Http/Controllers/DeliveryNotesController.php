<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryNotes;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use App\Models\Invoice;

use App\Services\InvoiceService;
use App\Services\UtilityService;

class DeliveryNotesController extends Controller
{

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = DeliveryNotes::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }

             // Apply reusable filters
            UtilityService::applyFilters(
                $query,
                $formdata, // FIXED
                $company,
                [
                    'search_fields' => ['delivery_note_id'],
                    'date_field'    => 'issue_date'
                ]
            );

            // Final Query
            $deliveryNotes = $query
                ->orderBy('id', 'DESC')
                ->with(['client', 'invoiceType', 'paymentMethod'])
                ->paginate($limit);


            $statuses = getStatuses();

            if ($request->ajax()) {
                return view('panel.delivery-notes.partial_data', compact('deliveryNotes','statuses'))->render();
            }
            return view('panel.delivery-notes.index-deliveryNote', compact('deliveryNotes'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        
    }
     
    public function editDeliveryNote($id)
    {
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            $deliveryNote = DeliveryNotes::where('id',$id)->first();
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $deliveryNote = DeliveryNotes::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }

            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            
            $country = CountryModel::all();
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.delivery-notes.form', compact('country','taxslab','paymentMethods', 'deliveryNote' ,'inventories', 'services', 'clients','defaultCurrency','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addDeliveryNote()
    {
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $deliveryNote = DeliveryNotes::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }
            $deliveryNote = new DeliveryNotes();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            
            $country = CountryModel::all();
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.delivery-notes.form', compact('country','taxslab','deliveryNote','paymentMethods', 'inventories', 'services', 'clients','defaultCurrency','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditDeliveryNotes(Request $request, InvoiceService $invoiceService)
    {

         try {
            // Extract form data
            $formdata = $request->all();
            $user = Auth::user();
            $company = $user->company;
            $adminUser = User::where('id',$company->admin_id ?? 1)->first();
            $delivery_note_id = $formdata['id'] ?? null;
        
            if($company){
                $gst_no = $company->gst_no ?? null;
            }else{
                $gst_no = $adminUser->extra['gst_no'] ?? null;
            }

            if(empty($gst_no)){
                return response()->json([
                    'success' => false,
                    'message' => __('Please add GST number in company settings to add Delivery Note.'),
                ], 200);
            }

            // Validate request data
            $validator = $this->validatedeliveryNote($formdata,$company);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $items = $this->processdeliveryNoteItems($formdata['items'], $formdata['currency']);
    
            if ($formdata['client_id'] === 'new-client') {
                if($formdata['client_country_code'] == 'ES' && isset($formdata['iscompany']) && $formdata['iscompany'] == 1){
                    $validatedGstNo = $this->fiskaly->validateGst($company,$formdata['client_gst_no'],$formdata['client_country_code'] ?? 'ES');
                    if(!$validatedGstNo){
                        return response()->json([
                            'success' => false,
                            'message' => __('The Spanish C.I.F. number must begin with A or B followed by 8 digits.'),
                        ]);
                    }
                }
                
                $client = $this->handleNewClient($formdata, $company);
                $formdata['client_id'] = $client->id;
            }
        
            $deliveryNote_data = [
                'client_id'     => $formdata['client_id'],
                'issue_date'     => $formdata['issue_date'],
                'due_date'       => $formdata['due_date'],
                'currency'       => $formdata['currency'],
                'payment_method' => $formdata['payment_method'],
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
                
                
            ];
            // dd($formdata['extra']);

            if (empty($delivery_note_id)) {
                $deliveryNote_data['delivery_note_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'],$company, 'delivery-note');;
               
                $deliveryNote_data['created_by'] = $user->id;
                $deliveryNote_data['domain_id'] = getDomainId();
                $deliveryNote_data['extra']= $formdata['extra'] ?? null;
                $deliveryNote_data['items'] = UtilityService::convertItemsToINFormat($deliveryNote_data['items']);
                $deliveryNote = DeliveryNotes::create($deliveryNote_data);
                
            } else {
                $olddeliveryNote = DeliveryNotes::find($delivery_note_id);

                // Update base invoice data (excluding 'extra')
                $deliveryNote_data['items'] = UtilityService::convertItemsToINFormat($deliveryNote_data['items']);
                DeliveryNotes::where('id', $delivery_note_id)->update($deliveryNote_data);

                $deliveryNote = DeliveryNotes::find($delivery_note_id);

                // ✅ Merge only incoming keys into existing extra
                if (!empty($formdata['extra']) && is_array($formdata['extra'])) {
                    $deliveryNote->extra = array_merge($deliveryNote->extra ?? [], $formdata['extra']);
                    $deliveryNote->save();
                }

            }

            return response()->json([
                'success' => true,
                'message' => $delivery_note_id ? __('Delivery Note updated successfully.') : __('Delivery Note created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoice: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    private function validatedeliveryNote($data,$company)
    {
        try {
        $table = $company ? (new Clients)->getTable() : (new User)->getTable();
        return Validator::make($data, [
            'client_id'      => 'required',
            'issue_date'      => 'required|date',
            'due_date'        => 'required|date|after_or_equal:issue_date',
            'currency'        => 'required|string|max:10',
            'items'           => 'required|array|min:1',
            'items.*.name' => 'required',
            'items.*.quantity'=> 'required|numeric|min:1',
            'items.*.price'   => 'required|min:0',
            'items.*.discount'=> 'nullable|min:0',
            'items.*.tax'     => 'nullable|min:0|max:100',
            'items.*.amount'  => 'required',
            'client_email'    => 'required_if:client_id,new-client',
            'client_name'     => 'required_if:client_id,new-client',
            'client_gst_no' => [
                'required_if:client_id,new-client',
            ],
            'client_company_name'     => 'required_if:client_id,new-client',
            'client_address'     => 'required_if:client_id,new-client',
            'client_locality'     => 'required_if:client_id,new-client',
            'client_zip_code'     => 'required_if:client_id,new-client',
            'client_country_code'     => 'required_if:client_id,new-client',
            'client_state_name'     => 'required_if:client_id,new-client',
            'extra.note' => 'nullable|string|max:500',
        ], [
            'client_email.required_if'      => __('Client email is required for a new client.'),
            'client_email.email'            => __('Please provide a valid email address for the client.'),
            'client_name.required_if'       => __('Client name is required for a new client.'),
            'client_gst_no.required_if'     => __('Client GST number is required for a new client.'),
            'client_gst_no.unique'          => __('This GST number is already registered. Please enter a unique GST number.'),
            'client_company_name.required_if' => __('Client company name is required for a new client.'),
            'client_address.required_if'    => __('Client address is required for a new client.'),
            'client_locality.required_if'   => __('Client locality is required for a new client.'),
            'client_zip_code.required_if'   => __('Client ZIP code is required for a new client.'),
            'client_country_code.required_if' => __('Client country is required for a new client.'),
            'client_state_name.required_if' => __('Client state is required for a new client.'),
            'items.required'            => __('At least one item is required in the invoice.'),
            'items.*.name.required'  => __('Please Select any item.'),
            'items.*.quantity.required' => __('Each item must have a quantity.'),
            'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
            'items.*.quantity.min'      => __('The quantity must be at least 1.'),
            'items.*.price.required'    => __('Each item must have a price.'),
            'items.*.price.min'         => __('The price must be at least 0.'),
            'items.*.discount.min'      => __('The discount must be at least 0.'),
            'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
            'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
            'items.*.amount.required'   => __('Each item must have an amount.'),
            'extra.note.string' => __('The note must be a valid text.'),
            'extra.note.max' => __('The note cannot be longer than 300 characters.'),
        ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }

    private function processdeliveryNoteItems($items, $currency)
    {
        $processedItems = [];

        foreach ($items as $item) {
            // if (isset($item['use_percentage']) && $item['use_percentage'] == 'true') {
            //     $item['discount'] = (parseNumber($item['discount_percentage']) * parseNumber($item['price'])) / 100;
            //     $item['discount'] = formatValue($item['discount'], $currency);
            // }

            if ($item['name'] === 'new-item') {
                $item['name'] = $this->createNewServiceItem($item); // this returns only string
            }

            if ($item['name'] === 'new-inventory') {
                $item['name'] = $this->createNewInventoryItem($item);
            }

            $processedItems[] = $item;
        }

        return $processedItems;
    }

    private function createNewServiceItem($item)
    {
        if (empty($item['new_item'])) {
            throw new \Exception(__('Please enter service name.'));
        }

        if (Services::where('name', $item['new_item'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_item'] . '" already exists.'));
        }

        $service = Services::create([
            'name'     => $item['new_item'],
            'slug'     => str_replace(' ', '-', strtolower($item['new_item'])),
            'status'   => 1,
            'price'    => parseInventoryServicePrice($item['price']),
            // 'tax_rate' => $item['tax'],
            'discount' => parseNumber($item['discount']),
        ]);

        return $service->name; // returns plain string
    }

    

    private function createNewInventoryItem($item)
    {
        if (empty($item['new_inventory'])) {
            throw new \Exception(__('Please enter inventory name.'));
        }

        if (Inventory::where('name', $item['new_inventory'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_inventory'] . '" already exists.'));
        }

        $inventory = Inventory::create([
            'name'      => $item['new_inventory'],
            'slug'      => str_replace(' ', '-', strtolower($item['new_inventory'])),
            'price'     => parseInventoryServicePrice($item['price']),
            'quantity'  => 0,
            // 'tax_rate'  => $item['tax'],
            'discount'  => parseNumber($item['discount']),
            'status'    => 1,
        ]);

        return $inventory->name;
    }
    
    private function handleNewClient($formdata, $company)
    {
        try{
            if ($company) {
                return Clients::create([
                    'name'     => $formdata['client_name'],
                    'email'    => $formdata['client_email'],
                    'mobile_no'=> $formdata['client_phone'],
                    'gst_no'=>$formdata['client_gst_no'],
                    'isCompany' => isset($formdata['iscompany']) ? $formdata['iscompany'] : 0,
                    'extra'=>[
                        'company_name'     => $formdata['client_company_name'],
                        'address'     => $formdata['client_address'],
                        'locality'     => $formdata['client_locality'],
                        'zip_code'     => $formdata['client_zip_code'],
                        'country_code'     => $formdata['client_country_code'],
                        'state_name'     => $formdata['client_state_name'],
                    ],
                    'status'   => 1,
                ]);
            }

            do {
                $slug = substr(str_shuffle('123456789'), 0, 10);
            } while (Company::where('company_slug', $slug)->exists());

            $client = User::create([
                'name'              => $formdata['client_name'],
                'email'             => $formdata['client_email'],
                'phone'             => $formdata['client_phone'] ?? null,
                'status'            => 0,
                'email_verified_at' => now(),
                'is_email_verified'=> true,
                'password'          => Hash::make('admin@1223')
            ]);

            Company::create([
                'company_name'  => $formdata['client_name'],
                'company_slug'  => $slug,
                'company_email' => $formdata['client_email'],
                'admin_id'      => $client->id,
            ]);

            $client->syncRoles(['Company']);
            return $client;
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }

    public function deleteDeliveryNote($id)
    {
        try {
            DeliveryNotes::destroy($id);
            // Return success response
            return response()->json(['success' => true, 'message' => __('Delivery Note deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Delivery Note. Please try again.')], 500);
        }
    }

    public function updateDeliveryNotestatus(Request $request)
    {
        try {
            $formdata = $request->all();
            if (!isset($formdata['status']) || is_null($formdata['status'])) {
                return response()->json(['success' => false, 'message' => __('Status is required')], 200);
            }

            if (!isset($formdata['id']) || empty($formdata['id'])) {
                return response()->json(['success' => false, 'message' => __('Delivery Note id is required')], 200);
            }
            // Attempt to delete the user by ID
            

            
            $editUrl = '';
           

            DeliveryNotes::where('id', $formdata['id'])->update(['status' => $formdata['status']]);

            // Return success response
            return response()->json(['success' => true,"editurl"=>$editUrl,'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function previewDeliveryNote($deliveryNoteId)
    {
        try{
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $deliveryNote = DeliveryNotes::findOrFail($deliveryNoteId);
            $templateId = env('DELIVERY_NOTE_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            // dd($company);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     // dd('hi');
            //     $deliveryNote->generateInvoiceQrCode();
            // }
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $deliveryNote, $company);


            $data = [
                'id' => $deliveryNote->id,
                'deliveryNote_no' => $deliveryNote['delivery_note_id'] ?? null,
                'customer_name' => $deliveryNote->client->name ?? null,
            ];


            return view('invoice.singlePreview', ['templateHtml' => $datahtml, 'data' => $data]);

            // return view('panel.delivery-notes.preview', ['templateHtml' => $datahtml, 'data' => $data]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function downloadDeliveryNote($deliveryNoteId)
    {
        $deliveryNote = DeliveryNotes::findOrFail($deliveryNoteId);
        $authUser = auth()->user();
        $company = $authUser->company instanceof \Illuminate\Database\Eloquent\Collection
            ? $authUser->company->first()
            : $authUser->company;

        $user = $company
            ? User::where('id', $company->admin_id)->first()
            : User::find(1);

        $templateId = env('DELIVERY_NOTE_TEMPLATE_ID');
        $template = Templates::where('id', $templateId)->first() 
            ?? Templates::where('status', 1)->first();

        $datahtml = parseInvoiceSortcodes($template->template_html, $deliveryNote, $company);

        $storagePath = rtrim(public_path('storage/'), '/') . '/';
        $baseUrl = rtrim(asset('storage'), '/') . '/';

        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );

        if (isset($deliveryNote->extra['policies']) && !empty($deliveryNote->extra['policies'])) {
            $policiesHtml = $deliveryNote->extra['policies'] ?? '';

            if (!empty($policiesHtml)) {
                $datahtml .= '<div style="page-break-before: always;"></div>';
                $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
            }
        }

        // ✅ Generate PDF
        $pdf = PDF::loadHTML($datahtml)->setPaper('a4', 'portrait');

        return $pdf->download("deliveryNote-{$deliveryNoteId}-{$deliveryNote->issue_date}.pdf");
    }


    public function sendEmail(Request $request)
    {
        try {
            $dynamicTableName = (new DeliveryNotes())->getTable();
            // Validate request input
            $formdata = $request->validate([
                'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
                'comment' => 'nullable|string',
            ]);
            // dd($formdata);

            $deliveryNoteId = $formdata['id'];

            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $deliveryNote = DeliveryNotes::findOrFail($deliveryNoteId);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     $deliveryNote->generateInvoiceQrCode();
            // }
            $templateId = env('DELIVERY_NOTE_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            // dd($template);
            $datahtml = parseInvoiceSortcodes($template->template_html, $deliveryNote, $company);

            
            $data = [
                'id' => $deliveryNote->id,
                'deliveryNote_no' => $deliveryNote['delivery_note_id'] ?? null,
                'customer_name' => $deliveryNote->client->name ?? null,
                'comment'=>$formdata['comment'] ?? null
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

            // Get the base URL dynamically
            $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );
            // dd($datahtml);
            
            if (isset($deliveryNote->extra['policies']) && !empty($deliveryNote->extra['policies'])) {
                $policiesHtml = $deliveryNote->extra['policies'] ?? '';

                if (!empty($policiesHtml)) {
                    $datahtml .= '<div style="page-break-before: always;"></div>';
                    $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
                }
            }

            // Generate PDF from the modified HTML
            $pdfContent = PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $altEmails = $deliveryNote->client->extra['alternative_email'] ?? $deliveryNote->client->email;
            }else{
                $clientCompany = Company::where('admin_id',$deliveryNote->client->id)->first();
                $altEmails = $clientCompany->extra['alternative_email'] ?? $deliveryNote->client->email;
            }
            
            if (is_string($altEmails)) {
                $emails = array_filter(array_map('trim', explode(',', $altEmails)));
            } elseif (is_array($altEmails)) {
                $emails = array_filter(array_map('trim', $altEmails));
            } else {
                $emails = [];
            }

            if (empty($emails)) {
                $emails = [$invoice->client->email];
            }

            $emails = array_unique(array_filter($emails));

            foreach ($emails as $email) {
                Mail::to($email)->send(new SystemEmail(
                    __('Please check your deliveryNote'),
                    'emails.deliveryNote-template', // Replace with your Blade view path
                    $data, // Dynamic data
                    $pdfContent, // Attach generated PDF content
                    "deliveryNote-{$deliveryNoteId}.pdf", // Optional file name for the PDF,
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'] 
                ));

            }
            // Send email with the PDF attachment
            // Mail::to($email)->send(new SystemEmail(
            //     __('Please check your deliveryNote'),
            //     'emails.deliveryNote-template', // Replace with your Blade view path
            //     $data, // Dynamic data
            //     $pdfContent, // Attach generated PDF content
            //     "deliveryNote-{$deliveryNoteId}.pdf", // Optional file name for the PDF,
            //     'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'],
            //     null,
            //     $company->user->email ?? 'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'] 
            // ));

            if($deliveryNote->status != 'accepted' && $deliveryNote->status != 'accepted'){
                $deliveryNote->status = 'sent'; //2 represents 'sent'
            }
            $deliveryNote->save();
            return response()->json([
                'success' => true,
                'message' => __('Delivery Note sent successfully.'),
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    // public function calculateDeliveryNotes(Request $request)
    // {
    //     try{
    //         $authUser = auth()->user();
    //         $company = $authUser->company;
        
    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             $company = $company->first();
    //         }
        
    //         $type = '';
    //         $retencion_rate = 0; // Default to 0
    //         $tax_slab_id = 1; // Default tax slab
        
    //         if ($company) {
    //             $type = $company->type ?? '';
    //             $retencion_id = $company->extra['retencion'] ?? TaxRules::where('tax_type', 'retention')->orderBy('id', 'asc')->pluck('id')->first();
    //             // $retencion_rate = $company->extra['retencion_rate'] ?? 15;
    //             $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
    //         } else {
    //             $adminUser = User::where('id', 1)->first();
    //             $type = $adminUser->extra['type'] ?? '';
    //             $retencion_id = $adminUser->extra['retencion'] ?? TaxRules::where('tax_type', 'retention')->orderBy('id', 'asc')->pluck('id')->first();
    //             // $retencion_rate = $adminUser->extra['retencion_rate'] ?? 15;
    //             $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();

    //         }
    //         $retention = TaxRules::where('id', $retencion_id)->first();
    //         // $retencion_rate = $retention->value;
    //         // $retencion_rate
    //         // Fetch tax rule
    //         $taxRule = TaxRules::where('id', $tax_slab_id)->first();
        
    //         $items = $request->items; // Get items array
    //         $currency = $request->currency ?? '$'; // Default currency
        
    //         $subtotal = 0;
    //         $totalDiscount = 0;
    //         $totalTax = 0;
    //         $totalRetencion = 0;
    //         $processedItems = [];
        
    //         foreach ($items as $item) {
    //             $quantity = (float) ($item['quantity'] ?? 0);
    //             $price = parseNumber($item['price'] ?? 0);
    //             $discount = parseNumber($item['discount'] ?? 0);
    //             $discountPercentage = parseNumber($item['discount_percentage'] ?? 0);
    //             $usePercentage = $item['use_percentage'] ?? false;
    //             $tax = parseNumber($item['tax'] ?? 0);
    //             $taxType = $item['tax_type'] ?? 'percentage'; // Default to percentage if not provided
    //             $rowSubtotal = $quantity * $price;
            
    //             if ($quantity == 0) {
    //                 $rowSubtotal = 0;
    //                 $discount = 0;
    //                 $discountPercentage = 0;
    //                 $rowTax = 0;
    //                 $rowRetencion = 0;
    //                 $rowAmountBeforeRetention = 0;
    //             } else {
    //                 // Calculate discount
    //                 if ($usePercentage) {
    //                     $discount = ($rowSubtotal * $discountPercentage) / 100;
    //                 } else {
    //                     $discountPercentage = $rowSubtotal != 0 ? ($discount / $rowSubtotal) * 100 : 0;
    //                 }
            
    //                 // dd($discount);
    //                 // **Apply tax based on tax type**
    //                 if ($taxType === 'fixed') {
    //                     $rowTax = $tax; // Use fixed tax value directly
    //                 } else { // Assume 'percentage'
    //                     $rowTax = (($rowSubtotal - $discount) * $tax) / 100;
    //                 }

    //                 // if ($taxType === 'fixed') {
    //                 //     $retencion_rate = (($rowSubtotal - $discount) * $retention->value) / 100; // Use fixed tax value directly
    //                 // } else { // Assume 'percentage'
    //                 //     $retencion_rate = $retention->value;
    //                 // }
            
    //                 // Apply retention (only if 'individual' or retention rate is set)
    //                 $rowRetencion = 0;
    //                 if ($type === 'individual' && $retencion_rate > 0) {
    //                     $rowRetencion = (($rowSubtotal - $discount) * $retencion_rate) / 100;
    //                 }
            
    //                 // Amount before retention
    //                 $rowAmountBeforeRetention = $rowSubtotal - $discount + $rowTax;
    //             }
            
    //             // Final row amount (for total calculation)
    //             $rowAmountFinal = $rowAmountBeforeRetention - $rowRetencion;
            
    //             // Accumulate totals
    //             $subtotal += $rowSubtotal;
    //             $totalDiscount += $discount;
    //             $totalTax += $rowTax;
    //             $totalRetencion += $rowRetencion;
            
    //             // Formatting values
    //             $formattedRowSubTotal = formatValue($rowSubtotal, $currency);
    //             $formattedRowTaxApplied = formatValue($rowTax, $currency);
    //             $formattedRowRetencionApplied = formatValue($rowRetencion, $currency);
    //             $formattedRowAmountBeforeRetention = formatValue($rowAmountBeforeRetention, $currency);
            
    //             $processedItems[] = [
    //                 'quantity' => $quantity,
    //                 'price' => $item['price'],
    //                 'price_unformatted' => $price,
    //                 'price_formatted' => formatPrice($price, $currency),
    //                 'subtotal' => $rowSubtotal,
    //                 'subtotal_formatted' => formatValueCurrency($formattedRowSubTotal, $currency),
    //                 'discount' => $item['discount'],
    //                 'discount_unformatted' => $discount,
    //                 'discount_formatted' => formatValue($discount, $currency),
    //                 'discount_percentage' => $discountPercentage,
    //                 'discount_percentage_formatted' => formatValue($discountPercentage, $currency),
    //                 'tax' => $tax,
    //                 'tax_type' => $taxType,
    //                 'tax_unformatted' => $tax,
    //                 'tax_formatted' => formatValue($tax, $currency),
    //                 'tax_applied' => $rowTax,
    //                 'tax_applied_formatted' => formatValueCurrency($formattedRowTaxApplied, $currency),
    //                 'retencion' => $retencion_rate,
    //                 'retencion_unformatted' => $retencion_rate,
    //                 'retencion_formatted' => formatValue($retencion_rate, $currency),
    //                 'retencion_applied' => $rowRetencion,
    //                 'retencion_applied_formatted' => formatValueCurrency($formattedRowRetencionApplied, $currency),
    //                 'row_amount' => $rowAmountBeforeRetention,
    //                 'row_amount_formatted' => formatValueCurrency($formattedRowAmountBeforeRetention, $currency),
    //             ];
    //         }
            
        
    //         // Calculate final totals
    //         $grandTotal = $subtotal - $totalDiscount + $totalTax - $totalRetencion;
    //         $formattedSubTotal = formatValue($subtotal, $currency);
    //         $formattedTotalDiscount = formatValue($totalDiscount, $currency);
    //         $formattedTotalTax = formatValue($totalTax, $currency);
    //         $formattedTotalRetencion = formatValue($totalRetencion, $currency);
    //         $formattedGrandTotal = formatValue($grandTotal, $currency);
        
    //         return response()->json([
    //             'subtotal' => $subtotal,
    //             'subtotal_formatted' => formatValueCurrency($formattedSubTotal, $currency),
    //             'total_discount' => $totalDiscount,
    //             'total_discount_formatted' => formatValueCurrency($formattedTotalDiscount, $currency),
    //             'total_tax' => $totalTax,
    //             'total_tax_formatted' => formatValueCurrency($formattedTotalTax, $currency),
    //             'total_retencion' => $totalRetencion,
    //             'total_retencion_formatted' => formatValueCurrency($formattedTotalRetencion, $currency),
    //             'grand_total' => $grandTotal,
    //             'grand_total_formatted' => formatValueCurrency($formattedGrandTotal, $currency),
    //             'items' => $processedItems,
    //         ]);
    //     } catch (\Throwable $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => __('Something went wrong.'),
    //         ], 500);
    //     }
    // }

    public function calculateDeliveryNotes(Request $request)
    {
        $data = $request->all();
        return response()->json(UtilityService::calculate($data));
    }
    
    public function convertDeliveryNoteToFactura($id){
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = DeliveryNotes::where('id', $id)->first();

            // dd($invoice);
            if($invoice->status == 'accepted'){
                return redirect()->back()->with('error', __('Already generated Invoice.'));
            }
            // $clients = Clients::where('status',1)->get();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
            
                
            }
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
               
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $taxslab = TaxRules::where('country', 'es')->where('tax_type', 'iva')->where('type', 'percentage')->get();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $country = CountryModel::all();
            return view('panel.delivery-notes.add-invoice', compact('invoice','country', 'paymentMethods', 'services','taxslab', 'invoicePrefixs','invoiceType', 'inventories', 'clients','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateStatusToAccepted(Request $request,$id){
        try {
            
            // Attempt to delete the user by ID
            DeliveryNotes::where('id', $id)->update(['status' => 'accepted']);

            

            // Return success response
            return response()->json(['success' => true,'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }
}
