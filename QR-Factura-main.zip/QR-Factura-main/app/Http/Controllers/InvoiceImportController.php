<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\InvoiceImport;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Exception;

class InvoiceImportController extends Controller
{
    /**
     * Handle invoice import
     */
    public function import(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv|max:5120',
        ]);

        $file = $request->file('file');
        try {
            $import = new InvoiceImport;
            DB::transaction(function () use ($import, $file) {
                Excel::import($import, $file);
            });

            $failures = $import->failures();

            if ($failures->isNotEmpty()) {
                $token = Str::uuid()->toString();
                $filePath = "imports/failed_import_{$token}.json";

                $data = [
                    'total_rows' => $import->getRowCount() ?? 0,
                    'failed_count' => count($failures),
                    'failures' => $failures->map(function ($failure) {
                        return [
                            'row' => $failure->row(),
                            'attribute' => $failure->attribute(),
                            'errors' => $failure->errors(),
                            'values' => $failure->values(),
                        ];
                    })->values(),
                ];

                Storage::disk('local')->put($filePath, json_encode($data, JSON_PRETTY_PRINT));

                return redirect()->route('admin.invoices.import.errors', ['token' => $token]);
            }

            return redirect()->route('getInvoices')->with('success', 'All invoices imported successfully.');
        } catch (Exception $e) {
            return redirect()->back()->with('error', 'Import failed: ' . $e->getMessage());
        }
    }

    /**
     * Show errors page
     */
    public function showErrors($token)
    {
        $filePath = "imports/failed_import_{$token}.json";

        if (!Storage::disk('local')->exists($filePath)) {
            return redirect()->route('invoices.index')->with('error', 'Error file not found or expired.');
        }
        // dd($filePath);
        $data = json_decode(Storage::disk('local')->get($filePath), true);

        return view('panel.invoice.import_errors', [
            'data' => $data,
            'token' => $token,
        ]);
    }

    /**
     * Download failed rows as CSV
     */
    public function downloadFailed($token)
    {
        $filePath = "imports/failed_import_{$token}.json";

        if (!Storage::disk('local')->exists($filePath)) {
            abort(404, 'File not found');
        }

        $data = json_decode(Storage::disk('local')->get($filePath), true);

        $csvFileName = "failed_invoices_{$token}.csv";
        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, ['Row', 'Field', 'Error', 'Values']);

        foreach ($data['failures'] as $failure) {
            fputcsv($handle, [
                $failure['row'],
                $failure['attribute'],
                implode('; ', $failure['errors']),
                json_encode($failure['values']),
            ]);
        }

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename={$csvFileName}");
    }
}
