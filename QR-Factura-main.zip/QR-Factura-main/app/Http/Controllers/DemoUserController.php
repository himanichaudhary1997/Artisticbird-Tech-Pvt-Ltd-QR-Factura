<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Menu;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Company;
use Illuminate\Support\Str;
use App\Models\SubscriptionPlans;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Permission;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use App\Jobs\SubscriptionReminderJob;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\TaxRules;

class DemoUserController extends Controller
{

    public function addDemoCompany(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            $user_subscription_id = $formdata['user_subscription_id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email',
                'phone' => 'nullable|numeric|digits_between:8,15',
            ];
            $alreadyUser = User::where('email', $formdata['email'])->first();
            if(!empty($alreadyUser)){
                $subject = "You have already account with us";
                $view = 'emails.already-user'; // View file path without .blade.php
                $data = [
                    'name' => $alreadyUser->name,
                    'email' => $alreadyUser->email,
                ];

                Mail::to($alreadyUser->email)->send(new SystemEmail($subject, $view, $data));
                return response()->json([
                    'success' => false,
                    'message' => __('User already exists.'),
                ], 200);
            }
            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }


            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                'extra'=> ['is_demo_user'=>true],
                // 'status'=> $formdata['status'],
            ];

            $user_data['email_verified_at'] = now();
            $user_data['is_email_verified'] = true;
            $password = $user_model->generateRandomPassword();
            $user_data['password'] = Hash::make($password);

            User::create($user_data);
            $user = User::where('email', $formdata['email'])->first();
            $user->syncRoles(['Company']);
            
            do {
                // Get digits 1 to 9 and shuffle them
                $digits = range(1, 9);
                shuffle($digits);
            
                // Add an extra random digit from 1 to 9 to make it 10 digits
                $slug = implode('', $digits) . rand(1, 9);
            } while (Company::where('company_slug', $slug)->exists());

            if(!empty($user)){

                $company_data = [
                    'company_name'=>$formdata['company_name'] ?? $formdata['name'],
                    'company_email'=>$formdata['email'],
                    'gst_no'=>$formdata['gst_no'] ?? null,
                    'type'=>'company',
                    'extra'=>['language'=>'en'],
                ];

                $company_data['admin_id']=$user->id;
                $company_data['company_slug']=$slug;
                $company = Company::create($company_data);
            }
            
            
            $plan_id = 2;
            $subscriptionPlan = SubscriptionPlans::where('id',$plan_id)->first();
            $subscriptionData = [
                'subscription_id'=> $plan_id,
                'time'=>$subscriptionPlan->time_period ?? 1,
            ];
            $planDates = $user_model->getStartAndEndDate($subscriptionData['time']);
            $subscriptionData['start_date']=$planDates['start_date'];
            $subscriptionData['end_date']=$planDates['end_date'];
            $subscriptionData['user_id'] = $user->id;
            $userSubscription = UserSubscriptions::create($subscriptionData);


            // dd($formdata['renew_plan']);
            $subject = "Please check your demo login details";
            $view = 'emails.send-demo-details'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'password' => $password,
            ];

            Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('User updated successfully.') 
                    : __('User created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }
}
