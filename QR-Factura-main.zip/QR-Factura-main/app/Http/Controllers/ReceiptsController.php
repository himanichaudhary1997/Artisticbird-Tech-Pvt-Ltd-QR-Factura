<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Receipts;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use Exception;
use Dompdf\Dompdf;
use Dompdf\Options;
use App\Models\ActivityLog;
use Vinkla\Hashids\Facades\Hashids;


use App\Services\FiskalyInvoiceService;
use App\Services\InvoiceService;

class ReceiptsController extends Controller
{
    
    protected $fiskaly;
    const NEGATIVE_INVOICE = 4;

    public function __construct(FiskalyInvoiceService $fiskaly, InvoiceService $invoiceService)
    {
        $this->fiskaly = $fiskaly;
        $this->invoiceService = $invoiceService;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
           
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = Receipts::whereNull('reference_id');

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }

            if(empty(getDomainId())){
                $query->whereNull('domain_id');
            }else{
                $query->where('domain_id',getDomainId());
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('receipt_id', 'like', '%' . $searchTerm . '%')->orWhere('ref_no', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($formdata) {
                            $query->where('name', 'like', '%' . $formdata['search'] . '%')
                                    ->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $formdata['search'] . '%']);
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
            

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('created_at', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('created_at', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('created_at', '<=', $formdata['to_date']);
            }

            // Check if the user is not an Admin and role is neither 1 nor 2
            // if (!$user->hasRole('Admin') && !$user->hasRole('Company') ) {
            //     $query->where('created_by', $user->id);
            // }

            $targetCurrency = $baseCurrency = '€';
            $receipts = $query->orderBy('id','DESC')->with(['client'])->paginate($limit);

            $monthlyTotals = [];
            $totalYearGrandTotal = 0;
            $totalYearTax = 0;
            $totalYearSubTotal = 0;

            foreach ($receipts as $receipt) {
                $receiptCurrency =  $baseCurrency;
                $month = date('m', strtotime($receipt->created_at));
                $year = date('Y', strtotime($receipt->created_at));
                $monthYearKey = date('F Y', strtotime($receipt->created_at));
                
                if (!isset($monthlyTotals[$monthYearKey])) {
                    $monthlyTotals[$monthYearKey] = [
                        'month' => $month,
                        'year' => $year,
                        'monthYear' => $monthYearKey,
                        'grandTotal' => 0, 
                        'tax' => 0,
                        'formattedGrandTotal' => '',
                        'formattedTax' => ''
                    ];
                }

                $grandTotal = parseNumber($receipt->grandTotal ?? 0);
                $totalTax = parseNumber($receipt->totalTax ?? 0);
                $subTotal = parseNumber($receipt->subtotal) - parseNumber($receipt->totalDiscount ?? 0);

                // Convert to base currency if different
                if ($receiptCurrency !== $baseCurrency) {
                    $rate = $exchangeRates[$receiptCurrency] ?? 1;
                    $grandTotal = $grandTotal / $rate;
                    $totalTax = $totalTax / $rate;
                }

                // Accumulate totals
                $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
                $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                
                $totalYearGrandTotal += $grandTotal;
                $totalYearTax += $totalTax;
                $totalYearSubTotal += $subTotal;
            }
            $totalYearGrandTotal = formatValueCurrency(
                formatValue($totalYearGrandTotal, $targetCurrency),
                $targetCurrency
            );
            $totalYearTax = formatValueCurrency(
                formatValue($totalYearTax, $targetCurrency),
                $targetCurrency
            );

            $totalYearSubTotal = formatValueCurrency(
                formatValue($totalYearSubTotal, $targetCurrency),
                $targetCurrency
            );

            // Sort by year and month (newest first)
            uasort($monthlyTotals, function($a, $b) {
                if ($a['year'] == $b['year']) {
                    return $b['month'] <=> $a['month'];
                }
                return $b['year'] <=> $a['year'];
            });

            // Format all values
            foreach ($monthlyTotals as &$totals) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );
            }


            if ($request->ajax()) {
                return view('panel.verifactu-receipt.partial_data', compact('receipts','totalYearGrandTotal','totalYearTax','totalYearSubTotal','targetCurrency'))->render();
            }

            return view('panel.verifactu-receipt.index-receipt', compact('receipts','totalYearGrandTotal','totalYearTax','totalYearSubTotal','targetCurrency'));
        }catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addReceipts()
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $receipt = Receipts::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }

            // $templates = Templates::get();
            
            $defaultCurrency =  '€';
            
            if(!empty($company)){
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.verifactu-receipt.add-receipt', compact('inventories','clients','defaultCurrency','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditReceipts(Request $request)
    {

        try {
          
            $formdata = $request->all();
            $user = Auth::user();
            $company = $user->company;
            $receipt_id = $formdata['id'] ?? null;
            $adminUser = User::where('id',$company->admin_id ?? 1)->first();

            if ($company && $company->user->subscriptionDetails->subscription) {
                $totalLeftReceipt = $company->user->subscriptionDetails->receipts ?? $company->user->subscriptionDetails->subscription->receipts ?? null;


                // Count invoices issued in the same month & year as the issue_date
                $totalCreatedReceipt = Receipts::whereBetween('created_at', [
                    $company->user->subscriptionDetails->start_date,
                    $company->user->subscriptionDetails->end_date,
                ])->count();

                // Only check limit if it's NOT unlimited (null means unlimited)
                if (!is_null($totalLeftReceipt) && $totalCreatedReceipt >= $totalLeftReceipt) {
                    return response()->json([
                        'success' => false,
                        'message' => __("You can't create more receipts. Total Limit Reached. Contact Administrator."),
                    ], 200);
                }
            }

            if($company){
                $gst_no = $company->gst_no ?? null;
            }else{
                $gst_no = $adminUser->extra['gst_no'] ?? null;
            }

            if($formdata['grandTotal'] > 3000){
                return response()->json([
                    'success' => false,
                    'message' => __('You can\'t create receipts more that 3000.'),
                ], 200);
            }

            if(empty($gst_no)){
                return response()->json([
                    'success' => false,
                    'message' => __('Please add GST number in company settings to add receipt.'),
                ], 200);
            }

            

            // Validate request data
            $validator = $this->validateReceipts($formdata,$company);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $items = $this->processReceiptsItems($formdata['items'], '€');
    
            // if ($formdata['client_id'] === 'new-client') {
            //     $client = $this->handleNewClient($formdata, $company);
            //     $formdata['client_id'] = $client->id;
            // }
        
            $receipt_data = [
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
            ];
            // dd($formdata['extra']);

            
            
            if (empty($receipt_id)) {
                $receipt_data['receipt_id'] =  $this->invoiceService->generateInvoiceId(now(), $company, 'ticket');
                $receipt_data['ref_no']  =   $receipt_data['receipt_id'];
                $receipt_data['created_by'] = $user->id;
                $receipt_data['extra']= $formdata['extra'] ?? null;
                $receipt_data['issue_date']= now();
                $receipt = Receipts::create($receipt_data);
                
            } else {
                $oldReceipt = Receipts::find($receipt_id);
                Receipts::where('id', $receipt_id)->update($receipt_data);
                $receipt = Receipts::find($receipt_id);

                // ✅ Merge only incoming keys into existing extra
                if (!empty($formdata['extra']) && is_array($formdata['extra'])) {
                    $receipt->extra = array_merge($receipt->extra ?? [], $formdata['extra']);
                    $receipt->save();
                }

            }

            if(empty($receipt->qr_code)){
                if(auth()->user()->company && auth()->user()->company->is_verifactu && !$receipt->is_verified){
                    // dd($receipt);
                    $fiskalyReceipt = $this->fiskaly->createReceipt($company,$receipt);
                    //dd($fiskalyReceipt);

                    ActivityLog::create([
                        'user_id' => $user->id,
                        'company_id'=>$company->id ?? null,
                        'action' => 'Verified Receipt '. $receipt->receipt_id,
                        'ip_address' => $request->ip()
                    ]);
                    //dd($fiskalyInvoice);
                }elseif(auth()->user()->company && !auth()->user()->company->is_verifactu){
                    $receipt->generateReceiptsQrCode();
                }
            }

            

            return response()->json([
                'success' => true,
                'message' => $receipt_id ? __('Receipt updated successfully.') : __('Receipt created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditReceipt: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' =>$e->getMessage(),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    private function validateReceipts($data,$company)
    {
        try {
            $table = $company ? (new Clients)->getTable() : (new User)->getTable();
            return Validator::make($data, [
                // 'client_id'      => 'required',
                'items'           => 'required|array|min:1',
                'items.*.name' => 'required',
                'items.*.quantity'=> 'required|numeric|min:1',
                'items.*.price'   => 'required|min:0',
                'items.*.discount'=> 'nullable|min:0',
                'items.*.tax'     => 'nullable|min:0|max:100',
                'items.*.amount'  => 'required',
                'client_email'   => [
                    'required_if:client_id,new-client',
                ],
                'client_name'     => 'required_if:client_id,new-client',
            ], [
                'client_email.required_if' => __('Client email is required for a new client.'),
                'client_name.required_if'  => __('Client name is required for a new client.'),
                'client_email.email'       => __('Please provide a valid email address for the client.'),
                'client_email.unique'      => __('The client email already exists.'),
                'items.required'            => __('At least one item is required in the receipt.'),
                'items.*.name.required'  => __('Please Select any item.'),
                'items.*.quantity.required' => __('Each item must have a quantity.'),
                'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
                'items.*.quantity.min'      => __('The quantity must be at least 1.'),
                'items.*.price.required'    => __('Each item must have a price.'),
                'items.*.price.min'         => __('The price must be at least 0.'),
                'items.*.discount.min'      => __('The discount must be at least 0.'),
                'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
                'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
                'items.*.amount.required'   => __('Each item must have an amount.'),
                'extra.note.string' => __('The note must be a valid text.'),
                'extra.note.max' => __('The note cannot be longer than 300 characters.'),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 200);
        }
    }


    private function processReceiptsItems($items, $currency)
    {
        // try {
            $processedItems = [];

            foreach ($items as $item) {
                
                

                if ($item['name'] === 'new-inventory') {
                    $item['name'] = $this->createNewInventoryItem($item);
                }

                
                // dd($item);

                $processedItems[] = $item;
            }

            return $processedItems;
        // }
        //     catch (\Exception $e) {
        //         return response()->json([
        //             'success' => false,
        //             'message' => __('Something went wrong.')
        //         ], 500);
        //     }
    }


    private function createNewInventoryItem($item)
    {
        if (empty($item['new_inventory'])) {
            throw new \Exception(__('Please enter inventory name.'));
        }

        if (Inventory::where('name', $item['new_inventory'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_inventory'] . '" already exists.'));
        }

        $inventory = Inventory::create([
            'name'      => $item['new_inventory'],
            'slug'      => str_replace(' ', '-', strtolower($item['new_inventory'])),
            'price'     => parseInventoryServicePrice($item['price']),
            'quantity'  => 0,
            'tax_rate'  => $item['tax'],
            'discount'  => parseNumber($item['discount']),
            'status'    => 1,
        ]);

        return $inventory->name;
    }
    
    private function handleNewClient($formdata, $company)
    {
        try{
            if ($company) {
                return Clients::create([
                    'name'     => $formdata['client_name'],
                    'email'    => $formdata['client_email'],
                    'mobile_no'=> $formdata['client_phone'],
                    'status'   => 1,
                ]);
            }

            do {
                $slug = substr(str_shuffle('123456789'), 0, 10);
            } while (Company::where('company_slug', $slug)->exists());

            $client = User::create([
                'name'              => $formdata['client_name'],
                'email'             => $formdata['client_email'],
                'phone'             => $formdata['client_phone'] ?? null,
                'status'            => 0,
                'email_verified_at' => now(),
                'is_email_verified'=> true,
                'password'          => Hash::make('admin@1223')
            ]);

            Company::create([
                'company_name'  => $formdata['client_name'],
                'company_slug'  => $slug,
                'company_email' => $formdata['client_email'],
                'admin_id'      => $client->id,
            ]);

            $client->syncRoles(['Company']);
            return $client;
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }


    // private function generateReceiptsId($issue_date, $company, $user, $formdata)
    // {
    //     try {
    //         $year = date('Y', strtotime($issue_date));
    //         $companyInitials = 'TK'; // or derive dynamically if needed

    //         // ✅ Get max number used so far for this year + company
    //         $latestNumber = Receipts::where('receipt_id', 'LIKE', "$year/$companyInitials/%")
    //             ->selectRaw("MAX(CAST(SUBSTRING_INDEX(receipt_id, '/', -1) AS UNSIGNED)) as max_number")
    //             ->value('max_number');

    //         $nextReceiptNumber = $latestNumber ? $latestNumber + 1 : 1;

    //         return sprintf('%s/%s/%04d', $year, $companyInitials, $nextReceiptNumber);

    //     } catch (\Exception $e) {
    //         throw new \Exception($e->getMessage());
    //     }
    // }



    public function previewReceipts(Request $request, $id)
    {
        try {
            $user     = Auth::user();
            $receipt  = Receipts::with('client')->where('id', $id)->firstOrFail();
            $company  = $user->company;
            $client   = $receipt->client;
            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? $user->extra['country_code'] ?? null)->first();
            // ✅ Render Blade template to HTML string
            $html = view('panel.verifactu-receipt.receipt_html', compact('client','country','receipt', 'company', 'user'))->render();

            // ✅ Pass the HTML into preview page
            return view('panel.verifactu-receipt.preview', compact('client', 'receipt', 'company', 'user', 'html'));

        } catch (\Exception $e) {
            throw new \Exception(
                    "Error on line {$e->getLine()} in file {$e->getFile()}: {$e->getMessage()}"
                );
        }
    }

    public function downloadReceipts(Request $request, $id)
    {
        try {
            $user     = Auth::user();
            $receipt  = Receipts::with('client')->findOrFail($id);
            // dd($receipt);
            $company  = $user->company;
            $client   = $receipt->client;

            $countryCode = $company->extra['country_code'] 
                            ?? $user->extra['country_code'] 
                            ?? null;

            $country = CountryModel::where('country_code', $countryCode)->first();

            // Render Ticket HTML
            $html = view('pdf.ticket', compact(
                'client','country','receipt','company','user'
            ))->render();


            // ---- DomPDF Setup ---- //
            $options = new Options();
            $options->set('isRemoteEnabled', true);  // allow external logos
            $options->set('isHtml5ParserEnabled', true);
            $options->set('defaultFont', 'Arial');

            $dompdf = new Dompdf($options);
            $dompdf->loadHtml($html);



            $ticketWidthMm = 80;
            $ticketWidthPts = $ticketWidthMm * 2.83465;
            $ticketHeightPts = 800;

            $dompdf->setPaper([0, 0, $ticketWidthPts, $ticketHeightPts], 'portrait');
            $dompdf->render();
            
            return $dompdf->stream('receipt_' . $receipt->id . '.pdf', [
                'Attachment' => true
            ]);

        } catch (\Exception $e) {

            // Better error handling
            return response()->json([
                'status'  => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function makeReceiptVerified(Request $request,$id){
        try {
            $user = auth()->user();
            $company = $user->company;

            $receipt = Receipts::where('id',$id)->first();

            $fullAmount = parseNumber($receipt->grandTotal);
            // dd($fullAmount);
            if($fullAmount > 3000){
                if(empty($receipt->client->gst_no)){
                    return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Client Gst No is Required');
                }

                if(empty($receipt->client->extra['company_name'])){
                    return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Company Name is Required');
                }

                if (
                    empty($receipt->client->extra['address']) ||
                    empty($receipt->client->extra['locality']) ||
                    empty($receipt->client->extra['zip_code']) ||
                    empty($receipt->client->extra['country_code']) ||
                    empty($receipt->client->extra['state_code'])
                ) {
                    return redirect()->back()->with('error', 'Your Receipt Amount exceed 3000 in that case All address fields are required');
                }

            }

            $fiskalyReceipt = $this->fiskaly->createReceipt($company,$receipt);
            //dd($fiskalyReceipt);

            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Receipt '. $receipt->receipt_id,
                'ip_address' => $request->ip()
            ]);
            // dd($fiskalyReceipt);
            return redirect()->back()->with('success', $fiskalyReceipt['content']['message'] ?? 'Invoice Verified Successfully');
        } 
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function calculateReceipts(Request $request)
    {
        try {
            $authUser = auth()->user();
            $company = $authUser->company;
        
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }
        
            $type = '';
            $tax_slab_id = 1; // Default tax slab
        
            if ($company) {
                $type = $company->type ?? '';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            } else {
                $adminUser = User::where('id', 1)->first();
                $type = $adminUser->extra['type'] ?? '';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();

            }
            // Fetch tax rule
            $taxRule = TaxRules::where('id', $tax_slab_id)->first();
        
            $items = $request->items; // Get items array
            $currency = $request->currency ?? '$'; // Default currency
        
            $subtotal = 0;
            $totalDiscount = 0;
            $totalTax = 0;
            $processedItems = [];
        
            foreach ($items as $item) {
                $quantity = (float) ($item['quantity'] ?? 0);
                $price = parseNumber($item['price'] ?? 0);
                $discount = parseNumber($item['discount'] ?? 0);
                $discountPercentage = parseNumber($item['discount_percentage'] ?? 0);
                $usePercentage = $item['use_percentage'] ?? false;
                $tax = parseNumber($item['tax'] ?? 0);
                $taxType = $item['tax_type'] ?? 'percentage'; // Default to percentage if not provided
                $rowSubtotal = $quantity * $price;
            
                if ($quantity == 0) {
                    $rowSubtotal = 0;
                    $discount = 0;
                    $discountPercentage = 0;
                    $rowTax = 0;
                    $rowAmountBeforeRetention = 0;
                } else {
                    // Calculate discount
                    if ($usePercentage) {
                        $discount = ($rowSubtotal * $discountPercentage) / 100;
                    } else {
                        $discountPercentage = $rowSubtotal != 0 ? ($discount / $rowSubtotal) * 100 : 0;
                    }
            
                    // dd($discount);
                    // **Apply tax based on tax type**
                    if ($taxType === 'fixed') {
                        $rowTax = $tax; // Use fixed tax value directly
                    } else { // Assume 'percentage'
                        $rowTax = (($rowSubtotal - $discount) * $tax) / 100;
                    }

                  
            
                    // Amount before retention
                    $rowAmountBeforeRetention = $rowSubtotal - $discount + $rowTax;
                }
            
                // Final row amount (for total calculation)
            
                // Accumulate totals
                $subtotal += $rowSubtotal;
                $totalDiscount += $discount;
                $totalTax += $rowTax;
            
                // Formatting values
                $formattedRowSubTotal = formatValue($rowSubtotal, $currency);
                $formattedRowTaxApplied = formatValue($rowTax, $currency);
                $formattedRowAmountBeforeRetention = formatValue($rowAmountBeforeRetention, $currency);
            
                $processedItems[] = [
                    'quantity' => $quantity,
                    'price' => $item['price'],
                    'price_unformatted' => $price,
                    'price_formatted' => formatPrice($price, $currency),
                    'subtotal' => $rowSubtotal,
                    'subtotal_formatted' => formatValueCurrency($formattedRowSubTotal, $currency),
                    'discount' => $item['discount'],
                    'discount_unformatted' => $discount,
                    'discount_formatted' => formatValue($discount, $currency),
                    'discount_percentage' => $discountPercentage,
                    'discount_percentage_formatted' => formatValue($discountPercentage, $currency),
                    'tax' => $tax,
                    'tax_type' => $taxType,
                    'tax_unformatted' => $tax,
                    'tax_formatted' => formatValue($tax, $currency),
                    'tax_applied' => $rowTax,
                    'tax_applied_formatted' => formatValueCurrency($formattedRowTaxApplied, $currency),
                    'row_amount' => $rowAmountBeforeRetention,
                    'row_amount_formatted' => formatValueCurrency($formattedRowAmountBeforeRetention, $currency),
                ];
            }
            
        
            // Calculate final totals
            $grandTotal = $subtotal - $totalDiscount + $totalTax;
            $formattedSubTotal = formatValue($subtotal, $currency);
            $formattedTotalDiscount = formatValue($totalDiscount, $currency);
            $formattedTotalTax = formatValue($totalTax, $currency);
            $formattedGrandTotal = formatValue($grandTotal, $currency);
        
            return response()->json([
                'subtotal' => $subtotal,
                'subtotal_formatted' => formatValueCurrency($formattedSubTotal, $currency),
                'total_discount' => $totalDiscount,
                'total_discount_formatted' => formatValueCurrency($formattedTotalDiscount, $currency),
                'total_tax' => $totalTax,
                'total_tax_formatted' => formatValueCurrency($formattedTotalTax, $currency),
                'grand_total' => $grandTotal,
                'grand_total_formatted' => formatValueCurrency($formattedGrandTotal, $currency),
                'items' => $processedItems,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.'),
            ], 500);
        }
    }

    
    public function negativeIndex(Request $request)
    {
        try {
            // dd('test');
            $user = auth()->user();
            $company = $user->company;
            $limit = 30;

            $formdata = $request->query();
            $query = Receipts::whereNotNull('reference_id');

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('receipt_id', 'like', '%' . $searchTerm . '%')->orWhere('ref_no', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($formdata) {
                            $query->where('name', 'like', '%' . $formdata['search'] . '%')
                                    ->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $formdata['search'] . '%']);
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
            

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('created_at', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('created_at', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('created_at', '<=', $formdata['to_date']);
            }


            $receipts = $query->orderBy('id','DESC')->with(['client'])->paginate($limit);

            if ($request->ajax()) {
                return view('panel.verifactu-receipt.partial_data', compact('receipts'))->render();
            }

            return view('panel.verifactu-receipt.negative-receipt', compact('receipts'));
        }catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }



    public function addNegativeReceipts(){
       try {
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.verifactu-receipt.addNegativeReceipt', compact('inventories'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    
    public function getSearchResults(Request $request)
    {
        try {
            $searchTerm = $request->input('search');
            if (empty($searchTerm)) {
                return response()->json([]);
            }

            $user = auth()->user();
            $company = $user->company;

            $receipts = Receipts::whereNotNull('verifactu_id')    
                        ->where(function ($query) use ($searchTerm) {
                            $query->where('receipt_id', 'like', '%' . $searchTerm . '%');
                        })
                        ->limit(10)->orderBy('id','desc')
                        ->get();

            dd($receipts);
            $results = $receipts->map(function ($receipt) {
                $client = $receipt->client;
                $clientName = $client->company->company_name
                    ?? $client->extra['company_name']
                    ?? $client->name;
                

                return [
                    'receipt_id' => $receipt->receipt_id, // used to fill input
                    'text' => "{$clientName} - {$receipt->receipt_id}" // shown in dropdown
                ];
            });

            return response()->json($results);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
}
