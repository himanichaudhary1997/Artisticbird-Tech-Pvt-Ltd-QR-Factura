<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Clients;
use App\Models\Company;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use Exception;
use App\Models\ActivityLog;
use PhpOffice\PhpSpreadsheet\IOFactory;

use App\Services\FiskalyInvoiceService;

class ClientsConroller extends Controller
{
    
    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    // Function for Crud operation for Clients
    public function indexClients(Request $request)
    {
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 24;
            $formdata = $request->all();
            $company = $user->company;

            $client = Clients::where('id',2)->first();

            // $createClient = $this->fiskaly->createClient($client);
            // dd($createClient);

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

            if (!empty($company)) {
                $query = Clients::query();

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('mobile_no', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('gst_no', 'like', '%' . $formdata['search'] . '%')
                            ->orWhereRaw("JSON_SEARCH(LOWER(JSON_EXTRACT(extra, '$')), 'all', ?) IS NOT NULL",
                                ["%{$formdata['search']}%"]);
                    });
                }
            } else {
                $query = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    });

                // Apply search filter
                if (isset($formdata['search']) && !is_null($formdata['status'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            }

            if(isset($formdata['status'])){
                $query->where('status',$formdata['status']);
            }

            $clients = $query->orderBy('id','Desc')->paginate($limit);
            // dd($clients);
            if ($request->ajax()) {
                return view('panel.clients.partial_data', compact('clients'))->render();
            }

            return view('panel.clients.index-client', compact('clients'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateClientStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
    
            // Find the inventory item
            if(!empty($company)){
                $client = Clients::findOrFail($id);
                $client->status = $request->status;
                $client->save();
            }else{
                $user = User::findOrFail($id);
                $user->status = $request->status;
                $user->save();
            }
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Client status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Clients status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }

    public function getClients(Request $request)
    {
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 24;
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Base query excluding the authenticated user and filtering by role ID 2
            if (!empty($company)) {
                $query = Clients::query();

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('mobile_no', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            } else {
                $query = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    });

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            }


            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }



            // Fetch paginated results with related data
            $clients = $query->orderBy('id', 'DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Clients retrieved successfully.',
                'data' => $clients,
                'company' => $company ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve clients.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function addClients()
    {
        try{
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.clients.add-client', compact('country', 'states'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editClients($id)
    {
        try{
            $user = auth()->user();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

            if(!empty($company)){
                $client = Clients::FindorFail($id);
            }else{
                $client = User::FindorFail($id);
            }
            // $client = Clients::FindorFail($id);
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.clients.edit-client', compact('client', 'country', 'states'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditClients(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Extract form data
            $formdata = $request->all();
            $client_id = $formdata['id'] ?? null;
            $countryCode = $request->input('extra.country_code');
            if (!empty($company)) {
                $dynamicTableName = (new Clients())->getTable();
            } else {
                $dynamicTableName = (new User())->getTable();
            }

            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255|', // Ensures a valid email address
                'mobile_no' => 'nullable|digits_between:8,15', // Mobile number as a string with numeric validation
                'extra.company_name' => 'required|string|max:255',
                'extra.address' => 'required|string|max:255',
                'extra.locality' => 'required|string',
                'extra.zip_code' => 'required|string',
                'extra.country_code' => 'required|string',
                'extra.state_name' => 'required|string',
                 // GST number as a string
            ];
            // if(!empty($company)){
            //     $rules['gst_no'] = 'required|string|max:15|unique:'.$dynamicTableName.',gst_no,' . $client_id; 
            // }

            if (!empty($company)) {
                // $rules['gst_no'] = [
                //     'required',
                //     'string',
                //     'max:15',
                //     Rule::unique($dynamicTableName, 'gst_no')->ignore($client_id),

                //     // ── Spanish VAT validation ──────────────────────────────────────
                //     function ($attribute, $value, $fail) use ($countryCode) {
                //         if (strtoupper($countryCode) !== 'ES') {
                //             return; // Only validate for Spain
                //         }

                //         $value = strtoupper(trim($value));

                //         // Step 1: Basic format — ES + 9 alphanumeric chars
                //         if (!preg_match('/^ES[A-Z0-9]{9}$/', $value)) {
                //             $fail(__('validation.custom.gst_no.es_format'));
                //             return;
                //         }

                //         $body      = substr($value, 2); // strip "ES"
                //         $firstChar = $body[0];

                //         // Step 2: Route to correct algorithm
                //         if (ctype_digit($firstChar)) {
                //             // NIF — individual
                //             $error = self::validateSpanishNIF($body);
                //         } elseif (in_array($firstChar, ['X', 'Y', 'Z'])) {
                //             // NIE — foreigner
                //             $map       = ['X' => '0', 'Y' => '1', 'Z' => '2'];
                //             $converted = $map[$firstChar] . substr($body, 1);
                //             $error     = self::validateSpanishNIF($converted);
                //         } elseif (preg_match('/^[ABCDEFGHJKLMNPQRSUVW]$/', $firstChar)) {
                //             // CIF — company
                //             $error = self::validateSpanishCIF($body);
                //         } else {
                //             $error = __('validation.custom.gst_no.es_unknown_type');
                //         }

                //         if ($error) {
                //             $fail($error);
                //         }
                //     },
                // ];
                $rules['gst_no'] = [
                    'required',
                    'string',
                    'max:15',
                    Rule::unique($dynamicTableName, 'gst_no')->ignore($client_id),

                    function ($attribute, $value, $fail) use ($countryCode,$formdata) {

                        // Only validate for Spain
                        if (strtoupper($countryCode) !== 'ES' || empty($formdata['iscompany']) || (int)$formdata['iscompany'] !== 1) {
                            return;
                        }

                        $value = trim($value);

                        // Must start with A or B (uppercase only) + 8 digits
                        if (!preg_match('/^[AB][0-9]{8}$/', $value)) {
                            $fail(__('The Spanish C.I.F. number must begin with A or B followed by 8 digits.'));
                        }
                    },
                ];
            }
            // Validate the input data  
            $messages = [
                'extra.company_name.required' => __('validation.custom.extra.company_name.required'),
                'extra.company_name.string' => __('validation.custom.extra.company_name.string'),
                'extra.company_name.max' => __('validation.custom.extra.company_name.max'),
            ];

            // dd($formdata);
            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $clientId    = $formdata['id'] ?? null;
            $companyName = trim($formdata['extra']['company_name'] ?? '');
            $gstNo       = $formdata['gst_no'] ?? null;


            if (!empty($company) && $companyName !== '') {

                $query = Clients::whereRaw(
                    "LOWER(JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))) = ?",
                    [strtolower($companyName)]
                );

                // 🔁 Edit mode → ignore same record
                if (!empty($clientId)) {
                    $query->where('id', '!=', $clientId);
                }

                // // Optional: ignore same GST
                // if (!empty($gstNo)) {
                //     $query->where('gst_no', '!=', $gstNo);
                // }

                if ($query->exists()) {
                    return response()->json([
                        'success' => false,
                        'message' => __('Validation failed.'),
                        'errors' => [
                            'extra.company_name' => [
                                __('Company name already exists')
                            ]
                        ]
                    ]);
                }
            }

            if (!empty($formdata['iscompany']) && (int)$formdata['iscompany'] === 1) {

                $validatedGstNo = $this->fiskaly->validateGst($company,$formdata['gst_no'],$formdata['extra']['country_code'] ?? 'ES');
                if(!$validatedGstNo){
                    return response()->json([
                        'success' => false,
                        'message' =>  __('Validation failed.'),
                        'errors' => [
                            'gst_no' => [__('Invalid CIF format.')]
                        ]
                    ]);
                }
            }

            if (!empty($company)) {

                $client_data = [
                    'name' => $formdata['name'],
                    // 'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
                    'email' => $formdata['email'],
                    'mobile_no' => $formdata['mobile_no'] ?? null,
                    'gst_no' => $formdata['gst_no'],
                    'isCompany' => $formdata['iscompany'] ?? 0,
                    'extra' => $formdata['extra'] ?? null,

                ];

                // dd($client_data);

                if (!empty($client_id)) {
                    $client = Clients::find($client_id);
                
                    // Decode existing extra data
                    $existingExtra = is_array($client->extra) ? $client->extra : json_decode($client->extra, true) ?? [];
                
                    // Merge with new extra data
                    $updatedExtra = array_merge($existingExtra, $formdata['extra'] ?? []);
                
                    // Add merged extra back to the update array
                    $client_data['extra'] = $updatedExtra;
                
                    // dd($client_data);
                    // Update client
                    $client->update($client_data);
                } else {
                    // New client: assign extra directly
                    $client_data['extra'] = $formdata['extra'] ?? [];
                    $client = Clients::create($client_data);
                }
            } else {
                $user_data = [
                    'name' => $formdata['name'],
                    'email' => $formdata['email'],
                    'phone' => $formdata['mobile_no'] ?? null,

                ];

                $company_data = [
                    'gst_no' => $formdata['gst_no'] ?? null,
                ];

                // dd($client_data);
                $userModel = new User();
                if (!empty($client_id)) {
                    $userData = User::where('id', $client_id)->first();
                    User::where('id', $client_id)->update($user_data);
                    Company::where('id', $userData->company->id)->update([
                        'extra->company_address' => $formdata['extra']['address'] ?? null,
                        'extra->zip_code' => $formdata['extra']['zip_code'] ?? null,
                        'extra->state_code' => $formdata['extra']['state_code'] ?? null,
                        'extra->country_code' => $formdata['extra']['country_code'] ?? null,
                        'extra->invoice_prefix' => $formdata['extra']['invoice_prefix'] ?? null,
                        'extra->alternative_email' => $formdata['extra']['alternative_email'] ?? null,
                        'extra->locality' => $formdata['extra']['locality'] ?? null,
                    ]);
                    Company::where('id', $userData->company->id)->update($company_data);
                    $user = User::where('id', $client_id)->first();
                } else {
                    $user_data['password'] =  $userModel->generateRandomPassword();
                    $user_data['password'] = Hash::make($user_data['password']);
                    // Create a new invoice
                    $user = User::create($user_data);
                    $user->syncRoles(['Company']);
                }
            }


            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Client updated successfully.')
                    : __('Client created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditClient: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    /**
     * Validate a Spanish NIF (8 digits + 1 control letter).
     * Returns an error string or null on success.
     */
    private function validateSpanishNIF(string $body): ?string
    {
        $letters = 'TRWAGMYFPDXBNJZSQVHLCKE';

        if (!preg_match('/^\d{8}[A-Z]$/', $body)) {
            return __('validation.custom.gst_no.es_nif_format');
        }

        $num      = (int) substr($body, 0, 8);
        $letter   = $body[8];
        $expected = $letters[$num % 23];

        if ($letter !== $expected) {
            return __('validation.custom.gst_no.es_checksum', ['expected' => $expected]);
        }

        return null;
    }

    /**
     * Validate a Spanish CIF (company VAT).
     * Returns an error string or null on success.
     */
    private function validateSpanishCIF(string $body): ?string
    {
        if (!preg_match('/^[ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]$/', $body)) {
            return __('validation.custom.gst_no.es_cif_format');
        }

        $digits      = substr($body, 1, 7);
        $controlChar = $body[8];
        $typeChar    = $body[0];

        $evenSum = 0;
        $oddSum  = 0;

        for ($i = 0; $i < strlen($digits); $i++) {
            $d = (int) $digits[$i];
            if (($i + 1) % 2 === 0) {
                // Even positions — add directly
                $evenSum += $d;
            } else {
                // Odd positions — double and sum digits
                $doubled  = $d * 2;
                $oddSum  += $doubled < 10 ? $doubled : $doubled - 9;
            }
        }

        $total         = $evenSum + $oddSum;
        $controlDigit  = (10 - ($total % 10)) % 10;
        $controlLetter = 'JABCDEFGHI'[$controlDigit];

        // Some type letters only allow digit, some only allow letter
        $digitOnly  = in_array($typeChar, ['A', 'B', 'E', 'H']);
        $letterOnly = in_array($typeChar, ['P', 'Q', 'S', 'W']);

        if ($digitOnly && $controlChar !== (string) $controlDigit) {
            return __('validation.custom.gst_no.es_checksum', ['expected' => $controlDigit]);
        }

        if ($letterOnly && $controlChar !== $controlLetter) {
            return __('validation.custom.gst_no.es_checksum', ['expected' => $controlLetter]);
        }

        if (!$digitOnly && !$letterOnly) {
            if ($controlChar !== (string) $controlDigit && $controlChar !== $controlLetter) {
                return __('validation.custom.gst_no.es_checksum', [
                    'expected' => "{$controlDigit} or {$controlLetter}"
                ]);
            }
        }

        return null;
    }

    public function importClients(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|mimes:xlsx,xls,csv,ods'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation Failed',
                'errors' => $validator->errors()
            ], 200);
        }

        try {
            $file = $request->file('file');

            // Load the file and count sheets
            $spreadsheet = IOFactory::load($file->getRealPath());
            $sheetCount = $spreadsheet->getSheetCount();

            if ($sheetCount > 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Excel file should contain only one sheet. Found ' . $sheetCount
                ], 200);
            }

            $import = new ClientsImport();
            Excel::import($import, $file);

            return response()->json([
                'success' => $import->success,
                'message' => $import->message
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => [$e->getMessage()]
            ], 200);
        }
    }


    public function deleteClients($id)
    {
        try {
            // $allUserPermissions = auth()->user()->getAllUserPermissions();
            // // dd($allUserPermissions['companies']);
            // if (isset($allUserPermissions['users'])) {
            //     if (!empty($allUserPermissions['users']['children'])) {
            //         if (!in_array('delete client', $allUserPermissions['users']['children'])) {
            //             return;
            //         }
            //     }
            // } else {
            //     return;
            // }

            // Attempt to delete the user by ID
            Clients::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Client deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting Invoice Type: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Client. Please try again.')], 500);
        }
    }


    public function exportToCsv()
    {
        try {
            $user = Auth::user();
            $company = $user->company;


            if($company){
                $clients = Clients::all();
            }else{
                $clients = User::all();
            }
            $filename = "clients.csv";

            $headers = [
                "Content-Type"        => "text/csv; charset=UTF-8",
                "Content-Disposition" => "attachment; filename=\"{$filename}\"",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            ];

            $callback = function() use ($clients) {
                // clear any previous output that may corrupt CSV
                if (ob_get_level() > 0) {
                    ob_end_clean();
                }

                $file = fopen('php://output', 'w');

                // Add UTF-8 BOM so Excel doesn’t break accents/special chars
                fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

                
                // Header row
                fputcsv($file, [
                    __('Name'),
                    __('Surname'),
                    __('Company Name'),
                    __('Email'),
                    __('Mobile No'),
                    __('Alternative Email'),
                    __('Gst No'),
                    __('Address'),
                    __('Locality'),
                    __('Zip Code'),
                    __('Country'),
                    __('State'),
                ]);
                

                // Data rows
                foreach ($clients as $client) {

                    $country = CountryModel::where('country_code',$client->extra['country_code'] ?? null)->first();
                    // $state = StateModel::where('state_code',$client->extra['state_code'])->first();
                    fputcsv($file, [
                        $client->name,
                        $client->extra['surname'] ?? null,
                        $client->extra['company_name'] ?? null,
                        $client->email ?? null,
                        $client->mobile_no,
                        $client->extra['alternative_email'] ?? null,
                        $client->gst_no ?? null,
                        $client->extra['address'] ?? null,
                        $client->extra['locality'] ?? null,
                        $client->extra['zip_code'] ?? null,
                        $country->name ?? null,
                        $client->extra['state_name'] ?? null,
                    ]);
                }

                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        }
        catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

}
