<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Artisan;
use Exception;
use App\Models\ActivityLog;



class PaymentMethodsController extends Controller
{
    // Function for Crud operation for payment methods
    public function indexPaymentMethod(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = PaymentMethods::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }
            // Fetch paginated results with related data
            $paymentMethods = $query->orderBy('id', 'DESC')->paginate($limit);

            // $paymentMethods = PaymentMethods::paginate(10);
            if($request->ajax())
            {
                return view('panel.payment-methods.partial-paymentmethod',compact('paymentMethods'));
            }
             return view('panel.payment-methods.index-method', compact('paymentMethods'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function paymentmethodstatus(Request $request, $id)
    {
       try {
           // Validate the request
           $request->validate([
               'status' => 'required|string'
           ]);
        
           $paymentMethod = PaymentMethods::findOrFail($id);
           $paymentMethod->status = $request->status;
           $paymentMethod->save();
   
           // Return success response
           return response()->json([
               'success' => true, 
               'message' => __('PaymentMethod status updated successfully')
           ], 200);
       } catch (\Exception $e) {
           // Log the exception for debugging
           Log::error('Error updating Clients status: ' . $e->getMessage());
   
           // Return error response
           return response()->json([
               'success' => false, 
               'message' => __('Failed to update status. Please try again.')
           ], 500);
       }
    }

    
     

    public function editPaymentMethods($id)
    {
        try {
            $paymentMethod = PaymentMethods::where('id', $id)->first();

            return view('panel.payment-methods.edit-method', compact('paymentMethod'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addPaymentMethods()
    {
        try {
            return view('panel.payment-methods.add-method');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditPaymentMethods(Request $request)
    {

        try {
            // Extract form data
            $formdata = $request->all();
            $dynamicTableName = (new PaymentMethods())->getTable();
            $method_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:' . $dynamicTableName . ',name,' . $method_id,
            ];
            // Validate the input data  


            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $payment_data = [
                'name' => $formdata['name'],
                'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
                'extra' => $formdata['extra']

            ];

            if (!empty($method_id)) {
                $methodData = PaymentMethods::where('id', $method_id)->first();
                PaymentMethods::where('id', $method_id)->update($payment_data);
                $method = PaymentMethods::where('id', $method_id)->first();
            } else {
                // Create a new invoice
                $method = PaymentMethods::create($payment_data);
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Payment Method updated successfully.')
                    : __('Payment Method created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditPaymentMethod: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function getPaymentMethods(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = PaymentMethods::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            // Fetch paginated results with related data
            $paymentMethods = $query->orderBy('id', 'DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Payment methods retrieved successfully.',
                'data' => $paymentMethods,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Payment methods.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function deletePaymentMethods($id)
    {
        try {
            // Attempt to delete the user by ID
            PaymentMethods::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Payment method deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete payment method. Please try again.')], 500);
        }
    }
}
