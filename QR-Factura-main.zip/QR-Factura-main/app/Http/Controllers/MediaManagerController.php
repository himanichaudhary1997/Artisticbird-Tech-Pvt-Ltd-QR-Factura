<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use App\Models\ActivityLog;


class MediaManagerController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('media.index');
    }

    public function upload(Request $request)
    {
        try {
            $type = $request->input('type'); // Get type from payload (image, spreadsheet, etc.)

            // Define allowed MIME types based on type
            $allowedMimes = [
                'image_all' => 'jpeg,png,webp,jpg,svg',
                'image' => 'jpeg,png,jpg',
                'spreadsheet' => 'xls,xlsx',
                'document' => 'pdf,doc,docx',
                'video' => 'mp4,mov,avi,mkv',
            ];

            if (!$type || !isset($allowedMimes[$type])) {
                // If type is missing or invalid, allow all types except 'image_all' (optional)
                $mimesRule = implode(',', array_diff($allowedMimes, ['image_all']));
            } else {
                $mimesRule = $allowedMimes[$type];
            }
    
            // Define validation rules
            $rules = [
                'image' => "required|mimes:{$mimesRule}|max:5120", // 5MB limit
            ];
            // $rules =[
            //     'image' => 'required|mimes:jpeg,png,webp,jpg,pdf,svg,doc,docx,xls,xlsx|max:5120',
            // ];
            $formdata= $request->all();
            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => implode(', ', $validator->errors()->all()), // Convert errors to a comma-separated string
                    'errors' => $validator->errors() // Keep the original error messages
                ], 200);
            }
            

            $user = auth()->user();
            $role = $user->roles->first(); // Get the first assigned role

            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            // dd(in_array($role->name,['Accountant','CompanyAccountant']));
            if(in_array($role->name,['Accountant','CompanyAccountant'])){
                $folder = str_replace(' ', '_', $user->name) . $user->id;
            }else{
                $folder = $company ? $company->company_slug : 'admin';
            }
            $storagePath = storage_path("app/public/{$folder}");

            // Ensure the folder exists
            if (!file_exists($storagePath)) {
                mkdir($storagePath, 0755, true);
            }

            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);

            // Replace spaces with underscores
            $originalName = str_replace(' ', '_', $originalName);

            // Remove special characters
            $originalName = preg_replace('/[^A-Za-z0-9_\-]/', '', $originalName);
                // Randomize name for images
            $filename = Str::random(20).$originalName . '.' . $extension;

            $path = $file->storeAs("public/{$folder}", $filename);

            return response()->json([
                'success' => true,
                'message' => __('File uploaded successfully.'),
                'url' => Storage::url($path),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during file upload.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }



    public function getFiles(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
    
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }
            $role = $user->roles->first(); // Get the first assigned role
    
            if (in_array($role->name, ['Accountant', 'CompanyAccountant'])) {
                $folder = str_replace(' ', '_', $user->name) . $user->id;
            } else {
                $folder = $company ? $company->company_slug : 'admin';
            }
            $storagePath = "public/{$folder}";

            // Check if the folder exists
            if (!Storage::exists($storagePath)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No files found.',
                    'images' => []
                ], 200);
            }
    
            $files = collect(Storage::files($storagePath))->sortByDesc(function ($file) {
                return Storage::lastModified($file);
            });
    
            $fileUrls = [];
            $typeFilter = $request->input('type'); // Filtering type (image, image_all, pdf, video, document)
            $searchQuery = $request->input('search'); // Search filter
    
            // Define allowed MIME types
            $allowedMimes = [
                'image_all' => ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'image/svg+xml'],
                'image' => ['image/jpeg', 'image/png', 'image/jpg'],
                'spreadsheet' => ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                'document' => ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
                'video' => ['video/mp4', 'video/mov', 'video/avi', 'video/mkv'],
            ];
    
            foreach ($files as $file) {
                $filePath = Storage::path($file);
                $mimeType = file_exists($filePath) ? mime_content_type($filePath) : null;
                $type = 'unknown';
                $dimensions = 'N/A';
                $image_url = '';
    
                if ($mimeType) {
                    if (in_array($mimeType, $allowedMimes['image_all'])) {
                        $type = 'image';
                        if (@getimagesize($filePath)) {
                            [$width, $height] = getimagesize($filePath);
                            $dimensions = "{$width}x{$height}";
                        }
                        $image_url = url(Storage::url($file));
                    } elseif ($mimeType === 'application/pdf') {
                        $type = 'pdf';
                        $image_url = asset('uploads/images/pdf-icon.png');
                    } elseif (str_starts_with($mimeType, 'video/')) {
                        $type = 'video';
                        $image_url = asset('uploads/images/video-icon.png');
                    } elseif (in_array($mimeType, $allowedMimes['document'])) {
                        $type = 'document';
                        $image_url = asset('uploads/images/word.png');
                    } elseif (in_array($mimeType, $allowedMimes['spreadsheet'])) {
                        $type = 'spreadsheet';
                        $image_url = asset('uploads/images/excel-icon.jpeg');
                    }
                }
    
                // Apply filtering based on `type`
                if ($typeFilter) {
                    if ($typeFilter === 'image_all' && !in_array($mimeType, $allowedMimes['image_all'])) {
                        continue;
                    } elseif ($typeFilter === 'image' && !in_array($mimeType, $allowedMimes['image'])) {
                        continue;
                    } elseif ($typeFilter !== 'image' && $typeFilter !== 'image_all' && $typeFilter !== $type) {
                        continue;
                    }
                }
    
                // Apply search filter
                if ($searchQuery && stripos(basename($file), $searchQuery) === false) {
                    continue;
                }
    
                $fileUrls[] = [
                    'url' => '/storage/' . Str::after($file, 'public/'),
                    'public_url' => Storage::url($file),
                    'name' => basename($file),
                    'size' => Storage::size($file),
                    'dimensions' => $dimensions,
                    'type' => $type,
                    'image_url' => $image_url
                ];
            }
    
            return response()->json([
                'success' => true,
                'message' => 'Files retrieved successfully.',
                'images' => $fileUrls
            ], 200);
    
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving files.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function delete(Request $request)
    {
        try {
            $request->validate([
                'filename' => 'required|string',
            ]);

            $user = Auth()->user();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $role = $user->roles->first() ?? null;
            if (empty($company)) {
                $folder = 'admin';
            } else {
                $folder = $company->company_slug;
            }

            $filePath = "public/{$folder}/{$request->filename}";

            // Check if the file exists and delete it
            if (Storage::exists($filePath)) {
                ActivityLog::create([
                    'user_id' => $user->id,
                    'company_id'=>$company->id ?? null,
                    'action' => 'Delete File '. $filePath,
                    'ip_address' => $request->ip()
                ]);
                Storage::delete($filePath);
                return response()->json(['success' => true, 'message' => __('Image deleted successfully.')]);
            } else {
                return response()->json(['success' => false, 'message' => 'Image not found.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'An error occurred during image deletion.', 'error' => $e->getMessage()], 500);
        }
    }
}
