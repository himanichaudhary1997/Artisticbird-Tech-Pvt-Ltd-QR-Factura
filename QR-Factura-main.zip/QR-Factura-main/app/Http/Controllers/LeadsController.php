<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Leads;

class LeadsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request){
        try {
        $user = auth()->user();
        $formdata = $request->all();
        $limit = $formdata['limit'] ?? 15;
        
        $query = Leads::query();

        // Apply search filter
        if (isset($formdata['search']) && !empty($formdata['search'])) {
            // dd($formdata);
            $query->where(function ($q) use ($formdata) {
                $q->where('name', 'like', '%' . $formdata['search'] . '%');
                $q->orWhere('last_name', 'like', '%' . $formdata['search'] . '%');
                $q->orWhere('email', 'like', '%' . $formdata['search'] . '%');
                $q->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
            });
        }

        $leads = $query->orderBy('id','DESC')->paginate($limit);

        if ($request->ajax()) {
            return view('panel.leads.partial_data', compact('leads'))->render();
        }

        return view('panel.leads.index', compact('leads'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }
}
