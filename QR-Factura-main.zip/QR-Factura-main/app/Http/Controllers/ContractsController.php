<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Performa;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use App\Models\Invoice;
use Exception;


use App\Services\InvoiceService;
use App\Services\UtilityService;

use DOMDocument;
use DOMXPath;
use App\Models\Contracts;


class ContractsController extends Controller
{
    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = Contracts::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }


            // Apply reusable filters
            if (!empty($formdata['search'])) {
                $search = $formdata['search'];
                $query->whereHas('performa', function ($q) use ($search) {
                    $q->where('performa_id', 'like', "%$search%");
                });
            }

            if(empty(getDomainId())){
                $query->whereHas('performa', function ($q){
                    $q->whereNull('domain_id');
                });
            }else{
                $query->whereHas('performa', function ($q) {
                    $q->where('domain_id',getDomainId());
                });
            }

            if (!empty($formdata['status'])) {
                $query->where('status', $formdata['status']);
            }

            if (!empty($formdata['from_date'])) {
                $query->whereDate('contract_date', '>=', $formdata['from_date']);
            }

            if (!empty($formdata['to_date'])) {
                $query->whereDate('contract_date', '<=', $formdata['to_date']);
            }

            // Final Query
            $contracts = $query
                ->orderBy('id', 'DESC')
                ->paginate($limit);

            $statuses = getStatuses();

            if ($request->ajax()) {
                return view('panel.contracts.partial_data', compact('contracts','statuses'))->render();
            }
            return view('panel.contracts.index-contracts', compact('contracts'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __($e->getMessage()));
        }
        
    }

    public function previewContract($contractId)
    {
        try{
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }
            $contract = Contracts::findOrFail($contractId);
            $performaId = $contract->performa_id;

            $performa = Performa::findOrFail($performaId);
            // dd(date_format($performa->contract->contract_date, 'd/m/Y'));
            $templateId = env('CONTRACT_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            // dd($company);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     // dd('hi');
            //     $performa->generateInvoiceQrCode();
            // }
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);


            // $data = [
            //     'id' => $performa->id,
            //     'performa_no' => $performa['performa_id'] ?? null,
            //     'customer_name' => $performa->client->name ?? null,
            // ];



            // return view('panel.performa.preview', ['templateHtml' => $datahtml, 'data' => $data]);



            $data = [
                'id' => $performa->id,
                'invoice_no' => $performa['invoice_id'] ?? null,
                'customer_name' => $performa->client->name ?? null,
                'privacy' =>  $performa->extra['policies'] ?? null,
            ];



            return view('invoice.singlePreview', ['templateHtml' => $datahtml, 'data' => $data]);

        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __($e->getMessage()));
        }
    }

    public function downloadContract($contractId)
    {
        $contract = Contracts::findOrFail($contractId);
        $performaId = $contract->performa_id;
        $performa = Performa::findOrFail($performaId);
        $authUser = auth()->user();
        $company = $authUser->company instanceof \Illuminate\Database\Eloquent\Collection
            ? $authUser->company->first()
            : $authUser->company;

        $user = $company
            ? User::where('id', $company->admin_id)->first()
            : User::find(1);

        $templateId = env('CONTRACT_TEMPLATE_ID');
        $template = Templates::where('id', $templateId)->first() 
            ?? Templates::where('status', 1)->first();

        $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

        $storagePath = rtrim(public_path('storage/'), '/') . '/';
        $baseUrl = rtrim(asset('storage'), '/') . '/';
        
        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );

        $privacyText = '';
        
        $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
        // dd($invoiceData);
        $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
        $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

        $pdf = Pdf::loadHTML($html)
            ->setPaper('A4')
            ->setOption('isHtml5ParserEnabled', true)
            ->setOption('isRemoteEnabled', true)
            ->setOption('defaultFont', 'Arial');

        return $pdf->download("contrato-{$performa->performa_id}.pdf");
    }

    public function extractTables(string $html, array $ids): array
    {
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);

        // Force UTF-8 encoding
        $html = '<?xml encoding="UTF-8">' . $html;
        $html = str_replace(
            ["–", "—", "−"],
            "-",
            $html
        );

        
        // $dom = new DOMDocument();
        // libxml_use_internal_errors(true);
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $results = [];

        foreach ($ids as $id) {
            $node = $xpath->query("//*[@id='{$id}']")->item(0);
            if ($node) {
                $results[$id] = $dom->saveHTML($node);
                // Remove this node from DOM so it won’t appear in body
                $node->parentNode->removeChild($node);
            } else {
                $results[$id] = '';
            }
        }

        // Whatever remains is the clean "body" (without header/footer)
        $cleanBody = $dom->saveHTML();
        $results['body'] = $results['body'] ?: $cleanBody;

        return $results;
    }

    public function sendEmail(Request $request)
    {
        try {
            $dynamicTableName = (new Contracts())->getTable();
            // Validate request input
            $formdata = $request->validate([
                'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
                'comment' => 'nullable|string',
            ]);
            // dd($formdata);

            $contract = Contracts::findOrFail($formdata['id']);

            $performaId = $contract->performa_id;

            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $performa = Performa::findOrFail($performaId);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     $performa->generateInvoiceQrCode();
            // }
            $templateId = env('CONTRACT_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            // dd($template);
            $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

            
            $data = [
                'id' => $performa->id,
                'performa_no' => $performa['performa_id'] ?? null,
                'customer_name' => $performa->client->name ?? null,
                'comment'=>$formdata['comment'] ?? null
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); 

            // Get the base URL dynamically
            $baseUrl = asset('storage'); 

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );

            // if (isset($performa->extra['policies']) && !empty($performa->extra['policies'])) {
            //     $policiesHtml = $performa->extra['policies'] ?? '';

            //     if (!empty($policiesHtml)) {
            //         $datahtml .= '<div style="page-break-before: always;"></div>';
            //         $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
            //     }
            // }
            $privacyText = $performa->extra['policies'] ?? null;
        
            $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
            // dd($invoiceData);
            $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
            $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

            $pdfContent = Pdf::loadHTML($html)
                ->setPaper('A4')
                ->setOption('isHtml5ParserEnabled', true)
                ->setOption('isRemoteEnabled', true)
                ->setOption('defaultFont', 'Arial')
                ->output();
            
            // Generate PDF from the modified HTML
            // $pdfContent = PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $altEmails = $performa->client->extra['alternative_email'] ?? $performa->client->email;
            }else{
                $clientCompany = Company::where('admin_id',$performa->client->id)->first();
                $altEmails = $clientCompany->extra['alternative_email'] ?? $performa->client->email;
            }
            
            if (is_string($altEmails)) {
                $emails = array_filter(array_map('trim', explode(',', $altEmails)));
            } elseif (is_array($altEmails)) {
                $emails = array_filter(array_map('trim', $altEmails));
            } else {
                $emails = [];
            }

            if (empty($emails)) {
                $emails = [$invoice->client->email];
            }

            $emails = array_unique(array_filter($emails));

            foreach ($emails as $email) {
                Mail::to($email)->send(new SystemEmail(
                    __('Please review the attached contract'), // Subject
                    'emails.contract-template', // Replace with your Blade view path
                    $data, // Dynamic data
                    $pdfContent, // Attach generated PDF content
                    "contrato--{$performa->performa_id}.pdf", // Optional file name for the PDF,
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'] 
                ));

            }
            // Send email with the PDF attachment
            // Mail::to($email)->send(new SystemEmail(
            //     __('Please review the attached contract'), // Subject
            //     'emails.contract-template', // Replace with your Blade view path
            //     $data, // Dynamic data
            //     $pdfContent, // Attach generated PDF content
            //     "contrato--{$performa->performa_id}.pdf", // Optional file name for the PDF,
            //     'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'],
            //     null,
            //     $company->user->email ?? 'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'] 
            // ));

            if($contract->status != 'sent'){
                $contract->status = 'sent'; //2 represents 'sent'
            }
            $contract->save();
            return response()->json([
                'success' => true,
                'message' => __('Proposal sent successfully.'),
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    public function updateDate(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'contract_date' => ['required', 'date'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->first(),
                'errors'  => $validator->errors(),
            ], 200);
        }

        $contract = Contracts::find($id);

        if (!$contract) {
            return response()->json([
                'success' => false,
                'message' => 'Contract not found.',
            ], 200);
        }

        $contract->update([
            'contract_date' => $request->contract_date,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Contract date updated successfully.',
            'data' => $contract,
        ], 200);
    }
}
