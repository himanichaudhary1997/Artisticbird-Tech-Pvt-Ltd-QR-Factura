<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Menu;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Company;
use Illuminate\Support\Str;
use App\Models\SubscriptionPlans;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Permission;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use App\Jobs\SubscriptionReminderJob;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\TaxRules;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use App\Models\CompanyUsers;
use App\Services\FiskalyInvoiceService;
use PDF;
use App\Models\VerifactuApiKeysModel;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request){
    try{
        $user = auth()->user();
        $formdata = $request->all();
        $subscriptions = SubscriptionPlans::where('status',1)->get()->toArray();

        // $company = Company::where('id',3)->first();
        // $aggrement = $this->fiskaly->createTaxPayer($company);
        // dd($aggrement);


        $allUsers = $query = User::where('id', '!=', $user->id)
            ->whereHas('roles', function ($query) {
                $query->where('id', 2); // Filter by role ID 2
            })->get();
        $query = User::where('id', '!=', $user->id)
            ->whereHas('roles', function ($query) {
                $query->where('id', 2); // Filter by role ID 2
            });

        // Apply search filter
        if (isset($formdata['search']) && !empty($formdata['search'])) {
            $query->where(function ($q) use ($formdata) {
                $q->where('name', 'like', '%' . $formdata['search'] . '%')
                    ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                    ->orWhere('phone', 'like', '%' . $formdata['search'] . '%')
                    ->orWhereHas('singleCompany', function ($query) use ($formdata) {
                        $query->where('company_name', 'like', '%' . $formdata['search'] . '%');
                        $query->orWhere('company_email', 'like', '%' . $formdata['search'] . '%');
                    });
            });
        }

        if (isset($formdata['status']) && !is_null($formdata['status'])) {
            $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
        }

        if(isset($formdata['plan_id']) && !is_null($formdata['plan_id'])){
            $query->whereHas('subscriptionDetails', function ($query) use ($formdata) {
                $query->where('subscription_id', $formdata['plan_id']);
            });
        }

        $users = $query->orderBy('id','DESC')->paginate(15);

        if ($request->ajax()) {
            return view('panel.users.partial_data', compact('users','subscriptions'))->render();
        }
        return view('panel.users.users-index',compact('users','subscriptions','allUsers'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }
     

     public function userstatusupdate(Request $request, $id)
     {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
    
            // Find the inventory item
            if(!empty($company)){
                $user = user::findOrFail($id);
                $user->status = $request->status;
                $user->save();
            }else{
                $user = User::findOrFail($id);
                $user->status = $request->status;
                $user->save();
            }
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('companies status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Clients status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
     }




    public function getUsers(Request $request)
    {
        try {
            

            $query = User::whereHas('roles', function ($query) {
                    $query->where('name', 'Company'); // Filter by role name
                });
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('phone', 'like', '%' . $formdata['search'] . '%')
                        ->orWhereHas('company', function ($query) use ($formdata) {
                            $query->where('company_name', 'like', '%' . $formdata['search'] . '%');
                        });
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            if(isset($formdata['plan_id']) && !is_null($formdata['plan_id'])){
                $query->whereHas('subscriptionDetails', function ($query) use ($formdata) {
                    $query->where('subscription_id', $formdata['plan_id']);
                });
            }

            // Fetch paginated results with related data
            $users = $query->with(['singleCompany','subscriptionDetails','subscriptionDetails.subscription']) // Replace 'relationName' with your actual relation
            ->orderBy('id','DESC')->paginate(15);
            // dd($users);
            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Users retrieved successfully.',
                'data' => $users,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function addUser(){
    try{
        // $user = auth()->user();
        // $role = $user->roles->first() ?? null;
        $subscriptions = SubscriptionPlans::where('status',1)->get()->toArray();
        // $roles = Role::where('id','!=',$role->id)->get();
        $permissions = Permission::where('parent_id',null)->get()->toArray();
        
        // $userPermissions = $user->getAllPermissions()->pluck('name')->toArray();
        // Organize permissions into parent-child structure
        $permissionGroups = [];

        foreach ($permissions as $permission) {
            $childPermissions = Permission::where('parent_id',$permission['id'])->get()->toArray();
            $permissionGroups[] = [
                'id' => $permission['id'], 
                'name' => $permission['name'],  // Parent permission name
                'child' => $childPermissions  // Child permissions
            ];
        }

        $country = CountryModel::all();
        $states = StateModel::all();
        $taxRules = TaxRules::where('status',1)->where('tax_type','iva')->get();
        $retencions = TaxRules::where('status',1)->where('tax_type','retention')->get();
        // return view('panel.users.add-user',compact('roles','subscriptions','permissionGroups','country','states'));
        return view('panel.users.add-user',compact('subscriptions','permissionGroups','country','states','taxRules','retencions'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function editUser($id){
    try{
        $user = User::where('id',$id)->first();
        $subscriptions = SubscriptionPlans::where('status',1)->get()->toArray();

        // Organize permissions into parent-child structure
        $permissions = Permission::where('parent_id',null)->get()->toArray();
        $userPermissions = $user->getAllPermissions()->pluck('name')->toArray();
        // $userPermissions = $user->getAllPermissions();

        // dd($userPermissions);
        // Organize permissions into parent-child structure
        $permissionGroups = [];

        foreach ($permissions as $permission) {
            $childPermissions = Permission::where('parent_id',$permission['id'])->get()->toArray();
            $permissionGroups[] = [
                'id' => $permission['id'], 
                'name' => $permission['name'],  // Parent permission name
                'child' => $childPermissions  // Child permissions
            ];
        }
        // if (!auth()->user()->can('edit company')) {
        //     return redirect()->route('access.denied'); // Redirect if no permission to edit
        // }
        // dd($subscriptions);
        $country = CountryModel::all();
        $states = StateModel::all();
        $taxRules = TaxRules::where('status',1)->where('tax_type','iva')->get();
        $retencions = TaxRules::where('status',1)->where('tax_type','retention')->get();

        return view('panel.users.edit-user',compact('user','subscriptions','permissionGroups','userPermissions','country','states','taxRules','retencions'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function deleteUser($id)
    {
        try {
            $user = User::where('id',$id)->first();
            // Attempt to delete the user by ID
            $company = Company::where('admin_id', $user->id)->first();

            $staffUsers = User::whereHas('roles', function ($query) {
                $query->where('name', 'CompanyStaff'); // Staff role ID
            })->join('company_users', 'users.id', '=', 'company_users.user_id')
            ->where('company_users.admin_id', $user->id)
            ->select('users.*')
            ->get();

            foreach ($staffUsers as $staffUser) {
                $staffUser->delete();
            }

            $companyAdmins = User::whereHas('roles', function ($query) {
                $query->where('name', 'CompanyAdmin'); // Staff role ID
            })->join('company_users', 'users.id', '=', 'company_users.user_id')
            ->where('company_users.admin_id', $user->id)
            ->select('users.*')
            ->get();

            foreach ($companyAdmins as $companyAdmin) {
                $companyAdmin->delete();
            }

            // Delete relation with accountant users 
            $companyUsers = CompanyUsers::where('admin_id', $user->id)->delete();

            if ($company) {
                $companyId = $company->id;

                // Drop dynamic tables (example: clients_20)
                $tablesToDrop = [
                    "documents_{$companyId}",
                    "document_categories_{$companyId}",
                    "document_categories_relation_{$companyId}",
                    "inventories_{$companyId}",
                    "invoices_{$companyId}",
                    "invoice_prefix_series_{$companyId}",
                    "services_{$companyId}",
                    "accountant_clients_{$companyId}",
                    "performas_{$companyId}",
                    "receipts_{$companyId}",
                    "clients_{$companyId}",
                    "verifactu_system_records_{$companyId}",

                    // add more if you have like invoices_{$companyId}, etc.
                ];

                foreach ($tablesToDrop as $table) {
                    if (Schema::hasTable($table)) {
                        Schema::drop($table);
                    }
                }

                // Delete company
                
                if ($company->organization_details) {
                    $company->organization_details->delete();
                }

                $company->delete();
            }
            // Delete user subscriptions
            $userSubscriptions = UserSubscriptions::where('user_id', $user->id)->delete();

            // Delete all staff users associated with the company
            

            
            // Finally, delete user
            $user->delete();

            // Return success response
            return response()->json(['success' => true, 'message' => __('User deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function addOrEditAdminUser(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            $user_subscription_id = $formdata['user_subscription_id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $userId,
                'phone' => 'nullable|numeric|digits_between:8,15',
                // 'status' => 'required|boolean',
                'company_name' => [
                    'required_if:type,company'
                ],
                'company_email' => 'sometimes',
                'type' => 'required|string',
                'gst_no' => 'required|string|min:9|max:9|unique:companies,gst_no,' . $company_id,
                'dnia' => 'required|string|min:9|max:9|unique:companies,dnia,' . $company_id,
                'company.url'=>'nullable|string',
                'company.extra.company_address'=>'required',
                'company.extra.locality'=>'required',
                'company.extra.country_code'=>'required',
                'company.extra.state_code'=>'required',
                'company.extra.street_number'=>'required',
                'company.extra.zip_code'=>'required',
                'company.extra.personal.address'=>'required',
                'company.extra.personal.locality'=>'required',
                'company.extra.personal.country_code'=>'required',
                'company.extra.personal.state_code'=>'required',
                'company.extra.personal.street_number'=>'required',
                'company.extra.personal.zip_code'=>'required',
                'password' => 'nullable|string|min:8|confirmed',
                "plan"=>'required'
                // 'plan'=>'required',
                // 'time'=>'required',
                // 'plan_status'=>'required',
                // 'permission'=>'required|array'
            ];
            // dd($formdata);
            // Validate the input data  
            // dd($formdata['permission']);

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

           

            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                // 'status'=> $formdata['status'],
            ];

            if(!empty($userId)){

                if (!empty($formdata['password'])) {
                    $user_data['password'] = Hash::make($formdata['password']);
                }

                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                // dd($user);
            }else{
                $user_data['email_verified_at'] = now();
                $user_data['is_email_verified'] = true;
                
                if (!empty($formdata['password'])) {
                    // Use given password if provided during creation
                    $user_data['password'] = Hash::make($formdata['password']);
                } else {
                    // Generate random one if not provided
                    $password = $user_model->generateRandomPassword();
                    $user_data['password'] = Hash::make($password);
                }

                $user = User::create($user_data);
                $user->syncRoles(['Company']);


                if(isset($formdata['plan']) && !empty($formdata['plan'])){
                    $subscriptionPlan = SubscriptionPlans::where('id',$formdata['plan'])->first();
                    $subscriptionData = [
                        'subscription_id'=> $formdata['plan'],
                        'time'=>$subscriptionPlan->time_period ?? 1,
                    ];

                    $planDates = $user_model->getStartAndEndDate($subscriptionData['time']);
                    $subscriptionData['start_date']=$planDates['start_date'];
                    $subscriptionData['end_date']=$planDates['end_date'];
                    $subscriptionData['invoices']= $formdata['plan_detail']['invoices'] ?? null;
                    $subscriptionData['receipts']= $formdata['plan_detail']['receipts'] ?? null;

                    // dd($user);
                    $subscriptionData['user_id'] = $user->id;
                    $userSubscription = UserSubscriptions::create($subscriptionData);
                    
                }
            }
            if ($user) {
                if (!empty($formdata['permission'])) {
                    // Get or create permissions from the provided array
                    $permissions = collect($formdata['permission'])->map(function ($permissionName) {
                        return Permission::firstOrCreate(['name' => $permissionName])->id; // Ensure permission exists and get its ID
                    });
            
                    // Synchronize user's permissions: assign only the current permissions
                    $user->syncPermissions($permissions);
                } else {
                    // If no permissions are provided, remove all permissions
                    $user->syncPermissions([]);
                }
            }
            do {
                // Get digits 1 to 9 and shuffle them
                $digits = range(1, 9);
                shuffle($digits);
            
                // Add an extra random digit from 1 to 9 to make it 10 digits
                $slug = implode('', $digits) . rand(1, 9);
            } while (Company::where('company_slug', $slug)->exists());

            if(!empty($user)){
                $alreadyCompany = Company::find($company_id);

                // Decode the existing 'extra' JSON or set an empty array if null
                $existingExtra = $alreadyCompany ? $alreadyCompany->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Merge existing extra fields with new data (only add or update fields)
                $mergedExtra = array_merge($existingExtra, $newExtra);
                $company_data = [
                    'company_name'=>$formdata['company_name'] ?? $formdata['name'],
                    'company_email'=>$formdata['company_email'] ?? $formdata['email'],
                    'gst_no'=>$formdata['gst_no'],
                    'dnia'=>$formdata['dnia'],
                    'url'=>$formdata['url']??'',
                    'type'=>$formdata['type'],
                    'extra'=>$mergedExtra,
                    
                ];

                if(!empty($company_id)){
                    if(empty($alreadyCompany->territory)){
                        $company_data['territory']=$formdata['territory'] ?? null;
                    }
                    $company = Company::where('id', $company_id)->update($company_data);

                    $oldUrl = $alreadyCompany->url;
                    $newUrl = $company_data['url'];

                    if ($oldUrl !== $newUrl) {
                        DB::table('verifactu_api_keys')
                            ->where('company_id', $company_id)
                            ->update([
                                'allowed_url' => $newUrl
                            ]);
                    }
                }else{
                    $company_data['admin_id']=$user->id;
                    $company_data['territory']=$formdata['territory'] ?? 'SPAIN OTHER';
                    $company_data['company_slug']=$slug;
                    $company = Company::create($company_data);
                }
            }
            
            
            
            
            // if((isset($formdata['renew_plan']) && $formdata['renew_plan'] == "true") || (isset($formdata['upgrade_plan']) && $formdata['upgrade_plan'] == "true") && isset($formdata['plan']) && !empty($formdata['plan'])){
            //     // dd('hi');
            //     $subscriptionPlan = SubscriptionPlans::where('id',$formdata['plan'])->first();
            //     $subscriptionData = [
            //         'subscription_id'=> $formdata['plan'],
            //         'time'=>$subscriptionPlan->time_period ?? 1,
            //     ];

                
            //     $planDates = $user_model->getStartAndEndDate($subscriptionData['time']);
            //     $subscriptionData['start_date']=$planDates['start_date'];
            //     $subscriptionData['end_date']=$planDates['end_date'];
            //     $subscriptionData['invoices']= $formdata['plan_detail']['invoices'] ?? null;
            //     $subscriptionData['receipts']= $formdata['plan_detail']['receipts'] ?? null;
                
            //     if(!empty($user_subscription_id)){
            //         $userSubscription = UserSubscriptions::where('id', $user_subscription_id)->update(['status'=>0]);
            //     }

            //     $subscriptionData['user_id'] = $user->id;
            //     $userSubscription = UserSubscriptions::create($subscriptionData);
               
            // }

            if (
                (isset($formdata['renew_plan']) && $formdata['renew_plan'] == "true") ||
                (isset($formdata['upgrade_plan']) && $formdata['upgrade_plan'] == "true")
                ) {
                    if (isset($formdata['plan']) && !empty($formdata['plan'])) {

                        $subscriptionPlan = SubscriptionPlans::find($formdata['plan']);

                        $subscriptionData = [
                            'subscription_id' => $formdata['plan'],
                            'time'            => $subscriptionPlan->time_period ?? 1,
                        ];

                        $planDates = $user_model->getStartAndEndDate($subscriptionData['time']);
                        $subscriptionData['start_date'] = $planDates['start_date'];
                        $subscriptionData['end_date']   = $planDates['end_date'];
                        $subscriptionData['invoices']   = $formdata['plan_detail']['invoices'] ?? null;
                        $subscriptionData['receipts']   = $formdata['plan_detail']['receipts'] ?? null;
                        $subscriptionData['user_id']    = $user->id;

                        // Check if user already has same active plan
                        $existingSubscription = UserSubscriptions::where('user_id', $user->id)
                            ->where('subscription_id', $formdata['plan'])
                            ->where('status', 1)
                            ->first();

                        if ($existingSubscription) {
                            // 🔄 Update existing subscription instead of creating new one
                            $existingSubscription->update($subscriptionData);
                        } else {
                            // 🔒 Deactivate old subscription (if any)
                            if (!empty($user_subscription_id)) {
                                UserSubscriptions::where('id', $user_subscription_id)->update(['status' => 0]);
                            }

                            // 🆕 Create new subscription
                            UserSubscriptions::create($subscriptionData);
                        }
                    }
                } else {
                    // Just update invoices/receipts on active subscription anytime
                    UserSubscriptions::where('user_id', $user->id)
                        ->where('status', 1)
                        ->update([
                            'invoices' => $formdata['plan_detail']['invoices'] ?? null,
                            'receipts' => $formdata['plan_detail']['receipts'] ?? null,
                            'extra'=>[]
                        ]);
                }


            // dd($formdata['renew_plan']);
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('User updated successfully.') 
                    : __('User created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }




    public function sendDetails(Request $request)
    {
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user_model = new User();
            $user = User::find($validated['user_id']);
            $newPassword = $user_model->generateRandomPassword(); // Generate a random temporary password
            $user->password = Hash::make($newPassword); // Hash the new password
            $user->save();
            // dd($password);

            $subject = "Please check your login details";
            $view = 'emails.send-details'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'password' => $newPassword,
            ];

            Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));

            // Return success response
            return response()->json(['success' => true, 'message' => __('Details sent successfully.')], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation errors
            return response()->json(['success' => false, 'message' => $e->getMessage()], 200);
        }
    }


    public function sendReminders(Request $request){

        $formdata = $request->all(); // Accept `user_ids` as input
        // if(isset($formdata['user_ids']) && empty($formdata['user_ids']))
        // Dispatch the job
        SubscriptionReminderJob::dispatch($formdata['user_ids'] ?? null);

        return response()->json(['success' => true, 'message' => 'Subscription reminders sent.']);
    }


    public function profile(){
    try{
        $user = auth()->user();
        $role = $user->roles->first();
        $taxRules = TaxRules::where('status',1)->where('tax_type','iva')->get();
        $retencions = TaxRules::where('status',1)->where('tax_type','retention')->get();
        $country = CountryModel::all();
        $states = StateModel::all();
        $role_name = '';
        if (!empty($role)) {
            if($role->name == 'Staff' || $role->name == 'CompanyStaff' || $role->name == 'CompanyAdmin'){
                $role_name = 'staff';
            }elseif($role->name == 'Company'){
                $role_name = 'company';
            }elseif($role->name == 'Accountant' || $role->name == 'CompanyAccountant'){
                $role_name = 'accountant';
            }else{
                $role_name = $role->name;
            }
            return view('panel.' .strtolower(str_replace(' ', '-', $role_name)) . '.profile',compact('user','country','states','taxRules','retencions'));
        }else{
            return view('panel.super-admin.profile',compact('user','country','states','taxRules'));
        }
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function resetCompany(Request $request){
        try{

            $formdata = $request->all();
            $id = $formdata['company_id'] ?? null;
            // $user = User::where('id',$id)->first();
            $company = Company::where('id',$id)->first();

            if($company){
                $companyId = $company->id;

                // Drop dynamic tables (example: clients_20)
                $tablesToDrop = [
                    "invoices_{$companyId}",
                    "performas_{$companyId}",
                    "receipts_{$companyId}",
                    "delivery_notes_{$companyId}",
                    "auto_invoices_{$companyId}",
                    "verifactu_system_records_{$companyId}",

                    // add more if you have like invoices_{$companyId}, etc.
                ];

                foreach ($tablesToDrop as $table) {
                    if (Schema::hasTable($table)) {
                        Schema::drop($table);
                    }
                }


                if($company->is_verifactu){
                    $orgainzation = $company->organization_details;
                    $deleteOrganization = $this->fiskaly->deleteOrganization($orgainzation->organization_id);

                    if($deleteOrganization){
                        // Delete organization details
                        if ($orgainzation) {
                            $orgainzation->delete();
                        }

                        // Update company to remove Verifactu association
                        $company->is_verifactu = false;
                        $company->save();
                    }
                }
            }

            return response()->json(['success' => true, 'message' => __('Company reset successfully')], 200);
        } catch (\Throwable $e) {
            return response()->json(['success' => false, 'message' => __($e->getMessage())], 500);
        }
    }



    public function updateAdminUser(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            // dd($formdata);
            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            
            

            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email:rfc,dns|unique:users,email,' . $userId,
                'phone' => 'nullable|numeric|digits_between:8,15',
                'company_name' => 'required|string|max:255',
                'company_email' => 'sometimes',
                'gst_no' => 'required|string|min:9|max:9|unique:companies,gst_no,' . $company_id,
                'dnia' => 'required|string|min:9|max:9|unique:companies,dnia,' . $company_id,
                'company.privacy'=>'nullable|string',
                'company.extra.company_address'=>'required',
                'company.extra.locality'=>'required',
                'company.extra.country_code'=>'required',
                'company.extra.state_code'=>'required',
                'company.extra.street_number'=>'required',
                'company.extra.zip_code'=>'required',
                'company.extra.personal.address'=>'required',
                'company.extra.personal.locality'=>'required',
                'company.extra.personal.country_code'=>'required',
                'company.extra.personal.state_code'=>'required',
                'company.extra.personal.street_number'=>'required',
                'company.extra.personal.zip_code'=>'required'

                // 'permission'=>'required|array'
            ];
            // Validate the input data  
            // dd($formdata['permission']);

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $images = [
                'company.extra.company_logo' => $formdata['company']['extra']['company_logo'] ?? null,
                'company.extra.company_favicon' => $formdata['company']['extra']['company_favicon'] ?? null,
                'company.extra.profile_picture' => $formdata['company']['extra']['profile_picture'] ?? null,
            ];
            
            $invalidImages = [];
            
            foreach ($images as $key => $url) {
                if (!empty($url) && !preg_match('/\.(jpg|jpeg|png)$/i', $url)) {
                    $invalidImages[] = $key;
                }
            }
            
            if (!empty($invalidImages)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Images should be in JPG, PNG, or JPEG format.',
                    'invalid_fields' => $invalidImages,
                ], 200);
            }

            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                

            ];

            if(!empty($userId)){
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                // dd($user);
            }
            

            if(!empty($user)){
                $company = Company::find($company_id);

                // Decode the existing 'extra' JSON or set an empty array if null
                $existingExtra = $company ? $company->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Merge existing extra fields with new data (only add or update fields)
                $mergedExtra = array_merge($existingExtra, $newExtra);
                $company_data = [
                    'company_name'=>$formdata['company_name'],
                    'company_email'=>$formdata['company_email'] ?? $formdata['email'],
                    'gst_no'=>$formdata['gst_no'] ?? null,
                    'dnia'=>$formdata['dnia'] ?? null,
                    'type'=>$formdata['type'] ?? null,
                    'privacy'=>$formdata['privacy'] ?? null,
                    'extra'=>$mergedExtra
                    
                ];
                
                // dd($formdata['company']['is_agree']);
                if(isset($formdata['company']['is_agree'])){
                    $company_data['is_agree'] = true;
                }

                if(isset($formdata['territory'])){
                    $company_data['territory'] = $formdata['territory'];
                }
                // dd($company_data);
                if(!empty($company_id)){
                    $company = Company::where('id', $company_id)->update($company_data);
                }
            }    
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Details updated successfully.') 
                    : __('Data created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in updateAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function profileSaveStep(Request $request){
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = auth()->user()->id;
            $company_id = auth()->user()->company->id ?? null;
            $current = $formdata['current'];
            
            if($current == "0"){
                $rules = [
                    'name' => 'required|string|max:255',
                    'email' => 'required|email:rfc,dns|unique:users,email,' . $userId,
                    'phone' => 'nullable|numeric|digits_between:8,15',
                    'dnia' => 'required|string|min:9|max:9|unique:companies,dnia,' . $company_id,
                    'territory'=>"required",
                    'company.extra.personal.address'=>'required',
                    'company.extra.personal.locality'=>'required',
                    'company.extra.personal.country_code'=>'required',
                    'company.extra.personal.state_code'=>'required',
                    'company.extra.personal.street_number'=>'required',
                    'company.extra.personal.zip_code'=>'required'
                ];
            }elseif($current == "1"){
                $rules = [
                    'company_name' => 'required|string|max:255',
                    'company_email' => 'sometimes',
                    'gst_no' => 'required|string|min:9|max:9|unique:companies,gst_no,' . $company_id,
                ];
            }elseif($current == "2"){
                $rules = [
                    'company.extra.company_address'=>'required',
                    'company.extra.locality'=>'required',
                    'company.extra.street_number'=>'required',
                    'company.extra.country_code'=>'required',
                    'company.extra.state_code'=>'required',
                    'company.extra.zip_code'=>'required'
                ];
            }else{
                $rules = [
                    'company.is_agree'=>'required',
                ];
            }
            // dd($formdata);
            // Validate the input data  
            // dd($formdata['permission']);

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }


            if ($current == "0") {
                $user_data = [
                    'name'  => $formdata['name'],
                    'email' => $formdata['email'],
                    'phone' => $formdata['phone'] ?? null,
                ];

                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);

                $company = Company::find($company_id);

                $existingExtra = $company ? $company->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Add current step to extra
                $newExtra['current'] = $current;   // ✅ include current

                // Merge existing extra fields with new data
                $mergedExtra = array_merge($existingExtra, $newExtra);

                $company_data = [
                    'dnia'      => $formdata['dnia'] ?? null,
                    'territory' => $formdata['territory'] ?? null,
                    'extra'     => $mergedExtra
                ];

                $company->update($company_data);
            }

            if ($current == "1") {

                $company = Company::find($company_id);

                $existingExtra = $company ? $company->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Add current step to extra
                $newExtra['current'] = $current;   // ✅ include current

                // Merge existing extra fields with new data
                $mergedExtra = array_merge($existingExtra, $newExtra);

                $company_data = [
                    'company_name'      => $formdata['company_name'] ?? null,
                    'company_email' => $formdata['company_email'] ?? null,
                    'gst_no'     => $formdata['gst_no'] ?? null,
                    'extra'     => $mergedExtra,
                ];

                $company->update($company_data);
            }

            if ($current == "2") {

                $company = Company::find($company_id);

                $existingExtra = $company ? $company->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Add current step to extra
                $newExtra['current'] = $current;   // ✅ include current
                $newExtra['company_address'] = $formdata['company']['extra']['company_address'];
                $newExtra['locality'] = $formdata['company']['extra']['locality'];
                $newExtra['street_number'] = $formdata['company']['extra']['street_number'];
                $newExtra['country_code'] = $formdata['company']['extra']['country_code'];
                $newExtra['state_code'] = $formdata['company']['extra']['state_code'];  
                $newExtra['zip_code'] = $formdata['company']['extra']['zip_code'];  
                // Merge existing extra fields with new data
                $mergedExtra = array_merge($existingExtra, $newExtra);

                $company_data = [
                    'extra'     => $mergedExtra,
                ];

                $company->update($company_data);
            }

            if ($current == "3") {

                $company = Company::find($company_id);

                $existingExtra = $company ? $company->extra ?? [] : [];

                // Get new 'extra' values from formdata
                $newExtra = $formdata['company']['extra'] ?? [];

                // Add current step to extra
                $newExtra['current'] = $current;   // ✅ include current
                $newExtra['language'] = $formdata['company']['extra']['language'];
                $newExtra['currency'] = $formdata['company']['extra']['currency'];
                $newExtra['retencion'] = $formdata['company']['extra']['retencion'];
                $newExtra['tax_slab'] = $formdata['company']['extra']['tax_slab'];
                
                // Merge existing extra fields with new data
                $mergedExtra = array_merge($existingExtra, $newExtra);

                $company_data = [
                    'type'=> $formdata['type'],
                    'extra'     => $mergedExtra,
                    'is_agree'=>true
                ];

                $company->update($company_data);
            }
             
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Details updated successfully.') 
                    : __('Data created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in updateAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }


    public function updateSuperAdminUser(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email:rfc,dns|unique:users,email,' . $userId,
                'phone' => 'nullable|numeric|digits_between:8,15',
                // 'extra.gst_no' => 'required|string|unique:companies,gst_no,' . $company_id,
                // 'extra.company_logo'=> 'required',
                // 'extra.profile_picture'=> 'required',
                // 'permission'=>'required|array'
            ];
            // dd($formdata);
            // Validate the input data  
            // dd($formdata['permission']);

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $images = [
                'extra.company_logo' => $formdata['extra']['company_logo'] ?? null,
                'extra.company_favicon' => $formdata['extra']['company_favicon'] ?? null,
                'extra.profile_picture' => $formdata['extra']['profile_picture'] ?? null,
            ];
            
            $invalidImages = [];
            
            foreach ($images as $key => $url) {
                if (!empty($url) && !preg_match('/\.(jpg|jpeg|png)$/i', $url)) {
                    $invalidImages[] = $key;
                }
            }
            
            if (!empty($invalidImages)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Images should be in JPG, PNG, or JPEG format.',
                    'invalid_fields' => $invalidImages,
                ], 200);
            }

            $alreadyUser = User::find($userId);

                // Decode the existing 'extra' JSON or set an empty array if null
            $existingExtra = $alreadyUser ? $alreadyUser->extra ?? [] : [];

            // Get new 'extra' values from formdata
            $newExtra = $formdata['extra'] ?? [];

            // Merge existing extra fields with new data (only add or update fields)
            $mergedExtra = array_merge($existingExtra, $newExtra);

            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                'extra'=> $mergedExtra,
            ];

            if(!empty($userId)){
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                // dd($user);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Details updated successfully.') 
                    : __('Data created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in updateAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function generateQrCode(Request $request,$id)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = $id;
           
            $user = User::where('id',$id)->first();
            $user->generateQrCode();
            // Return success response
            return response()->json([
                'success' => true,
                'message' =>  __('Qr Code Generated Successfully') 
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in updateAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function updateSubAdminUser(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email:rfc,dns|unique:users,email,' . $userId,
                'phone' => 'nullable|numeric|digits_between:8,15',
                // 'permission'=>'required|array'
            ];
            // dd($formdata);
            // Validate the input data  
            // dd($formdata['permission']);

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $images = [
                'extra.profile_picture' => $formdata['extra']['profile_picture'] ?? null,
            ];
            
            $invalidImages = [];
            
            foreach ($images as $key => $url) {
                if (!empty($url) && !preg_match('/\.(jpg|jpeg|png)$/i', $url)) {
                    $invalidImages[] = $key;
                }
            }
            
            if (!empty($invalidImages)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Images should be in JPG, PNG, or JPEG format.',
                    'invalid_fields' => $invalidImages,
                ], 200);
            }

            $alreadyUser = User::find($userId);

                // Decode the existing 'extra' JSON or set an empty array if null
            $existingExtra = $alreadyUser ? $alreadyUser->extra ?? [] : [];

            // Get new 'extra' values from formdata
            $newExtra = $formdata['extra'] ?? [];

            // Merge existing extra fields with new data (only add or update fields)
            $mergedExtra = array_merge($existingExtra, $newExtra);

            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                'extra'=> $mergedExtra,
                

            ];

            if(!empty($userId)){
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                // dd($user);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Details updated successfully.') 
                    : __('Data created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in updateAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function updatePassword(Request $request){
        try{
            $formdata = $request->all();
            $user = auth()->user();
            $rules = [
                'password' => 'required|string|min:8|confirmed',
            ];
            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }
            $password = $formdata['password']; // Generate a random temporary password
            $password = Hash::make($password); // Hash the new password
            $updatePassword = User::where('id', $user->id)->update(['password'=>$password]);
            // dd($password);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Password updated successfully.')], 200);

        }catch(\Exception $e){
            Log::error('Error in updatePassword: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function importUsers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['success'=>false,'message' => 'Validation Failed','errors' => $validator->errors()], 200);
        }

        try {
            $import = new UsersImport();
            Excel::import($import, $request->file('file'));
            // dd($import);
            return response()->json(['success'=>$import->success,'message' => $import->message], 200);
        } catch (\Exception $e) {
            return response()->json(['success'=>false,'message' => [ $e->getMessage()]], 200);
        }
    }

    public function downloadUserXml(Request $request,$id){
    try{
        $user = User::findOrFail($id);

        $xmlData = '<?xml version="1.0" encoding="UTF-8"?>';
        $xmlData .= '<user>';
        $xmlData .= '<id>' . $user->id . '</id>';
        $xmlData .= '<name>' . htmlspecialchars($user->name) . '</name>';
        $xmlData .= '<email>' . htmlspecialchars($user->email) . '</email>';
        $xmlData .= '</user>';
    
        return Response::make($xmlData, 200, [
            'Content-Type' => 'application/xml',
            'Content-Disposition' => 'attachment; filename="user_' . $user->id . '.xml"',
        ]);
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function addDemoCompany(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $userId = $formdata['id'] ?? null;
            $company_id = $formdata['company_id'] ?? null;
            $user_subscription_id = $formdata['user_subscription_id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email',
                'phone' => 'nullable|numeric|digits_between:8,15',
            ];

            $user_model = new User();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }


            $user_data = [
                'name'=> $formdata['name'],
                'email'=> $formdata['email'],
                'phone'=> $formdata['phone'] ?? null,
                'extra'=> ['is_demo_user'=>true],
                // 'status'=> $formdata['status'],
            ];

            $user_data['email_verified_at'] = now();
            $user_data['is_email_verified'] = true;
            $password = $user_model->generateRandomPassword();
            $user_data['password'] = Hash::make($password);

            $user = User::create($user_data);
            $user->syncRoles(['Company']);
            
            do {
                // Get digits 1 to 9 and shuffle them
                $digits = range(1, 9);
                shuffle($digits);
            
                // Add an extra random digit from 1 to 9 to make it 10 digits
                $slug = implode('', $digits) . rand(1, 9);
            } while (Company::where('company_slug', $slug)->exists());

            if(!empty($user)){

                $company_data = [
                    'company_name'=>$formdata['company_name'] ?? $formdata['name'],
                    'company_email'=>$formdata['email'],
                    'gst_no'=>$formdata['gst_no'] ?? null,
                    'type'=>'company',
                    'extra'=>$mergedExtra,
                    
                ];

                $company_data['admin_id']=$user->id;
                $company_data['company_slug']=$slug;
                $company = Company::create($company_data);
            }
            
            
            $plan_id = 2;
            $subscriptionPlan = SubscriptionPlans::where('id',$plan_id)->first();
            $subscriptionData = [
                'subscription_id'=> $plan_id,
                'time'=>$subscriptionPlan->time_period ?? 1,
            ];

            $subscriptionData['start_date']=$userSubscriptionDetails['start_date'];
            $subscriptionData['end_date']=$userSubscriptionDetails['end_date'];
            $subscriptionData['user_id'] = $user->id;
            $userSubscription = UserSubscriptions::create($subscriptionData);


            // dd($formdata['renew_plan']);
            $subject = "Please check your demo login details";
            $view = 'emails.send-demo-details'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'password' => $newPassword,
            ];

            Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('User updated successfully.') 
                    : __('User created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditAdminUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function getstates(Request $request){
        try {
            $country = CountryModel::where('country_code',$request->country_id)->first();
            $country_id = $country->id;
            $states = StateModel::where('country_id',$country_id)->get();
            if($states){
                return response()->json(['success'=>true,'data'=>$states], 200);
            }else{ 
                return response()->json(['success'=>false,'message' => 'No states found'], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong.',
            ], 500);
        }
    }

    // public function updateVerifactu(Request $request,$id){
    //     try {
    //         // Validate the request
    //         $company = Company::where('id',$id)->first();
            
    //         if(empty($company->gst_no)){
    //             return response()->json([
    //             'success' => false, 
    //                 'message' => __('Please add gst no first.')
    //             ], 200);
    //         }

    //         if(empty($company->territory)){
    //             return response()->json([
    //             'success' => false, 
    //                 'message' => __('Please add territory.')
    //             ], 200);
    //         }

    //         if(empty($company->dnia)){
    //             return response()->json([
    //             'success' => false, 
    //                 'message' => __('Please add dnia no first.')
    //             ], 200);
    //         }

    //         if(empty($company->extra['company_address']) ||
    //             empty($company->extra['locality']) ||
    //             empty($company->extra['zip_code']) ||
    //             empty($company->extra['country_code']) ||
    //             empty($company->extra['street_number']) ||
    //             empty($company->extra['state_code'])){
    //             return response()->json([
    //             'success' => false, 
    //                 'message' => __('All address fields are required.')
    //             ], 200);
    //         }
          
    //         if($request->status == "1" && empty($company->organization_details)){
    //             $organization = $this->fiskaly->createOrganisation($company);
    //             $company->refresh()->load('organization_details');
    //             $taxPayer = $this->fiskaly->createTaxPayer($company);
    //             $aggrement = $this->fiskaly->generateAgreement($company);
    //             $signer = $this->fiskaly->createSigner($company->user);
    //             $client = $this->fiskaly->createClient($company->user);
    //         }
            
    //         $company->is_verifactu = $request->status;
    //         $company->save();

    //         return response()->json([
    //             'success' => true, 
    //             'message' => __('Added in Verifcatu Successfully.')
    //         ], 200);
    //         // Return success response
    //     } catch (\Exception $e) {
    //         // Log the exception for debugging
    //         Log::error('Error updating verifcatu: ' . $e->getMessage());
    
    //         // Return error response
    //         return response()->json([
    //             'success' => false,
    //             'message' => __('Failed to add verifactu.'),
    //             'file' => $e->getFile(),
    //             'line' => $e->getLine(),
    //             'error' => $e->getMessage()
    //         ], 500);
    //     }
    // }

    // public function updateVerifactu(Request $request, $id){
    //     try {
    //         $company = Company::where('id', $id)->first();

    //         if(empty($company->gst_no)){
    //             return response()->json(['success' => false, 'message' => __('Please add gst no first.')], 200);
    //         }
    //         if(empty($company->territory)){
    //             return response()->json(['success' => false, 'message' => __('Please add territory.')], 200);
    //         }
    //         if(empty($company->dnia)){
    //             return response()->json(['success' => false, 'message' => __('Please add dnia no first.')], 200);
    //         }
    //         if(empty($company->extra['company_address']) ||
    //             empty($company->extra['locality']) ||
    //             empty($company->extra['zip_code']) ||
    //             empty($company->extra['country_code']) ||
    //             empty($company->extra['street_number']) ||
    //             empty($company->extra['state_code'])){
    //             return response()->json(['success' => false, 'message' => __('All address fields are required.')], 200);
    //         }

    //         if($request->status == "1") {

    //             if(empty($company->organization_details)) {
    //                 // First time setup
    //                 $this->fiskaly->createOrganisation($company);
    //                 $company->refresh()->load('organization_details');
    //                 $this->fiskaly->createTaxPayer($company);
    //                 $this->fiskaly->generateAgreement($company);
    //                 $this->fiskaly->createSigner($company->user);
    //                 $this->fiskaly->createClient($company->user);
    //             } else {
    //                 // Re-enabling — patch existing client back to ENABLED
    //                 $clientId = $company->organization_details->client_id ?? null;

    //                 if($clientId) {
    //                     $enableResponse = $this->fiskaly->updateClient($company, $clientId, 'ENABLED');

    //                     if(isset($enableResponse['error'])){
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => __('Failed to re-enable Verifactu client.'),
    //                             'error'   => $enableResponse['error']
    //                         ], 500);
    //                     }
    //                 }
    //             }

    //         } else {
    //             // Disabling
    //             $clientId = $company->organization_details->client_id ?? null;

    //             if($clientId) {
    //                 $disableResponse = $this->fiskaly->updateClient($company, $clientId, 'DISABLED');

    //                 if(isset($disableResponse['error'])){
    //                     return response()->json([
    //                         'success' => false,
    //                         'message' => __('Failed to disable Verifactu client.'),
    //                         'error'   => $disableResponse['error']
    //                     ], 500);
    //                 }
    //             }
    //         }

    //         $company->is_verifactu = $request->status;
    //         $company->save();

    //         $message = $request->status == "1"
    //             ? __('Verifactu enabled successfully.')
    //             : __('Verifactu disabled successfully.');

    //         return response()->json(['success' => true, 'message' => $message], 200);

    //     } catch (\Exception $e) {
    //         Log::error('Error updating verifactu: ' . $e->getMessage());
    //         return response()->json([
    //             'success' => false,
    //             'message' => __('Failed to update verifactu.'),
    //             'file'    => $e->getFile(),
    //             'line'    => $e->getLine(),
    //             'error'   => $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function updateVerifactu(Request $request, $id){
        try {
            $company = Company::where('id', $id)->first();

            // --- Validation checks (keep your existing ones) ---
            if(empty($company->gst_no)){
                return response()->json(['success' => false, 'message' => __('Please add gst no first.')], 200);
            }
            if(empty($company->territory)){
                return response()->json(['success' => false, 'message' => __('Please add territory.')], 200);
            }
            if(empty($company->dnia)){
                return response()->json(['success' => false, 'message' => __('Please add dnia no first.')], 200);
            }
            if(empty($company->extra['company_address']) ||
                empty($company->extra['locality']) ||
                empty($company->extra['zip_code']) ||
                empty($company->extra['country_code']) ||
                empty($company->extra['street_number']) ||
                empty($company->extra['state_code'])){
                return response()->json(['success' => false, 'message' => __('All address fields are required.')], 200);
            }

            // --- ENABLING ---
            if($request->status == "1") {

                if(empty($company->organization_details)) {
                    // Fresh setup — organization never created
                    $organization = $this->fiskaly->createOrganisation($company);
                    $company->refresh()->load('organization_details');
                    $this->fiskaly->createTaxPayer($company);
                    $this->fiskaly->generateAgreement($company);
                    $this->fiskaly->createSigner($company->user);
                    $this->fiskaly->createClient($company->user);

                } else {
                    // Organization exists — was previously disabled, create a new client
                    $newClientResponse = $this->fiskaly->createClient($company->user);

                    if(isset($newClientResponse['error'])){
                        return response()->json([
                            'success' => false,
                            'message' => __('Failed to re-enable Verifactu client.'),
                            'error'   => $newClientResponse['error']
                        ], 500);
                    }

                    // createClient() already saves the new client_id inside organization_details
                    // so nothing extra needed here
                }
            }

            // --- DISABLING ---
            if($request->status == "0") {
                $clientId = $company->organization_details->client_id ?? null;

                if($clientId) {
                    $disableResponse = $this->fiskaly->updateClient($company, $clientId);

                    if(isset($disableResponse['error'])){
                        return response()->json([
                            'success' => false,
                            'message' => __('Failed to disable Verifactu client.'),
                            'error'   => $disableResponse['error']
                        ], 500);
                    }
                }
            }

            $company->is_verifactu = $request->status;
            $company->save();

            $message = $request->status == "1"
                ? __('Verifactu enabled successfully.')
                : __('Verifactu disabled successfully.');

            return response()->json(['success' => true, 'message' => $message], 200);

        } catch (\Exception $e) {
            Log::error('Error updating verifactu: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => __('Failed to update verifactu.'),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
                'error'   => $e->getMessage()
            ], 500);
        }
    }


    public function generateAgreement(Request $request,$id){
        try {
            // Validate the request
            $company = Company::where('id',$id)->first();
    
          
            $agreement = $this->fiskaly->generateAgreement($company);

            // dd($agreement);
            return response()->json([
                'success' => true, 
                'message' => __('Generated Agreement Successfully.')
            ], 200);
            // Return success response
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error generate agreement: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('Failed to generate agreement.'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function uploadAgreement(Request $request)
    {
    try{
        $request->validate([
            'signed_agreement' => 'required|file|mimes:pdf',
            'company_id'=>'required'
        ]);

        $formdata = $request->all();
        $company = Company::where('id',$formdata['company_id'])->first();

        // Rename file with "_signed"
        $originalName = pathinfo($request->file('signed_agreement')->getClientOriginalName(), PATHINFO_FILENAME);
        $newFileName = $originalName . '_signed.pdf';

        // Save signed agreement in "signed_agreements" folder
        $filePath = $request->file('signed_agreement')->storeAs('signed_agreements', $newFileName, 'public');

        // Save path in database
        $company->organization_details->signed_agreement = 'storage/' . $filePath;
        $company->organization_details->save();

        $company->refresh();

        // Upload signed agreement to Fiskaly
        $uploadResponse = $this->fiskaly->uploadAgreement($company);

        // dd($uploadResponse);
        if (isset($uploadResponse['content']['status']) && $uploadResponse['content']['status'] != 200) {
            return back()->with('error',$uploadResponse['content']['message'] ?? 'Fiskaly upload failed');
        }

        return back()->with('success', 'Signed agreement uploaded and sent to Fiskaly successfully!');
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', $e->getMessage());
    }
    }

    public function generateApiKey(Request $request)
    {
        try{
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user = User::find($validated['user_id']);
          

            // generate unique API key
            do {
                $apiKey = Str::random(40);
            } while (VerifactuApiKeysModel::where('api_key', $apiKey)->exists());

            $apiData = [
                'name'       => $user->company['extra']['url'] ?? 'Custom Integration',
                'company_id' => $user->company->id,
                'api_key'    => $apiKey,
                'allowed_url'=> $user->company['extra']['url'] ?? 'https://www.entraenlared.com',
            ];

            $verifactu = VerifactuApiKeysModel::updateOrCreate(
                ['company_id' => $user->company->id],   // condition
                $apiData                                       // data to update or insert
            );
            // VerifactuApiKeysModel::create($apiData);

            return back()->with('success', 'API Key Generated Successfully.');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function sendAgreement(Request $request){
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user_model = new User();
            $user = User::find($validated['user_id']);
            // dd($password);

            $subject = "Please check your agreement";
            $view = 'emails.send-agreement'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
            ];
            $pdfPath = public_path($user->company->organization_details->agreement);

            if (!file_exists($pdfPath)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Agreement file not found'
                ], 200);
            }
            $fileName = basename($user->company->organization_details->agreement);

            Mail::to($user->company->extra['alternative_email'] ?? $user->email)->send(new SystemEmail($subject, $view, $data,null,$fileName,null,null,$pdfPath));

            // Return success response
            return response()->json(['success' => true, 'message' => __('Agreement sent successfully.')], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation errors
            return response()->json(['success' => false, 'message' => $e->getMessage()], 200);
        }
    }


    public function sendApiKeys(Request $request){
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user_model = new User();
            $user = User::find($validated['user_id']);
            // dd($password);

            $subject = "Please check your api keys";
            $view = 'emails.send-api'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'apikeys'=>$user->company->apikeys
            ];
            

            Mail::to('aditya.sharma@entraenlared.com' ?? $user->company->extra['alternative_email'] ?? $user->email)->send(new SystemEmail($subject, $view, $data));

            // Return success response
            return response()->json(['success' => true, 'message' => __('Api sent successfully.')], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation errors
            return response()->json(['success' => false, 'message' => $e->getMessage()], 200);
        }
    }

    public function makeSuperCompany(Request $request){
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user = User::find($validated['user_id']);
            $user->assignRole('SupCompany');


            // Return success response
            return response()->json(['success' => true, 'message' => __('Assigned Super Comapny role Successfully.')], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation errors
            return response()->json(['success' => false, 'message' => $e->getMessage()], 200);
        }
    }

    public function enableAgreePopup(Request $request)
    {
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);

            $user = User::find($validated['user_id']);
            $company = $user->company;

            $company->is_agree = 0;

            // Decode JSON safely and remove 'current' key
            $extra = $company->extra ?? [];

            if (is_array($extra) && array_key_exists('current', $extra)) {
                unset($extra['current']);
            }

            // Assign updated array back
            $company->extra = $extra;

            $company->save();

            return response()->json([
                'success' => true,
                'message' => __('Popup Enabled Successfully.'),
            ], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

}
