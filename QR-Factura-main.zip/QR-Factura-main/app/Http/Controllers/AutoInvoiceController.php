<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AutoInvoice;
use App\Models\Providers;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use Exception;
use App\Models\ActivityLog;
use PhpOffice\PhpSpreadsheet\IOFactory;


use App\Services\UtilityService;
use App\Services\InvoiceService;

class AutoInvoiceController extends Controller
{
    use ContentDataTrait;
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            // dd($company);
            // if(!empty($company) && $company->id == 3){
            //     // dd($company);
            //     $aggrement = $this->fiskaly->generateAgreement($company);
            //     dd($aggrement);
            // }
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            // $query = AutoInvoice::query();
            $query = AutoInvoice::where('status', '!=', AutoInvoice::NEGATIVE_INVOICE);

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
             // Apply reusable filters
            UtilityService::applyFilters(
                $query,
                $formdata, // FIXED
                $company,
                [
                    'search_fields' => ['invoice_id'],
                    'date_field'    => 'issue_date'
                ]
            );

            // Final Query
            $invoices = $query
                ->orderBy('id', 'DESC')
                ->with(['client', 'invoiceType', 'paymentMethod'])
                ->paginate($limit);
                
            $statuses = getStatuses();
            $invoicesTypes = InvoiceType::all();

            if ($request->ajax()) {
                return view('panel.auto-invoice.partial_data', compact('invoices','statuses'))->render();
            }

            return view('panel.auto-invoice.index-invoice', compact('invoices', 'statuses'));
        } 
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        
    }

    public function makeInvoiceVerified(Request $request,$id){
        try {
            $user = auth()->user();
            $company = $user->company;

            $invoice = AutoInvoice::where('id',$id)->first();
            // dd($invoice);
            if(!$company->is_verifactu){
                $invoice->generateAutoInvoiceQrCode();
                return redirect()->back()->with('success','E Invoice Created Successfully');
            }

            $fullAmount = parseNumber($invoice->grandTotal);
            // dd($fullAmount);
            if($fullAmount > 3000){
                if(empty($invoice->client->gst_no)){
                    return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Client Gst No is Required');
                }


                if (
                    empty($invoice->client->extra['address']) ||
                    empty($invoice->client->extra['zip_code'])
                ) {
                    return redirect()->back()->with('error', 'Your Invoice Amount exceed 3000 in that case All address fields are required');
                }

            }

            $fiskalyInvoice = $this->fiskaly->createAutoInvoice($company,$invoice);
            // dd($fiskalyInvoice);

            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Invoice '. $invoice->invoice_id,
                'ip_address' => $request->ip()
            ]);
            // dd($fiskalyInvoice);
            return redirect()->back()->with('success', $fiskalyInvoice['content']['message'] ?? 'Invoice Verified Successfully');
        } 
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

     public function calculateInvoices(Request $request)
    {
        $data = $request->all();
        return response()->json(UtilityService::calculate($data));
    }


    public function exportInvoicesToCsv()
    {
        try {
            $invoices = AutoInvoice::all();
            $filename = "invoices.csv";

            $headers = [
                "Content-Type"        => "text/csv; charset=UTF-8",
                "Content-Disposition" => "attachment; filename=\"{$filename}\"",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            ];

            $callback = function() use ($invoices) {
                // clear any previous output that may corrupt CSV
                if (ob_get_level() > 0) {
                    ob_end_clean();
                }

                $file = fopen('php://output', 'w');

                // Add UTF-8 BOM so Excel doesn’t break accents/special chars
                fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

                
                // Header row
                fputcsv($file, [
                    __('Customer'),
                    __('Invoice id'),
                    __('Issue'),
                    __('Expiration'),
                    __('Invoice Type'),
                    __('Payment Method'),
                    __('Items'),
                    __('Sub Total'),
                    __('Tax'),
                    __('Total'),
                    __('Status'),
                ]);
                

                // Data rows
                foreach ($invoices as $invoice) {

                    $items = $invoice->items;
                    $itemLines = [];

                    if (is_array($items)) {
                        foreach ($items as $item) {
                            $itemLines[] = $item['name'] . " (Qty: " . $item['quantity'] . ", Price: " . $item['price'] . ", Amount: " . $item['amount'] . ")";
                        }
                    }

                    // Join items with line breaks
                    $itemsString = implode("\n", $itemLines);

                    fputcsv($file, [
                        $invoice->client->company->company_name ?? $invoice->client->extra['company_name'] ?? $invoice->client->name ?? null,
                        $invoice->invoice_id,
                        $invoice->issue_date,
                        $invoice->due_date,
                        $invoice->invoiceType->name??'',
                        $invoice->paymentMethod->name??'',
                        $itemsString,
                        formatCurrency(parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount),$invoice->currency),
                        formatCurrency($invoice->totalTax,$invoice->currency),
                        formatCurrency($invoice->grandTotal,$invoice->currency),
                        __($statuses[$invoice->status] ?? 'NA')
                    ]);
                }

                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    

    public function indexNegativeInvoice(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            // dd($company);
            // if(!empty($company) && $company->id == 3){
            //     // dd($company);
            //     $aggrement = $this->fiskaly->updateTaxPayer($company);
            //     dd($aggrement);
            // }
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = AutoInvoice::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('invoice_id', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($formdata) {
                            $query->where('name', 'like', '%' . $formdata['search'] . '%')
                                    ->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $formdata['search'] . '%']);
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); 
            }

            if (isset($formdata['invoice_type']) && !is_null($formdata['invoice_type'])) {
                $query->where('invoice_type', $formdata['invoice_type']); 
            }

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            }

            // Check if the user is not an Admin and role is neither 1 nor 2
            // if (!$user->hasRole('Admin') && !$user->hasRole('Company') ) {
            //     $query->where('created_by', $user->id);
            // }

            $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            $invoices = $query->where('status',self::NEGATIVE_INVOICE)->orderBy('id','DESC')->with(['client','invoiceType','paymentMethod'])->paginate($limit);
            $allNegativeInvoices = AutoInvoice::where('status','!=',self::NEGATIVE_INVOICE)->orderBy('id','DESC')->get();
            // dd($invoices);
            $invoicesTypes = InvoiceType::all();

            $statuses = getStatuses();
            $monthlyTotals = [];
            $totalYearGrandTotal = 0;
            $totalYearTax = 0;
            $totalYearSubTotal = 0;

            foreach ($invoices as $invoice) {
                $invoiceCurrency = $invoice->currency ?? $baseCurrency;
                $month = date('m', strtotime($invoice->issue_date));
                $year = date('Y', strtotime($invoice->issue_date));
                $monthYearKey = date('F Y', strtotime($invoice->issue_date));
                
                if (!isset($monthlyTotals[$monthYearKey])) {
                    $monthlyTotals[$monthYearKey] = [
                        'month' => $month,
                        'year' => $year,
                        'monthYear' => $monthYearKey,
                        'grandTotal' => 0, 
                        'tax' => 0,
                        'formattedGrandTotal' => '',
                        'formattedTax' => ''
                    ];
                }

                $grandTotal = parseNumber($invoice->grandTotal ?? 0);
                $totalTax = parseNumber($invoice->totalTax ?? 0);
                $subTotal =  parseNumber($invoice->subtotal)-parseNumber($invoice->totalDiscount);

                // Convert to base currency if different
                if ($invoiceCurrency !== $baseCurrency) {
                    $rate = $exchangeRates[$invoiceCurrency] ?? 1;
                    $grandTotal = $grandTotal / $rate;
                    $totalTax = $totalTax / $rate;
                }

                // Accumulate totals
                $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
                $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                
                $totalYearGrandTotal += $grandTotal;
                $totalYearTax += $totalTax;
                $totalYearSubTotal += $subTotal;
            }
            $totalYearGrandTotal = formatValueCurrency(
                formatValue($totalYearGrandTotal, $targetCurrency),
                $targetCurrency
            );
            $totalYearTax = formatValueCurrency(
                formatValue($totalYearTax, $targetCurrency),
                $targetCurrency
            );

            $totalYearSubTotal = formatValueCurrency(
                formatValue($totalYearSubTotal, $targetCurrency),
                $targetCurrency
            );

            // Sort by year and month (newest first)
            uasort($monthlyTotals, function($a, $b) {
                if ($a['year'] == $b['year']) {
                    return $b['month'] <=> $a['month'];
                }
                return $b['year'] <=> $a['year'];
            });

            // Format all values
            foreach ($monthlyTotals as &$totals) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );
            }

            // if($company && $company->is_verifactu){
            //     // if(!$company->organization_details->is_verified){
            //     //     abort(403, 'You must first verify the company with the Verifactu agreement.');
            //     // }
            //     if ($request->ajax()) {
            //         return view('panel.verifactu-auto-invoice.partial_negative_invoice_data', compact('invoices','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal'))->render();
            //     }

            //     return view('panel.verifactu-auto-invoice.index-negative-invoice', compact('invoices', 'invoicesTypes','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal','allNegativeInvoices'));
            // }

            if ($request->ajax()) {
                return view('panel.auto-invoice.partial_negative_invoice_data', compact('invoices','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal'))->render();
            }

            return view('panel.auto-invoice.index-negative-invoice', compact('invoices', 'invoicesTypes','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal','allNegativeInvoices'));
        
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        } 
    }

    public function getSearchResults(Request $request)
    {
        try {
            $searchTerm = $request->input('search');

            if (empty($searchTerm)) {
                return response()->json([]);
            }

            $user = auth()->user();
            $company = $user->company;

            $invoices = AutoInvoice::with('client')
                ->where(function ($query) use ($searchTerm, $company) {
                    $query->where('invoice_id', 'like', '%' . $searchTerm . '%');

                    $query->orWhereHas('client', function ($q) use ($searchTerm, $company) {
                        $q->where('name', 'like', '%' . $searchTerm . '%');

                        if (!empty($company)) {
                            $q->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $searchTerm . '%']);
                        } else {
                            $q->orWhereHas('singleCompany', function ($subQuery) use ($searchTerm) {
                                $subQuery->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        }
                    });
                })
                ->limit(10)->orderBy('id','desc')->where('status','!=',self::NEGATIVE_INVOICE)
                ->get();

            $results = $invoices->map(function ($invoice) {
                $client = $invoice->client;
                $clientName = $client->company->company_name
                    ?? $client->extra['company_name']
                    ?? $client->name;

                return [
                    'invoice_id' => $invoice->invoice_id, // used to fill input
                    'text' => "{$clientName} - {$invoice->invoice_id}" // shown in dropdown
                ];
            });

            return response()->json($results);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


     
     
     
    public function editInvoice($id)
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = AutoInvoice::where('id', $id)->first();
            // $clients = Providers::where('status',1)->get();
            
            $clients = Providers::get();
            
                
            
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            return view('panel.auto-invoice.form', compact('invoice','taxslab', 'paymentMethods', 'services', 'invoicePrefixs','invoiceType', 'inventories', 'clients', 'templates','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

   

    public function addInvoice()
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $invoice = AutoInvoice::where('id',$id)->first();
            
            $clients = Providers::get();
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            // $services = Services::where('status',1)->get();
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
                
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            $invoice = new AutoInvoice();
            return view('panel.auto-invoice.form', compact('paymentMethods','taxslab', 'invoice','inventories', 'services', 'invoiceType', 'clients', 'templates','defaultCurrency','tax_slab','invoicePrefixs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    } 

    public function addOrEditInvoices(Request $request, InvoiceService $invoiceService)
    {

        try {
          
            $formdata = $request->all();
            $user = Auth::user();
            $company = $user->company;
            $invoice_id = $formdata['id'] ?? null;
            $adminUser = User::where('id',$company->admin_id ?? 1)->first();

            // if ($company && $company->user->subscriptionDetails->subscription) {
            //     $totalLeftInvoice = $company->user->subscriptionDetails->subscription->invoices ?? null;
            //     $invoice_issue_date = $formdata['issue_date'];

            //     // Count invoices issued in the same month & year as the issue_date
            //     $totalCreatedInvoice = AutoInvoice::whereMonth('issue_date', date('m', strtotime($invoice_issue_date)))
            //         ->whereYear('issue_date', date('Y', strtotime($invoice_issue_date)))
            //         ->count();

            //     // Only check limit if it's NOT unlimited (null means unlimited)
            //     if (!is_null($totalLeftInvoice) && $totalCreatedInvoice >= $totalLeftInvoice) {
            //         return response()->json([
            //             'success' => false,
            //             'message' => __("You can't create more invoices. Total Limit Reached. Contact Administrator."),
            //         ], 200);
            //     }
            // }


            if($company){
                $gst_no = $company->gst_no ?? null;
            }else{
                $gst_no = $adminUser->extra['gst_no'] ?? null;
            }

            if(empty($gst_no)){
                return response()->json([
                    'success' => false,
                    'message' => __('Please add GST number in company settings to add auto-invoice.'),
                ], 200);
            }

            

            // Validate request data
            $validator = $this->validateInvoice($formdata,$company);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            // if($formdata['client_id'] == 'new-client'){
            //     $isExist = null;
            //     if(empty($company)){
            //         $isExist = User::where('email',$formdata['client_email'])->first();
            //     }else{
            //         $isExist = Providers::where('email',$formdata['client_email'])->first();
            //     }

            //     if(!empty($isExist)){
            //         return response()->json([
            //             'success' => false,
            //             'message' => __('Validation failed.'),
            //             'errors' => [
            //                 'client_email'=>[__('The client email already exists.')]
            //             ]
            //         ], 200);
            //     }
            // }

            $items = $formdata['items'];
    
            // if ($formdata['client_id'] === 'new-client') {
            //     $client = $this->handleNewClient($formdata, $company);
            //     $formdata['client_id'] = $client->id;
            // }
        
            $invoice_data = [
                'client_id'     => $formdata['client_id'],
                'issue_date'     => $formdata['issue_date'],
                'currency'       => $formdata['currency'],
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
            ];
            // dd($formdata['extra']);

            
          
            if (empty($invoice_id)) {
                $invoice_data['invoice_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'],$company, 'auto-invoice');  
                // $this->generateInvoiceId($formdata['issue_date'], $company, $user,$formdata['client_id'],$formdata);
                // if(isset($formdata['status'])){
                    $invoice_data['status']= $formdata['status'] ?? 0;
                // }

                $invoice_data['items'] = UtilityService::convertItemsToINFormat($invoice_data['items']);
                $invoice_data['created_by'] = $user->id;
                $invoice_data['domain_id'] = getDomainId();
                $invoice_data['extra']= $formdata['extra'] ?? null;
                $invoice = AutoInvoice::create($invoice_data);
                
            } else {
                $oldInvoice = AutoInvoice::find($invoice_id);

                // if ($formdata['extra']['invoice_prefix'] != ($oldInvoice->extra['invoice_prefix'] ?? null)) {
                //     $invoice_data['invoice_id'] = $this->generateInvoiceId($formdata['issue_date'], $company, $user, $formdata['client_id'], $formdata);
                // }

                // Update base invoice data (excluding 'extra')
                $invoice_data['items'] = UtilityService::convertItemsToINFormat($invoice_data['items']);
                AutoInvoice::where('id', $invoice_id)->update($invoice_data);

                $invoice = AutoInvoice::find($invoice_id);

                // ✅ Merge only incoming keys into existing extra
                if (!empty($formdata['extra']) && is_array($formdata['extra'])) {
                    $invoice->extra = array_merge($invoice->extra ?? [], $formdata['extra']);
                    $invoice->save();
                }

            }

            return response()->json([
                'success' => true,
                'message' => $invoice_id ? __('Invoice updated successfully.') : __('Invoice created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoice: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    private function validateInvoice($data,$company)
    {
        try {
            $table =  (new Providers)->getTable();
            return Validator::make($data, [
                'client_id'      => 'required',
                'issue_date'      => 'required|date',
                'currency'        => 'required|string|max:10',
                
                'ref_no'          => 'sometimes|max:255',
                'items'           => 'required|array|min:1',
                'items.*.name' => 'required',
                'items.*.quantity'=> 'required|numeric|min:1',
                'items.*.price'   => 'required|min:0',
                'items.*.discount'=> 'nullable|min:0',
                'items.*.tax'     => 'nullable|min:0|max:100',
                'items.*.amount'  => 'required',
                'client_email'   => [
                    'required_if:client_id,new-client',
                ],
                'client_name'     => 'required_if:client_id,new-client',
                'extra.note' => 'nullable|string|max:300',
            ], [
                'client_email.required_if' => __('Client email is required for a new client.'),
                'client_name.required_if'  => __('Client name is required for a new client.'),
                'client_email.email'       => __('Please provide a valid email address for the client.'),
                'client_email.unique'      => __('The client email already exists.'),
                'items.required'            => __('At least one item is required in the auto-invoice.'),
                'items.*.name.required'  => __('Please Select any item.'),
                'items.*.quantity.required' => __('Each item must have a quantity.'),
                'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
                'items.*.quantity.min'      => __('The quantity must be at least 1.'),
                'items.*.price.required'    => __('Each item must have a price.'),
                'items.*.price.min'         => __('The price must be at least 0.'),
                'items.*.discount.min'      => __('The discount must be at least 0.'),
                'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
                'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
                'items.*.amount.required'   => __('Each item must have an amount.'),
                'extra.note.string' => __('The note must be a valid text.'),
                'extra.note.max' => __('The note cannot be longer than 300 characters.'),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }

    
    public function previewInvoice($invoiceId)
    {
        // try {
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $invoice = AutoInvoice::findOrFail($invoiceId);
            $templateId = env('AUTO_INVOICE_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            // dd($company);
            // if($company && !$company->is_verifactu && $company->extra['country_code'] == 'ES'){
            //     // dd('hi');
            //     $invoice->generateInvoiceQrCode();
            // }
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);


            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $invoice->client->name ?? null,
            ];

            return view('invoice.singlePreview', ['templateHtml' => $datahtml, 'data' => $data]);
            // return view('invoice.preview', ['templateHtml' => $datahtml, 'data' => $data]);
        // } catch (\Throwable $e) {
        //     return redirect()->back()->with('error', __($e->getMessage() . $e->getLine()));
        // }
    }

    public function downloadInvoice($invoiceId)
    {
        try {
            $invoice = AutoInvoice::findOrFail($invoiceId);
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

            // if($company && !$company->is_verifactu && $company->extra['country_code'] == 'ES'){
            //     $invoice->generateInvoiceQrCode();
            // }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                // $user = $authUser;
                $user = User::where('id', 1)->first();
            }

            $templateId = env('AUTO_INVOICE_TEMPLATE_ID');

            $template = Templates::where('id', $templateId)->first();
            
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }

            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
            // Get the storage path dynamically
            $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

            // Get the base URL dynamically
            $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';


            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );
            // dd($datahtml);
            // Generate PDF from the rendered template
            $pdf = PDF::loadHTML($datahtml)->setPaper('a4', 'portrait');

            return $pdf->download("invoice-{$invoiceId}-{$invoice->issue_date}.pdf");
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
}
