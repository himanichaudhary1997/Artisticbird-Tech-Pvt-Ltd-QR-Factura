<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tutorials;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class TutorialsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    // Show all TUTORIALs
    public function indexTutorials(Request $request)
    {
        try{
        $query = Tutorials::query()->orderBy('id', 'DESC');

        if ($request->filled('search')) {
            $search = $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        $tutorials = $query->get(); // ✅ Better than get() if you have many TUTORIALs

        if ($request->ajax()) {
            return view('panel.tutorials.partial', compact('tutorials'))->render();
        }

        return view('panel.tutorials.index', compact('tutorials'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }


    // Show create form
    public function createTutorials()
    {
    try{
        return view('panel.tutorials.create');
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }


    // Show edit form
    public function editTutorials($id)
    {
    try{
        $tutorial = Tutorials::findOrFail($id);
        return view('panel.tutorials.edit', compact('tutorial'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function addOrEditTutorials(Request $request)
    {
        
        try {
            $formdata = $request->all();

            $tutorial_id = $formdata['id'] ?? null;

            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'video_url'   => 'required',
                'thumbnail'   => 'required',
                'description'   => 'required',
            ];
            $validator = Validator::make($formdata, $rules);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors'  => $validator->errors(),
                ], 200);
            }

            $extra = [
                'description' => $formdata['description'] ?? null,
            ];

            $tutorialData = [
                'name' => $formdata['name'],
                'video_url'   => $formdata['video_url'],
                'thumbnail' => $formdata['thumbnail'],
                'extra'     => $extra,

            ];

            if (!empty($tutorial_id)) {
                // Update existing TUTORIAL
                $tutorial = Tutorials::findOrFail($tutorial_id);
                $tutorial->update($tutorialData);

                $message = __('TUTORIAL updated successfully.');
            } else {
                // Create new TUTORIAL
                $tutorial = Tutorials::create($tutorialData);

                $message = __('TUTORIAL created successfully.');
            }

            return response()->json([
                'success' => true,
                'message' => $message,
                'data'    => $tutorial,
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error in addOrEditTutorials: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error'   => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ], 500);
        }
    }
    // Delete TUTORIAL
    public function deleteTutorials($id)
    {
        try{
            $tutorial = Tutorials::findOrFail($id);
            $tutorial->delete();

            return redirect()->route('tutorials.index')->with('success', 'TUTORIAL deleted successfully!');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
}
