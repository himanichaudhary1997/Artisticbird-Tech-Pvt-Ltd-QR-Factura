<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InvoicePrefix;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
class InvoicePrefixController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function indexInvoicePrefix(Request $request){
        try {
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
        
            $query = InvoicePrefix::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                // dd($formdata);
                $query->where(function ($q) use ($formdata) {
                    $q->where('prefix', 'like', '%' . $formdata['search'] . '%');
                    $q->orWhere('series', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            // if (isset($formdata['type']) && !empty($formdata['type'])) {
            //     $query->where('type', $formdata['type']); // Assuming `scope` is a column in the `users` table
            // }   

        
            // Fetch paginated results with related data
            $invoicePrefix = $query->orderBy('id','DESC')->paginate($limit);
            // $InvoicePrefix = InvoicePrefix::paginate(10);
            
            if ($request->ajax()) {
                return view('panel.invoice-prefix.partial_data', compact('invoicePrefix'))->render();
            }

            return view('panel.invoice-prefix.index-invoice-prefix', compact('invoicePrefix'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function editInvoicePrefix($id){
        try {
        $invoicePrefix = InvoicePrefix::find($id);
        return view('panel.invoice-prefix.edit-prefix',compact('invoicePrefix'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addInvoicePrefix(){
        try {
        return view('panel.invoice-prefix.add-prefix');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
    public function addOrEditInvoicePrefix(Request $request){
        
        try {
            // Extract form data
            $formdata = $request->all();
            // $service_id = $formdata['id'] ?? null;
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoie_prefix_id = $formdata['id'] ?? null;
            $dynamicTableName = (new InvoicePrefix())->getTable();
            $defaultPrefix = strtoupper(substr($company->company_name ?? 'AR', 0, 2));
            // dd($defaultPrefix);
            // dd($service_id);
            // Validation rules
            $rules = [
                'prefix' => [
                    'required',
                    // 'regex:/^[A-Z]{1,2}$/', // Ensures exactly 1 or 2 uppercase letters
                    // 'not_in:' . $defaultPrefix, // Ensures prefix is NOT equal to $defaultPrefix
                    'unique:' . $dynamicTableName . ',prefix,' . $invoie_prefix_id, // Correct syntax
                ],
                // 'series' => 'required|integer|digits_between:1,4|min:1', // Ensures 1 to 4 digit integer
            ];
            
            // $messages = [
            //     'prefix.required' => 'The prefix field is required.',
            //     'prefix.regex' => 'The prefix must be 1 or 2 uppercase letters only.',
            //     'prefix.not_in' => 'The prefix cannot be the default prefix.',
            //     'prefix.unique' => 'This prefix is already taken.',           
            //     'series.required' => 'The series field is required.',
            //     'series.integer' => 'The series must be a valid number.',
            //     'series.digits_between' => 'The series must be between 1 and 4 digits.',
            // ];
            
            
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // dd($formdata);
            

            $invoice_prefix_data = [
                'prefix'=> $formdata['prefix'] ?? null,
                'series'=>$formdata['series'] ?? null,
                'extra'=>$formdata['extra'] ?? null,
            ];
            


            if (!empty($invoie_prefix_id)) {
                $invoicePrefixData = InvoicePrefix::where('id',$invoie_prefix_id)->first();
                InvoicePrefix::where('id', $invoie_prefix_id)->update($invoice_prefix_data);
                $invoicePrefix = InvoicePrefix::where('id',$invoie_prefix_id)->first();
    
                
            } else {
                // Create a new invoice
                $invoicePrefix = InvoicePrefix::create($invoice_prefix_data);
                
                
                
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Invoice Prefix updated successfully.') 
                    : __('Invoice Prefix created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoicePrefix: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function deleteInvoicePrefix($id){
        try {
            InvoicePrefix::destroy($id);
            return response()->json(['success'=>true,'message' => 'Invoice Prefix deleted successfully']);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete Invoice Prefix. Please try again.'
            ], 500);
        }
    }

    public function updateStatus(Request $request, $id){
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;
 
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
    
            $invoicePrefix = InvoicePrefix::findOrFail($id);
            $invoicePrefix->status = $request->status;
            $invoicePrefix->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Invoice Prefix status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Invoice Prefix status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
}
