<?php

namespace App\Http\Controllers;

use App\Services\PrestashopInvoicePdf;
use Illuminate\Http\Request;
use App\Models\Leads;
use Validator;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use App\Models\Templates;
use App\Models\Company;
use App\Models\Invoice;
use Vinkla\Hashids\Facades\Hashids;
use App\Models\User;
use App\Models\Receipts;
use App\Models\CountryModel;
use App\Models\Clients;
use App\Models\AutoInvoice;

class FrontController extends Controller
{
    
    public function index(Request $request){

        return view('front.index');
    }

    public function avisoLegal(Request $request){
        return view('front.aviso-legal');
    }

    public function politicaDePrivacidad(Request $request){
        return view('front.privacy-policy');
    }

    public function politicasDeCookies(Request $request){
        return view('front.cookies');
    }

    public function declaracionResponsable(Request $request){
        return view('front.declaration');
    }

    public function gracias(Request $request){
        return view('front.gracias');
    }

    public function store(Request $request)
    {
        try {
        $validator = Validator::make($request->all(), [
            'name'       => 'required|string|max:100',
            'last_name'  => 'required|string|max:100',
            'email'      => 'required|email',
            'phone'      => 'nullable|string|max:20',
            'message'    => 'nullable|string',
            'policy'     => 'accepted',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Por favor corrige los errores.',
                'errors'  => $validator->errors()
            ], 422);
        }

        $lead = Leads::create($request->only(['name','last_name','email','phone','message']));

        $data = [
            'name'=>$lead->name,
            'last_name'=>$lead->last_name,
            'email'=>$lead->email,
            'phone'=>$lead->phone,
            'message'=>$lead->message,
        ];

        Mail::to('emilio@entraenlared.com')
                ->send(new SystemEmail(
                'New Query Come',
                'emails.new-query', // Replace with your Blade view path
                $data, // Dynamic data
            ));

        return response()->json([
            'success' => true,
            'message' => 'Gracias, tu solicitud se envió correctamente.'
        ]);
    }
      catch (\Exception $e) {
            
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(),
              
            ], 500);
        }
    }


    public function previewInvoice($companyIdHash, $invoiceIdHash)
    {
        try {
            // 1️⃣ Decode Hashids
            $decodedCompany = Hashids::connection('company')->decode($companyIdHash);
            $decodedInvoice = Hashids::connection('invoice')->decode($invoiceIdHash);


            if (empty($decodedCompany) || empty($decodedInvoice)) {
                abort(404, 'Invalid QR Code');
            }

            $companyId = $decodedCompany[0];
            $invoiceId = $decodedInvoice[0];

            // 2️⃣ Get company + admin (fallback user if needed)
            $company = Company::findOrFail($companyId);
            $user = User::find($company->admin_id) ?? User::find(1);

            // 3️⃣ Fetch invoice from dynamic company table
            $invoice = (new Invoice())->setDynamicTableName($companyId)->findOrFail($invoiceId);
            // dd($invoice);
            $client = (new Clients())->setDynamicTableName($companyId)->find($invoice->client_id);
            // 4️⃣ Resolve template
            // $templateId = $company->extra['favouraite_template']
            //     ?? $user->extra['favouraite_template']
            //     ?? Templates::where('status', 1)->value('id');

            $templateId = getTemplateId(!empty($company) ? $company : $user);
            $template = Templates::where('id', $templateId)->first();
            if (empty($template) || $template->status != 1) {
                $template = Templates::where('status', 1)->first();
            }

            // 5️⃣ Generate invoice HTML
            $datahtml = PrestashopInvoicePdf::previewHtml($invoice, $company)
                ?? parseInvoiceSortcodes($template->template_html, $invoice, $company);

            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $client->name ?? null,
            ];

            return view('invoice.front-preview', [
                'templateHtml' => $datahtml,
                'data' => $data
            ]);

        } catch (\Throwable $e) {
            logger()->error($e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }

    }

    public function previewAutoInvoice($companyIdHash, $invoiceIdHash)
    {
        try {
            // 1️⃣ Decode Hashids
            $decodedCompany = Hashids::connection('company')->decode($companyIdHash);
            $decodedInvoice = Hashids::connection('auto-invoice')->decode($invoiceIdHash);
            // dd($decodedCompany,$decodedInvoice);

            if (empty($decodedCompany) || empty($decodedInvoice)) {
                abort(404, 'Invalid QR Code');
            }

            $companyId = $decodedCompany[0];
            $invoiceId = $decodedInvoice[0];

            // 2️⃣ Get company + admin (fallback user if needed)
            $company = Company::findOrFail($companyId);
            $user = User::find($company->admin_id) ?? User::find(1);

            // 3️⃣ Fetch invoice from dynamic company table
            $invoice = (new AutoInvoice())->setDynamicTableName($companyId)->findOrFail($invoiceId);
            // dd($invoice);
            
            // 4️⃣ Resolve template
            $templateId = env('AUTO_INVOICE_TEMPLATE_ID');

            $template = Templates::where('id', $templateId)->first();
            if (empty($template) || $template->status != 1) {
                $template = Templates::where('status', 1)->first();
            }

            // 5️⃣ Generate invoice HTML
            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);

            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                
            ];

            return view('invoice.front-preview', [
                'templateHtml' => $datahtml,
                'data' => $data
            ]);

        } catch (\Throwable $e) {
            logger()->error($e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
                // 'file' => $e->getFile(),
                // 'line' => $e->getLine(),
            ], 500);
        }

    }


    public function previewReceipt($companyIdHash, $receiptIdHash)
    {
        try {
            // 1️⃣ Decode Hashids
            $decodedCompany = Hashids::connection('company')->decode($companyIdHash);
            $decodedReceipt = Hashids::connection('receipt')->decode($receiptIdHash);


            if (empty($decodedCompany) || empty($decodedReceipt)) {
                abort(404, 'Invalid QR Code');
            }

            $companyId = $decodedCompany[0];
            $receiptId = $decodedReceipt[0];

            // 2️⃣ Get company + admin (fallback user if needed)
            $company = Company::findOrFail($companyId);
            $user = User::find($company->admin_id) ?? User::find(1);

            // 3️⃣ Fetch invoice from dynamic company table
            $receipt = (new Receipts())->setDynamicTableName($companyId)->findOrFail($receiptId);
            $client = (new Clients())->setDynamicTableName($companyId)->find($receipt->client_id);
            // 4️⃣ Resolve template
            
            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? $user->extra['country_code'] ?? null)->first();
            // ✅ Render Blade template to HTML string
            $html = view('panel.verifactu-receipt.receipt_html', compact('client','country','receipt', 'company', 'user'))->render();

            // ✅ Pass the HTML into preview page
            return view('invoice.receipt-preview', compact('client', 'receipt', 'company', 'user', 'html'));
            

        } catch (\Throwable $e) {
            logger()->error($e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }

    }


}
