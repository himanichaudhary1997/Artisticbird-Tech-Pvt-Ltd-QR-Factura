<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\DB;

class PermissionsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request){
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Permission::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['parent_id']) && !empty($formdata['parent_id'])) {
                $query->where('parent_id', $formdata['parent_id']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $permissions = $query->orderby('id','DESC')->paginate($limit);

            $permissions->getCollection()->transform(function ($permission) use ($user) {
                $menu = Menu::where('name',strtoupper($permission->name))->first();
                $permission->is_editable = !empty($menu) ? false : true;
                return $permission;
            });

            $permissions->getCollection()->transform(function ($permission) {
                // Count users assigned to this permission
                $permission->user_count = DB::table('model_has_permissions')
                    ->where('permission_id', $permission->id)
                    ->count();
    
                // Check if permission is editable based on menu existence
                $menu = Menu::where('name', strtoupper($permission->name))->first();
                $permission->is_editable = empty($menu);
    
                return $permission;
            });
             $parentPermissions = Permission::where('parent_id',null)->get();
             if($request->ajax())
             {
              return view('panel.permissions.partial_permission',compact('permissions'));
             }
            return view('panel.permissions.index-permission', compact('parentPermissions','permissions'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addPermission(){
        try{
        $parentPermissions = Permission::where('parent_id',null)->get();
        return view('panel.permissions.add-permission', compact('parentPermissions') );
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editPermission($id){
        try{
        $parentPermissions = Permission::where('parent_id',null)->get();
        $permission = Permission::where('id',$id)->first();
        return view('panel.permissions.edit-permission', compact('parentPermissions','permission'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function deletePermission($id){
        try {
            // Attempt to delete the user by ID
            Permission::destroy($id);
            

            // Return success response
            return response()->json(['success' => true, 'message' => __('Permission deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Permission. Please try again.')], 500);
        }
    }

    public function getAllPermissions(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Permission::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['parent_id']) && !empty($formdata['parent_id'])) {
                $query->where('parent_id', $formdata['parent_id']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $permissions = $query->orderby('id','DESC')->paginate($limit);

            $permissions->getCollection()->transform(function ($permission) use ($user) {
                $menu = Menu::where('name',strtoupper($permission->name))->first();
                $permission->is_editable = !empty($menu) ? false : true;
                return $permission;
            });

            $permissions->getCollection()->transform(function ($permission) {
                // Count users assigned to this permission
                $permission->user_count = DB::table('model_has_permissions')
                    ->where('permission_id', $permission->id)
                    ->count();
    
                // Check if permission is editable based on menu existence
                $menu = Menu::where('name', strtoupper($permission->name))->first();
                $permission->is_editable = empty($menu);
    
                return $permission;
            });
            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Permissions retrieved successfully.',
                'data' => $permissions,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Menus.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function addOrEditPermission(Request $request){
        try {
            // Extract form data
            $formdata = $request->all();

            $permission_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:permissions,name,' . $permission_id,
                'parent_id' => 'sometimes',
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $permission_data = [
                'name'=> strtolower($formdata['name']),
                'parent_id'=>$formdata['parent_id'] ?? null,
                'guard_name'=>'web'

            ];

            if (!empty($permission_id)) {
                $permissionData = Permission::where('id',$permission_id)->first();
                Permission::where('id', $permission_id)->update($permission_data);
                $permission = Permission::where('id',$permission_id)->first();
    
                
            } else {
                $permission = Permission::create($permission_data);
                
                
            }

            $superAdminRole = Role::where('name', 'Admin')->first();
            if ($superAdminRole) {
                $superAdminRole->givePermissionTo($permission);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Permission updated successfully.') 
                    : __('Permission created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditPermission: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }
}
