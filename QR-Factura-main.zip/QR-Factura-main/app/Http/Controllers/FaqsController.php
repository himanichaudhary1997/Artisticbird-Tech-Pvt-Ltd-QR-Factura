<?php

namespace App\Http\Controllers;

use App\Models\Faqs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class FaqsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    // Show all FAQs
    public function indexFaqs(Request $request)
    {
        try {
            $query = Faqs::query();

            if ($request->filled('search')) {
                $search = $request->get('search');
                $query->where(function ($q) use ($search) {
                    $q->where('question', 'like', "%{$search}%")
                    ->orWhere('answer', 'like', "%{$search}%");
                });
            }

            $faqs = $query->orderBy('id','ASC')->get(); // ✅ Better than get() if you have many FAQs

            if ($request->ajax()) {
                return view('panel.faqs.partial', compact('faqs'))->render();
            }

            return view('panel.faqs.index', compact('faqs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    // Show create form
    public function createFaqs()
    {
        try {
        return view('panel.faqs.create');
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    // Show edit form
    public function editFaqs($id)
    {
        try {
        $faq = Faqs::findOrFail($id);
        return view('panel.faqs.edit', compact('faq'));
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditFaqs(Request $request)
    {
        try {
            $formdata = $request->all();

            $faq_id = $formdata['id'] ?? null;

            // Validation rules
            $rules = [
                'question' => 'required|string|max:255',
                'answer'   => 'required|string',
            ];

            $validator = Validator::make($formdata, $rules);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors'  => $validator->errors(),
                ], 200);
            }

            $faqData = [
                'question' => $formdata['question'],
                'answer'   => $formdata['answer'],
            ];

            if (!empty($faq_id)) {
                // Update existing FAQ
                $faq = Faqs::findOrFail($faq_id);
                $faq->update($faqData);

                $message = __('FAQ updated successfully.');
            } else {
                // Create new FAQ
                $faq = Faqs::create($faqData);

                $message = __('FAQ created successfully.');
            }

            return response()->json([
                'success' => true,
                'message' => $message,
                'data'    => $faq,
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error in addOrEditFaqs: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error'   => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ], 500);
        }
    }

    // Delete FAQ
    public function deleteFaqs($id)
    {
        try {
            $faq = Faqs::findOrFail($id);
            $faq->delete();
            return redirect()->route('faqs.index')->with('success', 'FAQ deleted successfully!');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
}
