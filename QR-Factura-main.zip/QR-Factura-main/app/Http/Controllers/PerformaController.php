<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Performa;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use App\Models\Invoice;
use Exception;


use App\Services\InvoiceService;
use App\Services\UtilityService;

use DOMDocument;
use DOMXPath;
use App\Models\Contracts;


class PerformaController extends Controller
{

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = Performa::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }


            // Apply reusable filters
            UtilityService::applyFilters(
                $query,
                $formdata, // FIXED
                $company,
                [
                    'search_fields' => ['performa_id'],
                    'date_field'    => 'issue_date'
                ]
            );

            // Final Query
            $performas = $query
                ->orderBy('id', 'DESC')
                ->with(['client','paymentMethod'])
                ->paginate($limit);

            
            // Apply search filter
            // if (isset($formdata['search']) && !empty($formdata['search'])) {
            //     $query->where(function ($q) use ($formdata,$company) {
            //         $searchTerm = $formdata['search'];
                    
            //         $q->where('performa_id', 'like', '%' . $searchTerm . '%');
            //         if(!empty($company)){
            //             $q->orWhereHas('client', function ($query) use ($formdata) {
            //                 $query->where('name', 'like', '%' . $formdata['search'] . '%')
            //                         ->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $formdata['search'] . '%']);
            //             });
            //         }else{
            //             $q->orWhereHas('client', function ($query) use ($searchTerm) {
            //                 $query->where('name', 'like', '%' . $searchTerm . '%');
            //                 $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
            //                     $query->where('company_name', 'like', '%' . $searchTerm . '%');
            //                 });
            //             });
            //         }
            //     });
            // }
            // if (isset($formdata['status']) && !is_null($formdata['status'])) {
            //     $query->where('status', $formdata['status']); 
            // }

            // // if (isset($formdata['performa_type']) && !is_null($formdata['performa_type'])) {
            // //     $query->where('performa_type', $formdata['performa_type']); 
            // // }

            // if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
            //     $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            // } elseif (!empty($formdata['from_date'])) {
            //     $query->where('issue_date', '>=', $formdata['from_date']);
            // } elseif (!empty($formdata['to_date'])) {
            //     $query->where('issue_date', '<=', $formdata['to_date']);
            // }

            // // Check if the user is not an Admin and role is neither 1 nor 2
            // // if (!$user->hasRole('Admin') && !$user->hasRole('Company') ) {
            // //     $query->where('created_by', $user->id);
            // // }

            // $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            // $performas = $query->orderBy('id','DESC')->with(['client','paymentMethod'])->paginate($limit);

            

            
            // $monthlyTotals = [];
            // $totalYearGrandTotal = 0;
            // $totalYearTax = 0;
            // $totalYearSubTotal = 0;

            // foreach ($performas as $performa) {
            //     $performaCurrency = $performa->currency ?? $baseCurrency;
            //     $month = date('m', strtotime($performa->issue_date));
            //     $year = date('Y', strtotime($performa->issue_date));
            //     $monthYearKey = date('F Y', strtotime($performa->issue_date));
                
            //     if (!isset($monthlyTotals[$monthYearKey])) {
            //         $monthlyTotals[$monthYearKey] = [
            //             'month' => $month,
            //             'year' => $year,
            //             'monthYear' => $monthYearKey,
            //             'grandTotal' => 0, 
            //             'tax' => 0,
            //             'formattedGrandTotal' => '',
            //             'formattedTax' => ''
            //         ];
            //     }

            //     $grandTotal = parseNumber($performa->grandTotal ?? 0);
            //     $totalTax = parseNumber($performa->totalTax ?? 0);
            //     $subTotal = parseNumber($performa->subtotal ?? 0);

            //     // Convert to base currency if different
            //     if ($performaCurrency !== $baseCurrency) {
            //         $rate = $exchangeRates[$performaCurrency] ?? 1;
            //         $grandTotal = $grandTotal / $rate;
            //         $totalTax = $totalTax / $rate;
            //     }

            //     // Accumulate totals
            //     $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
            //     $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                
            //     $totalYearGrandTotal += $grandTotal;
            //     $totalYearTax += $totalTax;
            //     $totalYearSubTotal += $subTotal;
            // }
            // $totalYearGrandTotal = formatValueCurrency(
            //     formatValue($totalYearGrandTotal, $targetCurrency),
            //     $targetCurrency
            // );
            // $totalYearTax = formatValueCurrency(
            //     formatValue($totalYearTax, $targetCurrency),
            //     $targetCurrency
            // );

            // $totalYearSubTotal = formatValueCurrency(
            //     formatValue($totalYearSubTotal, $targetCurrency),
            //     $targetCurrency
            // );

            // // Sort by year and month (newest first)
            // uasort($monthlyTotals, function($a, $b) {
            //     if ($a['year'] == $b['year']) {
            //         return $b['month'] <=> $a['month'];
            //     }
            //     return $b['year'] <=> $a['year'];
            // });

            // // Format all values
            // foreach ($monthlyTotals as &$totals) {
            //     $totals['formattedGrandTotal'] = formatValueCurrency(
            //         formatValue($totals['grandTotal'], $targetCurrency),
            //         $targetCurrency
            //     );
            //     $totals['formattedTax'] = formatValueCurrency(
            //         formatValue($totals['tax'], $targetCurrency),
            //         $targetCurrency
            //     );
            // }

            $statuses = getStatuses();
            $stats = Performa::get();
            if ($request->ajax()) {
                return view('panel.performa.partial_data', compact('performas','statuses'))->render();
            }
            return view('panel.performa.index-performa', compact('performas', 'stats'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        
    }
     
    public function editPerforma($id)
    {
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            $performa = Performa::where('id',$id)->first();
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $performa = Performa::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            
            $country = CountryModel::all();
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.performa.form', compact('country','paymentMethods', 'taxslab','performa' ,'inventories', 'services', 'clients','defaultCurrency','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addPerforma()
    {
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $performa = Performa::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            
            $country = CountryModel::all();
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $taxslab = TaxRules::where('tax_type', 'iva')->where('status',1)
                ->where('type', 'percentage')
                ->orderByRaw('CAST(value AS DECIMAL(10,2)) ASC')
                ->get();
            $services = Services::where('status', 1)->get();
            $performa = new Performa();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.performa.form', compact('country','taxslab','performa','paymentMethods', 'inventories', 'services', 'clients','defaultCurrency','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditPerformas(Request $request, InvoiceService $invoiceService)
    {

         try {
            // Extract form data
            $formdata = $request->all();
            $user = Auth::user();
            $company = $user->company;
            $adminUser = User::where('id',$company->admin_id ?? 1)->first();
            $performa_id = $formdata['id'] ?? null;
        
            if($company){
                $gst_no = $company->gst_no ?? null;
            }else{
                $gst_no = $adminUser->extra['gst_no'] ?? null;
            }

            if(empty($gst_no)){
                return response()->json([
                    'success' => false,
                    'message' => __('Please add GST number in company settings to add Proposal.'),
                ], 200);
            }

            // Validate request data
            $validator = $this->validatePerforma($formdata,$company);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $items = $this->processPerformaItems($formdata['items'], $formdata['currency']);
    
            if ($formdata['client_id'] === 'new-client') {
                if($formdata['client_country_code'] == 'ES' && isset($formdata['iscompany']) && $formdata['iscompany'] == 1){
                    $validatedGstNo = $this->fiskaly->validateGst($company,$formdata['client_gst_no'],$formdata['client_country_code'] ?? 'ES');
                    if(!$validatedGstNo){
                        return response()->json([
                            'success' => false,
                            'message' => __('The Spanish C.I.F. number must begin with A or B followed by 8 digits.'),
                        ]);
                    }
                }
                $client = $this->handleNewClient($formdata, $company);
                $formdata['client_id'] = $client->id;
            }
        
            $performa_data = [
                'client_id'     => $formdata['client_id'],
                'issue_date'     => $formdata['issue_date'],
                'due_date'       => $formdata['due_date'],
                'currency'       => $formdata['currency'],
                'payment_method' => $formdata['payment_method'],
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
                
                
            ];
            // dd($formdata['extra']);

            if (empty($performa_id)) {
                $performa_data['performa_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'],$company, 'performa'); 
                // if(isset($formdata['status'])){
                    $performa_data['status']= $formdata['status'] ?? 'draft';
                // }
                $performa_data['created_by'] = $user->id;
                $performa_data['domain_id'] = getDomainId();
                $performa_data['extra']= $formdata['extra'] ?? null;
                $performa_data['items'] = UtilityService::convertItemsToINFormat($performa_data['items']);
                $performa = Performa::create($performa_data);
                
            } else {
                $oldPerforma = Performa::find($performa_id);

                

                // Update base invoice data (excluding 'extra')
                $performa_data['items'] = UtilityService::convertItemsToINFormat($performa_data['items']);
                Performa::where('id', $performa_id)->update($performa_data);

                $performa = Performa::find($performa_id);

                // ✅ Merge only incoming keys into existing extra
                if (!empty($formdata['extra']) && is_array($formdata['extra'])) {
                    $performa->extra = array_merge($performa->extra ?? [], $formdata['extra']);
                    $performa->save();
                }

            }

            return response()->json([
                'success' => true,
                'message' => $performa_id ? __('Proposal updated successfully.') : __('Proposal created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoice: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    private function validatePerforma($data,$company)
    {
        try {
        $table = $company ? (new Clients)->getTable() : (new User)->getTable();
        return Validator::make($data, [
            'client_id'      => 'required',
            'issue_date'      => 'required|date',
            'due_date'        => 'required|date|after_or_equal:issue_date',
            'currency'        => 'required|string|max:10',
            'items'           => 'required|array|min:1',
            'items.*.name' => 'required',
            'items.*.quantity'=> 'required|numeric|min:1',
            'items.*.price'   => 'required|min:0',
            'items.*.discount'=> 'nullable|min:0',
            'items.*.tax'     => 'nullable|min:0|max:100',
            'items.*.amount'  => 'required',
            'client_email'    => 'required_if:client_id,new-client',
            'client_name'     => 'required_if:client_id,new-client',
            'client_gst_no' => [
                'required_if:client_id,new-client',
                // 'unique:'.$table.',gst_no',
            ],
            'client_company_name'     => 'required_if:client_id,new-client',
            'client_address'     => 'required_if:client_id,new-client',
            'client_locality'     => 'required_if:client_id,new-client',
            'client_zip_code'     => 'required_if:client_id,new-client',
            'client_country_code'     => 'required_if:client_id,new-client',
            'client_state_name'     => 'required_if:client_id,new-client',
            'extra.note' => 'nullable|string|max:500',
        ], [
            'client_email.required_if'      => __('Client email is required for a new client.'),
            'client_email.email'            => __('Please provide a valid email address for the client.'),
            'client_name.required_if'       => __('Client name is required for a new client.'),
            'client_gst_no.required_if'     => __('Client GST number is required for a new client.'),
            'client_gst_no.unique'          => __('This GST number is already registered. Please enter a unique GST number.'),
            'client_company_name.required_if' => __('Client company name is required for a new client.'),
            'client_address.required_if'    => __('Client address is required for a new client.'),
            'client_locality.required_if'   => __('Client locality is required for a new client.'),
            'client_zip_code.required_if'   => __('Client ZIP code is required for a new client.'),
            'client_country_code.required_if' => __('Client country is required for a new client.'),
            'client_state_name.required_if' => __('Client state is required for a new client.'),
            'items.required'            => __('At least one item is required in the invoice.'),
            'items.*.name.required'  => __('Please Select any item.'),
            'items.*.quantity.required' => __('Each item must have a quantity.'),
            'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
            'items.*.quantity.min'      => __('The quantity must be at least 1.'),
            'items.*.price.required'    => __('Each item must have a price.'),
            'items.*.price.min'         => __('The price must be at least 0.'),
            'items.*.discount.min'      => __('The discount must be at least 0.'),
            'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
            'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
            'items.*.amount.required'   => __('Each item must have an amount.'),
            'extra.note.string' => __('The note must be a valid text.'),
            'extra.note.max' => __('The note cannot be longer than 300 characters.'),
        ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }

    private function processPerformaItems($items, $currency)
    {
        $processedItems = [];

        foreach ($items as $item) {
            // if (isset($item['use_percentage']) && $item['use_percentage'] == 'true') {
            //     $item['discount'] = (parseNumber($item['discount_percentage']) * parseNumber($item['price'])) / 100;
            //     $item['discount'] = formatValue($item['discount'], $currency);
            // }

            if ($item['name'] === 'new-item') {
                $item['name'] = $this->createNewServiceItem($item); // this returns only string
            }

            if ($item['name'] === 'new-inventory') {
                $item['name'] = $this->createNewInventoryItem($item);
            }

            $processedItems[] = $item;
        }

        return $processedItems;
    }

    private function createNewServiceItem($item)
    {
        if (empty($item['new_item'])) {
            throw new \Exception(__('Please enter service name.'));
        }

        if (Services::where('name', $item['new_item'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_item'] . '" already exists.'));
        }

        $service = Services::create([
            'name'     => $item['new_item'],
            'slug'     => str_replace(' ', '-', strtolower($item['new_item'])),
            'status'   => 1,
            'price'    => parseInventoryServicePrice($item['price']),
            // 'tax_rate' => $item['tax'],
            'discount' => parseNumber($item['discount']),
        ]);

        return $service->name; // returns plain string
    }

    private function createNewInventoryItem($item)
    {
        if (empty($item['new_inventory'])) {
            throw new \Exception(__('Please enter inventory name.'));
        }

        if (Inventory::where('name', $item['new_inventory'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_inventory'] . '" already exists.'));
        }

        $inventory = Inventory::create([
            'name'      => $item['new_inventory'],
            'slug'      => str_replace(' ', '-', strtolower($item['new_inventory'])),
            'price'     => parseInventoryServicePrice($item['price']),
            'quantity'  => 0,
            // 'tax_rate'  => $item['tax'],
            'discount'  => parseNumber($item['discount']),
            'status'    => 1,
        ]);

        return $inventory->name;
    }
    
    private function handleNewClient($formdata, $company)
    {
        try{
            if ($company) {
                return Clients::create([
                    'name'     => $formdata['client_name'],
                    'email'    => $formdata['client_email'],
                    'mobile_no'=> $formdata['client_phone'],
                    'gst_no'=>$formdata['client_gst_no'],
                    'isCompany'=> isset($formdata['iscompany']) ? $formdata['iscompany'] : 0,
                    'extra'=>[
                        'company_name'     => $formdata['client_company_name'],
                        'address'     => $formdata['client_address'],
                        'locality'     => $formdata['client_locality'],
                        'zip_code'     => $formdata['client_zip_code'],
                        'country_code'     => $formdata['client_country_code'],
                        'state_name'     => $formdata['client_state_name'],
                    ],
                    'status'   => 1,
                ]);
            }

            do {
                $slug = substr(str_shuffle('123456789'), 0, 10);
            } while (Company::where('company_slug', $slug)->exists());

            $client = User::create([
                'name'              => $formdata['client_name'],
                'email'             => $formdata['client_email'],
                'phone'             => $formdata['client_phone'] ?? null,
                'status'            => 0,
                'email_verified_at' => now(),
                'is_email_verified'=> true,
                'password'          => Hash::make('admin@1223')
            ]);

            Company::create([
                'company_name'  => $formdata['client_name'],
                'company_slug'  => $slug,
                'company_email' => $formdata['client_email'],
                'admin_id'      => $client->id,
            ]);

            $client->syncRoles(['Company']);
            return $client;
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }


    public function deletePerforma($id)
    {
        try {
            Performa::destroy($id);
            // Return success response
            return response()->json(['success' => true, 'message' => __('Proposal deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Proposal. Please try again.')], 500);
        }
    }

    public function updatePerformaStatus(Request $request)
    {
        try {
            $formdata = $request->all();
            if (!isset($formdata['status']) || is_null($formdata['status'])) {
                return response()->json(['success' => false, 'message' => __('Status is required')], 200);
            }

            if (!isset($formdata['id']) || empty($formdata['id'])) {
                return response()->json(['success' => false, 'message' => __('Performa id is required')], 200);
            }
            // Attempt to delete the user by ID
            

            
            $editUrl = '';
            // if($formdata['status'] == 'accepted'){
            //     // $id = $this->convertProposalToFacturaInline($formdata['id']);
            //     $editUrl = route('performa.convertProposalToFactura',$formdata['id']);
            // }else{
            //     Performa::where('id', $formdata['id'])->update(['status' => $formdata['status']]);
            // }
             Performa::where('id', $formdata['id'])->update(['status' => $formdata['status']]);

            if($formdata['status'] == 'accepted'){
                $contract = Contracts::where('performa_id', $formdata['id'])->first();
                // if(empty($contract)){
                //     Contracts::create([
                //         'performa_id' => $formdata['id'],
                //         'contract_date' => now(),
                //     ]);
                // }

                Contracts::updateOrCreate(
                    ['performa_id' => $formdata['id']],
                    ['contract_date' => now()]
                );
            }

            // Return success response
            return response()->json(['success' => true,"editurl"=>$editUrl,'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function updateStatusToAccepted(Request $request,$id){
        try {
            
            // Attempt to delete the user by ID
            Performa::where('id', $id)->update(['status' => 'accepted']);

            $contract = Contracts::where('performa_id', $id)->first();
            // if(empty($contract)){
            //     Contracts::create([
            //         'performa_id' => $id,
            //         'contract_date' => now(),
            //     ]);
            // }
            Contracts::updateOrCreate(
                ['performa_id' => $id],
                ['contract_date' => now()]
            );

            // Return success response
            return response()->json(['success' => true,'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function previewPerforma($performaId)
    {
        try{
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $performa = Performa::findOrFail($performaId);
            $templateId = env('PRESUPESTOS_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            // dd($company);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     // dd('hi');
            //     $performa->generateInvoiceQrCode();
            // }
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);


            // $data = [
            //     'id' => $performa->id,
            //     'performa_no' => $performa['performa_id'] ?? null,
            //     'customer_name' => $performa->client->name ?? null,
            // ];



            // return view('panel.performa.preview', ['templateHtml' => $datahtml, 'data' => $data]);



            $data = [
                'id' => $performa->id,
                'invoice_no' => $performa['invoice_id'] ?? null,
                'customer_name' => $performa->client->name ?? null,
                'privacy' =>  $performa->extra['policies'] ?? null,
            ];



            return view('invoice.singlePreview', ['templateHtml' => $datahtml, 'data' => $data]);
            // return view('invoice.preview', ['templateHtml' => $datahtml, 'data' => $data]);

        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function downloadPerforma($performaId)
    {
        $performa = Performa::findOrFail($performaId);
        $authUser = auth()->user();
        $company = $authUser->company instanceof \Illuminate\Database\Eloquent\Collection
            ? $authUser->company->first()
            : $authUser->company;

        $user = $company
            ? User::where('id', $company->admin_id)->first()
            : User::find(1);

        $templateId = env('PRESUPESTOS_TEMPLATE_ID');
        $template = Templates::where('id', $templateId)->first() 
            ?? Templates::where('status', 1)->first();

        $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

        $storagePath = rtrim(public_path('storage/'), '/') . '/';
        $baseUrl = rtrim(asset('storage'), '/') . '/';
        
        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );

        // // ✅ Append company policies on new page if enabled
        // if (isset($performa->extra['policies']) && !empty($performa->extra['policies'])) {
        //     $policiesHtml = $performa->extra['policies'] ?? '';

        //     if (!empty($policiesHtml)) {
        //         $datahtml .= '<div style="page-break-before: always;"></div>';
        //         $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
        //     }
        // }

        // // ✅ Generate PDF
        // $pdf = PDF::loadHTML($datahtml)->setPaper('a4', 'portrait');

        // return $pdf->download("performa-{$performaId}-{$performa->issue_date}.pdf");

        /////////////Anueag


        $privacyText = $performa->extra['policies'] ?? null;
        
        $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
        // dd($invoiceData);
        $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
        $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

        $pdf = Pdf::loadHTML($html)
            ->setPaper('A4')
            ->setOption('isHtml5ParserEnabled', true)
            ->setOption('isRemoteEnabled', true)
            ->setOption('defaultFont', 'Arial');

        return $pdf->download("performa-{$performa->performa_id}.pdf");
        // return $pdf->download("performa-{$performaId}-{$performa->issue_date}.pdf");

    }

    public function sendEmail(Request $request)
    {
        try {
            $dynamicTableName = (new Performa())->getTable();
            // Validate request input
            $formdata = $request->validate([
                'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
                'comment' => 'nullable|string',
            ]);
            // dd($formdata);

            $performaId = $formdata['id'];

            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $performa = Performa::findOrFail($performaId);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     $performa->generateInvoiceQrCode();
            // }
            $templateId = env('PRESUPESTOS_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            // dd($template);
            $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

            
            $data = [
                'id' => $performa->id,
                'performa_no' => $performa['performa_id'] ?? null,
                'customer_name' => $performa->client->name ?? null,
                'comment'=>$formdata['comment'] ?? null
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); 

            // Get the base URL dynamically
            $baseUrl = asset('storage'); 

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );

            // if (isset($performa->extra['policies']) && !empty($performa->extra['policies'])) {
            //     $policiesHtml = $performa->extra['policies'] ?? '';

            //     if (!empty($policiesHtml)) {
            //         $datahtml .= '<div style="page-break-before: always;"></div>';
            //         $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
            //     }
            // }
            $privacyText = $performa->extra['policies'] ?? null;
        
            $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
            // dd($invoiceData);
            $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
            $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

            $pdfContent = Pdf::loadHTML($html)
                ->setPaper('A4')
                ->setOption('isHtml5ParserEnabled', true)
                ->setOption('isRemoteEnabled', true)
                ->setOption('defaultFont', 'Arial')
                ->output();
            
            // Generate PDF from the modified HTML
            // $pdfContent = PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $altEmails = $performa->client->extra['alternative_email'] ?? null;
            }else{
                $clientCompany = Company::where('admin_id',$performa->client->id)->first();
                $altEmails = $clientCompany->extra['alternative_email'] ?? null;
            }
            
            if (is_string($altEmails)) {
                $emails = array_filter(array_map('trim', explode(',', $altEmails)));
            } elseif (is_array($altEmails)) {
                $emails = array_filter(array_map('trim', $altEmails));
            } else {
                $emails = [];
            }

            if (empty($emails)) {
                $emails = [$invoice->client->email];
            }

            $emails = array_unique(array_filter($emails));

            foreach ($emails as $email) {
                Mail::to($email)->send(new SystemEmail(
                    __('Please review the attached budget'),
                    'emails.performa-template', // Replace with your Blade view path
                    $data, // Dynamic data
                    $pdfContent, // Attach generated PDF content
                    "performa-{$performaId}.pdf", // Optional file name for the PDF,
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'] 
                ));

            }
            // Send email with the PDF attachment
            // Mail::to($email)->send(new SystemEmail(
            //     __('Please review the attached budget'),
            //     'emails.performa-template', // Replace with your Blade view path
            //     $data, // Dynamic data
            //     $pdfContent, // Attach generated PDF content
            //     "performa-{$performaId}.pdf", // Optional file name for the PDF,
            //     'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'],
            //     null,
            //     $company->user->email ?? 'info@artisticbird.com',
            //     $company->company_name ?? $user->extra['company_name'] 
            // ));

            if($performa->status != 'accepted' && $performa->status != 'accepted'){
                $performa->status = 'sent'; //2 represents 'sent'
            }
            $performa->save();
            return response()->json([
                'success' => true,
                'message' => __('Proposal sent successfully.'),
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    public function downloadContract($performaId)
    {
        $performa = Performa::findOrFail($performaId);
        $authUser = auth()->user();
        $company = $authUser->company instanceof \Illuminate\Database\Eloquent\Collection
            ? $authUser->company->first()
            : $authUser->company;

        $user = $company
            ? User::where('id', $company->admin_id)->first()
            : User::find(1);

        $templateId = env('CONTRACT_TEMPLATE_ID');
        $template = Templates::where('id', $templateId)->first() 
            ?? Templates::where('status', 1)->first();

        $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

        $storagePath = rtrim(public_path('storage/'), '/') . '/';
        $baseUrl = rtrim(asset('storage'), '/') . '/';
        
        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );

        $privacyText = '';
        
        $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
        // dd($invoiceData);
        $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
        $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

        $pdf = Pdf::loadHTML($html)
            ->setPaper('A4')
            ->setOption('isHtml5ParserEnabled', true)
            ->setOption('isRemoteEnabled', true)
            ->setOption('defaultFont', 'Arial');

        return $pdf->download("contract-{$performa->performa_id}.pdf");
    }

    public function sendEmailBck(Request $request)
    {
        try {
            $dynamicTableName = (new Performa())->getTable();
            // Validate request input
            $formdata = $request->validate([
                'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
                'comment' => 'nullable|string',
            ]);
            // dd($formdata);

            $performaId = $formdata['id'];

            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $performa = Performa::findOrFail($performaId);
            // if($company && $company->extra['country_code'] == 'ES'){
            //     $performa->generateInvoiceQrCode();
            // }
            $templateId = env('PRESUPESTOS_TEMPLATE_ID');
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            // dd($template);
            $datahtml = parseInvoiceSortcodes($template->template_html, $performa, $company);

            
            $data = [
                'id' => $performa->id,
                'performa_no' => $performa['performa_id'] ?? null,
                'customer_name' => $performa->client->name ?? null,
                'comment'=>$formdata['comment'] ?? null
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); 

            // Get the base URL dynamically
            $baseUrl = asset('storage'); 

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );

            if (isset($performa->extra['policies']) && !empty($performa->extra['policies'])) {
                $policiesHtml = $performa->extra['policies'] ?? '';

                if (!empty($policiesHtml)) {
                    $datahtml .= '<div style="page-break-before: always;"></div>';
                    $datahtml .= '<div class="policy-section" style="padding: 40px;">' . $policiesHtml . '</div>';
                }
            }
            // dd($datahtml);
            
            // Generate PDF from the modified HTML
            $pdfContent = PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $email = $performa->client->extra['alternative_email'] ?? $performa->client->email;
            }else{
                $clientCompany = Company::where('admin_id',$performa->client->id)->first();
                $email = $clientCompany->extra['alternative_email'] ?? $performa->client->email;
            }
            
            // Ensure client email exists
            if (empty($email)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client email not found.',
                ], 200);
            }
            // Send email with the PDF attachment
            Mail::to($email)->send(new SystemEmail(
                __('Please review the attached budget'),
                'emails.performa-template', // Replace with your Blade view path
                $data, // Dynamic data
                $pdfContent, // Attach generated PDF content
                "performa-{$performaId}.pdf", // Optional file name for the PDF,
                'info@artisticbird.com',
                $company->company_name ?? $user->extra['company_name'],
                null,
                $company->user->email ?? 'info@artisticbird.com',
                $company->company_name ?? $user->extra['company_name'] 
            ));

            if($performa->status != 'accepted' && $performa->status != 'accepted'){
                $performa->status = 'sent'; //2 represents 'sent'
            }
            $performa->save();
            return response()->json([
                'success' => true,
                'message' => __('Proposal sent successfully.'),
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    public function calculatePerformas(Request $request)
    {
        // try{
            $data = $request->all();
            return response()->json(UtilityService::calculate($data));

        // } catch (\Throwable $e) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => __('Something went wrong.'),
        //     ], 500);
        // }
    }

    public function convertProposalToFactura($id){
        try{
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = Performa::where('id', $id)->first();
            // $clients = Clients::where('status',1)->get();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
            }
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
               
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $taxslab = TaxRules::where('country', 'es')->where('tax_type', 'iva')->where('type', 'percentage')->get();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $country = CountryModel::all();
            return view('panel.performa.add-invoice', compact('invoice','country', 'paymentMethods', 'services','taxslab', 'invoicePrefixs','invoiceType', 'inventories', 'clients','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function extractTables(string $html, array $ids): array
    {
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);

        // Force UTF-8 encoding
        $html = '<?xml encoding="UTF-8">' . $html;
        
        // $dom = new DOMDocument();
        // libxml_use_internal_errors(true);
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $results = [];

        foreach ($ids as $id) {
            $node = $xpath->query("//*[@id='{$id}']")->item(0);
            if ($node) {
                $results[$id] = $dom->saveHTML($node);
                // Remove this node from DOM so it won’t appear in body
                $node->parentNode->removeChild($node);
            } else {
                $results[$id] = '';
            }
        }

        // Whatever remains is the clean "body" (without header/footer)
        $cleanBody = $dom->saveHTML();
        $results['body'] = $results['body'] ?: $cleanBody;

        return $results;
    }
}
