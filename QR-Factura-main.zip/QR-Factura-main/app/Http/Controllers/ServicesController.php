<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\Services;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use App\Models\CountryModel;
use App\Models\StateModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Exception;
use App\Models\ActivityLog;

class ServicesController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    // Function for Crud operation for Services
    public function indexServices(Request $request)
    {
        try{
            $query = Services::query();

            if ($request->has('sort') && !is_null($request->sort)) {
                // dd($request->sort);
                $query->where('status', $request->sort);
            }

            if ($request->has('search') && !empty($request->search)) {
                $query->where(function ($q) use ($request) {
                    $q->where('name', 'like', "%{$request->search}%");
                });
            }

            $services = $query->orderBy('id','Desc')->paginate(20);
            // dd($clients);
            if ($request->ajax()) {
                return view('panel.services.partial_data', compact('services'))->render();
            }

            return view('panel.services.index-service', compact('services'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function exportServicesToCsv()
    {
        try{
            $services = Services::all();
            $filename = "services.csv";

            $headers = [
                "Content-Type"        => "text/csv; charset=UTF-8",
                "Content-Disposition" => "attachment; filename=\"{$filename}\"",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            ];

            $callback = function() use ($services) {
                // clear any previous output that may corrupt CSV
                if (ob_get_level() > 0) {
                    ob_end_clean();
                }

                $file = fopen('php://output', 'w');

                // Add UTF-8 BOM so Excel doesn’t break accents/special chars
                fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

                
                // Header row
                fputcsv($file, [
                    __('Name'),
                    __('Price'),
                    __('Discount (in %)'),
                    __('Description'),
                ]);
                

                // Data rows
                foreach ($services as $service) {

                    fputcsv($file, [
                        $service->name,
                        $service->price,
                        $service->discount,
                        $service->description,
                    ]);
                }

                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateServicesPrice(Request $request)
    {
        try {
            $formData = $request->all();
            if (!isset($formData['percentage']) && empty($formData['percentage'])) {
                return response()->json(['success' => false, 'message' => __('Percentage Is Missing')], 200);
            }
            // Validate the percentage input
            // $formData = $request->validate([
            //     'percentage' => 'required|numeric', // Ensure percentage is a valid number
            // ]);

            $percentageIncrease = $formData['percentage']; // Get percentage value

            // Fetch all inventory items
            $services = Services::all();

            foreach ($services as $service) {
                // Normalize the price format
                $normalizedPrice = parseNumber($service->price);

                // Increase price by percentage
                $newPrice = $normalizedPrice + ($normalizedPrice * ($percentageIncrease / 100));

                // Convert back to Euro format before saving
                $service->price = parseNumber($newPrice);;
                $service->save();
            }

            return response()->json(['success' => true, 'message' => __('Price updated successfully.')], 200);
        } catch (\Exception $e) {
            Log::error('Error updating inventory prices: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => __('Failed to update services prices. Please try again.')], 200);
        }
    }

    public function updateStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
    
            // Find the inventory item
            $inventory = Services::findOrFail($id);
            $inventory->status = $request->status;
            $inventory->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Services status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating services status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
    public function getServices(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Services::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            // if (!empty($company)) {
            //     $query->where(function ($q) use ($company) {
            //         $q->where('scope', $company->id)
            //             ->orWhereNull('scope');
            //     });
            // }



            // Fetch paginated results with related data
            $services = $query->orderBy('id', 'DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Services retrieved successfully.',
                'data' => $services,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Services.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function editServices($id)
    {
        try{
            $service = Services::where('id', $id)->first();
            $companies = Company::all();
            return view('panel.services.edit-service', compact('service', 'companies'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addServices()
    {
        try{
            $companies = Company::all();
            return view('panel.services.add-service', compact('companies'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditServices(Request $request)
    {

        try {
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            // Extract form data
            $formdata = $request->all();

            $service_id = $formdata['id'] ?? null;
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $scope = ($role == 2) ? $company->id : ($formdata['scope'] ?? null);
            $dynamicTableName = (new Services())->getTable();
            // dd($userId);
            // Validation rules
            $rules = [
                // 'name'=>'required|string|max:255|unique:services,name,' . $service_id,
                'name' =>'required|string|max:255|unique:'.$dynamicTableName.',name,' . $service_id,
                'price'      => 'required',
                // 'tax_rate'   => 'required|numeric|min:0|max:255',
                'discount'   => 'required|string|min:0',
            ];

            // dd($formdata);
            // $formdata['discount'] = normalizePrice($formdata['discount']);
            // dd($formdata);
            // Validate the input data  
            
            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            // Step 1: Normalize the price format
            // Step 1: Check if the price is already in European format (e.g., 3.675,00)
            // if (preg_match('/^\d{1,3}(\.\d{3})*,\d{2}$/', $formdata['price'])) {
            //     // Price is already in European format; do nothing
            // } else {
            //     // Step 2: Handle US format (3,675.00 → 3675.00) and simple numbers
            //     if (preg_match('/^\d{1,3}(,\d{3})*\.\d{2}$/', $formdata['price'])) {
            //         // US format (thousands separated by commas, decimals by dot)
            //         $numericPrice = str_replace(',', '', $formdata['price']); // Remove commas
            //     } else {
            //         // Plain number (3675) or incorrectly formatted input
            //         $numericPrice = $formdata['price'];
            //     }

            //     // Convert to float
            //     $numericPrice = floatval(str_replace(',', '.', $numericPrice)); 

            //     // Step 3: Convert to European format (thousands separated by dot, decimals by comma)
            //     $integerPart = floor($numericPrice);
            //     $decimalPart = fmod($numericPrice, 1); // Get decimal part

            //     // Ensure decimal part has two digits
            //     $decimalStr = sprintf('%02d', round($decimalPart * 100));

            //     // Convert integer part to European thousands format (e.g., 3675 → 3.675)
            //     $formattedInteger = number_format($integerPart, 0, '', '.');

            //     // Combine the integer and decimal parts
            //     $formdata['price'] = $formattedInteger . ',' . $decimalStr;
            // }

            $service_data = [
                'name' => $formdata['name'],
                'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
                'desc' => $formdata['desc'],
                'price'=> parseInventoryServicePrice($formdata['price']),
                // 'tax_rate'=> $formdata['tax_rate'],
                'discount'=> $formdata['discount'] ?? null,
            ];

            // if (!empty($company)) {
            //     $service_data['scope'] = $company->id;
            // } else {
            //     $service_data['scope'] = $formdata['scope'] ?? null;
            // }


            if (!empty($service_id)) {
                $serviceData = Services::where('id', $service_id)->first();
                Services::where('id', $service_id)->update($service_data);
                $service = Services::where('id', $service_id)->first();
            } else {
                // Create a new invoice
                $service = Services::create($service_data);
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Service updated successfully.')
                    : __('Service created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditService: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }


    public function deleteServices($id)
    {
        try {
            // Attempt to delete the user by ID
            Services::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Service deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting Invoice Type: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete sevice. Please try again.')], 500);
        }
    }
}
