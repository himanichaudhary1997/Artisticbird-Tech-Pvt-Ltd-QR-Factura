<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use Exception;
use App\Models\ActivityLog;
use PhpOffice\PhpSpreadsheet\IOFactory;


use App\Services\InvoiceService;
use App\Services\InvoiceXmlService;


use DOMDocument;
use DOMXPath;


class InvoiceController extends Controller
{
    use ContentDataTrait;
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        // try {
            $user = auth()->user();
            $company = $user->company;
            // dd($company);
            // if(!empty($company) && $company->id == 3){
            //     // dd($company);
            //     $aggrement = $this->fiskaly->generateAgreement($company);
            //     dd($aggrement);
            // }
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = Invoice::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('invoice_id', 'like', '%' . $searchTerm . '%')->orWhere('ref_no', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($formdata) {
                            $searchTerm = strtolower($formdata['search']); // convert search to lowercase

                            $query->whereRaw('LOWER(name) like ?', ['%' . $searchTerm . '%'])
                                ->orWhereRaw(
                                    "LOWER(JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))) like ?", 
                                    ['%' . $searchTerm . '%']
                                );
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); 
            }

            if (isset($formdata['invoice_type']) && !is_null($formdata['invoice_type'])) {
                $query->where('invoice_type', $formdata['invoice_type']); 
            }

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            }

            // Check if the user is not an Admin and role is neither 1 nor 2
            // if (!$user->hasRole('Admin') && !$user->hasRole('Company') ) {
            //     $query->where('created_by', $user->id);
            // }

            $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            $invoices = $query->where('status','!=',self::NEGATIVE_INVOICE)->orderBy('id','DESC')->with(['client','invoiceType','paymentMethod'])->paginate($limit);

            // dd($invoices);
            $invoicesTypes = InvoiceType::all();

            $statuses = getStatuses();
            $monthlyTotals = [];
            $totalYearGrandTotal = 0;
            $totalYearTax = 0;
            $totalYearSubTotal = 0;

            foreach ($invoices as $invoice) {
                $invoiceCurrency = $invoice->currency ?? $baseCurrency;
                $month = date('m', strtotime($invoice->issue_date));
                $year = date('Y', strtotime($invoice->issue_date));
                $monthYearKey = date('F Y', strtotime($invoice->issue_date));
                
                if (!isset($monthlyTotals[$monthYearKey])) {
                    $monthlyTotals[$monthYearKey] = [
                        'month' => $month,
                        'year' => $year,
                        'monthYear' => $monthYearKey,
                        'grandTotal' => 0, 
                        'tax' => 0,
                        'formattedGrandTotal' => '',
                        'formattedTax' => ''
                    ];
                }

                $grandTotal = parseNumber($invoice->grandTotal ?? 0);
                $totalTax = parseNumber($invoice->totalTax ?? 0);
                $subTotal = parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount ?? 0);

                // Convert to base currency if different
                if ($invoiceCurrency !== $baseCurrency) {
                    $rate = $exchangeRates[$invoiceCurrency] ?? 1;
                    $grandTotal = $grandTotal / $rate;
                    $totalTax = $totalTax / $rate;
                }

                // Accumulate totals
                $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
                $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                
                $totalYearGrandTotal += $grandTotal;
                $totalYearTax += $totalTax;
                $totalYearSubTotal += $subTotal;
            }
            $totalYearGrandTotal = formatValueCurrency(
                formatValue($totalYearGrandTotal, $targetCurrency),
                $targetCurrency
            );
            $totalYearTax = formatValueCurrency(
                formatValue($totalYearTax, $targetCurrency),
                $targetCurrency
            );

            $totalYearSubTotal = formatValueCurrency(
                formatValue($totalYearSubTotal, $targetCurrency),
                $targetCurrency
            );

            // Sort by year and month (newest first)
            uasort($monthlyTotals, function($a, $b) {
                if ($a['year'] == $b['year']) {
                    return $b['month'] <=> $a['month'];
                }
                return $b['year'] <=> $a['year'];
            });

            // Format all values
            foreach ($monthlyTotals as &$totals) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );
            }

            // if($company && $company->is_verifactu){
            //     // if(!$company->organization_details->is_verified){
            //     //     abort(403, 'You must first verify the company with the Verifactu agreement.');
            //     // }
            //     if ($request->ajax()) {
            //         return view('panel.verifactu-invoice.partial_data', compact('invoices','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal'))->render();
            //     }

            //     return view('panel.verifactu-invoice.index-invoice', compact('invoices', 'invoicesTypes','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal'));
            // }

            $stats = $this->getStats();
            // dd($stats);

            if ($request->ajax()) {
                return view('panel.invoice.partial_data', compact('invoices','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal'))->render();
            }

            return view('panel.invoice.index-invoice', compact('invoices', 'invoicesTypes','statuses','totalYearGrandTotal','totalYearTax','totalYearSubTotal', 'stats'));
        // } 
        // catch (\Throwable $e) {
        //     return redirect()->back()->with('error', __('Something went wrong.'));
        // }
        
    }

    public function getFiskalyValidations(Request $request)
    {
        try {

            // ---- VALIDATION ----
            $validator = Validator::make($request->all(), [
                'invoice_id' => [
                    'required',
                    'string',
                    'max:50',
                    'regex:/^[0-9A-Za-z_\-\/.]+$/',   // allows letters, numbers, / - _ .
                ],
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors'  => $validator->errors(),
                ], 200);
            }

            // Get validated data
            $invoice_id = $request->invoice_id;

            // You must have company from auth or passed from controller
            $company = auth()->user()->company ?? null;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company context not available.',
                ], 200);
            }

            // ---- CALL FISKALY ----
            $validations = $this->fiskaly->checkValidations($company, $invoice_id, 'invoice');
            // dd($validations);
            // ---- RENDER HTML ----
            $html = view('panel.invoice.partials.validations', compact('validations'))->render();

            return response()->json([
                'success' => true,
                'html'    => $html,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ], 200);
        }
    }


    private function getStats()
    {
        $query = Invoice::query();

        // --- Basic totals (assuming these come from controller) ---
        $totalInvoices      = $query->count();
        $totalAmount        = $totalYearGrandTotal ?? 0;
        $totalTax           = $totalYearTax ?? 0;
        $totalSubTotal      = $totalYearSubTotal ?? 0;

        // --- Individual status counts ---
        $draftCount         = $query->clone()->where('status', Invoice::DRAFT)->count();
        $paidCount          = $query->clone()->where('status', Invoice::PAID)->count();
        $unpaidCount        = $query->clone()->where('status', Invoice::UNPAID)->count();
        $overdueCount       = $query->clone()->where('status', Invoice::OVERDUE)->count();

        // --- Completed Payments total amount ---
        $paidAmount = $query->clone()
            ->where('status', Invoice::PAID)
            ->sum('grandTotal');

        // --- Drafts amount ---
        $draftAmount = $query->clone()
            ->where('status', Invoice::DRAFT)
            ->sum('grandTotal');

        // --- Overdue amount ---
        $overdueAmount = $query->clone()
            ->where('status', Invoice::OVERDUE)
            ->sum('grandTotal');

        // --- Average Time to Get Paid (days) ---
        $paidInvoices = $query->clone()
                ->where('status', Invoice::PAID)
                ->get(['issue_date', 'extra']);

            $days = [];

            foreach ($paidInvoices as $invoice) {
                $extra = $invoice->extra ?? [];

                if (!empty($extra['payment_date'])) {
                    $issueDate   = \Carbon\Carbon::parse($invoice->issue_date);
                    $paymentDate = \Carbon\Carbon::parse($extra['payment_date']);

                    $days[] = $issueDate->diffInDays($paymentDate);
                }
            }

            $avgDaysToPay = !empty($days)
                ? round(array_sum($days) / count($days))
                : 0;





        $stats = [
            // ----------------------------------
            // Existing stats
            // ----------------------------------
            'total_invoices'   => $totalInvoices,
            'total_amount'     => $totalAmount,
            'total_tax'        => $totalTax,
            'total_subtotal'   => $totalSubTotal,

            'paid_invoices'    => $paidCount,
            'unpaid_invoices'  => $unpaidCount,
            'overdue_invoices' => $overdueCount,

            'today' => [
                'count'  => $query->clone()->whereDate('issue_date', today())->count(),
                'amount' => formatValueCurrency(
                    formatValue(
                        $query->clone()->whereDate('issue_date', today())->sum('grandTotal'),
                        getCurrency()
                    ),
                    getCurrency()
                ),
            ],

            'this_month' => [
                'count'  => $query->clone()
                    ->whereMonth('issue_date', now()->month)
                    ->whereYear('issue_date', now()->year)
                    ->count(),
                'amount' => formatValueCurrency(
                    formatValue(
                        $query->clone()
                            ->whereMonth('issue_date', now()->month)
                            ->whereYear('issue_date', now()->year)
                            ->sum('grandTotal'),
                        getCurrency()
                    ),
                    getCurrency()
                ),
            ],

            'this_year' => [
                'count'  => $query->clone()->whereYear('issue_date', now()->year)->count(),
                'amount' => $totalAmount,
            ],

            // ----------------------------------
            // NEW STATS FOR YOUR WIDGETS
            // ----------------------------------

            // 1️⃣ Drafts
            'drafts' => [
                'count'  => $draftCount,
                'amount' => $draftAmount,
            ],

            // 2️⃣ Completed Payment (Fully Paid Invoices)
            'completed_payment' => [
                'count'  => $paidCount,
                'amount' => $paidAmount,
            ],

            // 3️⃣ Average Time to Get Paid
            'avg_payment_time' => [
                'days' => $avgDaysToPay ? round($avgDaysToPay) : 0,
            ],

            // 4️⃣ Overdue (With Count + Amount)
            'overdue' => [
                'count'  => $overdueCount,
                'amount' => $overdueAmount,
            ],
        ];

        return $stats;
    }



    public function exportInvoicesToCsv()
    {
        try {
            $invoices = Invoice::all();
            $filename = "invoices.csv";

            $headers = [
                "Content-Type"        => "text/csv; charset=UTF-8",
                "Content-Disposition" => "attachment; filename=\"{$filename}\"",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            ];

            $callback = function() use ($invoices) {
                // clear any previous output that may corrupt CSV
                if (ob_get_level() > 0) {
                    ob_end_clean();
                }

                $file = fopen('php://output', 'w');

                // Add UTF-8 BOM so Excel doesn’t break accents/special chars
                fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

                
                // Header row
                fputcsv($file, [
                    __('Customer'),
                    __('Gst No'),
                    __('Address'),
                    __('Locality'),
                    __('Zip Code'),
                    __('Country'),
                    __('State'),
                    __('Invoice id'),
                    __('Issue'),
                    __('Expiration'),
                    __('Invoice Type'),
                    __('Payment Method'),
                    __('Items'),
                    __('Sub Total'),
                    __('Tax'),
                    __('Total'),
                    __('Status'),
                ]);
                

                // Data rows
                foreach ($invoices as $invoice) {

                    $items = $invoice->items;
                    $itemLines = [];

                    if (is_array($items)) {
                        foreach ($items as $item) {
                            $itemLines[] = $item['name'] . " (Qty: " . $item['quantity'] . ", Price: " . $item['price'] . ", Amount: " . $item['amount'] . ")";
                        }
                    }
                    $country = CountryModel::where('country_code',$invoice->client->company->extra['country_code'] ?? $invoice->client->extra['country_code'] ?? null)->first();

                    // Join items with line breaks
                    $itemsString = implode("\n", $itemLines);
                    $statuses = getStatuses();
                    fputcsv($file, [
                        $invoice->client->company->company_name ?? $invoice->client->extra['company_name'] ?? $invoice->client->name ?? null,
                        $invoice->client->company->gst_no ?? $invoice->client->gst_no,
                        $invoice->client->company->extra['company_address'] ?? $invoice->client->extra['address'] ?? null,
                        $invoice->client->company->extra['locality'] ?? $invoice->client->extra['locality'] ?? null,
                        $invoice->client->company->extra['zip_code'] ?? $invoice->client->extra['zip_code'] ?? null,
                        $country->name ?? null,
                        $invoice->client->company->extra['state_name'] ?? $invoice->client->extra['state_name'] ?? null,
                        $invoice->invoice_id,
                        $invoice->issue_date,
                        $invoice->due_date,
                        $invoice->invoiceType->name??'',
                        $invoice->paymentMethod->name??'',
                        $itemsString,
                        formatCurrency(parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount),$invoice->currency),
                        formatCurrency($invoice->totalTax,$invoice->currency),
                        formatCurrency($invoice->grandTotal,$invoice->currency),
                        __($statuses[$invoice->status] ?? 'NA')
                    ]);
                }

                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function importInvoicesFromCsv(Request $request)
    {
        try {
            $request->validate([
                'file' => 'required|file|mimes:csv,txt',
            ]);

            $path = $request->file('file')->getRealPath();
            $file = fopen($path, 'r');

            // Handle BOM
            $firstLine = fgets($file);
            $bom = pack('CCC', 0xEF, 0xBB, 0xBF);
            if (strncmp($firstLine, $bom, 3) === 0) {
                $firstLine = substr($firstLine, 3);
            }
            $headers = str_getcsv(trim($firstLine), ',');

            // Spanish → internal mapping
            $map = [
                'Cliente'              => 'customer_name',
                'C.I.F / N.I.F'        => 'gst_no',
                'Dirección'            => 'address',
                'Localidad'            => 'locality',
                'Código Postal'        => 'zip_code',
                'Provincia'            => 'state_name',
                'Emitida'              => 'issue_date',
                'Vencimiento'          => 'due_date',
                'Tipo de Factura'      => 'invoice_type',
                'Método de Pago'       => 'payment_method',
                'Artículos'            => 'items',
                'Neto'             => 'subtotal',
                'Impuesto'             => 'tax',
                'Total'                => 'total',
                'Estado'               => 'status',
                'Moneda'               => 'currency',
            ];

            $errors = [];
            $count = 0;

            while (($row = fgetcsv($file, 1000, ',')) !== false) {
                $data = array_combine($headers, $row);
                if (!$data) continue;

                // Map Spanish keys to internal names
                $mapped = [];
                foreach ($map as $es => $en) {
                    $mapped[$en] = trim($data[$es] ?? '');
                }

                // Validate required fields
                $required = ['gst_no', 'invoice_id', 'currency', 'items'];
                foreach ($required as $field) {
                    if (empty($mapped[$field])) {
                        $errors[] = "Missing {$field} for invoice {$mapped['invoice_id']}";
                        continue 2; // skip row
                    }
                }

                DB::beginTransaction();

                try {
                    // Find or create client
                    $client = Client::where('gst_no', $mapped['gst_no'])->first();

                    if (!$client) {
                        $client = Client::create([
                            'name'    => $mapped['customer_name'],
                            'gst_no'  => $mapped['gst_no'],
                            'extra'   => [
                                'address'   => $mapped['address'],
                                'locality'  => $mapped['locality'],
                                'zip_code'  => $mapped['zip_code'],
                                'state_name'=> $mapped['state_name'],
                                'company_name'=> $mapped['customer_name'],
                                'country_code'=> 'ES',
                            ],
                        ]);
                    }

                    // Create Invoice
                    $invoice = Invoice::create([
                        'client_id'        => $client->id,
                        'invoice_id'       => $mapped['invoice_id'],
                        'issue_date'       => $mapped['issue_date'],
                        'due_date'         => $mapped['due_date'],
                        'currency'         => $mapped['currency'],
                        'status'           => $mapped['status'],
                        'subtotal'         => $mapped['subtotal'],
                        'totalTax'         => $mapped['tax'],
                        'grandTotal'       => $mapped['total'],
                        'invoice_type'  => InvoiceType::where('name', $mapped['invoice_type'])->value('id'),
                        'payment_method'=> PaymentMethod::where('name', $mapped['payment_method'])->value('id'),
                    ]);

                    // Parse Items (multi-line, separated by \n)
                    $itemLines = preg_split("/\r\n|\n|\r/", $mapped['items']);
                    $invoiceItems = [];

                    foreach ($itemLines as $itemLine) {
                        if (empty(trim($itemLine))) continue;

                        // Example format from export:
                        // "Item A (Qty: 2, Price: 100, Amount: 200, Discount: 5%, Tax: 18%)"
                        preg_match('/(.*?)\(Qty:\s*(\d+),\s*Price:\s*([\d\.]+),\s*Amount:\s*([\d\.]+),\s*Discount:\s*([\d\.]+)%,\s*Tax:\s*([\d\.]+)%\)/', $itemLine, $matches);

                        if ($matches) {
                            $invoiceItems[] = [
                                'name'                => trim($matches[1]),
                                'quantity'            => $matches[2],
                                'price'               => $matches[3],
                                'amount'              => $matches[4],
                                'discount_percentage' => $matches[5],
                                'tax_percentage'      => $matches[6],
                            ];
                        }
                    }

                    $invoice->items = $invoiceItems;
                    $invoice->save();

                    DB::commit();
                    $count++;
                } catch (\Throwable $e) {
                    DB::rollBack();
                    $errors[] = "Error on invoice {$mapped['invoice_id']}: " . $e->getMessage();
                }
            }

            fclose($file);

            if (!empty($errors)) {
                return back()->with('warning', __('Import completed with some issues. Imported: :count', ['count' => $count]))
                            ->with('details', $errors);
            }

            return back()->with('success', __("Successfully imported {$count} invoices."));
        } catch (\Throwable $e) {
            report($e);
            return back()->with('error', __('Import failed: ') . $e->getMessage());
        }
    }


    public function makeInvoiceVerified(Request $request,$id){
        try {
            $user = auth()->user();
            $company = $user->company;

            $invoice = Invoice::where('id',$id)->first();

            $fullAmount = parseNumber($invoice->grandTotal);
            // dd($fullAmount);
            if($fullAmount > 3000){
                if(empty($invoice->client->gst_no)){
                    return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Client Gst No is Required');
                }

                if(empty($invoice->client->extra['company_name'])){
                    return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Company Name is Required');
                }

                if (
                    empty($invoice->client->extra['address']) ||
                    empty($invoice->client->extra['locality']) ||
                    empty($invoice->client->extra['zip_code']) ||
                    empty($invoice->client->extra['country_code']) ||
                    empty($invoice->client->extra['state_name'])
                ) {
                    return redirect()->back()->with('error', 'Your Invoice Amount exceed 3000 in that case All address fields are required');
                }

            }

            $fiskalyInvoice = $this->fiskaly->createInvoice($company,$invoice);
            
            // Convert JsonResponse → array
            $response = $fiskalyInvoice instanceof \Illuminate\Http\JsonResponse
                ? $fiskalyInvoice->getData(true)   // gives associative array exactly matching ->original
                : $fiskalyInvoice;

            $error = $invoiceService->handleVerifactuError($fiskalyInvoice, $invoice, false);
            if (!empty($error)) {
                return response()->json([
                    'success' => false,
                    'errors'  => $error['error'] ?? 'Bad request',
                    'message' => $error['message'] ?? 'Validation Failed',
                ], 200);
            }
            // Now we check the REAL content
            // if (
            //     isset($response['success']) && $response['success'] === false ||
            //     isset($response['errors']) ||
            //     (isset($fiskalyInvoice->statusCode) && $fiskalyInvoice->statusCode >= 400)
            // ) {
            //     $invoice->status = 0;

            //     return response()->json([
            //         'success' => false,
            //         'errors'  => $response['errors'] ?? 'Bad request',
            //         'message' => $response['errors'] ?? 'Validation Failed',
            //     ], 200);
            // }
            

            ActivityLog::create([
                'user_id' => $user->id,
                'company_id'=>$company->id ?? null,
                'action' => 'Verified Invoice '. $invoice->invoice_id,
                'ip_address' => $request->ip()
            ]);
            // dd($fiskalyInvoice);
            return redirect()->back()->with('success', $fiskalyInvoice['content']['message'] ?? 'Invoice Verified Successfully');
        } 
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function indexNegativeInvoice(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 30;
            $query = Invoice::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('invoice_id', 'like', '%' . $searchTerm . '%')->orWhere('ref_no', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($formdata) {
                            $query->where('name', 'like', '%' . $formdata['search'] . '%')
                                    ->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $formdata['search'] . '%']);
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
          
            

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            }

            
            $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            $invoices = $query->where('status',self::NEGATIVE_INVOICE)->orderBy('id','DESC')->with(['client','invoiceType','paymentMethod'])->paginate($limit);
            
            $stats = Invoice::where('status', Invoice::NEGATIVE)->get();

            if ($request->ajax()) {
                return view('panel.invoice.partial_negative_invoice_data', compact('invoices'))->render();
            }

            return view('panel.invoice.index-negative-invoice', compact('invoices', 'stats'));
        
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        } 
    }

    public function getSearchResults(Request $request)
    {
        try {
            $searchTerm = $request->input('search');

            if (empty($searchTerm)) {
                return response()->json([]);
            }

            $user = auth()->user();
            $company = $user->company;

            $invoices = Invoice::with('client')
                        ->whereNotNull('verifactu_id')                          // ✔ must have verifactu_id
                        ->where('status', '!=', self::NEGATIVE_INVOICE)         // ✔ not negative invoice
                        ->where(function ($query) use ($searchTerm, $company) {
                            $query->where('invoice_id', 'like', "%{$searchTerm}%")
                                    ->orWhere('ref_no', 'like', "%{$searchTerm}%");

                            $query->orWhereHas('client', function ($q) use ($searchTerm, $company) {
                                $q->where('name', 'like', '%' . $searchTerm . '%');

                                if (!empty($company)) {
                                    $q->orWhereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name')) LIKE ?", ['%' . $searchTerm . '%']);
                                } else {
                                    $q->orWhereHas('singleCompany', function ($subQuery) use ($searchTerm) {
                                        $subQuery->where('company_name', 'like', '%' . $searchTerm . '%');
                                    });
                                }
                            });
                        })
                        ->limit(10)->orderBy('id','desc')
                        ->get();

            $results = $invoices->map(function ($invoice) {
                $client = $invoice->client;
                $clientName = $client->company->company_name
                    ?? $client->extra['company_name']
                    ?? $client->name;

                return [
                    'invoice_id' => $invoice->invoice_id, // used to fill input
                    'text' => "{$clientName} - {$invoice->invoice_id}" // shown in dropdown
                ];
            });

            return response()->json($results);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


     
     
     
    public function editInvoice($id)
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = Invoice::where('id', $id)->first();
            $taxslab = TaxRules::where('country', 'es')->where('tax_type', 'iva')->where('type', 'percentage')->get();
            $defaultCurrency = $invoice->currency ?? getCurrency();
            
            // $clients = Clients::where('status',1)->get();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
            } else {
                $clients = Clients::get();
            }

            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $country = CountryModel::all();

            return view('panel.invoice.form', compact('invoice','country', 'paymentMethods', 'services', 'invoicePrefixs','invoiceType', 'inventories', 'clients', 'templates','tax_slab', 'defaultCurrency', 'taxslab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editInvoiceOLD($id)
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = Invoice::where('id', $id)->first();
            
            // $clients = Clients::where('status',1)->get();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
            
                
            }
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $country = CountryModel::all();
            return view('panel.invoice.edit-invoice', compact('invoice','country', 'paymentMethods', 'services', 'invoicePrefixs','invoiceType', 'inventories', 'clients', 'templates','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
    public function editNegativeInvoice($id)
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $invoice = Invoice::where('id', $id)->first();
            // $clients = Clients::where('status',1)->get();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
            
                
            }
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            return view('panel.invoice.edit-negative-invoice', compact('invoice', 'paymentMethods', 'services', 'invoicePrefixs','invoiceType', 'inventories', 'clients', 'templates','tax_slab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addInvoice()
    {
        try {
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // $invoice = Invoice::where('id',$id)->first();
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    })->get();
                    
            } else {
                $clients = Clients::get();
                
            }
            $invoicePrefixs = InvoicePrefix::where('status',1)->get();
            // $services = Services::where('status',1)->get();
            $invoiceType = InvoiceType::where('status', 1)->get();
            $paymentMethods = PaymentMethods::where('status', 1)->get();
            // $templates = Templates::get();
            $favouriteTemplates = [];
            if(!empty($company)){
                $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
                $defaultCurrency = $company->extra['currency'] ?? '€';
                $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplates = $adminUser->extra['favourite_templates'] ?? [];
                $defaultCurrency = $adminUser->extra['currency'] ?? '€';
                $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
            }
            if (!empty($company)) {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->where('scope', $company->id)->orWhereNull('scope')->get();
                }else{
                    $templates = Templates::where('scope', $company->id)->orWhereNull('scope')->get();
                }
                
            } else {
                if(!empty($favouriteTemplates)){
                    $templates = Templates::whereIn('id',$favouriteTemplates)->get();
                }else{
                    $templates = Templates::get();
                }
            }

            $taxslab = TaxRules::where('country', 'es')->where('tax_type', 'iva')->where('type', 'percentage')->get();
            $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            $country = CountryModel::all();
            $invoice = new Invoice();
            return view('panel.invoice.form', compact('invoice', 'paymentMethods','country', 'inventories', 'services', 'invoiceType', 'clients', 'templates','defaultCurrency','tax_slab','invoicePrefixs', 'taxslab'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    
    public function addNegativeInvoice(){
       try {

            // issue:Anurag we have to discuss this
            $user = Auth()->user();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }
            
            if (empty($company)) {
                $clients = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2);
                    })->get();
            } else {
                $clients = Clients::get();
                
            }
            // issue:Anurag

            
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            
            return view('panel.invoice.addNegativeInvoice', compact('inventories', 'services'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
   
    public function fetchInvoiceDetails(Request $request) {
        try {
            $formdata = $request->all();
            $validator = Validator::make($formdata, [
                'invoice_id' => 'required|string'
            ]);

            if ($validator->fails()) {
                $errorMessage = implode(' ', $validator->errors()->all());
                return redirect()->back()
                    ->with('error', $errorMessage)
                    ->withInput();
            }

            // $invoice = Invoice::where('invoice_id',$formdata['invoice_id'])->where('status','!=',self::NEGATIVE_INVOICE)->whereNotNull('verifactu_id')->first();
            $invoice = Invoice::where(function ($q) use ($formdata) {
                        $q->where('invoice_id', $formdata['invoice_id'])
                        ->orWhere('ref_no', $formdata['invoice_id']);
                    })
                    ->where('status', '!=', self::NEGATIVE_INVOICE)
                    ->whereNotNull('verifactu_id')
                    ->first();

            if(empty($invoice)){
                return redirect()->back()->with('error','Invoice Not Found please enter correct id.');
            }

            $alreadyExists = Invoice::where('status', self::NEGATIVE_INVOICE)->where('reference_id', $invoice->id)->first();
            if($alreadyExists){
                return redirect()->back()->with('error',__('Negative invoice already created'));
            }

            
            $services = Services::where('status', 1)->get();
            $inventories = Inventory::where('status', 1)->get();
            // dd($invoice->items);
            $html = view('panel.invoice.partials.items', [
                'invoice'  => $invoice,
                'items' => $invoice->items,
                'services' => $services,
                'products' => $inventories
            ])->render();
            
            

            return response()->json([
                'status'   => true,
                'html'     => $html,
                'invoice'  => $invoice,
                // 'customer' => $invoice->customer,
                // 'items'    => $invoice->items,
            ]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    
    public function storeNegativeInvoice(Request $request, InvoiceService $invoiceService)
    {

        try {
            $user = $request->user();
            $company = $user->company;
            $formdata = $request->all();
            
            $validator = Validator::make($formdata, [
                'abono_invoice_id'         => 'required|string',
                'method'                   => ['required', 'string','in:SUBSTITUTION,DIFFERENCES'],
                'note'                     => 'nullable|string|max:250',
                'items.*.name'             => 'required|string',
                'items.*.quantity'         => ['required'],
                'items.*.price'            => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,4})?$/'],
                'items.*.discount'         => ['required', 'regex:/^-?\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?$/'],
                'items.*.tax_percentage'   => ['required', 'string','in:0,2,4,5,7,7.5,8,10,16,18,21'],
                'items.*.amount'           => 'required|string',
                'subtotal'                 => 'required|string',
                'totalDiscount'            => 'required|string',
                'totalTax'                 => 'required|string',
                'grandTotal'               => 'required|string',
            ]);
    

            if ($validator->fails()) {
                return response()->json([
                    'status'  => false,
                    'errors'  => $validator->errors(),
                    'message' => 'Validation failed'
                ], 200);
            }
            // 🔹 Check original invoice
            $invoice = Invoice::where('status', '!=', Invoice::NEGATIVE_INVOICE)
            ->whereNotNull('verifactu_id')
            ->where(function ($query) use ($formdata) {
                $query->where('invoice_id', $formdata['abono_invoice_id'])
                    ->orWhere('ref_no', $formdata['abono_invoice_id']);
            })
            ->first();
            if (empty($invoice)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invoice Not Found, please enter a correct ID.',
                ], 404);
            }

            try {

                $invoiceService->validateWithOriginal($invoice, $formdata);

            } catch (\Illuminate\Validation\ValidationException $e) {

                return response()->json([
                    'status'  => false,
                    'errors'  => $e->errors(),   // <– EXACT message from service
                    'message' => 'Validation failed',
                ], 200);
            }
            // $invoiceService->validateWithOriginal($invoice, $formdata);
    
            // 🔹 Get admin user
            $adminUser = $company
                ? User::find($company->admin_id)
                : User::find($user->id);
            $invoiceData = [];
            $invoiceData['reference_id'] = $invoice->id;
            $invoiceData['ref_no'] = null;
            $invoiceData['invoice_id'] = $invoiceService->generateInvoiceId($invoice->issue_date, $company, 'negative-invoice');
            $invoiceData['issue_date'] = $invoice->issue_date;
            $invoiceData['due_date'] = $invoice->issue_date;
            $invoiceData['items'] = $invoiceService->invoiceItems($formdata['items']);
            $invoiceData['subtotal']       = normalizePrice($formdata['subtotal'], 2,'IN');
            $invoiceData['totalDiscount']  = normalizePrice($formdata['totalDiscount'], 2,'IN');
            $invoiceData['totalTax']       = normalizePrice($formdata['totalTax'], 2,'IN');
            $invoiceData['grandTotal'] = normalizePrice($formdata['grandTotal'], 2,'IN');
            $invoiceData['extra'] = ['note' => $formdata['note']];
            $invoiceData['currency'] = $invoice->currency;
            $invoiceData['invoice_type'] = $invoice->invoice_type;
            $invoiceData['extra'] = $invoice->extra;
            $invoiceData['client_id'] = $invoice->client_id;
            $invoiceData['payment_method'] = $invoice->payment_method;
            $invoiceData['status'] = Invoice::NEGATIVE_INVOICE;
            $invoiceData['is_verified'] = 0;
            $invoiceData['created_by'] = $company->admin_id;

            $corrected = $invoiceService->generateCorrectedInvoice($invoiceData, $formdata['method']);
            // dd($corrected);
                // $newInvoice->save();
            // dd($company->is_verifactu);
            $newInvoice= Invoice::create($corrected);
            // dd($corrected, $newInvoice);

            // 🔹 Handle verifactu or QR
            if ($company && $company->is_verifactu && $invoice->is_verified) {
                
                $response = $this->fiskaly->createNegativeInvoice($company, $newInvoice, $invoice, $formdata['method']);
                // dd($response);
                // if (isset($response['content']['error'])) {
                //     $invoiceService->handleVerifactuError($response, $newInvoice);
                // }else{
                //     $invoiceService->saveQrAndVerificationData($response, $company, $newInvoice, ($newInvoice->ref_no ?? $newInvoice->invoice_id));
                // }
                // $response = $this->fiskaly->createNegativeInvoice($company, $newInvoice, $invoice, $formdata['method']);
                
                $error = $invoiceService->handleVerifactuError($response, $newInvoice, false);
                if (!empty($error)) {
                    return response()->json([
                        'success' => false,
                        'errors'  => $error['error'] ?? 'Bad request',
                        'message' => $error['message'] ?? 'Validation Failed',
                    ], 200);
                }

                $invoiceService->saveQrAndVerificationData(
                    $response,
                    $company,
                    $newInvoice,
                    $newInvoice->invoice_id
                );
            }else{
                $newInvoice->generateInvoiceQrCode();
            }

            return response()->json([
                'status'  => true,
                'message' => __('Negative invoice created successfully.'),
            ], 200);
       
        } catch (\Throwable $e) {
            return response()->json([
                'status'  => false,
                'message' => $e->getMessage() ?? __('Something went wrong.'),
            ], 200);
            // return redirect()->back()->with('error', $e->getMessage() ?? __('Something went wrong.'));
        }
    }



    // public function storeNegativeInvoiceOLD(Request $request){
    //     try {
    //         $user = Auth()->user();
    //         $role = $user->roles->pluck('id')->first();
    //         $company = $user->company;
    //         $formdata = $request->all();

    //         $validator = Validator::make($formdata, [
    //             'abono_invoice_id' => 'required|string',
    //             'issue_date' => 'required|date',
    //             'note' => 'nullable|string|max:1000',
    //         ]);

    //         if ($validator->fails()) {
    //             $errorMessage = implode(' ', $validator->errors()->all());
    //             return redirect()->back()
    //                 ->with('error', $errorMessage)
    //                 ->withInput();
    //         }

    //         $invoice = Invoice::where('invoice_id',$formdata['abono_invoice_id'])->where('status','!=',self::NEGATIVE_INVOICE)->whereNotNull('verifactu_invoice_id')->first();
    //        // dd($invoice);

    //         if(empty($invoice)){
    //             return redirect()->back()->with('error','Invoice Not Found please enter correct id.');
    //         }

    //         $alreadyExists = Invoice::where('status', self::NEGATIVE_INVOICE)->where('reference_id', $invoice->id)->first();
    //        // dd($invoice,$alreadyExists,$request->all());
    //         if($alreadyExists){
    //             //dd($alreadyExists);
    //             return redirect()->back()->with('error',__('Negative invoice already created'));
    //         }

    //         if($company){
    //             $adminUser = User::where('id', $company->admin_id)->first();
    //         }else{
    //             $adminUser = User::where('id', $user->id)->first();
    //         }
    //         $companyname = $company->company_name ?? $user->extra['company_name'] ?? null;

    //         $lastInvoice = Invoice::orderBy('id', 'desc')->value('invoice_id');
    //         $numberparts = explode('/', $lastInvoice);
    //         $numberparts[1] = 'ER';
    //         $numberparts[2] = str_pad(((int)$numberparts[2]) + 1, 4, '0', STR_PAD_LEFT);

    //         $newInvoice = $invoice->replicate();
    //         $newInvoice['reference_id'] = $invoice->id;
    //         $newInvoice['qr_code'] = $newInvoice['verifactu_invoice_id'] = '';
    //         $newInvoice['invoice_id'] = implode('/', $numberparts);
    //         $newInvoice['issue_date'] = $formdata['issue_date'];
    //         $newInvoice['due_date'] = $formdata['issue_date'];
    //         $newInvoice['extra'] = ['note'=>$formdata['note']];
    //         $newInvoice['status'] = self::NEGATIVE_INVOICE;
    //         $newInvoice['is_verified'] = 0;
    //         $newInvoice['created_by'] = $company->admin_id;
    //         $newInvoice->save();

    //         if(auth()->user()->company && auth()->user()->company->is_verifactu && !$newInvoice->is_verified){
    //             $fiskalyInvoice = $this->fiskaly->createNegativeInvoice($company,$newInvoice,$invoice);
    //             //dd($fiskalyInvoice);
    //             // if (isset($fiskalyInvoice['content']['error']) || 
    //             //     (isset($fiskalyInvoice['content']['status']) && $fiskalyInvoice['content']['status'] >= 400)) {
    //             //     return redirect()->back()->with('error', $fiskalyInvoice['content']['message'] ?? __('Bad request'));
    //             // }

    //             $error = $invoiceService->handleVerifactuError($fiskalyInvoice, $newInvoice, false);
    //             if (!empty($error)) {
    //                 // return response()->json([
    //                 //     'success' => false,
    //                 //     'errors'  => $error['error'] ?? 'Bad request',
    //                 //     'message' => $error['message'] ?? 'Validation Failed',
    //                 // ], 200);
    //                 return redirect()->back()->with('error', $error['error'] ?? __('Bad request'));
    //             }
    
    //             ActivityLog::create([
    //                 'user_id' => $user->id,
    //                 'company_id'=>$company->id ?? null,
    //                 'action' => 'Verified Invoice '. $newInvoice->invoice_id,
    //                 'ip_address' => $request->ip()
    //             ]);
    //         }elseif(auth()->user()->company && !auth()->user()->company->is_verifactu){
    //             $newInvoice->generateInvoiceQrCode();
    //         }


    //         return redirect()->back()->with('success','Negative invoice created successfully.');
    //     } catch (\Throwable $e) {
    //         //dd($e);
    //         return redirect()->back()->with('error', __('Something went wrong.'));
    //     }
    // }


   
    // public function addNegativeInvoiceOLD(Request $request){
    //     try {
    //         $user = Auth()->user();
    //         $role = $user->roles->pluck('id')->first();
    //         $company = $user->company;
    //         $formdata = $request->all();

    //         $validator = Validator::make($formdata, [
    //             'abono_invoice_id' => 'required|string',
    //             'issue_date' => 'required|date',
    //             // 'due_date' => 'required|date|after_or_equal:issue_date',
    //             'note' => 'nullable|string|max:1000',
    //         ]);

    //         if ($validator->fails()) {
    //             $errorMessage = implode(' ', $validator->errors()->all());
    //             return redirect()->back()
    //                 ->with('error', $errorMessage)
    //                 ->withInput();
    //         }
    //         // dd($formdata);
    //         $invoice = Invoice::where('invoice_id',$formdata['abono_invoice_id'])->where('status','!=',self::NEGATIVE_INVOICE)->first();

    //         if(empty($invoice)){
    //             return redirect()->back()->with('error','Invoice Not Found please enter correct id.');
    //         }
    //         // dd($invoice);
    //         if($company){
    //             $adminUser = User::where('id', $company->admin_id)->first();
    //         }else{
    //             $adminUser = User::where('id', $user->id)->first();
    //         }
    //         $companyname = $company->company_name ?? $user->extra['company_name'] ?? null;

    //         $issueDate = $formdata['issue_date'];
    //         $dueDate = $formdata['issue_date'];
    //         $currentYear = date('Y', strtotime($issueDate));
    //         $currentMonth = date('m', strtotime($issueDate));
    //         $companyInitials = strtoupper(substr($companyname, 0, 2));

    //         $previousDate = now()->subMonthNoOverflow();
    //         $previousMonth = $previousDate->month;
    //         $previousYear = $previousDate->year;
    //         // dd($invoice);

    //         $alreadyExists = Invoice::where('status', self::NEGATIVE_INVOICE)
    //             ->where('reference_id', $invoice->id)
    //             ->first();

    //         if($alreadyExists){
    //             return redirect()->back()->with('error',__('Negative invoice already created'));
    //         }
            
    //         $total = $invoice->grandTotal;
    //         $tax = $invoice->totalTax;
    //         $price = $total - $tax;

    //         $taxPercentage = ($tax / $price) * 100;
    //         // dd($taxPercentage);
    //         $item = [
    //             "name" => "Abono de producto",
    //             "new_item" => null,
    //             "quantity" => "1",
    //             "price" => formatValue(-$price,$invoice->currency),
    //             "discount" => "0,00",
    //             "discount_percentage" => "0,00",
    //             "tax" => formatValue($taxPercentage,$invoice->currency),
    //             "use_tax_percentage" => "true",
    //             "tax_type" => "percentage",
    //             "amount" => formatValue(-$total,$invoice->currency)
    //         ];
    //         $parts = explode('/', $invoice->invoice_id);
    //         $previousInitials = $parts[1] ?? $companyInitials;
    //         preg_match('/(\d+)$/', $parts[2] ?? '0000', $matches);
    //         $lastNumber = isset($matches[1]) ? (int) $matches[1] : 0;

    //         $nextNumber = $lastNumber + 1;
    //         do {
    //             $newId = $currentYear . '/' . $previousInitials . '/' . str_pad($nextNumber++, 4, '0', STR_PAD_LEFT);
    //         } while (Invoice::where('invoice_id', $newId)->exists());

    //         $newInvoice = $invoice->replicate();
    //         $newInvoice->invoice_id = $this->generateInvoiceId($formdata['issue_date'], $company, $user,$invoice->client_id,$invoice);
    //         $newInvoice->verifactu_invoice_id = null;
    //         $newInvoice->is_verified = 0;
    //         $newInvoice->issue_date = $issueDate;
    //         $newInvoice->due_date = $dueDate;
    //         $newInvoice->status = self::NEGATIVE_INVOICE;
    //         $newInvoice->invoice_type = 1;
    //         $newInvoice->reference_id = $invoice->id;
    //         $newInvoice->created_by = $user->id;
    //         $newInvoice->items = [$item];
    //         $newInvoice->subtotal = -$price;
    //         $newInvoice->totalDiscount = 0;
    //         $newInvoice->totalTax = -$tax;
    //         $newInvoice->totalRetencion = 0;
    //         $newInvoice->grandTotal = -$total;
    //         $extra = $newInvoice->extra ?? []; // Get current extra or empty array
    //         $newInvoice->qr_code = null;
    //         $extra['note'] = $formdata['note'] ?? null;
    //         $newInvoice->extra = $extra;
    //         // dd($newInvoice);
    //         $newInvoice->save();



    //         // dd($newInvoice);
    //         if(empty($newInvoice->qr_code)){
    //             if(auth()->user()->company && auth()->user()->company->is_verifactu && !$newInvoice->is_verified){
    //                 $fullAmount = parseNumber($newInvoice->grandTotal);
    //                 // dd($fullAmount);
        
    //                 $fiskalyInvoice = $this->fiskaly->createInvoice($company,$newInvoice);
    //                 // dd($fiskalyInvoice);
        
    //                 ActivityLog::create([
    //                     'user_id' => $user->id,
    //                     'company_id'=>$company->id ?? null,
    //                     'action' => 'Verified Invoice '. $newInvoice->invoice_id,
    //                     'ip_address' => $request->ip()
    //                 ]);
    //             }elseif(auth()->user()->company && !auth()->user()->company->is_verifactu){
    //                 $newInvoice->generateInvoiceQrCode();
    //             }
    //         }


    //         return redirect()->back()->with('success','Negative invoice created successfully.');
    //     } catch (\Throwable $e) {
    //         return redirect()->back()->with('error', __('Something went wrong.'));
    //     }
    // }


    

    public function addOrEditInvoices(Request $request, InvoiceService $invoiceService)
    {
        // try {
          
            $formdata = $request->all();
            // dd($formdata);
            $user = Auth::user();
            $company = $user->company;
            $invoice_id = $formdata['id'] ?? null;
            $adminUser = User::where('id',$company->admin_id ?? 1)->first();

            if ($company && $company->user->subscriptionDetails->subscription) {
                $totalLeftInvoice = $company->user->subscriptionDetails->invoices ?? $company->user->subscriptionDetails->subscription->invoices ?? null;
                $invoice_issue_date = $formdata['issue_date'];

                // Count invoices issued in the same month & year as the issue_date
                $totalCreatedInvoice = Invoice::whereMonth('issue_date', date('m', strtotime($invoice_issue_date)))
                    ->whereYear('issue_date', date('Y', strtotime($invoice_issue_date)))
                    ->count();

                // Only check limit if it's NOT unlimited (null means unlimited)
                if (!is_null($totalLeftInvoice) && $totalCreatedInvoice >= $totalLeftInvoice) {
                    return response()->json([
                        'success' => false,
                        'message' => __("You can't create more invoices. Total Limit Reached. Contact Administrator."),
                    ], 200);
                }
            }


            if($company){
                $gst_no = $company->gst_no ?? null;
            }else{
                $gst_no = $adminUser->extra['gst_no'] ?? null;
            }

            if(empty($gst_no)){
                return response()->json([
                    'success' => false,
                    'message' => __('Please add GST number in company settings to add invoice.'),
                ], 200);
            }

            

            // Validate request data
            $validator = $this->validateInvoice($formdata, $company);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }


            $items = $this->processInvoiceItems($formdata['items'], $formdata['currency']);
    
            if ($formdata['client_id'] === 'new-client') {
                $client = $this->handleNewClient($formdata, $company);
                $formdata['client_id'] = $client->id;
            }
        
            $invoice_data = [
                'client_id'     => $formdata['client_id'],
                'issue_date'     => $formdata['issue_date'],
                'due_date'       => $formdata['due_date'],
                'currency'       => $formdata['currency'],
                'invoice_type'   => $formdata['invoice_type'],
                'payment_method' => $formdata['payment_method'],
                'ref_no'         => $formdata['ref_no'] ?? null,
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'extraTax'       => $formdata['additionalTax'] ?? null,
                'totalRetencion' => $formdata['totalRetencion'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
                
            ];
            // dd($formdata['extra']);

            
            // $invoice_data['invoice_id'] = $this->generateInvoiceId($formdata['issue_date'], $company, $user,$formdata['client_id'],$formdata);
            
            if (empty($invoice_id)) {
                $invoice_data['invoice_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'],$company, 'invoice', $formdata['extra']['invoice_prefix']);
                $invoice_data['created_by'] = $user->id;
                $invoice_data['status'] = $formdata['status'] ?? 0;
                $invoice_data['extra'] = $formdata['extra'] ?? null;
                $invoice = Invoice::create($invoice_data);
                
            } else {
                $oldInvoice = Invoice::find($invoice_id);
                // dd($formdata['extra']['invoice_prefix'], $oldInvoice->extra['invoice_prefix']);
                if ($formdata['extra']['invoice_prefix'] != ($oldInvoice->extra['invoice_prefix'] ?? null)) {
                    $invoice_data['invoice_id'] = $invoiceService->generateInvoiceId($formdata['issue_date'],$company, 'invoice', $formdata['extra']['invoice_prefix']);
                }


                // Update base invoice data (excluding 'extra')
                Invoice::where('id', $invoice_id)->update($invoice_data);

                $invoice = Invoice::find($invoice_id);

                // ✅ Merge only incoming keys into existing extra
                if (!empty($formdata['extra']) && is_array($formdata['extra'])) {
                    $invoice->extra = array_merge($invoice->extra ?? [], $formdata['extra']);
                    $invoice->save();
                }

            }

            return response()->json([
                'success' => true,
                'message' => $invoice_id ? __('Invoice updated successfully.') : __('Invoice created successfully.')
            ], 200);
        // } catch (\Exception $e) {
        //     // Handle exceptions
        //     Log::error('Error in addOrEditInvoice: ' . $e->getMessage());

        //     return response()->json([
        //         'success' => false,
        //         'message' => $e->getMessage(),
        //         'error' => $e->getMessage(), // Error message
        //         'line' => $e->getLine(),     // Line number where the error occurred
        //         'file' => $e->getFile(),     // File where the error occurred
        //     ], 200);
        // }
    }

    private function validateInvoice($data,$company)
    {
        try {
            $table = $company ? (new Clients)->getTable() : (new User)->getTable();
            return Validator::make($data, [
                'client_id'      => 'required',
                'issue_date'      => 'required|date',
                'due_date'        => 'required|date|after_or_equal:issue_date',
                'currency'        => 'required|string|max:10',
                'invoice_type'    => 'required|integer',
                'payment_method'  => 'required|integer',
                'ref_no'          => 'sometimes|max:255',
                'items'           => 'required|array|min:1',
                'items.*.name' => 'required',
                'items.*.quantity'=> 'required|numeric|min:1',
                'items.*.price'   => 'required|min:0',
                'items.*.discount'=> 'nullable|min:0',
                'items.*.tax'     => 'nullable|min:0|max:100',
                'items.*.amount'  => 'required',
                'client_email'   => [
                    'required_if:client_id,new-client',
                ],
                'client_name'     => 'required_if:client_id,new-client',
                'client_gst_no' => [
                    'required_if:client_id,new-client',
                    // 'unique:'.$table.',gst_no',
                ],
                'client_company_name'     => 'required_if:client_id,new-client',
                'client_address'     => 'required_if:client_id,new-client',
                'client_locality'     => 'required_if:client_id,new-client',
                'client_zip_code'     => 'required_if:client_id,new-client',
                'client_country_code'     => 'required_if:client_id,new-client',
                'client_state_name'     => 'required_if:client_id,new-client',
                'extra.note' => 'nullable|string|max:500',
            ], [
                'client_email.required_if'      => __('Client email is required for a new client.'),
                'client_email.email'            => __('Please provide a valid email address for the client.'),
                'client_name.required_if'       => __('Client name is required for a new client.'),
                'client_gst_no.required_if'     => __('Client GST number is required for a new client.'),
                'client_gst_no.unique'          => __('This GST number is already registered. Please enter a unique GST number.'),
                'client_company_name.required_if' => __('Client company name is required for a new client.'),
                'client_address.required_if'    => __('Client address is required for a new client.'),
                'client_locality.required_if'   => __('Client locality is required for a new client.'),
                'client_zip_code.required_if'   => __('Client ZIP code is required for a new client.'),
                'client_country_code.required_if' => __('Client country is required for a new client.'),
                'client_state_name.required_if' => __('Client state is required for a new client.'),
                'items.required'            => __('At least one item is required in the invoice.'),
                'items.*.name.required'  => __('Please Select any item.'),
                'items.*.quantity.required' => __('Each item must have a quantity.'),
                'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
                'items.*.quantity.min'      => __('The quantity must be at least 1.'),
                'items.*.price.required'    => __('Each item must have a price.'),
                'items.*.price.min'         => __('The price must be at least 0.'),
                'items.*.discount.min'      => __('The discount must be at least 0.'),
                'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
                'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
                'items.*.amount.required'   => __('Each item must have an amount.'),
                'extra.note.string' => __('The note must be a valid text.'),
                'extra.note.max' => __('The note cannot be longer than 300 characters.'),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }



    private function processInvoiceItems($items, $currency)
    {
        $processedItems = [];

        foreach ($items as $item) {
            // if (isset($item['use_percentage']) && $item['use_percentage'] == 'true') {
            //     $item['discount'] = (parseNumber($item['discount']) * parseNumber($item['price'])) / 100;
            //     $item['discount'] = formatValue($item['discount'], $currency);
            // }

            if ($item['name'] === 'new-item') {
                $item['name'] = $this->createNewServiceItem($item); // this returns only string
            }

            if ($item['name'] === 'new-inventory') {
                $item['name'] = $this->createNewInventoryItem($item);
            }

            $processedItems[] = $item;
        }

        return $processedItems;
    }

    private function createNewServiceItem($item)
    {
        if (empty($item['new_item'])) {
            throw new \Exception(__('Please enter service name.'));
        }

        if (Services::where('name', $item['new_item'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_item'] . '" already exists.'));
        }

        $service = Services::create([
            'name'     => $item['new_item'],
            'slug'     => str_replace(' ', '-', strtolower($item['new_item'])),
            'status'   => 1,
            'price'    => parseInventoryServicePrice($item['price']),
            // 'tax_rate' => $item['tax'],
            'discount' => parseNumber($item['discount']),
        ]);

        return $service->name; // returns plain string
    }

    

    private function createNewInventoryItem($item)
    {
        if (empty($item['new_inventory'])) {
            throw new \Exception(__('Please enter inventory name.'));
        }

        if (Inventory::where('name', $item['new_inventory'])->exists()) {
            throw new \Exception(__('Item "' . $item['new_inventory'] . '" already exists.'));
        }

        $inventory = Inventory::create([
            'name'      => $item['new_inventory'],
            'slug'      => str_replace(' ', '-', strtolower($item['new_inventory'])),
            'price'     => parseInventoryServicePrice($item['price']),
            'quantity'  => 0,
            // 'tax_rate'  => $item['tax'],
            'discount'  => parseNumber($item['discount']),
            'status'    => 1,
        ]);

        return $inventory->name;
    }

    
    private function handleNewClient($formdata, $company)
    {
        try{
            if ($company) {
                return Clients::create([
                    'name'     => $formdata['client_name'],
                    'email'    => $formdata['client_email'],
                    'mobile_no'=> $formdata['client_phone'],
                    'gst_no'=>$formdata['client_gst_no'],
                    'extra'=>[
                        'company_name'     => $formdata['client_company_name'],
                        'address'     => $formdata['client_address'],
                        'locality'     => $formdata['client_locality'],
                        'zip_code'     => $formdata['client_zip_code'],
                        'country_code'     => $formdata['client_country_code'],
                        'state_name'     => $formdata['client_state_name'],
                    ],
                    'status'   => 1,
                ]);
            }

            do {
                $slug = substr(str_shuffle('123456789'), 0, 10);
            } while (Company::where('company_slug', $slug)->exists());

            $client = User::create([
                'name'              => $formdata['client_name'],
                'email'             => $formdata['client_email'],
                'phone'             => $formdata['client_phone'] ?? null,
                'status'            => 0,
                'email_verified_at' => now(),
                'is_email_verified'=> true,
                'password'          => Hash::make('admin@1223')
            ]);

            Company::create([
                'company_name'  => $formdata['client_name'],
                'company_slug'  => $slug,
                'company_email' => $formdata['client_email'],
                'admin_id'      => $client->id,
            ]);

            $client->syncRoles(['Company']);
            return $client;
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.')
            ], 500);
        }
    }


    // private function generateInvoiceId($issue_date, $company, $user, $client_id, $formdata)
    // {
    //     try {
        
    //         if (!empty($company)) {
    //             $client = Clients::where('id', $client_id)->first();
    //         } else {
    //             $client = User::where('id', $client_id)->first();
    //         }

    //         $invoicePrefixData = '';
    //         if (isset($formdata['extra']['invoice_prefix']) && !empty($formdata['extra']['invoice_prefix'])) {
    //             $invoicePrefixData = explode('/', $formdata['extra']['invoice_prefix']);
    //         }

    //         $invoice_starting_series = $invoicePrefixData[1] ?? null;
    //         $year = date('Y', strtotime($issue_date));
    //         $companyInitials = $invoicePrefixData[0] ?? strtoupper(substr($company->company_name ?? $user->extra['company_name'] ?? '', 0, 2));

    //         // Match pattern like "2025/EN/123"
    //         $prefix = "$year/$companyInitials/";

    //         // Get the maximum number used so far for this year/company
    //         $maxNumber = Invoice::where('invoice_id', 'like', $prefix . '%')
    //             ->selectRaw("MAX(CAST(SUBSTRING_INDEX(invoice_id, '/', -1) AS UNSIGNED)) as max_number")
    //             ->value('max_number');

    //         // Determine the next invoice number
    //         if ($invoice_starting_series && $maxNumber === null) {
    //             $nextInvoiceNumber = (int) $invoice_starting_series;
    //         } else {
    //             $nextInvoiceNumber = (int) $maxNumber + 1;
    //         }

    //         return sprintf('%s/%s/%04d', $year, $companyInitials, $nextInvoiceNumber);
    //     } catch (\Exception $e) {
    //         throw new \Exception('Something went wrong.');
    //     }
    // }






    public function deleteInvoice($id)
    {
        try {

            // $allUserPermissions = auth()->user()->getAllUserPermissions();
            // // dd($allUserPermissions);
            // // if (isset($allUserPermissions['invoices'])) {
            // //     if (!empty($allUserPermissions['invoices']['children'])) {
            // //         if (!in_array('delete invoice', $allUserPermissions['invoices']['children'])) {
            // //             return;
            // //         }
            // //     }
            // // } else {
            // //     return;
            // // }
            // Attempt to delete the user by ID
            Invoice::destroy($id);
            // Return success response
            return response()->json(['success' => true, 'message' => __('Invoice deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Invoice. Please try again.')], 500);
        }
    }


    public function showMonthlyBilling(Request $request)
    {
        try {
            $authUser = auth()->user();
            $company = $authUser->company;

            if(empty($company)){
                $user = User::where('id',1)->first();
            }

            // 1. Get user's base/target currency (same for both)
            $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            
            // 2. Exchange rates (1 BASE = X OTHER CURRENCY)
            $exchangeRates = getExchangeRates($baseCurrency);

            $year = date('Y');

            $formdata = $request->all();
            $query = Invoice::query();
            $now = Carbon::now();

            if ($now->month >= 4) {
                // We are in April or later → financial year starts this April
                $startDate = Carbon::create($now->year, 4, 1)->startOfDay();
                $endDate = Carbon::create($now->year + 1, 3, 31)->endOfDay();
            } else {
                // We are before April → financial year started last year April
                $startDate = Carbon::create($now->year - 1, 4, 1)->startOfDay();
                $endDate = Carbon::create($now->year, 3, 31)->endOfDay();
            }
            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            } else {
                $query->whereBetween('issue_date', [$startDate, $endDate]);
            }

            $invoices = $query->where('status',self::PAID_INVOICE)->orderBy('issue_date', 'DESC')->paginate(15);
            
            $monthlyTotals = [];
            $totalYearGrandTotal = 0;
            $totalYearTax = 0;
            $totalYearSubTotal = 0;

            foreach ($invoices as $invoice) {
                $invoiceCurrency = $invoice->currency ?? $baseCurrency;
                $month = date('m', strtotime($invoice->issue_date));
                $year = date('Y', strtotime($invoice->issue_date));
                $monthYearKey = date('F Y', strtotime($invoice->issue_date));
                
                if (!isset($monthlyTotals[$monthYearKey])) {
                    $monthlyTotals[$monthYearKey] = [
                        'month' => $month,
                        'year' => $year,
                        'monthYear' => $monthYearKey,
                        'grandTotal' => 0, 
                        'tax' => 0,
                        'subTotal' => 0,
                        'formattedGrandTotal' => '',
                        'formattedTax' => ''
                    ];
                }

                $grandTotal = parseNumber($invoice->grandTotal ?? 0);
                $totalTax = parseNumber($invoice->totalTax ?? 0);
                $subTotal = parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount ?? 0);
                // Convert to base currency if different
                if ($invoiceCurrency !== $baseCurrency) {
                    $rate = $exchangeRates[$invoiceCurrency] ?? 1;
                    $grandTotal = $grandTotal / $rate;
                    $totalTax = $totalTax / $rate;
                    $subTotal = $subTotal / $rate;
                }

                // Accumulate totals
                $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
                $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                $monthlyTotals[$monthYearKey]['subTotal'] += $subTotal;
                
                $totalYearGrandTotal += $grandTotal;
                $totalYearTax += $totalTax;
                $totalYearSubTotal += $subTotal;
            }

            // Sort by year and month (newest first)
            uasort($monthlyTotals, function($a, $b) {
                if ($a['year'] == $b['year']) {
                    return $b['month'] <=> $a['month'];
                }
                return $b['year'] <=> $a['year'];
            });

            // Format all values
            foreach ($monthlyTotals as &$totals) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );

                $totals['formattedSubTotal'] = formatValueCurrency(
                    formatValue($totals['subTotal'], $targetCurrency),
                    $targetCurrency
                );
            }

            if ($request->ajax()) {
                return view('panel.invoice.partial_monthly_billing', [
                    'monthlyTotals' => $monthlyTotals,
                    'totalYearGrandTotal' => formatValueCurrency(
                        formatValue($totalYearGrandTotal, $targetCurrency),
                        $targetCurrency
                    ),
                    'totalYearTax' => formatValueCurrency(
                        formatValue($totalYearTax, $targetCurrency),
                        $targetCurrency
                    ),
                    'totalYearSubTotal' => formatValueCurrency(
                        formatValue($totalYearSubTotal, $targetCurrency),
                        $targetCurrency
                    ),
                    'targetCurrency' => $targetCurrency,
                    'invoices'=>$invoices
                ])->render();
            }
            return view('panel.invoice.monthly-billing', [
                'monthlyTotals' => $monthlyTotals,
                'totalYearGrandTotal' => formatValueCurrency(
                    formatValue($totalYearGrandTotal, $targetCurrency),
                    $targetCurrency
                ),
                'totalYearTax' => formatValueCurrency(
                    formatValue($totalYearTax, $targetCurrency),
                    $targetCurrency
                ),
                'totalYearSubTotal' => formatValueCurrency(
                    formatValue($totalYearSubTotal, $targetCurrency),
                    $targetCurrency
                ),
                'targetCurrency' => $targetCurrency,
                'invoices'=>$invoices
            ]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function showMonthlyPendingBilling(Request $request){
        try {
            $authUser = auth()->user();
            $company = $authUser->company;

            if(empty($company)){
                $user = User::where('id',1)->first();
            }

            // 1. Get user's base/target currency (same for both)
            $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
            
            // 2. Exchange rates (1 BASE = X OTHER CURRENCY)
            $exchangeRates = getExchangeRates($baseCurrency);


            $year = date('Y');

            $formdata = $request->all();
            $query = Invoice::query();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            } else {
                $query->whereYear('issue_date', $year);
            }

            $invoices = $query->orderBy('id', 'DESC')->where('status','!=',self::PAID_INVOICE)->paginate(15);
            // dd($invoices);
            
            $monthlyTotals = [];
            $totalYearGrandTotal = 0;
            $totalYearTax = 0;
            $totalYearSubTotal = 0;

            foreach ($invoices as $invoice) {
                $invoiceCurrency = $invoice->currency ?? $baseCurrency;
                $month = date('m', strtotime($invoice->issue_date));
                $year = date('Y', strtotime($invoice->issue_date));
                $monthYearKey = date('F Y', strtotime($invoice->issue_date));
                
                if (!isset($monthlyTotals[$monthYearKey])) {
                    $monthlyTotals[$monthYearKey] = [
                        'month' => $month,
                        'year' => $year,
                        'monthYear' => $monthYearKey,
                        'grandTotal' => 0, 
                        'tax' => 0,
                        'subTotal' => 0,
                        'formattedGrandTotal' => '',
                        'formattedTax' => ''
                    ];
                }

                $grandTotal = parseNumber($invoice->grandTotal ?? 0);
                $totalTax = parseNumber($invoice->totalTax ?? 0);
                $subTotal = parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount ?? 0);
                // Convert to base currency if different
                if ($invoiceCurrency !== $baseCurrency) {
                    $rate = $exchangeRates[$invoiceCurrency] ?? 1;
                    $grandTotal = $grandTotal / $rate;
                    $totalTax = $totalTax / $rate;
                    $subTotal = $subTotal / $rate;
                }

                // Accumulate totals
                $monthlyTotals[$monthYearKey]['grandTotal'] += $grandTotal;
                $monthlyTotals[$monthYearKey]['tax'] += $totalTax;
                $monthlyTotals[$monthYearKey]['subTotal'] += $subTotal;
                
                $totalYearGrandTotal += $grandTotal;
                $totalYearTax += $totalTax;
                $totalYearSubTotal += $subTotal;
            }

            // Sort by year and month (newest first)
            uasort($monthlyTotals, function($a, $b) {
                if ($a['year'] == $b['year']) {
                    return $b['month'] <=> $a['month'];
                }
                return $b['year'] <=> $a['year'];
            });

            // Format all values
            foreach ($monthlyTotals as &$totals) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );

                $totals['formattedSubTotal'] = formatValueCurrency(
                    formatValue($totals['subTotal'], $targetCurrency),
                    $targetCurrency
                );
            }

            if ($request->ajax()) {
                return view('panel.invoice.partial_pending_invoices', [
                    'monthlyTotals' => $monthlyTotals,
                    'totalYearGrandTotal' => formatValueCurrency(
                        formatValue($totalYearGrandTotal, $targetCurrency),
                        $targetCurrency
                    ),
                    'totalYearTax' => formatValueCurrency(
                        formatValue($totalYearTax, $targetCurrency),
                        $targetCurrency
                    ),
                    'totalYearSubTotal' => formatValueCurrency(
                        formatValue($totalYearSubTotal, $targetCurrency),
                        $targetCurrency
                    ),
                    'targetCurrency' => $targetCurrency,
                    'invoices'=>$invoices
                ])->render();
            }
            return view('panel.invoice.pending-invoices', [
                'monthlyTotals' => $monthlyTotals,
                'totalYearGrandTotal' => formatValueCurrency(
                    formatValue($totalYearGrandTotal, $targetCurrency),
                    $targetCurrency
                ),
                'totalYearTax' => formatValueCurrency(
                    formatValue($totalYearTax, $targetCurrency),
                    $targetCurrency
                ),
                'totalYearSubTotal' => formatValueCurrency(
                    formatValue($totalYearSubTotal, $targetCurrency),
                    $targetCurrency
                ),
                'targetCurrency' => $targetCurrency,
                'invoices'=>$invoices
            ]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateInvoiceStatus(Request $request)
    {
        try {
            $formdata = $request->all();
            if (!isset($formdata['status']) || is_null($formdata['status'])) {
                return response()->json(['success' => false, 'message' => __('Status is required')], 200);
            }

            if (!isset($formdata['id']) || empty($formdata['id'])) {
                return response()->json(['success' => false, 'message' => __('Invoice id is required')], 200);
            }
            // Attempt to delete the user by ID
            Invoice::where('id', $formdata['id'])->update(['status' => $formdata['status']]);

            if(isset($formdata['status']) && $formdata['status'] == self::PAID_INVOICE){
                $invoice = Invoice::find($formdata['id']);

                $extra = is_array($invoice->extra) ? $invoice->extra : json_decode($invoice->extra, true);
                $extra['paid_comment'] = $formdata['comment'] ?? null;
                $extra['payment_date'] = $formdata['payment_date'] ?? null;

                $invoice->extra = $extra;
                $invoice->save();
            }


            if(isset($formdata['status']) && $formdata['status'] == 5){
                $invoice = Invoice::find($formdata['id']);

                $extra = is_array($invoice->extra) ? $invoice->extra : json_decode($invoice->extra, true);
                $extra['paid_comment'] =  null;
                $extra['payment_date'] =  null;

                $invoice->extra = $extra;
                $invoice->save();
            }

            // Return success response
            return response()->json(['success' => true, 'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }

    public function updateComment(Request $request){
        try {
            $formdata = $request->all();
            // if (!isset($formdata['comment']) || is_null($formdata['comment'])) {
            //     return response()->json(['success' => false, 'message' => __('comment is required')], 200);
            // }

            if (!isset($formdata['id']) || empty($formdata['id'])) {
                return response()->json(['success' => false, 'message' => __('Invoice id is required')], 200);
            }
            $invoice = Invoice::find($formdata['id']);

            $extra = is_array($invoice->extra) ? $invoice->extra : json_decode($invoice->extra, true);
            $extra['paid_comment'] = $formdata['comment'] ?? null;
            $extra['payment_date'] = $formdata['payment_date'] ?? null;

            $invoice->extra = $extra;
            $invoice->save();

            // Return success response
            return response()->json(['success' => true, 'message' => __('Comment Updated Sucessfully.')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }


    public function getInvoices(Request $request)
    {
        try {
            return $this->contentdata($request, Invoice::class, 'invoice');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }



    public function previewInvoice($invoiceId)
    {
        try {
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $invoice = Invoice::findOrFail($invoiceId);
            $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??  Templates::where('status', 1)->value('id');
            $template = Templates::where('id', $templateId)->first();
            // dd($template);
            // dd($company);
            // if($company && !$company->is_verifactu && $company->extra['country_code'] == 'ES'){
            //     // dd('hi');
            //     $invoice->generateInvoiceQrCode();
            // }
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);


            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $invoice->client->name ?? null,
                'privacy' => ($invoice['extra']['privacy'] ?? null) === 'on' ? $company->privacy??null : null,
            ];



            return view('invoice.singlePreview', ['templateHtml' => $datahtml, 'data' => $data]);
            // return view('invoice.preview', ['templateHtml' => $datahtml, 'data' => $data]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }




    public function renderTemplate($templateHtml, $data)
    {
        
        // Replace placeholders with actual data
        try {
            $items = $data['items'] ?? null;
            if (is_string($items)) {
                $items = json_decode($items, true); // Decode the JSON string to an associative array
            }
            unset($data['items']);
            if (isset($data['services'])) {
                unset($data['services']);
            }
            foreach ($data as $key => $value) {
                // Replace placeholders in the template
                // Placeholders are expected to be in the format {{key}}
                $templateHtml = str_replace(':' . $key, $value, $templateHtml);
            }

            // Loop through items and replace :items placeholder
            $itemsHtml = '';
            $itemsHtml .= "<table align='center' border='0' cellpadding='18' cellspacing='0' style='width:100%'>
                    <tbody>
                ";
            foreach ($items as $item) {
                // $service = new Services();
                // $service->setDynamicTableName($data['company_id']); // Set table to 'invoices_5'
                // $service = $service->where('id', $item['item_id'])->first();
                // dd($service);
                // dd($item);
                if (isset($item['item_type']) && $item['item_type'] == 'inventory') {
                    $service = Inventory::where('id', $item['item_id'])->first();
                } else {
                    $service = Services::where('id', $item['item_id'])->first();
                }
                $itemsHtml .= "
                    <tr style='border-bottom:1px solid #ccc'>
                        <td style='text-align:left; width:20%; border-right:1px solid #ccc'><font style='vertical-align: inherit;'>{$service->name}</font></td>
                        <td style='text-align:center; width:18.10%;border-right:1px solid #ccc'>{$item['quantity']}</td>
                        <td style='text-align:center; width:18.10%;border-right:1px solid #ccc'>{$data['currency']}{$item['price']}</td>
                        <td style='text-align:center; width:18.10%;border-right:1px solid #ccc'>{$data['currency']}{$item['discount']}</td>
                        <td style='text-align:center; width:18.10%;border-right:1px solid #ccc'>{$item['tax']}%</td>
                        <td style='text-align:center; width:20%;border-right:1px solid #ccc'>{$data['currency']}{$item['amount']}</td>
                    </tr>";
            }

            $itemsHtml .= '</tbody>
                    </table>';

            // Replace the :items placeholder with the actual table rows
            $templateHtml = str_replace(':items', $itemsHtml, $templateHtml);

            // Replace the :total placeholder
            // $templateHtml = str_replace(':total', $data['total'], $templateHtml);

            return $templateHtml;
        } catch (\Throwable $e) {
            return __('Something went wrong ');
        }
    }

    // public function downloadInvoiceOLD($invoiceId)
    // {

    //     try {
    //         $invoice = Invoice::findOrFail($invoiceId);
    //         $authUser = auth()->user();
    //         $company = $authUser->company;
    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             $company = $company->first();
    //         }

    //         if ($company) {
    //             $user = User::where('id', $company->admin_id)->first();
    //         } else {
    //             $user = User::where('id', 1)->first();
    //         }

    //         $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
    //         $template = Templates::where('id', $templateId)->first();
            
    //         if(empty($template) || $template->status != 1){
    //             $template = Templates::where('status', 1)->first();
    //         }

    //         $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
    //         $storagePath = public_path('storage/');
    //         $baseUrl = asset('storage');

    //         $storagePath = rtrim($storagePath, '/') . '/';
    //         $baseUrl = rtrim($baseUrl, '/') . '/';


    //         $datahtml = preg_replace_callback(
    //             '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
    //             function ($matches) use ($storagePath) {
    //                 return $storagePath . ltrim($matches[1], '/');
    //             },
    //             $datahtml
    //         );

    //         $privacyChecked = $invoice['extra']['privacy'] ?? null;

    //         $privacyText = $privacyChecked === 'on'
    //             ? ($company->privacy ?? null)
    //             : null;

            
    //         $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
    //         // dd($invoiceData);
    //         $html = view('pdf.invoice', compact('invoiceData', 'privacyText'))->render();
    //         $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

    //         $pdf = Pdf::loadHTML($html)
    //             ->setPaper('A4')
    //             ->setOption('isHtml5ParserEnabled', true)
    //             ->setOption('isRemoteEnabled', true)
    //             ->setOption('defaultFont', 'Arial');

    //         return $pdf->download("invoice-{$invoiceId}-{$invoice->issue_date}.pdf");
    //     } catch (\Throwable $e) {
    //         return redirect()->back()->with('error', __($e->getMessage()));
    //     }
    // }

   

    public function downloadInvoice($invoiceId)
    {

        try {
            $invoice = Invoice::findOrFail($invoiceId);
            $negative = Invoice::where('reference_id', $invoice->id)->first();

            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
            $template = Templates::where('id', $templateId)->first();
            
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }

            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
            $storagePath = public_path('storage/');
            $baseUrl = asset('storage');

            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';


            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );


            $negativeHtml = '';
            
            if ($negative) {
                $negHtml = parseInvoiceSortcodes($template->template_html, $negative, $company);
                $negHtml = preg_replace_callback(
                    '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                    function ($matches) use ($storagePath) {
                        return $storagePath . ltrim($matches[1], '/');
                    },
                    $negHtml
                );
                

                $negSections = $this->extractTables($negHtml, ['header', 'footer', 'body']);
                $negativeHtml = $negSections[ 'body'];
            }

            $privacyChecked = $invoice['extra']['privacy'] ?? null;

            $privacyText = $privacyChecked === 'on'
                ? ($company->privacy ?? null)
                : null;

            
            $invoiceData = $this->extractTables($datahtml, ['header', 'footer', 'body']);
            $html = view('pdf.invoice', compact('invoiceData', 'negativeHtml', 'privacyText'))->render();
            $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');

            $pdf = Pdf::loadHTML($html)
                ->setPaper('A4')
                ->setOption('isHtml5ParserEnabled', true)
                ->setOption('isRemoteEnabled', true)
                ->setOption('defaultFont', 'Arial');

            return $pdf->download("invoice-{$invoiceId}-{$invoice->issue_date}.pdf");
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __($e->getMessage()));
        }
    }


    public function extractTables(string $html, array $ids): array
    {
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);

        // Force UTF-8 encoding
        $html = '<?xml encoding="UTF-8">' . $html;
        
        // $dom = new DOMDocument();
        // libxml_use_internal_errors(true);
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $results = [];

        foreach ($ids as $id) {
            $node = $xpath->query("//*[@id='{$id}']")->item(0);
            if ($node) {
                $results[$id] = $dom->saveHTML($node);
                // Remove this node from DOM so it won’t appear in body
                $node->parentNode->removeChild($node);
            } else {
                $results[$id] = '';
            }
        }

        // Whatever remains is the clean "body" (without header/footer)
        $cleanBody = $dom->saveHTML();
        $results['body'] = $results['body'] ?: $cleanBody;

        return $results;
    }

    // public function sendEmailOLD(Request $request, InvoiceService $invoiceService)
    // {
    //     try {
    //         $dynamicTableName = (new Invoice())->getTable();
    //         // Validate request input
    //         $formdata = $request->validate([
    //             'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
    //             'comment' => 'nullable|string',
    //         ]);
    //         // dd($formdata);

    //         $invoiceId = $formdata['id'];

    //         $authUser = auth()->user();
    //         $company = $authUser->company;
    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             // If it's a collection, take the first item
    //             $company = $company->first();
    //         }
    //         if ($company) {
    //             $user = User::where('id', $company->admin_id)->first();
    //         } else {
    //             $user = User::where('id', 1)->first();
    //         }

    //         $invoice = Invoice::findOrFail($invoiceId);



    //         if(empty($invoice->qr_code)){
                  
    //             // dd($invoice->client->extra);
    //             // dd($invoice->client->extra['address'], $invoice->client->extra['locality'], $invoice->client->extra['zip_code'], $invoice->client->extra['country_code'], $invoice->client->extra['state_name']);
                

    //             if(auth()->user()->company && auth()->user()->company->is_verifactu && !$invoice->is_verified){
    //                 $fullAmount = $invoice->grandTotal;
    //                 // dd($fullAmount);
    //                 if($fullAmount > 3000){
    //                     if(empty($invoice->client->gst_no)){
    //                         // return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Client Gst No is Required');
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => 'Your Invoice Amount exceed 3000 in that case Client Gst No is Required.',
    //                         ], 200);
    //                     }
        
    //                     if(empty($invoice->client->extra['company_name'])){
    //                         // return redirect()->back()->with('error','Your Invoice Amount exceed 3000 in that case Company Name is Required');
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => 'Your Invoice Amount exceed 3000 in that case Company Name is Required.',
    //                         ], 200);
    //                     }
        
    //                     if (
    //                         empty($invoice->client->extra['address']) ||
    //                         empty($invoice->client->extra['locality']) ||
    //                         empty($invoice->client->extra['zip_code']) ||
    //                         empty($invoice->client->extra['country_code']) ||
    //                         empty($invoice->client->extra['state_name'])
    //                     ) {
    //                         // return redirect()->back()->with('error', '');
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => 'Your Invoice Amount exceed 3000 in that case All address fields are required.',
    //                         ], 200);
    //                     }
        
    //                 }

                    
                  

    //                 // $fiskalyInvoice = $this->fiskaly->createInvoice($company,$invoice);

    //                 $response = $this->fiskaly->createInvoice($company, $invoice);
    //                 if (isset($response['content']['error'])) {
    //                     $error = $invoiceService->handleVerifactuError($response, $invoice, false);
    //                     return response()->json([
    //                         'success' => false,
    //                         'errors'  => $error['error'] ?? 'Bad request',
    //                         'message' => $error['message'] ?? 'Validation Failed',
    //                     ], 200);
    //                 }else{
    //                     $invoiceService->saveQrAndVerificationData($response, $company, $invoice, ($invoice->ref_no ?? $invoice->invoice_id));
    //                 }
    //                 // Convert JsonResponse → array
    //                 // $response = $fiskalyInvoice instanceof \Illuminate\Http\JsonResponse
    //                 //     ? $fiskalyInvoice->getData(true)   // gives associative array exactly matching ->original
    //                 //     : $fiskalyInvoice;

    //                 // Now we check the REAL content
    //                 // if (
    //                 //     isset($response['success']) && $response['success'] === false ||
    //                 //     isset($response['errors']) ||
    //                 //     (isset($fiskalyInvoice->statusCode) && $fiskalyInvoice->statusCode >= 400)
    //                 // ) {
    //                 //     $invoice->status = 0;

    //                 //     return response()->json([
    //                 //         'success' => false,
    //                 //         'errors'  => $response['errors'] ?? 'Bad request',
    //                 //         'message' => $response['errors'] ?? 'Validation Failed',
    //                 //     ], 200);
    //                 // }else{
    //                 //     $invoiceService->saveQrAndVerificationData($response, $company, $invoice, ($invoice->ref_no ?? $invoice->invoice_id));
    //                 // }
        
    //                 ActivityLog::create([
    //                     'user_id' => $user->id,
    //                     'company_id'=>$company->id ?? null,
    //                     'action' => 'Verified Invoice '. $invoice->invoice_id,
    //                     'ip_address' => $request->ip()
    //                 ]);
    //             }elseif(auth()->user()->company && !auth()->user()->company->is_verifactu){
    //                 $invoice->generateInvoiceQrCode();
    //             }
    //         }

            
    //         // if($company && !$company->is_verifactu && $company->extra['country_code'] == 'ES'){
    //         //     $invoice->generateInvoiceQrCode();
    //         // }
    //         $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
    //         $template = Templates::where('id', $templateId)->first();
    //         if(empty($template) || $template->status != 1){
    //             $template = Templates::where('status', 1)->first();
    //         }
    //         // dd($template);
    //         $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);

            
    //         $data = [
    //             'id' => $invoice->id,
    //             'invoice_no' => $invoice['invoice_id'] ?? null,
    //             'customer_name' => $invoice->client->name ?? null,
    //             'comment'=>$formdata['comment'] ?? null
    //         ];

    //         // Generate PDF from the rendered template
    //         // $pdfContent = PDF::loadHTML($datahtml)->output();

    //         // Get the storage path dynamically
    //         $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

    //         // Get the base URL dynamically
    //         $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

    //         // Ensure correct trailing slashes
    //         $storagePath = rtrim($storagePath, '/') . '/';
    //         $baseUrl = rtrim($baseUrl, '/') . '/';

    //         $data['templateHtml'] = preg_replace('/\s+/', ' ', $datahtml);

    //         $datahtml = preg_replace_callback(
    //             '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
    //             function ($matches) use ($storagePath) {
    //                 return $storagePath . ltrim($matches[1], '/');
    //             },
    //             $datahtml
    //         );
    //         // dd($datahtml);
            
    //         // Generate PDF from the modified HTML
    //         $pdfContent = PDF::loadHTML($datahtml)->output();
            
    //         if(!empty($company)){
    //             $email = $invoice->client->extra['alternative_email'] ?? $invoice->client->email;
    //         }else{
    //             $clientCompany = Company::where('admin_id',$invoice->client->id)->first();
    //             $email = $clientCompany->extra['alternative_email'] ?? $invoice->client->email;
    //         }
            
    //         // Ensure client email exists
    //         if (empty($email)) {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => 'Client email not found.',
    //             ], 200);
    //         }

    //         // Send email with the PDF attachment
    //         Mail::to($email)->send(new SystemEmail(
    //             'Please check your invoice',
    //             'emails.invoice-template', // Replace with your Blade view path
    //             $data, // Dynamic data
    //             $pdfContent, // Attach generated PDF content
    //             "invoice-{$invoiceId}.pdf", // Optional file name for the PDF,
    //             'info@artisticbird.com',
    //             $company->company_name ?? $user->extra['company_name'],
    //             null,
    //             $company->user->email ?? 'info@artisticbird.com',
    //             $company->company_name ?? $user->extra['company_name'] 
    //         ));

    //         if($invoice->status != self::PAID_INVOICE && $invoice->status != self::NEGATIVE_INVOICE){
    //             $invoice->status = self::SEND_INVOICE; //2 represents 'sent'
    //         }
    //         $invoice->save();
    //         return response()->json([
    //             'success' => true,
    //             'message' => __('Invoice sent successfully.'),
    //         ]);
    //     } catch (\Illuminate\Validation\ValidationException $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Validation failed.',
    //             'errors' => $e->errors(),
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'An error occurred while sending the invoice.',
    //             'error' => $e->getMessage(),
    //         ], 200);
    //     }
    // }

    // public function sendEmailWorking(Request $request, InvoiceService $invoiceService)
    // {
    //     // try {
    //         $dynamicTableName = (new Invoice())->getTable();

    //         $formdata = $request->validate([
    //             'id' => 'required|integer|exists:' . $dynamicTableName . ',id',
    //             'comment' => 'nullable|string',
    //         ]);

    //         $invoiceId = $formdata['id'];
    //         $invoice   = Invoice::findOrFail($invoiceId);

    //         /** ------------------------------------
    //          *  GET COMPANY + USER
    //          * ------------------------------------*/
    //         $authUser = auth()->user();
    //         $company  = $authUser->company;

    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             $company = $company->first();
    //         }

    //         $user = $company
    //             ? User::find($company->admin_id)
    //             : User::find(1);

    //         /** ------------------------------------
    //          *  VERIFACTU + QR LOGIC
    //          * ------------------------------------*/
    //         if (empty($invoice->qr_code)) {

    //             if ($company && $company->is_verifactu && !$invoice->is_verified) {

    //                 $fullAmount = $invoice->grandTotal;

    //                 // >3000 EUR validation
    //                 if ($fullAmount > 3000) {

    //                     if (empty($invoice->client->gst_no)) {
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => 'Invoice amount exceeds 3000€. Client GST number is required.',
    //                         ], 200);
    //                     }

    //                     if (empty($invoice->client->extra['company_name'])) {
    //                         return response()->json([
    //                             'success' => false,
    //                             'message' => 'Invoice amount exceeds 3000€. Company name is required.',
    //                         ], 200);
    //                     }

    //                     $requiredFields = [
    //                         'address', 'locality', 'zip_code', 'country_code', 'state_name'
    //                     ];

    //                     foreach ($requiredFields as $field) {
    //                         if (empty($invoice->client->extra[$field])) {
    //                             return response()->json([
    //                                 'success' => false,
    //                                 'message' => 'Invoice amount exceeds 3000€. All address fields must be filled.',
    //                             ], 200);
    //                         }
    //                     }
    //                 }

    //                 /** SEND TO FISKALY */
    //                 $response = $this->fiskaly->createInvoice($company, $invoice);

    //                 /** Check for errors */
    //                 $error = $invoiceService->handleVerifactuError($response, $invoice, false);

    //                 if (!empty($error)) {
    //                     return response()->json([
    //                         'success' => false,
    //                         'errors'  => $error['error'] ?? 'Bad request',
    //                         'message' => $error['message'] ?? 'Validation Failed',
    //                     ], 200);
    //                 }

    //                 /** Save QR + verification */
    //                 $invoiceService->saveQrAndVerificationData(
    //                     $response,
    //                     $company,
    //                     $invoice,
    //                     ($invoice->ref_no ?? $invoice->invoice_id)
    //                 );

    //             } else {
    //                 // Normal QR generation
    //                 if ($company && !$company->is_verifactu) {
    //                     $invoice->generateInvoiceQrCode();
    //                 }
    //             }
    //         }

    //         /** ------------------------------------
    //          *  FETCH TEMPLATE FOR EMAIL HTML
    //          * ------------------------------------*/
    //         $templateId = $company->extra['favouraite_template']
    //             ?? $user->extra['favouraite_template']
    //             ?? Templates::where('status', 1)->value('id');

    //         $template = Templates::find($templateId);

    //         if (!$template || $template->status != 1) {
    //             $template = Templates::where('status', 1)->first();
    //         }

    //         // Generate template HTML
    //         $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);

    //         /** STORAGE AND URL FIX */
    //         $storagePath = rtrim(public_path('storage/'), '/') . '/';
    //         $baseUrl     = rtrim(asset('storage'), '/') . '/';

    //         // Replace URLs → storage paths
    //         $datahtml = preg_replace_callback(
    //             '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
    //             function ($matches) use ($storagePath) {
    //                 return $storagePath . ltrim($matches[1], '/');
    //             },
    //             $datahtml
    //         );

    //         // Minify HTML
    //         $cleanHtml = preg_replace('/\s+/', ' ', $datahtml);

    //         /** DATA PASSED TO EMAIL TEMPLATE */
    //         $data = [
    //             'id'            => $invoice->id,
    //             'invoice_no'    => $invoice->invoice_id ?? null,
    //             'customer_name' => $invoice->client->name ?? null,
    //             'comment'       => $formdata['comment'] ?? null,
    //             'templateHtml'  => $cleanHtml
    //         ];

    //         /** ------------------------------------
    //          *  GENERATE PDF USING downloadInvoice()
    //          * ------------------------------------*/
    //         $pdfResponse = $this->downloadInvoice($invoice->id);
    //         $pdfContent  = $pdfResponse->getOriginalContent();

    //         /** ------------------------------------
    //          *  GET EMAIL
    //          * ------------------------------------*/
    //         $email = 'anurag@entraenlared.com' ?? $invoice->client->extra['alternative_email']
    //             ?? $invoice->client->email;

    //         if (empty($email)) {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => 'Client email not found.',
    //             ], 200);
    //         }

    //         /** SEND EMAIL */
    //         Mail::to($email)->send(new SystemEmail(
    //             'Please check your invoice',
    //             'emails.invoice-template',
    //             $data,
    //             $pdfContent,
    //             "invoice-{$invoiceId}.pdf",
    //             'info@artisticbird.com',
    //             $company->company_name ?? $user->extra['company_name'],
    //             null,
    //             $company->user->email ?? 'info@artisticbird.com',
    //             $company->company_name ?? $user->extra['company_name']
    //         ));

    //         /** ------------------------------------
    //          *  UPDATE STATUS
    //          * ------------------------------------*/
    //         if (!in_array($invoice->status, [self::PAID_INVOICE, self::NEGATIVE_INVOICE])) {
    //             $invoice->status = self::SEND_INVOICE;
    //         }
    //         $invoice->save();

    //         return response()->json([
    //             'success' => true,
    //             'message' => 'Invoice sent successfully.'
    //         ]);

    //     // } catch (\Illuminate\Validation\ValidationException $e) {
    //     //     return response()->json([
    //     //         'success' => false,
    //     //         'message' => 'Validation failed.',
    //     //         'errors'  => $e->errors(),
    //     //     ], 200);

    //     // } catch (\Exception $e) {
    //     //     return response()->json([
    //     //         'success' => false,
    //     //         'message' => 'An error occurred while sending the invoice.',
    //     //         'error'   => $e->getMessage(),
    //     //     ], 200);
    //     // }
    // }

    public function sendEmail(Request $request, InvoiceService $invoiceService)
    {
        try {
            $dynamicTableName = (new Invoice())->getTable();

            $formdata = $request->validate([
                'id' => 'required|integer|exists:' . $dynamicTableName . ',id',
                'comment' => 'nullable|string',
            ]);

            $invoiceId = $formdata['id'];
            $invoice   = Invoice::findOrFail($invoiceId);

            $company   = auth()->user()->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            if ($company && $company->is_verifactu) {
                $errorText = $invoiceService->validateHighValueInvoice($invoice);
                if ($errorText) {
                    return response()->json(['success' => false, 'message' => $errorText], 200);
                }
            }

            if ($company && $company->is_verifactu && !$invoice->is_verified) {

                $response = $this->fiskaly->createInvoice($company, $invoice);
                
                $error = $invoiceService->handleVerifactuError($response, $invoice, false);
                if (!empty($error)) {
                    return response()->json([
                        'success' => false,
                        'errors'  => $error['error'] ?? 'Bad request',
                        'message' => $error['message'] ?? 'Validation Failed',
                    ], 200);
                }

                $invoiceService->saveQrAndVerificationData(
                    $response,
                    $company,
                    $invoice, $invoice->invoice_id
                );
            } elseif(auth()->user()->company && !auth()->user()->company->is_verifactu){
                $invoice->generateInvoiceQrCode();
            }

            $templateHtml = $invoiceService->getInvoiceTemplateHtml($invoice, $company);
            $pdf = $this->downloadInvoice($invoice->id);
            $pdfContent = $pdf->getOriginalContent();

            $data = [
                'id'            => $invoice->id,
                'invoice_no'    => $invoice->invoice_id,
                'customer_name' => $invoice->client->name,
                'comment'       => $formdata['comment'],
                'templateHtml'  => $templateHtml
            ];

            
            
            $email = $invoice->client->extra['alternative_email'] ?? $invoice->client->email;

            if (empty($email)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client email not found.',
                ], 200);
            }

            /** SEND EMAIL */
            if(auth()->user()->company){
                Mail::to($email)->send(new SystemEmail(
                    'Please check your invoice',
                    'emails.invoice-template',
                    $data,
                    $pdfContent,
                    "invoice-{$invoiceId}.pdf",
                    'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name'],
                    null,
                    $company->user->email ?? 'info@artisticbird.com',
                    $company->company_name ?? $user->extra['company_name']
                ));
            }else{

                Mail::to($email)->send(new SystemEmail(
                    'Please check your invoice',
                    'emails.invoice-template',
                    $data,
                    $pdfContent,
                    "invoice-{$invoiceId}.pdf",
                    'info@artisticbird.com',
                    null,
                    null,
                    null,
                    null
                ));

            }

            /** ------------------------------------
             *  UPDATE STATUS
             * ------------------------------------*/
            if (!in_array($invoice->status, [self::PAID_INVOICE, self::NEGATIVE_INVOICE])) {
                $invoice->status = self::SEND_INVOICE;
            }
            $invoice->save();

            return response()->json([
                'success' => true,
                'message' => 'Invoice sent successfully.'
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors'  => $e->errors(),
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error'   => $e->getMessage(),
            ], 200);
        }
    }


    public function exportToXml(Request $request, $id)
    {
        try {
            $authUser = auth()->user();
            $company = $authUser->company;

            $invoice = Invoice::findOrFail($id);
            $user = $company->adminUser ?? User::where('id',1)->first();
            // dd($user);
            // Build XML structure
            $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><invoice></invoice>');
            
            if ($user) {
                $country = CountryModel::where('country_code', $company->extra['country_code'] ?? $user->extra['country_code'] ?? null)->first();
                $state = StateModel::where('state_code', $company->extra['state_code'] ?? $user->extra['state_code'] ?? null)->first();
                $useraddressParts = array_filter([
                    $company->extra['company_address'] ?? $user->extra['company_address'] ?? null,
                    $company->extra['locality'] ?? $user->extra['locality'] ?? null,
                    $company->extra['zip_code'] ?? $user->extra['zip_code'] ?? null,
                    $state->name ?? null,
                    $country->name ?? null
                ]);
                
                $companyUser = $xml->addChild('company');
                $companyUser->addChild('company_name', $company->company_name ?? $user->extra['company_name']);
                $companyUser->addChild('email', $user->email);
                $companyUser->addChild('phone', $user->phone);
                $companyUser->addChild('gst_no',$company->gst_no ?? $user->extra['gst_no'] ?? null);
                $companyUser->addChild('address', implode(',',$useraddressParts));
            }

            $statuses = getStatuses();

            $xml->addChild('invoice_id', $invoice->invoice_id);
            $xml->addChild('currency', $invoice->currency);
            $xml->addChild('issue_date', $invoice->issue_date);
            $xml->addChild('due_date', $invoice->due_date);
            $xml->addChild('invoice_type', $invoice->invoiceType->name);
            $xml->addChild('payment_method', $invoice->paymentMethod->name);
            $xml->addChild('status', $statuses[$invoice->status]);
            

            if ($invoice->client) {
                $client = $invoice->client;
                if(!empty($company)){
                    $country = CountryModel::where('country_code', $client->extra['country_code'] ?? null)->first();
                    $state = StateModel::where('state_code', $client->extra['state_code'] ?? null)->first();
                
                    $addressParts = array_filter([
                        $client->extra['address'] ?? null,
                        $client->extra['locality'] ?? null,
                        $client->extra['zip_code'] ?? null,
                        $state->name ?? null,  // Get state name
                        $country->name ?? null // Get country name
                    ]);
                }else{
                    $country = CountryModel::where('country_code', $client->company->extra['country_code'] ?? null)->first();
                    $state = StateModel::where('state_code', $client->company->extra['state_code'] ?? null)->first();
                
                    $addressParts = array_filter([
                        $client->company->extra['company_address'] ?? null,
                        $client->company->extra['locality'] ?? null,
                        $client->company->extra['zip_code'] ?? null,
                        $state->name ?? null,  // Get state name
                        $country->name ?? null // Get country name
                    ]);
    
                }
                
                $customer = $xml->addChild('customer');
                $customer->addChild('company_name', $invoice->client->extra['company_name'] ?? $invoice->client->company->company_name ?? $invoice->client->name);
                $customer->addChild('email', $invoice->client->email);
                $customer->addChild('phone', $invoice->client->mobile_no ?? $invoice->client->phone);
                $customer->addChild('gst_no', $invoice->client->gst_no ?? $invoice->client->company->gst_no ?? null);
                $customer->addChild('address', implode(',',$addressParts));
            }
            
            // // Add items if exists
            if ($invoice->items) {
                $items = $xml->addChild('items');
                foreach ($invoice->items as $item) {
                    if (isset($item['item_type']) && $item['item_type'] == 'inventory') {
                        $service = Inventory::where('id', $item['item_id'])->first();
                    } else {
                        $service = Services::where('id', $item['item_id'])->first();
                    }
                    $itemNode = $items->addChild('item');
                    $itemNode->addChild('item', $service['name']);
                    $itemNode->addChild('quantity', $item['quantity']);
                    $itemNode->addChild('price', $item['price']);
                    $itemNode->addChild('discount', $item['discount']);
                    $itemNode->addChild('tax', $item['tax']);
                    $itemNode->addChild('tax_type', $item['tax_type']);
                    $itemNode->addChild('amount', $item['amount']);
                }
            }
            $xml->addChild('subtotal', formatValue(parseNumber($invoice->subtotal) - parseNumber($invoice->totalDiscount),$invoice->currency));
            $xml->addChild('totalDiscount', formatValue(parseNumber($invoice->totalDiscount),$invoice->currency));
            $xml->addChild('totalTax', formatValue(parseNumber($invoice->totalTax),$invoice->currency));
            if ($company) {
                $type = $company->type ?? '';
            } else {
                $type = $user->extra['type'] ?? '';
            }

            if($type == 'individual'){
                $xml->addChild('totalRetencion', formatValue(parseNumber($invoice->totalRetencion),$invoice->currency));
            }
            $xml->addChild('grandTotal', formatValue(parseNumber($invoice->grandTotal),$invoice->currency));
            $xml->addChild('note', $invoice->extra['note'] ?? null);
            // Format XML for output
            $dom = dom_import_simplexml($xml)->ownerDocument;
            $dom->formatOutput = true;
            $xmlString = $dom->saveXML();
            
            // Generate filename
            $filename = 'invoice_' . $invoice->invoice_number . '_' . date('Y-m-d') . '.xml';
            
            // Return as downloadable response
            return response($xmlString, 200)
                ->header('Content-Type', 'application/xml')
                ->header('Content-Disposition', 'attachment; filename="' . $filename . '"');
            } catch (\Throwable $e) {
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
    }
    
    public function sendPeriodicEmail(Request $request)
    {
        try {
            $formdata = $request->all();
            

            SendPeridoicInvoices::dispatchAfterResponse($formdata['comment'] ?? null,$formdata['ids'] ?? null,$this->fiskaly);
          
            return response()->json([
                'success' => true,
                'message' => 'All Invoices send in some time you will get email when all invoices are sent.',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending invoices.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    public function updatePeriodicInvoice(Request $request)
    {
        try {
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            $formdata = $request->all();
            // Artisan::call('invoices:duplicate-periodic', [
            //     'user_id' => auth()->id(),
            //     'issue_date' => $formdata['issue_date'],
            //     'due_date' => $formdata['due_date'],
            // ]);
            $userId = auth()->id();
            $issueDate = $formdata['issue_date'];
            $dueDate = $formdata['due_date'];
            $selectedIds = $formdata['ids'] ?? null;
            DuplicatePeriodicInvoices::dispatchAfterResponse($userId, $issueDate, $dueDate,$selectedIds);
            // event(new \App\Events\PeriodicInvoiceDuplicationRequested(
            //     auth()->id(),
            //     $formdata['issue_date'],
            //     $formdata['due_date']
            // ));
            
            // $job->handle();
            return response()->json([
                'success' => true,
                'message' => 'Your periodic invoices are being duplicate in some time. When it done you get an email.',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while duplicating invoices.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

    public function SendBulkEmails(Request $request)
    {
        try {
            $formdata = $request->all();
            $invoiceIds = $formdata['ids'] ?? null;

            if (empty($invoiceIds)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No invoice IDs provided.',
                ], 200);
            }
            // dd($invoiceIds);
            SendBulkEmails::dispatchAfterResponse($formdata['comment'] ?? null,$invoiceIds,$this->fiskaly);

            return response()->json([
                'success' => true,
                'message' => 'All invoices are being sent in some time. When it done you get an email.',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending invoices.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }

   

    public function downloadBulkInvoices(Request $request)
    {
        try {
            $invoiceIds = $request->input('ids', []);
        
            if (empty($invoiceIds)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No invoices selected for bulk download.',
                ], 200);
            }
            $user = auth()->id();


            SendBulkInvoicesPdfEmailJob::dispatchAfterResponse($invoiceIds, $user);
            // SendBulkInvoicesPdfEmailJob::dispatch($invoiceIds, $userId);
        
            return response()->json([
                'success' => true,
                'message' => __('Invoices are being processed and will be emailed to you shortly.'),
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.'),
            ], 500);
        }
    }

 

    // public function calculateInvoicesAditya(Request $request)
    // {
    //     try {
    //         $authUser = auth()->user();
    //         $company = $authUser->company;
        
    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             $company = $company->first();
    //         }
        
    //         $type = '';
    //         $retencion_rate = 0; // Default to 0
    //         $tax_slab_id = 1; // Default tax slab
        
    //         if ($company) {
    //             $type = $company->type ?? '';
    //             $retencion_id = $company->extra['retencion'] ?? TaxRules::where('tax_type', 'retention')->orderBy('id', 'asc')->pluck('id')->first();
    //             // $retencion_rate = $company->extra['retencion_rate'] ?? 15;
    //             $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
    //         } else {
    //             $adminUser = User::where('id', 1)->first();
    //             $type = $adminUser->extra['type'] ?? '';
    //             $retencion_id = $adminUser->extra['retencion'] ?? TaxRules::where('tax_type', 'retention')->orderBy('id', 'asc')->pluck('id')->first();
    //             // $retencion_rate = $adminUser->extra['retencion_rate'] ?? 15;
    //             $tax_slab_id = $adminUser->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();

    //         }
    //         $retention = TaxRules::where('id', $retencion_id)->first();
    //         $retencion_rate = $retention->value;
    //         // $retencion_rate
    //         // Fetch tax rule
    //         $taxRule = TaxRules::where('id', $tax_slab_id)->first();
        
    //         $items = $request->items; // Get items array
    //         $currency = $request->currency ?? '$'; // Default currency
        
    //         $subtotal = 0;
    //         $totalDiscount = 0;
    //         $totalTax = 0;
    //         $totalRetencion = 0;
    //         $processedItems = [];
        
    //         foreach ($items as $item) {
    //             $quantity = (float) ($item['quantity'] ?? 0);
    //             $price = parseNumber($item['price'] ?? 0);
    //             // dd($price);
    //             $discount = parseNumber($item['discount'] ?? 0);
    //             $discountPercentage = parseNumber($item['discount_percentage'] ?? 0);
    //             $usePercentage = $item['use_percentage'] ?? false;
    //             $tax = parseNumber($item['tax'] ?? 0);
    //             $taxType = $item['tax_type'] ?? 'percentage'; // Default to percentage if not provided
    //             $rowSubtotal = $quantity * $price;
            
    //             if ($quantity == 0) {
    //                 $rowSubtotal = 0;
    //                 $discount = 0;
    //                 $discountPercentage = 0;
    //                 $rowTax = 0;
    //                 $rowRetencion = 0;
    //                 $rowAmountBeforeRetention = 0;
    //             } else {
    //                 // Calculate discount
    //                 if ($usePercentage) {
    //                     $discount = ($rowSubtotal * $discountPercentage) / 100;
    //                 } else {
    //                     $discountPercentage = $rowSubtotal != 0 ? ($discount / $rowSubtotal) * 100 : 0;
    //                 }
            
    //                 // dd($discount);
    //                 // **Apply tax based on tax type**
    //                 if ($taxType === 'fixed') {
    //                     $rowTax = $tax; // Use fixed tax value directly
    //                 } else { // Assume 'percentage'
    //                     $rowTax = (($rowSubtotal - $discount) * $tax) / 100;
    //                 }

    //                 // if ($taxType === 'fixed') {
    //                 //     $retencion_rate = (($rowSubtotal - $discount) * $retention->value) / 100; // Use fixed tax value directly
    //                 // } else { // Assume 'percentage'
    //                 //     $retencion_rate = $retention->value;
    //                 // }
            
    //                 // Apply retention (only if 'individual' or retention rate is set)
    //                 $rowRetencion = 0;
    //                 if ($type === 'individual' && $retencion_rate > 0) {
    //                     $rowRetencion = (($rowSubtotal - $discount) * $retencion_rate) / 100;
    //                 }
            
    //                 // Amount before retention
    //                 $rowAmountBeforeRetention = $rowSubtotal - $discount + $rowTax;
    //             }
            
    //             // Final row amount (for total calculation)
    //             $rowAmountFinal = $rowAmountBeforeRetention - $rowRetencion;
            
    //             // Accumulate totals
    //             $subtotal += $rowSubtotal;
    //             $totalDiscount += $discount;
    //             $totalTax += $rowTax;
    //             $totalRetencion += $rowRetencion;
            
    //             // Formatting values
    //             $formattedRowSubTotal = formatValue($rowSubtotal, $currency);
    //             $formattedRowTaxApplied = formatValue($rowTax, $currency);
    //             $formattedRowRetencionApplied = formatValue($rowRetencion, $currency);
    //             $formattedRowAmountBeforeRetention = formatValue($rowAmountBeforeRetention, $currency);
            
    //             $processedItems[] = [
    //                 'quantity' => $quantity,
    //                 'price' => $item['price'],
    //                 'price_unformatted' => $price,
    //                 'price_formatted' => formatPrice($price, $currency),
    //                 'subtotal' => $rowSubtotal,
    //                 'subtotal_formatted' => formatValueCurrency($formattedRowSubTotal, $currency),
    //                 'discount' => $item['discount'],
    //                 'discount_unformatted' => $discount,
    //                 'discount_formatted' => formatValue($discount, $currency),
    //                 'discount_percentage' => $discountPercentage,
    //                 'discount_percentage_formatted' => formatValue($discountPercentage, $currency),
    //                 'tax' => $tax,
    //                 'tax_type' => $taxType,
    //                 'tax_unformatted' => $tax,
    //                 'tax_formatted' => formatValue($tax, $currency),
    //                 'tax_applied' => $rowTax,
    //                 'tax_applied_formatted' => formatValueCurrency($formattedRowTaxApplied, $currency),
    //                 'retencion' => $retencion_rate,
    //                 'retencion_unformatted' => $retencion_rate,
    //                 'retencion_formatted' => formatValue($retencion_rate, $currency),
    //                 'retencion_applied' => $rowRetencion,
    //                 'retencion_applied_formatted' => formatValueCurrency($formattedRowRetencionApplied, $currency),
    //                 'row_amount' => $rowAmountBeforeRetention,
    //                 'row_amount_formatted' => formatValueCurrency($formattedRowAmountBeforeRetention, $currency),
    //             ];
    //         }
            
        
    //         // Calculate final totals
    //         $grandTotal = $subtotal - $totalDiscount + $totalTax - $totalRetencion;
    //         $formattedSubTotal = formatValue($subtotal, $currency);
    //         $formattedTotalDiscount = formatValue($totalDiscount, $currency);
    //         $formattedTotalTax = formatValue($totalTax, $currency);
    //         $formattedTotalRetencion = formatValue($totalRetencion, $currency);
    //         $formattedGrandTotal = formatValue($grandTotal, $currency);
        
    //         return response()->json([
    //             'subtotal' => $subtotal,
    //             'subtotal_formatted' => formatValueCurrency($formattedSubTotal, $currency),
    //             'total_discount' => $totalDiscount,
    //             'total_discount_formatted' => formatValueCurrency($formattedTotalDiscount, $currency),
    //             'total_tax' => $totalTax,
    //             'total_tax_formatted' => formatValueCurrency($formattedTotalTax, $currency),
    //             'total_retencion' => $totalRetencion,
    //             'total_retencion_formatted' => formatValueCurrency($formattedTotalRetencion, $currency),
    //             'grand_total' => $grandTotal,
    //             'grand_total_formatted' => formatValueCurrency($formattedGrandTotal, $currency),
    //             'items' => $processedItems,
    //         ]);
    //     } catch (\Throwable $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => __('Something went wrong.'),
    //         ], 500);
    //     }
    // }
    

    public function calculateInvoices(Request $request)
    {
        try {
            $authUser = auth()->user();
            $company = $authUser->company;
        
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }
        
            $type = $company->type ?? '';
            $retencion_id = $company->extra['retencion'] 
                ?? TaxRules::where('tax_type', 'retention')->value('id');
            $tax_slab_id = $company->extra['tax_slab'] 
                ?? TaxRules::where('tax_type', 'iva')->value('id');

            $retencion_rate = optional(TaxRules::find($retencion_id))->value ?? 0;
            $tax_rule_value = optional(TaxRules::find($tax_slab_id))->value ?? 0;


            $additionalTax = $request->additionalTax ?? false;
            $taxSlab = $request->taxslab ?? '';
            if($additionalTax==true){
                $newTax = TaxRules::find($taxSlab);
            }else{
                $newTax =  '';
            }
            // dd($newTax);
        
            $items = $request->items ?? [];
            $currency = $request->currency ?? '€';
            switch ($currency) {
                case '€':
                    $currencyFormat = 'ES'; // European format
                    break;
                case '₹':
                    $currencyFormat = 'IN'; // Indian format
                    break;
                case '$':
                    $currencyFormat = 'IN'; // US format
                    break;
                default:
                    $currencyFormat = 'ES'; // fallback
                    break;
            }
        
            $totals = [
                'subtotal' => 0,
                'discount' => 0,
                'tax' => 0,
                'additionalTax' => 0,
                'retencion' => 0,
            ];
            
            $processedItems = [];
            $additionalTax = 0;
            foreach ($items as $item) {
                $quantity = normalizePrice($item['quantity'], 0, 'IN');
                $price = normalizePrice($item['price'], 6, 'IN');
                $discount = normalizePrice($item['discount'], 0, 'IN');
                $usePercentage = filter_var($item['use_percentage'] ?? false, FILTER_VALIDATE_BOOLEAN);
                $tax = normalizePrice(($item['tax'] ?? $tax_rule_value), 2, 'IN');
                if(!empty($newTax)){
                    $tax = (float) $newTax['value'];
                    $additionalTax =  (float) $newTax['RE_value'];
                }
                
                $taxType = $item['tax_type'] ?? 'percentage';

                if ($quantity <= 0 || $price <= 0) {
                    $processedItems[] = $this->emptyItem($item, $currency);
                    continue;
                }

                // Subtotal
                $rowSubtotal = $quantity * $price;

                // Discount
                if ($usePercentage && $discount > 0) {
                    $rowDiscount = ($rowSubtotal * $discount) / 100;
                } else {
                    $rowDiscount = $discount;
                    // if ($discount > 0 && $discount <= $price) {
                    //     $rowDiscount = $discount * $quantity;
                    // } else {
                    //     $rowDiscount = $discount;
                    // }
                }

                // dd($rowDiscount);

                // Clamp discount so it never becomes negative or larger than subtotal
                $rowDiscount = max(0, min($rowDiscount, $rowSubtotal));
                $rowTax = round((($rowSubtotal - $rowDiscount) * $tax) / 100, 2, PHP_ROUND_HALF_UP);
                $rowAdditionalTax = !empty($newTax)
                                    ? round((($rowSubtotal - $rowDiscount) * $additionalTax) / 100, 2, PHP_ROUND_HALF_UP)
                                    : 0;

                $rowRetencion = 0;

                // Total before & after retention
                $rowTotalBeforeRetention = $rowSubtotal - $rowDiscount + $rowTax + $rowAdditionalTax;
                $rowTotal = $rowTotalBeforeRetention - $rowRetencion;

                // Update totals
                $totals['subtotal'] += $rowSubtotal;
                $totals['discount'] += $rowDiscount;
                $totals['tax'] += $rowTax;
                $totals['additionalTax'] += $rowAdditionalTax;
                $totals['retencion'] += $rowRetencion;

                $processedItems[] = [
                    'quantity' => $quantity,
                    'price' => $item['price'],
                    'discount' => $discount,
                    'tax' => $newTax['value'] ?? $item['tax'],
                    'additionaltax' => $newTax['RE_value'] ?? 0,
                    'additionaltaxvalue' => $rowAdditionalTax,
                    'subtotal' => $rowSubtotal,
                    'total' =>$rowTotal,
                    'row_amount' => $rowTotalBeforeRetention,
                    'row_amount_formatted' => normalizePrice($rowTotalBeforeRetention, 2, $currencyFormat).''.$currency,
                ];

            }

        
            // dd($processedItems);
            $grandTotal = $totals['subtotal'] - $totals['discount'] + ($totals['tax'] + $totals['additionalTax'] )- $totals['retencion'];

            // dd($grandTotal, $processedItems);
            // Format totals
            $formattedTotals = array_map(fn($v) => formatValue($v, $currency), $totals);

            return response()->json([
                'subtotal' => $totals['subtotal'],
                'subtotal_formatted' => normalizePrice($formattedTotals['subtotal'], 2, $currencyFormat).''.$currency,
                'total_discount' => $totals['discount'],
                'total_discount_formatted' => normalizePrice($totals['discount'], 2, $currencyFormat).''.$currency,
                'total_tax' => $totals['tax'],
                'total_tax_formatted' => normalizePrice($totals['tax'], 2, $currencyFormat).''.$currency,
                'total_additionaltax' => $totals['additionalTax'],
                'total_additionaltax_formatted' => normalizePrice($totals['additionalTax'], 2, $currencyFormat).''.$currency,
                'total_retencion' => $totals['retencion'],
                'total_retencion_formatted' => normalizePrice($totals['retencion'], 2, $currencyFormat).''.$currency,
                'grand_total' => $grandTotal,
                'grand_total_formatted' => normalizePrice($grandTotal, 2, $currencyFormat).''.$currency,
                'items' => $processedItems,
            ]);     

        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.'),
            ], 500);
        }
    }





    private function emptyItem($item, $currency)
    {
        return [
            'quantity' => $item['quantity'] ?? 0,
            'price' => $item['price'] ?? '0',
            'subtotal_formatted' => normalizePrice(0),
            'discount_formatted' => normalizePrice(0),
            'tax_formatted' => normalizePrice(0),
            'retencion_formatted' => normalizePrice(0),
            'total_formatted' => normalizePrice(0),
        ];
    }





    public function deleteBulkInvoices(Request $request)
    {
        $authUser = auth()->user();
        $company = $authUser->company;
        
        $dynamicTableName = (new Invoice())->getTable();
        // Validate the request to ensure it's an array of IDs
        $request->validate([
            'ids' => 'required|array|min:1', // Ensure the 'ids' field is an array and contains at least one ID
            'ids.*' => 'exists:'.$dynamicTableName.',id', // Ensure each ID exists in the invoices table
        ]);

        // Retrieve the invoice IDs from the request
        $invoiceIds = $request->input('ids');

        try {
            // Delete the invoices
            if($company && $company->is_verifactu){
                Invoice::whereIn('id', $invoiceIds)->where('is_verified',0)->where('status',0)->delete();
            }else{
                Invoice::whereIn('id', $invoiceIds)->where('status',0)->delete();
            }

            // Return a success response
            return response()->json([
                'success' => true,
                'message' => 'Invoices deleted successfully.',
            ], 200);
        } catch (\Exception $e) {
            // Return an error response if something goes wrong
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete invoices. Please try again.',
            ], 500);
        }
    }

    public function convertInvoicesToNormal(Request $request){
        $dynamicTableName = (new Invoice())->getTable();
        // Validate the request to ensure it's an array of IDs
        $request->validate([
            'ids' => 'required|array|min:1', // Ensure the 'ids' field is an array and contains at least one ID
            'ids.*' => 'exists:'.$dynamicTableName.',id', // Ensure each ID exists in the invoices table
        ]);

        // Retrieve the invoice IDs from the request
        $invoiceIds = $request->input('ids');

        try {
            // Delete the invoices
            Invoice::whereIn('id', $invoiceIds)->update(['invoice_type'=>1]);

            // Return a success response
            return response()->json([
                'success' => true,
                'message' => 'Invoices Updated successfully.',
            ], 200);
        } catch (\Exception $e) {
            // Return an error response if something goes wrong
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete invoices. Please try again.',
            ], 500);
        }
    }

    // public function deleteInvoiceAfterDownload($filename)
    // {
    //     try {
    //     $filePath = storage_path('app/public/' . $filename);

    //     if (file_exists($filePath)) {
    //         unlink($filePath);  // Delete the file
    //     }

    //     return response()->json(['success' => true, 'message' => 'File deleted successfully.']);
    //     } catch (\Throwable $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => __('Failed to delete file.'),
    //         ], 500);
    //     }
    // }



    public function priceCalculation(Request $request)
    {
        $items = $request->items;

        $subtotal = 0;
        $totalDiscount = 0;
        $totalTax = 0;

        $responseItems = [];

        foreach ($items as $item) {

            $qty = floatval($item['quantity']);
            $price = floatval(str_replace(',', '.', $item['price']));
            $discount = floatval($item['discount']);
            $tax = floatval($item['tax']);
            $usePercentage = $item['use_percentage'] ?? 0;

            // BASE AMOUNT
            $lineBase = $qty * $price;

            // DISCOUNT
            if ($usePercentage) {
                $lineDiscount = ($lineBase * $discount) / 100;
            } else {
                $lineDiscount = $discount;
            }

            $afterDiscount = $lineBase - $lineDiscount;

            // TAX
            $lineTax = ($afterDiscount * $tax) / 100;

            // FINAL LINE TOTAL
            $lineTotal = $afterDiscount + $lineTax;

            // Totals
            $subtotal += $afterDiscount;
            $totalDiscount += $lineDiscount;
            $totalTax += $lineTax;

            $responseItems[] = [
                'amount' => round($lineTotal, 2),
                'amount_formatted' => number_format($lineTotal, 2, ',', '.') . ' €'
            ];
        }

        $grandTotal = $subtotal + $totalTax;

        return response()->json([
            'items' => $responseItems,

            'subtotal' => round($subtotal, 2),
            'subtotal_formatted' => number_format($subtotal, 2, ',', '.') . ' €',

            'discount' => round($totalDiscount, 2),
            'discount_formatted' => number_format($totalDiscount, 2, ',', '.') . ' €',

            'tax' => round($totalTax, 2),
            'tax_formatted' => number_format($totalTax, 2, ',', '.') . ' €',

            'total' => round($grandTotal, 2),
            'total_formatted' => number_format($grandTotal, 2, ',', '.') . ' €'
        ]);
    }


    public function generateXML($id)
    {
        $user = Auth()->user();
        $company = $user->company ?? [];
        $invoice = Invoice::with(['client', 'adminClient'])->findOrFail($id)->toArray();
        $items   = $invoice['items'];

        // Generate XML
        $xmlService = new InvoiceXmlService();
        $xmlString  = $xmlService->generateInvoiceXML($invoice, $items, $company->toArray());

        return response($xmlString, 200)
            ->header('Content-Type', 'application/xml');

        // Return XML download
        // return response($xmlString, 200)
        //         ->header('Content-Type', 'application/xml')
        //         ->header('Content-Disposition', 'attachment; filename="invoice_'.$id.'.xml"');
    }

}
