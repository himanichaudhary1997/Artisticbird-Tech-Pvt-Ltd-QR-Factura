<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use App\Models\Role;
// use Spatie\Permission\Models\Permission;
use App\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    
    public function index(Request $request)
    {
        try{
        $query = Role::Query();

         // Apply search filter
         if (isset($formdata['search']) && !empty($formdata['search'])) {
            $query->where(function ($q) use ($formdata) {
                $q->where('name', 'like', '%' . $formdata['search'] . '%')
                    ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                    ->orWhere('phone', 'like', '%' . $formdata['search'] . '%')
                    ->orWhereHas('company', function ($query) use ($formdata) {
                        $query->where('company_name', 'like', '%' . $formdata['search'] . '%');
                    });
            });
        }
        $roles = $query->orderBy('id','DESC')->paginate(15);

        if($request->ajax())
        {
            return view('panel.roles.partial_data',compact('roles'));
        }
        // $roles = $query->orderBy('id','DESC')->paginate(15);
        return view('panel.roles.index', compact('roles'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }


    public function create()
    {
        try{
        $role = new Role(); // Empty role object for form binding
        $heading = __('Create Role');
        $actiontext = __('Create Role');
        $action = route('roles.store');
        $method = 'POST';

        $permissions = Permission::all(); // Fetch all available permissions
        $rolePermissions = []; // No permissions assigned yet

        return view('panel.roles.form', compact('role', 'heading', 'actiontext', 'action', 'method', 'permissions', 'rolePermissions'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    


    public function store(Request $request)
    {
        try{
        $validatedData = $request->validate([
            'name' => 'required|string|unique:roles,name',
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,id', // Validate permission IDs
        ]);

        // Create a new role
        $role = Role::create(['name' => $validatedData['name'], 'guard_name' => 'web']);

        // Convert permission IDs to names and assign them
        $permissionNames = Permission::whereIn('id', $validatedData['permissions'] ?? [])->pluck('name')->toArray();
        $role->syncPermissions($permissionNames);

        return redirect()->route('roles.index')->with('success', __('Role created successfully.'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    // public function edit(Role $role)
    // {
    //     if ($role->name === 'Admin') {
    //         return redirect()->route('roles.index')->with('error', __('Admin role cannot be edited.'));
    //     }
    
    //     $heading = __('Edit Role');
    //     $actiontext = __('Update Role');
    //     $action = route('roles.update', $role);
    //     $method = 'PUT'; // For update


    //     $permissions = Permission::all(); // Get all permissions
    //     $rolePermissions = $role->permissions->pluck('id')->toArray(); // Get assigned permissions
    
    //     return view('panel.roles.form', compact('role', 'heading', 'actiontext', 'action', 'method', 'permissions', 'rolePermissions'));
    // }
    
//     use App\Models\Permission;
// use Spatie\Permission\Models\Role;

    public function edit(Role $role)
    {
        try{
        if ($role->name === 'Admin') {
            return redirect()->route('roles.index')->with('error', __('Admin role cannot be edited.'));
        }

        $heading = __('Edit Role');
        $actiontext = __('Update Role');
        $action = route('roles.update', $role);
        $method = 'PUT'; // For update

        // Get only top-level permissions (parent_id = null) and their children
        $permissions = Permission::whereNull('parent_id')->with('children')->get();
        
        // Get assigned permissions for the role
        $rolePermissions = $role->permissions->pluck('id')->toArray(); 

        return view('panel.roles.form', compact('role', 'heading', 'actiontext', 'action', 'method', 'permissions', 'rolePermissions'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }



    public function update(Request $request, Role $role)
    {
        try{
        if ($role->name === 'Admin') {
            return redirect()->route('roles.index')->with('error', __('Admin role cannot be modified.'));
        }

        $validatedData = $request->validate([
            'name' => 'required|string|unique:roles,name,' . $role->id,
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,id', // Validate permission IDs
        ]);

        // Update role name
        $role->update(['name' => $validatedData['name']]);

        // Convert permission IDs to names and assign them
        $permissionNames = Permission::whereIn('id', $validatedData['permissions'] ?? [])->pluck('name')->toArray();
        $role->syncPermissions($permissionNames);

        return redirect()->route('roles.index')->with('success', __('Role updated successfully.'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }



    public function destroy(Role $role)
    {
        try{
        if ($role->name === 'Admin') {
            return redirect()->route('roles.index')->with('error', 'Admin role cannot be deleted.');
        }

        // $role->delete();
        return redirect()->route('roles.index')->with('success', 'Role deleted successfully.');
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }
}
