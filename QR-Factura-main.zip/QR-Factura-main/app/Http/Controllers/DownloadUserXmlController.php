<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use Illuminate\Support\Facades\Response;

class DownloadUserXmlController extends Controller
{
    public function downloadUserXml(Request $request,$id){
        try {
        $user = User::findOrFail($id);
        $company = $user->company;
        $xmlData = '<?xml version="1.0" encoding="UTF-8"?>';
        $xmlData .= '<user>';
        $xmlData .= '<name>' . htmlspecialchars($user->name) . '</name>';
        $xmlData .= '<email>' . htmlspecialchars($user->email) . '</email>';
        $xmlData .= '<phone>' . htmlspecialchars($user->phone) . '</phone>';
        $xmlData .= '<company_name>' . htmlspecialchars($user->company->company_name ?? $user->extra['company_name']) . '</company_name>';
        $xmlData .= '<company_email>' . htmlspecialchars($user->company->company_email ?? $user->email) . '</company_email>';
        $xmlData .= '<gst_no>' . htmlspecialchars($user->company->gst_no ?? $user->extra['gst_no']) . '</gst_no>';
        $xmlData .= '</user>';
    
        return Response::make($xmlData, 200, [
            'Content-Type' => 'application/xml',
            'Content-Disposition' => 'attachment; filename="company.xml"',
        ]);
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }
}
