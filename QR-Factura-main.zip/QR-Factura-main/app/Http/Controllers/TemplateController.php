<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Http\Request;
use App\Models\Templates;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use App\Models\User;
use App\Models\Invoice;

class TemplateController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function indexTemplate(Request $request){
        try{
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
        //    dd($formdata);
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Templates::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                // dd($formdata);
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `scope` is a column in the `users` table
            }   

            if(!empty($company)){
                $query->where(function ($q) use ($company) {
                    $q->where('scope', $company->id)
                      ->orWhereNull('scope');
                });
                $query->where('status', 1);
            }

            $notShowIds = [env('PRESUPESTOS_TEMPLATE_ID'), env('AUTO_INVOICE_TEMPLATE_ID'),env('DELIVERY_NOTE_TEMPLATE_ID')];

            if(!empty($company)){
                $query->whereNotIn('id', $notShowIds);
            }
            // Fetch paginated results with related data
            $templates = $query->orderBy('id','DESC')->paginate($limit);
            // $templates = Templates::paginate(10);
            $companies = Company::all();
            if(!empty($company)){
                $favouriteTemplate = $company->extra['favouraite_template'] ?? Templates::where('status', 1)->value('id');
            }else{
                $adminUser = User::where('id',1)->first();
                $favouriteTemplate = $adminUser->extra['favouraite_template'] ??  Templates::where('status', 1)->value('id');
            }
            $template = Templates::find($favouriteTemplate);
            if(empty($template) || $template->status != 1){
                $favouriteTemplate = Templates::where('status', 1)->value('id');
            }
            if ($request->ajax()) {
                return view('panel.template.partial_template', compact('templates','favouriteTemplate'))->render();
            }
    
            return view('panel.template.index-template', compact('templates', 'companies','favouriteTemplate'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function editTemplate($id){
        try{
            $template = Templates::find($id);
            $companies = Company::all();
            return view('panel.template.edit-template',compact('template','companies'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addTemplate(){
        try{
        $companies = Company::all();
        return view('panel.template.add-template',compact('companies'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditTemplate(Request $request){
        
        try {
            // Extract form data
            $formdata = $request->all();
            // $service_id = $formdata['id'] ?? null;
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $template_id = $formdata['id'] ?? null;
            $scope = (!empty($company)) ? $company->id : ($formdata['scope'] ?? null);
            $dynamicTableName = (new Templates())->getTable();
            // dd($service_id);
            // Validation rules
            $rules = [
                'name'=>'required|string|max:255|unique:templates,name,' . $template_id,
                'template_html'=>'required'
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // dd($formdata);
            

            $template_data = [
                'name'=> $formdata['name'],
                'template_html'=>$formdata['template_html'],
                'extra'=>$formdata['extra'] ?? null,
            ];
            // dd($role);
            if(!empty($company)){
                $template_data['scope'] = $company->id;
            }else{
                $template_data['scope'] = $formdata['scope'] ?? null;
            }


            if (!empty($template_id)) {
                $templateData = Templates::where('id',$template_id)->first();
                Templates::where('id', $template_id)->update($template_data);
                $template = Templates::where('id',$template_id)->first();
    
                
            } else {
                // Create a new invoice
                $template = Templates::create($template_data);
                
                
                
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Template updated successfully.') 
                    : __('Template created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditTemplate: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }


    public function deleteTemplate($id){
        try {
            // Attempt to delete the user by ID
            Templates::destroy($id);
            

            // Return success response
            return response()->json(['success' => true, 'message' => __('Template deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Template. Please try again.')], 500);
        }
    }


    public function getTemplate(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Templates::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }   

            if(!empty($company)){
                $query->where(function ($q) use ($company) {
                    $q->where('scope', $company->id)
                      ->orWhereNull('scope');
                });
            }

            

            // Fetch paginated results with related data
            $templates = $query->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Templates retrieved successfully.',
                'data' => $templates,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,           
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Templates.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function previewTemplate(Request $request, $id){
        try{
            $authUser = auth()->user();
            $company = $authUser->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if ($company) {
                $user = User::where('id', $company->admin_id)->first();
            } else {
                $user = User::where('id', 1)->first();
            }

            // $invoice = Invoice::findOrFail(1);
            // dd($invoice);
            $invoice = new \stdClass();
            $invoice->id = 1;
            $invoice->reference_id = null;
            $invoice->invoice_id = "2025/CO/0001";
            $invoice->client_id = 2;
            $invoice->currency = "₹";
            $invoice->issue_date = "2025-02-19 00:00:00";
            $invoice->due_date = "2025-02-28 00:00:00";
            $invoice->invoice_type = 2;
            $invoice->payment_method = 1;
            $invoice->ref_no = 23433;
            $invoice->items = [
                ["item_id" => "2", "item_type" => "inventory", "quantity" => "1", "price" => "23.10", "discount" => "22", "tax" => "22.05", 'tax_type'=>"percentage",  "amount" => "2792.504"],
                ["item_id" => "2", "item_type" => "inventory", "quantity" => "1", "price" => "23.10", "discount" => "22", "tax" => "22.05",'tax_type'=>"percentage", "amount" => "2792.504"],
                ["item_id" => "5", "item_type" => "inventory", "quantity" => "1", "price" => "21000.00", "discount" => "1000", "tax" => "10", 'tax_type'=>"percentage","amount" => "-1076.9"],
                ["item_id" => "2", "item_type" => "inventory", "quantity" => "1", "price" => "23.10", "discount" => "22", "tax" => "22.05",'tax_type'=>"percentage", "amount" => "2792.504"],
                ["item_id" => "3", "item_type" => "inventory", "quantity" => "1", "price" => "75000.00", "discount" => "22", "tax" => "14.00",'tax_type'=>"percentage", "amount" => "1"]
            ];
            $invoice->extra =[
                "template_id" => "1",
                "item_type" => "inventory",
                "subtotal" => "6952",
                "totalDiscount" => "1066",
                "totalTax" => "1415.612",
                "grandTotal" => "7301.612"
            ];
            $invoice->status = 2;
            $invoice->preview = true;
            $invoice->client_id = null;
            $invoice->created_by = 1;
            $invoice->subtotal = "6952";
            $invoice->totalDiscount = "1066";
            $invoice->totalTax = "1415.612";
            $invoice->grandTotal = "7301.612";
            $invoice->created_at = "2025-02-19 07:19:39";
            $invoice->updated_at = "2025-02-24 09:14:09";

            // print_r($invoice);

            
            $templateId = !empty($invoice->extra['template_id']) ? $invoice->extra['template_id'] : 1;
            $template = Templates::where('id', $id)->first();

            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);


            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice->invoice_id ?? null,
                'customer_name' => 'Client Name',
            ];
            return view('panel.template.template-preview', ['templateHtml' => $datahtml, 'data' => $data]);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage() . ' '.$e->getLine() . ' ' .$e->getFile());
        }
    }

    public function addToFavouraite(Request $request)
    {
        try {
            // dd($request->all());
            // Validate input data
            $validator = Validator::make($request->all(), [
                'checked' => 'required', // Ensure checked is true or false
                'template_id' => 'required|integer' // Ensure template_id is an integer
            ]);
    
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
    
            // Get authenticated user
            $user = auth()->user();
            $company = $user->company ?? null;
            $adminUser = User::find(1); // Fetch Admin User
    
            // Determine where to store favourites (Company or Admin)
            $owner = $company ?? $adminUser;
    
            if (!$owner) {
                return response()->json([
                    'success' => false,
                    'message' => __('No valid owner found.'),
                ], 200);
            }
    
            // Fetch and decode the extra field
            $extra = is_array($owner->extra) ? $owner->extra : json_decode($owner->extra, true);
            $favouriteTemplates = $extra['favouraite_template'] ?? [];
    
    
            // Update extra field and save
            $extra['favouraite_template'] =(int) $request->template_id;; // Re-index array
            $owner->extra = $extra; // Save as JSON
            $owner->save();
    
            // Return success response
            return response()->json([
                'success' => true,
                'message' =>__('Successfully added to favouraite template.'),
                'favouraite_template' => $favouriteTemplates
            ], 200);
    
        } catch (\Exception $e) {
            Log::error('Error in addToFavouraite: ' . $e->getMessage());
    
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ], 200);
        }
    }
    public function statusupdate(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
           
            $document = Templates::findOrFail($id);
            $document->status = $request->status;
            $document->save();

            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Template status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Template status: ' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
}
