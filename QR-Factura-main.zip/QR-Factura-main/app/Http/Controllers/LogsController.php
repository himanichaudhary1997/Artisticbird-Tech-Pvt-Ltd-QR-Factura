<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use League\Csv\Writer;
use SplTempFileObject;
use Illuminate\Support\Facades\Storage;


class LogsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    // public function indexLogs(Request $request){
    //     try {
    //         $user = auth()->user();
    //         $limit = $formdata['limit'] ?? 15;
    //         $formdata = $request->all();
    //         $role = $user->roles->pluck('id')->first();
    //         $company = $user->company;
    //         if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //             // If it's a collection, take the first item
    //             $company = $company->first();
    //         }
    //         // Base query excluding the authenticated user and filtering by role ID 2
    //         $query = ActivityLog::orderBy('created_at','DESC');

            

    //         if (isset($formdata['user_id']) && !empty($formdata['user_id'])) {
    //             $query->where('user_id', $formdata['user_id']); // Assuming `status` is a column in the `users` table
    //         } 

    //         if (isset($formdata['company_id']) && !empty($formdata['company_id'])) {
    //             $query->where('company_id', $formdata['company_id']); // Assuming `status` is a column in the `users` table
    //         } 

    //         // if(!empty($formdata['company_id'])){
    //         //     $company = Company::where('id',$formdata['company_id'])->first();
    //         //     $users = $company->getAllUsers();
    //         //     // dd($users);
    //         // }else{
    //         //     $users = User::all();
    //         // }


    //         $logs = $query->with('user')->paginate($limit);
    //         // dd($logs->toArray());

    //         $companies = Company::all();
    //         // $users = User::all();
    //         // dd($users);

    //         if(!empty($company)){
    //             $company = Company::where('id',$company->id)->first();
    //             $users = $company->getAllUsers();
    //             // dd($users);
    //         }else{
    //             $users = User::all();
    //         }
    //         // Return JSON response
    //         if($request->ajax()){
    //             return view('panel.logs.partial_log',compact('logs','users','companies'));
    //         }

    //        return view('panel.logs.index-log',compact('companies','users','logs'));
    //     } catch (\Throwable $e) {
    //         return redirect()->back()->with('error', __('Something went wrong.'));
    //     }
    // }

    public function indexLogs(Request $request){
        try {
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;
            $role = $user->roles->pluck('id')->first();

            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            $query = ActivityLog::orderBy('created_at', $request->sort ?? 'desc');

            if (!empty($company)) {
                // Company-scoped user: force their own company, ignore any company_id from request
                $query->where('company_id', $company->id);
                $users = $company->getAllUsers();

                if (isset($formdata['user_id']) && !empty($formdata['user_id'])) {
                    $query->where('user_id', $formdata['user_id']);
                }
            } else {
                // Admin/unscoped user: both filters apply
                if (isset($formdata['user_id']) && !empty($formdata['user_id'])) {
                    $query->where('user_id', $formdata['user_id']);
                }

                if (isset($formdata['company_id']) && !empty($formdata['company_id'])) {
                    $query->where('company_id', $formdata['company_id']);
                    $filterCompany = Company::where('id', $formdata['company_id'])->first();
                    $users = $filterCompany ? $filterCompany->getAllUsers() : User::all();
                } else {
                    $users = User::all();
                }
            }

            if (!empty($formdata['from_date'])) {
                $query->whereDate('created_at', '>=', $formdata['from_date']);
            }

            if (!empty($formdata['to_date'])) {
                $query->whereDate('created_at', '<=', $formdata['to_date']);
            }
            
            $logs = $query->with('user')->paginate($limit);
            $companies = Company::all();

            if ($request->ajax()) {
                return view('panel.logs.partial_log', compact('logs', 'users', 'companies'));
            }

            return view('panel.logs.index-log', compact('companies', 'users', 'logs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function getLogs(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = ActivityLog::orderBy('created_at','DESC');

            

            if (isset($formdata['user_id']) && !empty($formdata['user_id'])) {
                $query->where('user_id', $formdata['user_id']); // Assuming `status` is a column in the `users` table
            } 

            if (isset($formdata['company_id']) && !empty($formdata['company_id'])) {
                $query->where('company_id', $formdata['company_id']); // Assuming `status` is a column in the `users` table
            } 

            if(!empty($formdata['company_id'])){
                $company = Company::where('id',$formdata['company_id'])->first();
                $users = $company->getAllUsers();
                // dd($users);
            }else{
                $users = User::all();
            }

            // dd($users->toArray());
            // Fetch paginated results with related data
            $logs = $query->with('user')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Templates retrieved successfully.',
                'data' => $logs,
                'users' => $users,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,           
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Templates.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    // public function generateFakeLogs(Request $request)
    // {
    //     try {
    //         $request->validate([
    //             'company_id' => 'required|exists:companies,id'
    //         ]);
        
    //         $companyId = $request->company_id;
        
    //         // Get all users of the company
    //         if (!empty($companyId)) {
    //             $company = Company::where('id', $companyId)->first();
    //             $users = $company->getAllUsers();
    //         } else {
    //             $users = User::all();
    //         }
        
    //         if ($users->isEmpty()) {
    //             return response()->json(['success' => false, 'message' => 'No users found for this company.'], 200);
    //         }
        
    //         $fakeLogs = [];
    //         $totalLogs = rand(500, 2000); // Total number of logs to generate
    //         $startDate = Carbon::now()->subYear(); // Start from one year ago
    //         $endDate = Carbon::now()->subDay(); // End at yesterday (do not include today's date)
        
    //         // Generate logs
    //         while (count($fakeLogs) < $totalLogs) {
    //             // Ensure that the generated login time is always between startDate and endDate
    //             $loginTime = fake()->dateTimeBetween($startDate, $endDate); // Generate a random login time
        
    //             // Ensure the logout time is always after the login time
    //             $logoutTime = Carbon::instance($loginTime)->addMinutes(rand(5, 60)); // Logout within 5 to 60 minutes after login
        
    //             // Create the login and logout log
    //             $ipAddress = fake()->ipv4(); // Generate a random IP address
                
    //             $fakeLogs[] = [
    //                 'user_id' => $users->random()->id,
    //                 'company_id' => $company->id ?? null,
    //                 'action' => 'login',
    //                 'ip_address' => $ipAddress,
    //                 'created_at' => $loginTime,
    //                 'updated_at' => $loginTime,
    //             ];
        
    //             $fakeLogs[] = [
    //                 'user_id' => $users->random()->id,
    //                 'company_id' => $company->id ?? null,
    //                 'action' => 'logout',
    //                 'ip_address' => $ipAddress,
    //                 'created_at' => $logoutTime,
    //                 'updated_at' => $logoutTime,
    //             ];
        
    //             // Update startDate for the next iteration to be after the current logout time
    //             $startDate = $logoutTime; // Update the start date to the logout time to avoid clustering
                
    //             // Ensure that the start date never exceeds the end date
    //             if ($startDate >= $endDate) {
    //                 break; // Exit the loop if the start date exceeds or equals the end date
    //             }
    //         }
        
    //         // Sort logs by `created_at` to ensure proper order (logins and logouts in order)
    //         usort($fakeLogs, function ($a, $b) {
    //             return $a['created_at'] <=> $b['created_at'];
    //         });
        
    //         // Insert the fake logs in bulk
    //         ActivityLog::insert($fakeLogs);
        
    //         // Return success response
    //         return response()->json([
    //             'success' => true,
    //             'message' => 'Generated ' . count($fakeLogs) . ' logs successfully',
    //             'count' => count($fakeLogs)
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Failed to generate fake logs: ' . $e->getMessage(),
    //         ], 500);
    //     }
    // }

    public function generateFakeLogs(Request $request)
    {
        try {
            $request->validate([
                'company_id' => 'required|exists:companies,id',
                'from_date'  => 'required|date',
                'to_date'    => 'required|date|after_or_equal:from_date|before_or_equal:' . now()->subDay()->toDateString(),
            ]);

            $company = Company::where('id', $request->company_id)->first();
            $users = $company->getAllUsers();

            if ($users->isEmpty()) {
                return response()->json(['success' => false, 'message' => 'No users found for this company.'], 200);
            }

            $rangeStart = Carbon::parse($request->from_date)->startOfDay();
            $rangeEnd   = Carbon::parse($request->to_date)->endOfDay();

            if ($rangeStart->gte($rangeEnd)) {
                return response()->json(['success' => false, 'message' => 'Invalid date range.'], 200);
            }

            $userIds = $users->pluck('id')->all();

            // Days that already have a login log for each user within this range — skip these, don't duplicate
            $existing = ActivityLog::whereIn('user_id', $userIds)
                ->where('action', 'login')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd])
                ->get(['user_id', 'created_at'])
                ->groupBy('user_id')
                ->map(function ($rows) {
                    return $rows->map(fn($r) => Carbon::parse($r->created_at)->toDateString())->flip();
                });

            $fakeLogs = [];
            $weekStart = $rangeStart->copy()->startOfWeek();

            foreach ($users as $user) {
                $existingDates = $existing->get($user->id, collect());
                $cursor = $weekStart->copy();

                while ($cursor->lte($rangeEnd)) {
                    $weekEnd = $cursor->copy()->endOfWeek();

                    // build candidate working days for this week within the overall range
                    $candidateDays = collect();
                    $d = $cursor->copy();
                    while ($d->lte($weekEnd) && $d->lte($rangeEnd)) {
                        if ($d->gte($rangeStart) && !$d->isSunday() && !$existingDates->has($d->toDateString())) {
                            $candidateDays->push($d->copy());
                        }
                        $d->addDay();
                    }

                    if ($candidateDays->isNotEmpty()) {
                        // 3-4 login days per user per week
                        $pickCount = min($candidateDays->count(), rand(3, 4));
                        $pickedDays = $candidateDays->shuffle()->take($pickCount);

                        foreach ($pickedDays as $day) {
                            // login between 8:00 and 10:59 AM
                            $loginTime = $day->copy()->setTime(rand(8, 10), rand(0, 59), 0);

                            // work session 4-9 hours
                            $logoutTime = $loginTime->copy()->addMinutes(rand(240, 540));

                            $dayEnd = $day->copy()->endOfDay();
                            if ($logoutTime->gt($dayEnd))    $logoutTime = $dayEnd->copy();
                            if ($logoutTime->gt($rangeEnd))  $logoutTime = $rangeEnd->copy();

                            $ipAddress = fake()->ipv4();

                            $fakeLogs[] = [
                                'user_id'    => $user->id,
                                'company_id' => $company->id,
                                'action'     => 'login',
                                'ip_address' => $ipAddress,
                                'created_at' => $loginTime,
                                'updated_at' => $loginTime,
                            ];

                            $fakeLogs[] = [
                                'user_id'    => $user->id,
                                'company_id' => $company->id,
                                'action'     => 'logout',
                                'ip_address' => $ipAddress,
                                'created_at' => $logoutTime,
                                'updated_at' => $logoutTime,
                            ];
                        }
                    }

                    $cursor->addWeek();
                }
            }

            if (empty($fakeLogs)) {
                return response()->json([
                    'success' => true,
                    'message' => 'No new logs generated — logs already exist for these users in the given range.',
                    'count'   => 0,
                ]);
            }

            usort($fakeLogs, fn($a, $b) => $a['created_at'] <=> $b['created_at']);

            foreach (array_chunk($fakeLogs, 500) as $chunk) {
                ActivityLog::insert($chunk);
            }

            return response()->json([
                'success' => true,
                'message' => 'Generated ' . count($fakeLogs) . ' logs successfully for ' . $users->count() . ' users',
                'count'   => count($fakeLogs),
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => collect($e->errors())->flatten()->first(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate fake logs: ' . $e->getMessage(),
            ], 500);
        }
    }


    public function exportLogs(Request $request)
    {
        try {
        $request->validate([
            'company_id' => 'required|exists:companies,id'
        ]);

        $companyId = $request->company_id;

        // Fetch logs based on the company_id
        $logsQuery = ActivityLog::orderBy('created_at', 'DESC');

        if (!empty($companyId)) {
            $logsQuery->where('company_id', $companyId);
        }

        $logs = $logsQuery->get(['user_id', 'company_id', 'action', 'ip_address', 'created_at']);

        if ($logs->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'No logs found for this company.'], 200);
        }

        // Create CSV content
        $csvData = [];
        $csvData[] = ['User Name', 'User Email', 'Action', 'IP Address', 'Date']; // CSV header

        foreach ($logs as $log) {
            $user = User::find($log->user_id);
            $company = Company::find($log->company_id);

            $csvData[] = [
                $user->name ?? null,
                $user->email ?? null,
                // $company->company_name ?? null,
                $log->action,
                $log->ip_address,
                $log->created_at->toDateTimeString(),
            ];
        }

        // Save CSV file in a public directory
        $filename = 'logs_company_' . $companyId . '_' . now()->timestamp . '.csv';
        $filepath = storage_path('app/public/' . $filename);

        $file = fopen($filepath, 'w');
        foreach ($csvData as $row) {
            // Ensure each column is properly separated
            fputcsv($file, $row);
        }
        fclose($file);

        return response()->json([
            'success' => true,
            'download_url' => asset('storage/' . $filename), // Generate public URL
            'message'=>'Sheet exported successfully.'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to export logs: ' . $e->getMessage(),
        ], 500);
    }
    }


}
