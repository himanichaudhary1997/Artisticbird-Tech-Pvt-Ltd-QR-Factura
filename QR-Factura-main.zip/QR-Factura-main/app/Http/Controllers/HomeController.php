<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Menu;
use App\Models\Company;
use App\Models\Invoice;
use App\Models\Issues;
use App\Models\Messages;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\DocuemntsModel;
use App\Models\ClientAccountantRelation;
use App\Models\Clients;
use App\Models\Receipts;
use App\Models\Performa;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
    // try {
        $user = auth()->user();

        $company = $user->company;
        // dd($company);
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();
        }
        
        // dd($user->roles->first());
        $role = $user->roles->first() ?? null;
        $roles = \Spatie\Permission\Models\Role::find(2);
        $country = CountryModel::all();
        $states = StateModel::all();
        // Fetch users who have role ID 2 and created_at in the current month and year
        $users = $roles->users()
            ->whereYear('created_at', date('Y'))  // Filter by current year
            ->whereMonth('created_at', date('m')) // Filter by current month
            ->get();

        if($company){
            $accountantUsers = User::whereHas('roles', function ($query) {
                $query->where('name', 'CompanyAccountant'); // Accountant role ID
            })->join('company_users', 'users.id', '=', 'company_users.user_id')
            ->where('company_users.admin_id', $company->admin_id)
            ->select('users.*') // Ensure only user columns are selected
            ->get();

            $staffUsers = User::whereHas('roles', function ($query) {
                $query->where('name', 'CompanyStaff'); // Staff role ID
            })->join('company_users', 'users.id', '=', 'company_users.user_id')
            ->where('company_users.admin_id', $company->admin_id)
            ->select('users.*')
            ->get();
        }else{
            $accountantUsers = User::whereHas('roles', function ($query) {
                $query->where('name', 'Accountant'); // Filter by role ID 4
            })
            ->get();
        
            $staffUsers = User::whereHas('roles', function ($query) {
                    $query->where('name', 'Staff'); // Filter by role ID 3
                })
                ->get();  
        }
        

        
        $companies = Company::all();
        // 1. Get user's base/target currency (same for both)
        $baseCurrency = $targetCurrency = $company->extra['currency'] ?? $user->extra['currency'] ?? '€';
        
        // 2. Exchange rates (1 BASE = X OTHER CURRENCY)
        $exchangeRates = getExchangeRates($baseCurrency);

        $year = date('Y');
        $invoices = Invoice::whereYear('issue_date', $year)->where('status','!=',1)->orderBy('id', 'DESC')->get();
        
        $monthlyTotals = [];
        $totalYearGrandTotal = 0;
        $totalYearTax = 0;

        // Initialize months
        for ($m = 1; $m <= 12; $m++) {
            $monthName = date('F', mktime(0, 0, 0, $m, 1));
            $monthlyTotals[$monthName] = [
                'grandTotal' => 0, 
                'tax' => 0,
                'formattedGrandTotal' => '',
                'formattedTax' => ''
            ];
        }

        foreach ($invoices as $invoice) {
            $invoiceCurrency = $invoice->currency ?? $baseCurrency;
            $monthName = date('F', strtotime($invoice->issue_date));

            $grandTotal = parseNumber($invoice->grandTotal ?? 0);
            $totalTax = parseNumber($invoice->totalTax ?? 0);

            // Convert to base currency if different
            if ($invoiceCurrency !== $baseCurrency) {
                $rate = $exchangeRates[$invoiceCurrency] ?? 1;
                $grandTotal = $grandTotal / $rate;
                $totalTax = $totalTax / $rate;
            }

            // Accumulate totals
            $monthlyTotals[$monthName]['grandTotal'] += $grandTotal;
            $monthlyTotals[$monthName]['tax'] += $totalTax;
            
            $totalYearGrandTotal += $grandTotal;
            $totalYearTax += $totalTax;
        }
        
        // Format all values in Euro format (1.234,56)
        $totalYearGrandTotal = formatValueCurrency(
            formatValue($totalYearGrandTotal, $targetCurrency),
            $targetCurrency
        );
        $totalYearTax = formatValueCurrency(
            formatValue($totalYearTax, $targetCurrency),
            $targetCurrency
        );
        
        // Format all values
        foreach ($monthlyTotals as $month => &$totals) {
            if ($totals['grandTotal'] > 0 || $totals['tax'] > 0) {
                $totals['formattedGrandTotal'] = formatValueCurrency(
                    formatValue($totals['grandTotal'], $targetCurrency),
                    $targetCurrency
                );
                $totals['formattedTax'] = formatValueCurrency(
                    formatValue($totals['tax'], $targetCurrency),
                    $targetCurrency
                );
            } else {
                unset($monthlyTotals[$month]);
            }
        }
        // Output result
        // dd($monthlyTotals);
        

        $expiredUsers = User::where(function ($query) {
            $query->where('status', 0)
                  ->orWhereHas('subscriptionDetails', function ($subQuery) {
                      $subQuery->whereDate('end_date', '<', now()) // Already expired
                               ->orWhereBetween('end_date', [now(), now()->addDays(10)]); // Expiring in 10 days
                  })
                  ->orWhereDoesntHave('subscriptionDetails'); // Users with no subscription
        })
        ->whereHas('roles', function ($query) {
            $query->where('name', 'Company'); // Only users with the 'Company' role
        })
        ->get();
    
    



        // dd($totalInEuro);
        $thisMonthInvoices = Invoice::whereMonth('issue_date', date('m'))  // Filter by current month
        ->whereYear('issue_date', date('Y'))  // Filter by current year
        ->get();
    
        $thisMonthReceipts = Receipts::whereMonth('created_at', date('m'))  // Filter by current month
        ->whereYear('created_at', date('Y'))  // Filter by current year
        ->get();

        $thisYearInvoices = Invoice::whereYear('issue_date', date('Y'))  // Filter by current year
        ->get();
        $sendInvoices = Invoice::where('status', 2)
        ->whereMonth('issue_date', date('m'))  // Filter by current month
        ->whereYear('issue_date', date('Y'))  // Filter by current year
        ->get();
        // dd($user);
        $accountantCompanies = [];
        if (in_array($role->name, ['Accountant', 'CompanyAccountant'])) {
                $accountantCompanies = auth()->user()->company()
                ->join('users', 'companies.admin_id', '=', 'users.id') // join with users
                ->where('users.status', 1)
                // ->whereIn('companies.admin_id', function ($query) {
                //     $query->select('user_id')
                //         ->from('user_subscriptions')
                //         ->where(function ($q) {
                //             $q->whereNull('end_date')
                //                 ->orWhere('end_date', '>=', now());
                //         });
                // })
                ->select('companies.id as company_id', 'companies.company_name', 'companies.company_slug')
                ->get()
                ->map(function ($company) {
                    $user = auth()->user();
        
                    $totalClients = (new ClientAccountantRelation())
                        ->setDynamicTableName($company->company_id)
                        ->newQuery()
                        ->where('accountant_id', $user->id)
                        ->count();
        
                    $totalClientsIds = (new ClientAccountantRelation())
                        ->setDynamicTableName($company->company_id)
                        ->newQuery()
                        ->where('accountant_id', $user->id)
                        ->pluck('client_id')
                        ->toArray();
        
                    $totalInvoices = (new Invoice())
                        ->setDynamicTableName($company->company_id)
                        ->newQuery()
                        ->whereIn('client_id', $totalClientsIds)
                        ->count();
        
                    $totalDocuments = (new DocuemntsModel())
                        ->setDynamicTableName($company->company_id)
                        ->newQuery()
                        ->where(function ($q) use ($totalClientsIds) {
                            foreach ($totalClientsIds as $clientId) {
                                $q->orWhereJsonContains('client_id', (string) $clientId);
                            }
                        })->count();
        
                    return [
                        'company_id'      => $company->company_id,
                        'company_name'    => $company->company_name,
                        'company_slug'    => $company->company_slug,
                        'total_clients'   => $totalClients,
                        'total_invoices'  => $totalInvoices,
                        'total_documents' => $totalDocuments,
                    ];
                })
                ->toArray();
        }
        
        

        if($role->name == 'Accountant'){
            $totalClients = ClientAccountantRelation::where('accountant_id',$user->id)->count();
            $totalClientsIds = ClientAccountantRelation::where('accountant_id',$user->id)->pluck('client_id')->toArray();
            // dd($totalClientsIds);   
            if (empty($totalClientsIds)) {
                $totalInvoices = 0;
                $totalDocuments = 0;
            } else {
                $totalInvoices = Invoice::whereIn('client_id', $totalClientsIds)->count();
            
                $totalDocuments = DocuemntsModel::where(function ($q) use ($totalClientsIds) {
                    foreach ($totalClientsIds as $clientId) {
                        $q->whereJsonContains('client_id', (string) $clientId);
                    }
                })->count();
            }
            
            $artisticBirdCompany = [
               'company_name'=>'Artistic Bird',
               'company_slug'=>'artisticbird',
               'total_clients'=>$totalClients,
               'total_invoices'=>$totalInvoices,  
               'total_documents'=>$totalDocuments,
            ];
            array_unshift($accountantCompanies, $artisticBirdCompany);
        }   
        $accountantClients = [];
        if (count($accountantCompanies) === 1) {

            $company = $accountantCompanies[0]; // the only company
            $companyId = $company['company_id'] ?? null;
        
            $user = auth()->user();
        
            // Get all client IDs under this accountant
            $clientIds = (new ClientAccountantRelation())
                ->setDynamicTableName($companyId)
                ->newQuery()
                ->where('accountant_id', $user->id)
                ->pluck('client_id');
        
            // Now get all client data from dynamic client table
            if(!empty($companyId)){
                $accountantClients = (new Clients())
                ->setDynamicTableName($companyId)
                ->newQuery()
                ->whereIn('id', $clientIds)
                ->get()
                ->map(function ($client) use ($companyId) {
                    $invoiceCount = (new Invoice())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->where('client_id', $client->id)
                        ->count();

                    $documentCount = (new DocuemntsModel())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->whereJsonContains('client_id', (string) $client->id)
                        ->count();

                    return [
                        'client_id'      => $client->id,
                        'client_name'    => $client->extra['company_name'] ?? $client->name ?? 'N/A',
                        'invoice_count'  => $invoiceCount,
                        'document_count' => $documentCount,
                    ];
                })->toArray();
            }else{
                $accountantClients = User::whereIn('id', $clientIds)->with('singleCompany')
                ->get()
                ->map(function ($client) use ($companyId) {
                    $invoiceCount = (new Invoice())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->where('client_id', $client->id)
                        ->count();

                    $documentCount = (new DocuemntsModel())
                        ->setDynamicTableName($companyId)
                        ->newQuery()
                        ->whereJsonContains('client_id', (string) $client->id)
                        ->count();

                    return [
                        'client_id'      => $client->id,
                        'client_name'    => $client->singleCompany->company_name ?? 'N/A',
                        'invoice_count'  => $invoiceCount,
                        'document_count' => $documentCount,
                    ];
                })->toArray();
            }
            

            // dd($clients);
        }
        
        $dashboardSummary = $this->getDashboardSummary($company);
        // dd($dashboardSummary);

        $role_name = '';
        if (!empty($role)) {
            if($role->name == 'Staff' || $role->name == 'CompanyStaff' ||  $role->name == 'Support'){
                $role_name = 'staff';
            }elseif($role->name == 'Company' || $role->name == 'CompanyAdmin'){
                $role_name = 'company';
            }elseif($role->name == 'Accountant' || $role->name == 'CompanyAccountant'){
                $role_name = 'accountant';
            }else{
                $role_name = $role->name;
            }
            // $role_name = 
            $folder_role = 'panel.' . strtolower(str_replace(' ', '-', $role_name)) . '.home';
            return view($folder_role,compact('dashboardSummary', 'users','companies','sendInvoices','thisMonthInvoices','thisMonthReceipts','thisYearInvoices','totalYearGrandTotal','staffUsers','accountantUsers','totalYearTax','monthlyTotals','states','country','accountantCompanies','expiredUsers','accountantClients'));
        }else{
            return view('home',compact('users','companies','sendInvoices','thisMonthInvoices','thisMonthReceipts','thisYearInvoices','totalYearGrandTotal','staffUsers','accountantUsers','totalYearTax','monthlyTotals','states','country','accountantCompanies','accountantClients'));
        }
    // } catch (\Throwable $e) {
    //     return redirect()->back()->with('error', __('Something went wrong.'));
    // }
    }   

    public function accesdenied(){
        try {
            return view('access-denied');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function viewSubscription(Request $request){

        $thisMonthInvoices = Invoice::whereMonth('issue_date', date('m'))  // Filter by current month
        ->whereYear('issue_date', date('Y'))  // Filter by current year
        ->get();
    
        $thisMonthReceipts = Receipts::whereMonth('created_at', date('m'))  // Filter by current month
        ->whereYear('created_at', date('Y'))  // Filter by current year
        ->get();

        return view('panel.company.subscription-details',compact('thisMonthInvoices','thisMonthReceipts'));
    }


    private function getDashboardSummary($company)
    {
        $year = date('Y');
        $targetCurrency =getCurrency();


        $annualInvoice = Invoice::whereYear('issue_date', $year)
                        ->whereIn('status', [1, 2, 4])
                        ->selectRaw('SUM(grandTotal) as total, SUM(totalTax) as tax')
                        ->first();

        $annualTickets = Receipts::whereYear('created_at', $year)
                        ->selectRaw('SUM(grandTotal) as total, SUM(totalTax) as tax')
                        ->first();

        $annualRevenueTotal = ($annualInvoice->total ?? 0) + ($annualTickets->total ?? 0);
        $annualRevenueTax   = ($annualInvoice->tax   ?? 0) + ($annualTickets->tax   ?? 0);

        $pendingProposals = Performa::where('status', 'accepted')
            ->sum('grandTotal');

        $invoiceTicketChart = $this->getInvoiceTicketChart();
        $invoiceTicketDatasets = [
            [
                'label' => __('Invoice Total'),
                'data' => $invoiceTicketChart['invoiceTotal'],
                'bootstrapColor' => 'secondary',
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ],
            [
                'label' => __('Ticket Total'),
                'data' => ($invoiceTicketChart['ticketTotal']),
                'bootstrapColor' => 'success',
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ]
        ];
        return [
            'year'              => $year,
            'annualRevenue' => [
                'total' => round($annualRevenueTotal, 2),
                'tax'   => round($annualRevenueTax, 2),
            ],
            'annualInvoice'     => $annualInvoice,
            'annualTickets'     => $annualTickets,
            'pendingProposals'  => $pendingProposals,
            'invoiceTicketChart'  => $this->getInvoiceTicketChart(),
            'proposalChart'  => $this->getProposalChart(),
            'incomeDistribution'  => $this->getAnnualIncomeDistribution(),
            'topInvoiceClients'  => $this->getTopInvoiceClients(),
            'topTicketClients'  => $this->getTopTicketClients(),
            'pendingInvoices'  => $this->getPendingInvoices(),
            'pendingProposals'  => $this->getPendingProposals(),
            'annualDocuments'  => $this->getAnnualDocumentStats(),
            'netWorthChart'  => $this->getNetWorthChart(),
        ];


    }

    private function getInvoiceTicketChart()
    {
        $year = date('Y');

        // Base months
        // $months = [];
        // for ($m = 1; $m <= 12; $m++) {
        //     $months[] = date('M', mktime(0, 0, 0, $m, 1)); // Jan, Feb, Mar...
        // }

        Carbon::setLocale(app()->getLocale());

        $months = [];
        for ($m = 1; $m <= 12; $m++) {
            $months[] = Carbon::create()->month($m)->translatedFormat('M');
        }

        $invoiceTotal = $invoiceTax = array_fill(0, 12, 0);
        $ticketTotal  = $ticketTax  = array_fill(0, 12, 0);

        // Monthly invoices
        $invoices = Invoice::whereYear('issue_date', $year)
            ->whereIn('status', [1, 2, 4])
            ->select('grandTotal', 'totalTax', 'issue_date')
            ->get();

        foreach ($invoices as $invoice) {
            $i = date('n', strtotime($invoice->issue_date)) - 1;
            $invoiceTotal[$i] += parseNumber($invoice->grandTotal);
            $invoiceTax[$i]   += parseNumber($invoice->totalTax);
        }

        // Monthly tickets
        $tickets = Receipts::whereYear('created_at', $year)
            ->select('grandTotal', 'totalTax', 'created_at')
            ->get();

        foreach ($tickets as $ticket) {
            $i = date('n', strtotime($ticket->created_at)) - 1;
            $ticketTotal[$i] += parseNumber($ticket->grandTotal);
            $ticketTax[$i]   += parseNumber($ticket->totalTax);
        }

        $invoiceTicketDatasets = [
            [
                'label' => __('Invoice Total'),
                'data' => $invoiceTotal,
                'bootstrapColor' => 'secondary',
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ],
            [
                'label' => __('Ticket Total'),
                'data' => $ticketTotal,
                'bootstrapColor' => 'danger',
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ]
        ];
        return [
            'months'       => $months,
            'invoiceTotal' => $invoiceTotal,
            'invoiceTax'   => $invoiceTax,
            'ticketTotal'  => $ticketTotal,
            'ticketTax'    => $ticketTax,
            'datatsets'    => $invoiceTicketDatasets,
        ];
    }

    private function getProposalChart()
    {
        $year = date('Y');

        // Short month names
        // $months = [];
        // for ($m = 1; $m <= 12; $m++) {
        //     $months[] = date('M', mktime(0, 0, 0, $m, 1)); // Jan, Feb, ...
        // }

        Carbon::setLocale(app()->getLocale());

        $months = [];
        for ($m = 1; $m <= 12; $m++) {
            $months[] = Carbon::create()->month($m)->translatedFormat('M');
        }

        $accepted = $pending = $rejected = array_fill(0, 12, 0);

        // Fetch Proformas / Proposals
        $proposals = Performa::whereYear('created_at', $year)
            ->select('status', 'grandTotal', 'created_at')
            ->get();
            
        foreach ($proposals as $p) {

            $i = date('n', strtotime($p->created_at)) - 1;

            switch ($p->status) {
                case 'accepted':
                    $accepted[$i] += parseNumber($p->grandTotal);
                    break;

                case 'sent':
                    $pending[$i] += parseNumber($p->grandTotal);
                    break;

                case 'draft':
                    $rejected[$i] += parseNumber($p->grandTotal);
                    break;
            }
        }

        // ------------------------------
        //  PREPARE DATASETS FOR CHARTJS
        // ------------------------------
        $datasets = [
            [
                'label' => __('Accepted'),
                'data' => $accepted,
                'bootstrapColor' => 'secondary',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ],
            [
                'label' => __('Pending'),
                'data' => $pending,
                'bootstrapColor' => 'success',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ],
            [
                'label' => __('Rejected'),
                'data' => $rejected,
                'bootstrapColor' => 'danger',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true,
            ]
        ];
        
        return [
            'months'   => $months,
            'accepted' => $accepted,
            'pending'  => $pending,
            'rejected' => $rejected,
            'datasets' => $datasets,
        ];
    }


    private function getAnnualIncomeDistribution()
    {
        $year = date('Y');

        $invoice = Invoice::whereYear('issue_date', $year)
            ->whereIn('status', [2,4])
            ->sum('grandTotal');

        $tickets = Receipts::whereYear('created_at', $year)
            ->sum('grandTotal');

        $labels = [__('Invoice Income'), __('Ticket Income')];

        $data = [
            (float) $invoice,
            (float) $tickets
        ];

        // Dataset ready for <x-chartjs> component
        $datasets = [
            [
                'data' => $data,
                'bootstrapColor' => [
                    'secondary', // blue
                    'danger'  // orange
                ],
                'borderColor' => [
                    'secondary',
                    'danger'
                ],
                'borderWidth' => 1
            ]
        ];

        return [
            'labels'   => $labels,
            'data'     => $data,
            'datasets' => $datasets  // ⭐ ChartJS-ready
        ];
    }


    private function getTopInvoiceClients($limit = 5)
    {
        $year = date('Y');

        return Invoice::whereYear('issue_date', $year)
                ->whereIn('status', [1, 2, 4])
                ->selectRaw('client_id, COUNT(*) as invoice_count, SUM(grandTotal) as total')
                ->groupBy('client_id')
                ->orderByDesc('total')
                ->limit($limit)
                ->get()
                ->map(function ($row) {
                    $client = Clients::find($row->client_id);

                    return [
                        'client_name' => $client->extra['company_name'] ?? $client->name ?? 'Unknown',
                        'count' => $row->invoice_count,
                        'total' => $row->total
                    ];
                })
                ->toArray();

    }

    private function getTopTicketClients($limit = 5)
    {
        $year = date('Y');

        return Receipts::whereYear('created_at', $year)
                ->selectRaw('client_id, COUNT(*) as receipt_count, SUM(grandTotal) as total')
                ->groupBy('client_id')
                ->orderByDesc('total')
                ->limit($limit)
                ->get()
                ->map(function ($row) {
                    $client = Clients::find($row->client_id);

                    return [
                        'client_name' => $client->extra['company_name'] ?? $client->name ?? 'Unknown',
                        'count' => $row->receipt_count,   // FIXED
                        'total' => $row->total
                    ];
                })
                ->toArray();

    }

    private function getPendingInvoices($limit = 5)
    {
        return Invoice::with('client')->where('status', 0) // status 1 = pending
            ->orderBy('issue_date', 'DESC')
            ->limit($limit)
            ->get();
    }

    private function getPendingProposals($limit = 5)
    {
        return Performa::with('client')->where('status', 'draft')
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }

    private function getAnnualDocumentStats()
    {
        $year = date('Y');
        
        return [
            'facturas' => Invoice::whereYear('issue_date', $year)
                            ->whereStatus('2') // finalized invoices
                            ->count(),
            // 'albaranes' => Albaran::whereYear('created_at', $year)->count(),
            'presupuestos' => Performa::whereYear('created_at', $year)->count(),
            // 'proformas' => Proforma::whereYear('created_at', $year)->count(),
        ];
    }


    private function getNetWorthChart()
    {
        $results = [
            'months' => [],
            'invoice' => [],
            'expense' => [],
            'networth' => [],
        ];

        for ($i = 5; $i >= 0; $i--) {

            $month = now()->subMonths($i);

            $monthName = $month->format('M'); // ✔ short month
            $year = $month->format('Y');
            $monthNum = $month->format('m');

            // Income: Invoices (status 2 or 4)
            $invoiceTotal = Invoice::whereYear('issue_date', $year)
                ->whereMonth('issue_date', $monthNum)
                ->whereIn('status', [1, 2, 4])
                ->sum('grandTotal');

            // Expenses (disabled for now)
            $expenseTotal = 0;

            // Net Worth
            $netWorth = $invoiceTotal - $expenseTotal;

            $results['months'][]   = $monthName;
            $results['invoice'][]  = (float) $invoiceTotal;
            $results['expense'][]  = (float) $expenseTotal;
            $results['networth'][] = (float) $netWorth;
        }

        // ------------------------------
        //   CHARTJS DATASETS SECTION
        // ------------------------------
        $datasets = [
            [
                'label' => 'Net Worth',
                'data' => $results['networth'],
                'bootstrapColor' => 'secondary',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true
            ],
            [
                'label' => 'Income',
                'data' => $results['invoice'],
                'bootstrapColor' => 'success',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true
            ],
            [
                'label' => 'Expenses',
                'data' => $results['expense'],
                'bootstrapColor' => 'danger',
                'gradient' => true,
                'borderWidth' => 2,
                'tension' => 0.4,
                'fill' => true
            ]
        ];

        // Add datasets to result
        $results['datasets'] = $datasets;

        return $results;
    }




}
