<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TaxRules;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class TaxRulesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function indexTaxRules(Request $request){
        try{
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;
            $role = $user->roles->pluck('id')->first();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            //    dd($formdata);
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = TaxRules::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                // dd($formdata);
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                    $q->orWhere('value', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['type']) && !empty($formdata['type'])) {
                $query->where('type', $formdata['type']); // Assuming `scope` is a column in the `users` table
            }   

        
            // Fetch paginated results with related data
            $taxRules = $query->orderBy('id','DESC')->paginate($limit);
            // $TaxRules = TaxRules::paginate(10);
            
            if ($request->ajax()) {
                return view('panel.taxRules.partial_data', compact('taxRules'))->render();
            }

            return view('panel.taxRules.index-tax-rules', compact('taxRules'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function editTaxRules($id){
        try{
            $taxRule = TaxRules::find($id);
            return view('panel.taxRules.edit-rule',compact('taxRule'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addTaxRules(){
        try{
            return view('panel.taxRules.add-rule');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
    public function addOrEditTaxRules(Request $request){
        
        try {
            // Extract form data
            $formdata = $request->all();
            // $service_id = $formdata['id'] ?? null;
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $tax_rule_id = $formdata['id'] ?? null;
            $dynamicTableName = (new TaxRules())->getTable();
            // dd($service_id);
            // Validation rules
            $rules = [
                'name' => [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('tax_rules', 'name')
                        ->where(function ($query) use ($request) {
                            return $query->where('tax_type', $request->type);
                        })
                        ->ignore($tax_rule_id),
                ],

                'value'=>'required',
                'type'=>'required'
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // dd($formdata);
            

            $tax_rule_data = [
                'name'=> $formdata['name'],
                'value'=>parseNumber($formdata['value']),
                'type'=>$formdata['type'],
                'tax_type'=>$formdata['tax_type'],
                'RE_value'=>parseNumber($formdata['RE_value']),
                'extra'=>$formdata['extra'] ?? null,
            ];
            


            if (!empty($tax_rule_id)) {
                $taxRuleData = TaxRules::where('id',$tax_rule_id)->first();
                TaxRules::where('id', $tax_rule_id)->update($tax_rule_data);
                $taxRule = TaxRules::where('id',$tax_rule_id)->first();
            } else {
                $taxRule = TaxRules::create($tax_rule_data);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Tax Rule updated successfully.') 
                    : __('Tax Rule created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditTaxRule: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function deleteTaxRules($id){
        try {
            TaxRules::destroy($id);
            return response()->json(['success'=>true,'message' => 'Tax Rule deleted successfully']);
        }
        catch (\Exception $e) {
            return response()->json([
                'success' => false, 
                'message' => __('Something went wrong.')
            ], 500);
        }
    }

    public function updateStatus(Request $request, $id){
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;
 
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
    
            $issue = TaxRules::findOrFail($id);
            $issue->status = $request->status;
            $issue->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Tax rule status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating tax rule status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
}
