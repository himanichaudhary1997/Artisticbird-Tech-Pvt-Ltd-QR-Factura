<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SubUser;
use App\Models\User;
use App\Models\Menu;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Company;
use Illuminate\Support\Str;
use App\Models\SubscriptionPlans;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Permission;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use App\Jobs\SubscriptionReminderJob;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Rules\UniqueInAllUsers;
use Auth;
use Illuminate\Support\Facades\DB;
use App\Models\CompanyUsers;
use App\Models\ClientAccountantRelation;
use App\Models\Clients;
use GuzzleHttp\Client;

class SubUserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function indexAccountant(Request $request){ 
    try{
        $companies = [];
        $user = auth()->user();
        $query = User::Query();
        $company = $user->company;

        // dd($company);
        if (empty($company)) {
            $query->whereHas('roles', function ($q) {
                $q->where('name', 'Accountant');
            });
        } else {
            $companyAdminId = $user->company->admin_id ?? null;
            if ($companyAdminId) {
                $query->whereHas('roles', function ($q) {
                    $q->where('name', 'CompanyAccountant');
                })->whereHas('companyUsers', function ($q) use ($companyAdminId) {
                    $q->where('admin_id', $companyAdminId);
                });
            }
        }
        if ($request->has('sort') && !is_null($request->sort)) {
            $query->where('status', $request->sort);
        }

        if ($request->has('search') && !empty($request->search)) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                    ->orWhere('email', 'like', "%{$request->search}%")
                    ->orWhere('phone', 'like', "%{$request->search}%");
            });
        }
        $users = $query->paginate(15);
        if ($request->ajax()) {
            return view('panel.sub-users.accountant_partial_data', compact('users'))->render();
        }
        return view('panel.sub-users.accountant-users-index',compact('users', 'companies'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function getAccountants(Request $request)
    {
        try {
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            // $subUser = new User();
            // $subUser = $subUser->setDynamicTableName($user->company->id);
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = User::where('id', '!=', $user->id)
            ->whereHas('roles', function ($query) {
                $query->where('id', 4); // Filter by role ID 4 (Accountant)
            });

            if (!empty($company)) {
                $query->whereHas('companyUsers', function ($query) use ($company) {
                    // Get users who exist in the company_users table for the given company
                    $query->where('company_id', $company->id);
                });
            } else {
                $query->whereDoesntHave('companyUsers'); // Get users who are NOT in the company_users table
            }
            

            if(isset($formdata['company_id']) && !empty($formdata['company_id'])){
                $query->whereHas('companyUsers', function ($query) use ($formdata) {
                    // Filter based on company_users table where user_id matches and company_id is the logged-in user's company_id
                    $query->where('company_id', $formdata['company_id']);
                });
            }

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            if(isset($formdata['plan_id']) && !is_null($formdata['plan_id'])){
                $query->whereHas('subscriptionDetails', function ($query) use ($formdata) {
                    $query->where('subscription_id', $formdata['plan_id']);
                });
            }

            // Fetch paginated results with related data
            $users = $query->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Users retrieved successfully.',
                'data' => $users,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function addAccountant(){
        try{
        $user = auth()->user();
        $role = $user->roles->first() ?? null;
        $roles = Role::where('id','!=',$role->id)->get();
        $userPermissions = [];
        $permissions = Permission::where('parent_id', null)->get();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }
        $permissionGroups = [];

        // Organize permissions into parent-child structure
        foreach ($permissions as $permission) {
            // Fetch child permissions for the parent
            $childPermissions = Permission::where('parent_id', $permission->id)->get();

            // Filter out permissions not assigned to the user
            $userChildPermissions = $childPermissions->filter(function ($child) use ($user) {
                return $user->hasPermissionTo($child->name);
            });

            if ($user->hasPermissionTo($permission->name) || $userChildPermissions->isNotEmpty()) {
                $permissionGroups[] = [
                    'id' => $permission->id,
                    'name' => $permission->name, // Parent permission name
                    'child' => $userChildPermissions->map(function ($child) {
                        return [
                            'id' => $child->id,
                            'name' => $child->name,
                        ];
                    })->toArray(), // Only child permissions assigned to the user
                ];
            }
        }
        if(!empty($company)){
            $clients = Clients::get();
        }else{
            $clients = User::whereHas('roles', function ($query) {
                $query->where('id', 2); // Accountant role ID
            })->get();
        }
        $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
            ->pluck('client_id')
            ->toArray();
        $country = CountryModel::all();
        $states = StateModel::all();
        return view('panel.sub-users.add-edit-accountant',compact('country','userPermissions','states','permissionGroups','permissions','currentAccountantClients','clients'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function editAccountant($id){
        try{
        $authuser = auth()->user();
        $user = User::where('id',$id)->first();
        $role = $user->roles->first() ?? null;
        $roles = Role::where('id','!=',$role->id)->get();
        $userPermissions = $user->getAllPermissions()->pluck('name')->toArray();
        $permissions = Permission::where('parent_id', null)->get();
        $company = $authuser->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }
        $permissionGroups = [];

        // Organize permissions into parent-child structure
        // Organize permissions into parent-child structure
        foreach ($permissions as $permission) {
            // Check if the parent permission is assigned to the user
            $isParentAssigned = $authuser->hasPermissionTo($permission->name);
        
            if (!$isParentAssigned) {
                continue; // Skip if the parent permission isn't assigned
            }
        
            // Fetch child permissions for the parent
            $childPermissions = Permission::where('parent_id', $permission->id)->get();
        
            if ($childPermissions->isEmpty()) {
                // If no child permissions exist, only include the parent
                $permissionGroups[] = [
                    'id' => $permission->id,
                    'name' => $permission->name,
                    'child' => [],
                ];
                continue;
            }
        
            // Filter child permissions assigned to the user
            $userChildPermissions = $childPermissions->filter(function ($child) use ($authuser) {
                return $authuser->hasPermissionTo($child->name);
            });
        
            if ($userChildPermissions->isEmpty()) {
                // If no specific child permissions are assigned, include all child permissions
                $permissionGroups[] = [
                    'id' => $permission->id,
                    'name' => $permission->name,
                    'child' => $childPermissions->map(function ($child) {
                        return [
                            'id' => $child->id,
                            'name' => $child->name,
                        ];
                    })->toArray(),
                ];
            } else {
                // Include only the assigned child permissions
                $permissionGroups[] = [
                    'id' => $permission->id,
                    'name' => $permission->name,
                    'child' => $userChildPermissions->map(function ($child) {
                        return [
                            'id' => $child->id,
                            'name' => $child->name,
                        ];
                    })->toArray(),
                ];
            }
        }

        if(!empty($company)){
            $clients = Clients::get();
            $admin_id = $company->admin_id;
        }else{
            $clients = User::whereHas('roles', function ($query) {
                $query->where('id', 2); // Accountant role ID
            })->get();
            $admin_id = 1;
        }
        // dd($company);
        $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
            ->pluck('client_id')
            ->toArray();
            // dd($currentAccountantClients);
        $country = CountryModel::all();
        $states = StateModel::all();
        return view('panel.sub-users.add-edit-accountant',compact('user','country','states','permissionGroups','userPermissions','currentAccountantClients','clients'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', $e->getMessage() . $e->getLine() . $e->getFile());
    }
    }

    public function deleteUser($id)
    {
        try {
            // Attempt to delete the user by ID
            User::destroy($id);
            CompanyUsers::where('user_id',$id)->delete();
            // Company::where('admin_id',$id)->delete();
            // UserSubscriptions::where('user_id',$id)->delete();

            // Return success response
            return response()->json(['success' => true, 'message' => __('User deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete user. Please try again.')], 500);
        }
    }


    public function deleteAccountantRelation($id){
        try {
            $authuser = auth()->user();
            $company = $authuser->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            if(empty($company)){
                $adminUser = User::where('id',1)->first();
            }

            $accountant = User::where('id',$id)->first();

            if(!empty($company)){
                CompanyUsers::where('user_id',$id)->where('admin_id',$company->admin_id ?? 1)->delete();
            }else{
                CompanyUsers::where('user_id',$id)->where('admin_id',$adminUser->id)->delete();
                $accountant->removeRole('Accountant');
            }

            return response()->json(['success' => true, 'message' => __('User deleted successfully')], 200);

        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete user. Please try again.')], 200);
        }
    }
    

    public function addOrEditAccountant(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            $userId = $formdata['id'] ?? null;
            $authuser = auth()->user();
            $company = $authuser->company;

            // dd($company);
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }


            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => [
                    'required',
                    'email',
                    function ($attribute, $value, $fail) {
                        $allowedRoles = ['Accountant', 'CompanyAccountant']; // Allowed roles
                        $existingUsers = User::where('email', $value)->get();

                        foreach ($existingUsers as $user) {
                            $userRoles = $user->getRoleNames()->toArray(); // Get assigned roles
                            // dd($userRoles);
                            if (empty(array_intersect($userRoles, $allowedRoles))) {
                                return $fail('The email is already exist.');
                            }
                        }
                    },
                ],
                'phone' => 'nullable|numeric|digits_between:8,15',
                
                // 'role' => 'required|string|in:Staff,Accountant',
            ];

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            

            $alreadyUser = User::find($userId);

            // Decode the existing 'extra' JSON or set an empty array if null
            $existingExtra = $alreadyUser ? $alreadyUser->extra ?? [] : [];

            // Get new 'extra' values from formdata
            $newExtra = $formdata['extra'] ?? [];

            // Merge existing extra fields with new data (only add or update fields)
            $mergedExtra = array_merge($existingExtra, $newExtra);
            // Prepare user data
            $user_data = [
                'name' => $formdata['name'],
                'email' => $formdata['email'],
                'phone' => $formdata['phone'] ?? null,
                'extra' => $mergedExtra,
            ];

            // If updating an existing user
            if (!empty($userId)) {
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);

                CompanyUsers::firstOrCreate([
                    'user_id' => $user->id,
                    'admin_id' => $company->admin_id ?? 1
                ]);
            } else {
                // Creating a new user
                $user_data['email_verified_at'] = now();
                $user_data['is_email_verified'] = true;
                $user_data['password'] = Hash::make(Str::random(12));

                $uniqueAccountantUser = User::where('email',$formdata['email'])->first();
                if(empty($uniqueAccountantUser)){
                    $user = User::create($user_data);
                    // $user->assignRole('Company_'.$formdata['role']);
                
                    if (!empty($company)) {
                        $user->assignRole('CompanyAccountant');
                    }else{
                        $user->assignRole('Accountant');
                    }
    
                    CompanyUsers::firstOrCreate([
                        'user_id' => $user->id,
                        'admin_id' => $company->admin_id ?? 1
                    ]);
                }else{
                    if (!empty($company)) {
                        if (!$uniqueAccountantUser->hasRole('CompanyAccountant')) {
                            $uniqueAccountantUser->assignRole('CompanyAccountant');
                        }
                    } else {
                        if (!$uniqueAccountantUser->hasRole('Accountant')) {
                            $uniqueAccountantUser->assignRole('Accountant');
                        }
                    }
                    $user = $uniqueAccountantUser;
                    CompanyUsers::firstOrCreate([
                        'user_id' => $uniqueAccountantUser->id,
                        'admin_id' => $company->admin_id ?? 1
                    ]);
                }
            }

            if(!empty($company)){
                $admin_id = $company->admin_id;
            }else{
                $admin_id = 1;
            }


            $existingRelations = ClientAccountantRelation::where('accountant_id', $user->id)->pluck('client_id')->toArray();

            // dd($existingRelations);
            $newClientIds = isset($formdata['client_ids']) ? $formdata['client_ids'] : [];

            // Find accountants that need to be removed (present in DB but not in the new request)
            $toBeRemoved = array_diff($existingRelations, $newClientIds);
            if (!empty($toBeRemoved)) {
                ClientAccountantRelation::where('accountant_id', $user->id)
                    ->whereIn('client_id', $toBeRemoved)
                    ->delete();
            }

            // Find accountants that need to be added (present in new request but not in DB)
            $toBeAdded = array_diff($newClientIds, $existingRelations);
            foreach ($toBeAdded as $accountant_id) {
                ClientAccountantRelation::create([
                    'client_id' => $accountant_id,
                    'accountant_id' =>$user->id 
                ]);
            }

            if(!empty($uniqueAccountantUser)){
                return response()->json([
                    'success' => true,
                    'message' => __('This Accountant user is already exist. Now it is assigned to you.') 
                ], 200);
            }else{
                return response()->json([
                    'success' => true,
                    'message' => isset($formdata['id']) 
                        ? __('User updated successfully.') 
                        : __('User created successfully.')
                ], 200);
            }
        } catch (\Exception $e) {
            Log::error('Error in addOrEditSubUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ], 500);
        }
    }


    


    public function sendDetails(Request $request)
    {
        try {
            // Validate the request data
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);
            $user_model = new User();
            $user = User::find($validated['user_id']);
            $newPassword = $user_model->generateRandomPassword(); // Generate a random temporary password
            $user->password = Hash::make($newPassword); // Hash the new password
            $user->save();
            // dd($password);

            $subject = "Please check your login details";
            $view = 'emails.send-details'; // View file path without .blade.php
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'password' => $newPassword,
            ];

            Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));

            // Return success response
            return response()->json(['success' => true, 'message' => __('Details sent successfully.')], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation errors
            return response()->json(['success' => false, 'message' => $e->getMessage()], 200);
        }
    }


    public function indexStaff(Request $request)
    {
        try {
            $companies = [];
            $user = auth()->user();
            $query = User::Query();
            $company = $user->company;
            if (empty($company)) {
                $query->whereHas('roles', function ($q) {
                    $q->whereIn('name', ['Staff', 'Support']);
                });

                $query->where('id','!=',$user->id);
            } else {
                $companyAdminId = $user->company->admin_id ?? null;
                if ($companyAdminId) {
                    $query->whereHas('roles', function ($q) {
                        $q->where('name', 'CompanyStaff');
                    })->whereHas('companyUsers', function ($q) use ($companyAdminId) {
                        $q->where('admin_id', $companyAdminId);
                    });
                }
                $query->where('id','!=',$user->id);
            }


            if ($request->has('sort') && !is_null($request->sort)) {
                $query->where('status', $request->sort);
            }

            if ($request->has('search') && !empty($request->search)) {
                $query->where(function ($q) use ($request) {
                    $q->where('name', 'like', "%{$request->search}%")
                        ->orWhere('email', 'like', "%{$request->search}%")
                        ->orWhere('phone', 'like', "%{$request->search}%");
                });
            }
            $users = $query->orderBy('id','desc')->paginate(15);

            if ($request->ajax()) {
                return view('panel.sub-users.staff_partial_data', compact('users'))->render();
            }

            return view('panel.sub-users.staff-users-index', compact('users', 'companies'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function getStaff(Request $request)
    {
        try {
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            // $subUser = new User();
            // $subUser = $subUser->setDynamicTableName($user->company->id);
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = User::where('id', '!=', $user->id)
                ->whereHas('roles', function ($query) {
                    $query->where('id', 3); // Filter by role ID 3 (Staff)
                });

            if(!empty($company)){
                $query->whereHas('companyUsers', function ($query) use ($company) {
                    // Filter based on company_users table where user_id matches and company_id is the logged-in user's company_id
                    $query->where('company_id', $company->id);
                });
            }else{
                $query->whereDoesntHave('companyUsers'); // Get users who are NOT in the company_users table
            }

            
            if(isset($formdata['company_id']) && !empty($formdata['company_id'])){
                $query->whereHas('companyUsers', function ($query) use ($formdata) {
                    // Filter based on company_users table where user_id matches and company_id is the logged-in user's company_id
                    $query->where('company_id', $formdata['company_id']);
                });
            }

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            if(isset($formdata['plan_id']) && !is_null($formdata['plan_id'])){
                $query->whereHas('subscriptionDetails', function ($query) use ($formdata) {
                    $query->where('subscription_id', $formdata['plan_id']);
                });
            }

            // Fetch paginated results with related data
            $users = $query->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Users retrieved successfully.',
                'data' => $users,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function addStaff(){
    try {
        $authUser = auth()->user();
        $role = $authUser->roles->first() ?? null;
        //$roles = Role::where('id','!=',$role->id)->get();
        $roles = Role::whereIn('name', ['Staff', 'Accountant','Support'])->get();
        $userPermissions = [];
        $permissions = Permission::where('parent_id', null)->get();
        $userRoles = [];
        $permissionGroups = [];

        // Organize permissions into parent-child structure
        foreach ($permissions as $permission) {
            // Fetch child permissions for the parent
            $childPermissions = Permission::where('parent_id', $permission->id)->get();

            // Filter out permissions not assigned to the user
            $userChildPermissions = $childPermissions->filter(function ($child) use ($authUser) {
                return $authUser->hasPermissionTo($child->name);
            });

            if ($authUser->hasPermissionTo($permission->name) || $userChildPermissions->isNotEmpty()) {
                $permissionGroups[] = [
                    'id' => $permission->id,
                    'name' => $permission->name, // Parent permission name
                    'child' => $userChildPermissions->map(function ($child) {
                        return [
                            'id' => $child->id,
                            'name' => $child->name,
                        ];
                    })->toArray(), // Only child permissions assigned to the user
                ];
            }
        }

        $country = CountryModel::all();
        $states = StateModel::all();


        
        return view('panel.sub-users.add-edit-staff',compact('country','states','permissionGroups','permissions','userPermissions','roles','userRoles'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function editStaff($id)
    {
        try {
            $authuser = auth()->user();
            $user = User::where('id',$id)->first();
            $role = $authuser->roles->first() ?? null;
            //$roles = Role::where('id','!=',$role->id)->get();
            $roles = Role::whereIn('name', ['Staff', 'Accountant','Support'])->get();

            $userPermissions = $user->getAllPermissions()->pluck('name')->toArray();
            $permissions = Permission::where('parent_id', null)->get();
            $company = $authuser->company;
            $userRoles = $user->roles->pluck('name')->toArray();
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $permissionGroups = [];

            // Organize permissions into parent-child structure
            // Organize permissions into parent-child structure
            foreach ($permissions as $permission) {
                // Check if the parent permission is assigned to the user
                $isParentAssigned = $authuser->hasPermissionTo($permission->name);
            
                if (!$isParentAssigned) {
                    continue; // Skip if the parent permission isn't assigned
                }
            
                // Fetch child permissions for the parent
                $childPermissions = Permission::where('parent_id', $permission->id)->get();
            
                if ($childPermissions->isEmpty()) {
                    // If no child permissions exist, only include the parent
                    $permissionGroups[] = [
                        'id' => $permission->id,
                        'name' => $permission->name,
                        'child' => [],
                    ];
                    continue;
                }
            
                // Filter child permissions assigned to the user
                $userChildPermissions = $childPermissions->filter(function ($child) use ($authuser) {
                    return $authuser->hasPermissionTo($child->name);
                });
            
                if ($userChildPermissions->isEmpty()) {
                    // If no specific child permissions are assigned, include all child permissions
                    $permissionGroups[] = [
                        'id' => $permission->id,
                        'name' => $permission->name,
                        'child' => $childPermissions->map(function ($child) {
                            return [
                                'id' => $child->id,
                                'name' => $child->name,
                            ];
                        })->toArray(),
                    ];
                } else {
                    // Include only the assigned child permissions
                    $permissionGroups[] = [
                        'id' => $permission->id,
                        'name' => $permission->name,
                        'child' => $userChildPermissions->map(function ($child) {
                            return [
                                'id' => $child->id,
                                'name' => $child->name,
                            ];
                        })->toArray(),
                    ];
                }
            }

            if(!empty($company)){
                $clients = Clients::get();
            }else{
                $clients = User::whereHas('roles', function ($query) {
                    $query->where('id', 2); // Accountant role ID
                })->get();
            }
            // dd($company);
            $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
                ->pluck('client_id')
                ->toArray();
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.sub-users.add-edit-staff',compact('user','country','states','permissionGroups','userPermissions','currentAccountantClients','clients','roles','userRoles'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditStaff(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            $userId = $formdata['id'] ?? null;
            $authuser = auth()->user();
            $company = $authuser->company;

            // dd($company);
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }


            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $userId . ',id',
                'phone' => 'nullable|numeric|digits_between:8,15',
                // 'role' => 'required|string|in:Staff,Accountant',
            ];
            

            if(empty($company)){
                $rules['roles']='required|array';
            }

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $alreadyUser = User::find($userId);

            // Decode the existing 'extra' JSON or set an empty array if null
            $existingExtra = $alreadyUser ? $alreadyUser->extra ?? [] : [];

            // Get new 'extra' values from formdata
            $newExtra = $formdata['extra'] ?? [];

            // Merge existing extra fields with new data (only add or update fields)
            $mergedExtra = array_merge($existingExtra, $newExtra);
            // Prepare user data
            $user_data = [
                'name' => $formdata['name'],
                'email' => $formdata['email'],
                'phone' => $formdata['phone'] ?? null,
                'extra' => $mergedExtra,
            ];

            // If updating an existing user
            if (!empty($userId)) {
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                if(empty($company)){
                    $user->syncRoles($formdata['roles']);

                }
            } else {
                // Creating a new user
                $user_data['email_verified_at'] = now();
                $user_data['is_email_verified'] = true;
                $user_data['password'] = Hash::make(Str::random(12));

                $user = User::create($user_data);
                // $user->assignRole('Company_'.$formdata['role']);
            
                if (!empty($company)) {
                    $user->assignRole('CompanyStaff');
                }else{
                    $user->assignRole($formdata['roles']);

                }

                CompanyUsers::create([
                    'user_id' => $user->id,
                    'admin_id' => $company->admin_id ?? 1
                ]);
            }

            if ($user) {
                if (!empty($formdata['permission'])) {
                    // Get or create permissions from the provided array
                    $permissions = collect($formdata['permission'])->map(function ($permissionName) {
                        return Permission::firstOrCreate(['name' => $permissionName])->id; // Ensure permission exists and get its ID
                    });
            
                    // Synchronize user's permissions: assign only the current permissions
                    $user->syncPermissions($permissions);
                } else {
                    // If no permissions are provided, remove all permissions
                    $user->syncPermissions([]);
                }
            }
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('User updated successfully.') 
                    : __('User created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Log error for debugging
            Log::error('Error in addOrEditSubUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ], 500);
        }
    }





    public function indexCompanyAdmins(Request $request)
    {
        try {
                $companies = [];
                $user = auth()->user();
                $query = User::Query();
                $company = $user->company;
                
                // Determine the role name of the logged-in user
                $roleName = $user->roles->pluck('name')->first();

                // if ($roleName === 'Company') {
                //     // If user is Company (owner), show all CompanyAdmins related to them
                //     $query->whereHas('roles', function ($q) {
                //         $q->where('name', 'CompanyAdmin');
                //     })->whereHas('companyUsers', function ($q) use ($company) {
                //         $q->where('admin_id', $company->user->id);
                //     });

                // } elseif ($roleName === 'CompanyAdmin') {
                    $companyAdminId = $company->admin_id ?? null;

                    $query->where(function ($q) use ($companyAdminId, $company) {
                        // Fetch other CompanyAdmins in the same company
                        $q->where(function ($inner) use ($company) {
                            $inner->whereHas('roles', function ($r) {
                                $r->where('name', 'CompanyAdmin');
                            })->whereHas('companyUsers', function ($cu) use ($company) {
                                $cu->where('admin_id', $company->user->id);
                            });
                        });
                        // dd($companyAdminId);

                        // Also fetch the Company (owner)
                        if ($companyAdminId) {
                            $q->orWhere(function ($inner) use ($companyAdminId) {
                                $inner->whereHas('roles', function ($r) {
                                    $r->where('name', 'Company');
                                })->where('id', $companyAdminId);
                            });
                        }
                    });
                // }

                // $query->where('id','!=',$user->id);


                if ($request->has('sort') && !is_null($request->sort)) {
                    $query->where('status', $request->sort);
                }

                if ($request->has('search') && !empty($request->search)) {
                    $query->where(function ($q) use ($request) {
                        $q->where('name', 'like', "%{$request->search}%")
                            ->orWhere('email', 'like', "%{$request->search}%")
                            ->orWhere('phone', 'like', "%{$request->search}%");
                    });
                }
                $users = $query->orderBy('id','DESC')->paginate(15);

                if ($request->ajax()) {
                    return view('panel.company-admins.partial_data', compact('users','companyAdminId'))->render();
                }

                return view('panel.company-admins.users-index', compact('users', 'companies','companyAdminId'));
            } catch (\Throwable $e) {
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
        }

    public function getCompanyAdmins(Request $request)
    {
        try {
            $user = auth()->user();
            $role = $user->roles->pluck('id')->first();
            // $subUser = new User();
            // $subUser = $subUser->setDynamicTableName($user->company->id);
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = User::where('id', '!=', $user->id);

            // Handle logic based on role
            if ($roleName === 'Company') {
                // Owner - only show CompanyAdmins from this company
                $query->whereHas('roles', function ($q) {
                    $q->where('name', 'CompanyAdmin');
                })->whereHas('companyUsers', function ($q) use ($company) {
                    $q->where('company_id', $company->id);
                });

            } elseif ($roleName === 'CompanyAdmin') {
                // Partner - show the Company (owner) and other CompanyAdmins of same company

                $query->where(function ($q) use ($company) {
                    $q->where(function ($inner) use ($company) {
                        // Include CompanyAdmin users of same company
                        $inner->whereHas('roles', function ($r) {
                            $r->where('name', 'CompanyAdmin');
                        })->whereHas('companyUsers', function ($cu) use ($company) {
                            $cu->where('company_id', $company->id);
                        });
                    })->orWhere(function ($inner) use ($company) {
                        // Include the owner (Company)
                        $inner->whereHas('roles', function ($r) {
                            $r->where('name', 'Company');
                        })->where('id', $company->admin_id); // Company owner user ID
                    });
                });
            }
            
            if(isset($formdata['company_id']) && !empty($formdata['company_id'])){
                $query->whereHas('companyUsers', function ($query) use ($formdata) {
                    // Filter based on company_users table where user_id matches and company_id is the logged-in user's company_id
                    $query->where('company_id', $formdata['company_id']);
                });
            }

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }


            // Fetch paginated results with related data
            $users = $query->orderBy('id','DESC')->paginate($limit);
            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Users retrieved successfully.',
                'data' => $users,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }



    public function addCompanyAdmins()
    {
        try {
            $authuser = auth()->user();

            $country = CountryModel::all();
            $states = StateModel::all();

            return view('panel.company-admins.add-edit-user', compact('country', 'states'));

        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }



    public function editCompanyAdmins($id)
    {
        try {
            $authuser = auth()->user();
            $user = User::where('id',$id)->first();
            
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.company-admins.add-edit-user',compact('user'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditCompanyAdmins(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();
            $userId = $formdata['id'] ?? null;
            $authuser = auth()->user();
            $company = $authuser->company;

            // dd($company);
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }


            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $userId . ',id',
                'phone' => 'nullable|numeric|digits_between:8,15',
                // 'role' => 'required|string|in:Staff,Accountant',
            ];
            

            if(empty($company)){
                $rules['roles']='required|array';
            }

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Found some errors'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $alreadyUser = User::find($userId);

            // Decode the existing 'extra' JSON or set an empty array if null
            $existingExtra = $alreadyUser ? $alreadyUser->extra ?? [] : [];

            // Get new 'extra' values from formdata
            $newExtra = $formdata['extra'] ?? [];

            // Merge existing extra fields with new data (only add or update fields)
            $mergedExtra = array_merge($existingExtra, $newExtra);
            // Prepare user data
            $user_data = [
                'name' => $formdata['name'],
                'email' => $formdata['email'],
                'phone' => $formdata['phone'] ?? null,
                'extra' => $mergedExtra,
            ];

            // If updating an existing user
            if (!empty($userId)) {
                User::where('id', $userId)->update($user_data);
                $user = User::find($userId);
                if(empty($company)){
                    $user->syncRoles($formdata['roles']);

                }
            } else {
                // Creating a new user
                $user_data['email_verified_at'] = now();
                $user_data['is_email_verified'] = true;
                $user_data['password'] = Hash::make(Str::random(12));

                $user = User::create($user_data);
                // $user->assignRole('Company_'.$formdata['role']);
            
                if (!empty($company)) {
                    $user->assignRole('CompanyAdmin');
                }else{
                    $user->assignRole($formdata['roles']);

                }

                CompanyUsers::create([
                    'user_id' => $user->id,
                    'admin_id' => $company->admin_id ?? 1
                ]);
            }

            if ($user) {
                if (!empty($formdata['permission'])) {
                    // Get or create permissions from the provided array
                    $permissions = collect($formdata['permission'])->map(function ($permissionName) {
                        return Permission::firstOrCreate(['name' => $permissionName])->id; // Ensure permission exists and get its ID
                    });
            
                    // Synchronize user's permissions: assign only the current permissions
                    $user->syncPermissions($permissions);
                } else {
                    // If no permissions are provided, remove all permissions
                    $user->syncPermissions([]);
                }
            }
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('User updated successfully.') 
                    : __('User created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Log error for debugging
            Log::error('Error in addOrEditSubUser: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ], 500);
        }
    }



    public function updateStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
    
            // Find the inventory item
            $inventory = User::findOrFail($id);
            $inventory->status = $request->status;
            $inventory->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('User status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating user status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
    
}
