<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\InvoiceType;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Exception;
use App\Models\ActivityLog;

class InvoiceTypeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    // Function for Crud operation for Invoice Type
    public function indexInvoiceType(Request $request)
    {
        try {

            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = InvoiceType::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            // Fetch paginated results with related data
            $invoiceTypes = $query->orderBy('id', 'DESC')->paginate($limit);
        
            if ($request->ajax()) {
                return view('panel.invoice-type.partial_type', compact('invoiceTypes'))->render();
            }
            // Return JSON response
            return view('panel.invoice-type.index-type',compact('invoiceTypes'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        
    }

    public function statusupdateinvoiceType(Request $request, $id)
    {
       try {
           // Validate the request
           $request->validate([
               'status' => 'required|string'
           ]);
           $user = auth()->user();
           $formdata = $request->all();
           $company = $user->company;

           if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
               // If it's a collection, take the first item
               $company = $company->first();
           }
   
          
            $user = InvoiceType::findOrFail($id);
            $user->status = $request->status;
            $user->save();
          
   
           // Return success response
           return response()->json([
               'success' => true, 
               'message' => __('invoice-type status updated successfully')
           ], 200);
       } catch (\Exception $e) {
           // Log the exception for debugging
           Log::error('Error updating Clients status: ' . $e->getMessage());
   
           // Return error response
           return response()->json([
               'success' => false, 
               'message' => __('Failed to update status. Please try again.')
           ], 500);
       }
    }

    public function editInvoiceType($id)
    {
        try {
            $invoiceType = InvoiceType::where('id', $id)->first();

            return view('panel.invoice-type.edit-type', compact('invoiceType'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addInvoiceType()
    {
        try {
            return view('panel.invoice-type.add-type');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditInvoiceType(Request $request)
    {

        try {
            // Extract form data
            $formdata = $request->all();

            $dynamicTableName = (new InvoiceType())->getTable();

            $invoice_type_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:' . $dynamicTableName . ',name,' . $invoice_type_id,
            ];
            // Validate the input data  


            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $invoice_Data = [
                'name' => $formdata['name'],
                'slug' => str_replace(' ', '-', strtolower($formdata['name'])),

            ];

            if (!empty($invoice_type_id)) {
                $invoiceTypeData = InvoiceType::where('id', $invoice_type_id)->first();
                InvoiceType::where('id', $invoice_type_id)->update($invoice_Data);
                $invoicetype = InvoiceType::where('id', $invoice_type_id)->first();
            } else {
                // Create a new invoicepublic function __construct()

                $invoicetype = InvoiceType::create($invoice_Data);
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Invoice Type updated successfully.')
                    : __('Invoice Type created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoiceType: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function getInvoiceTypes(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = InvoiceType::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            // Fetch paginated results with related data
            $invoiceTypes = $query->orderBy('id', 'DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Invoice type retrieved successfully.',
                'data' => $invoiceTypes,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Invoice type.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function deleteInvoiceType($id)
    {
        try {
            // Attempt to delete the user by ID
            InvoiceType::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Invoice Type deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting Invoice Type: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Invoice type. Please try again.')], 500);
        }
    }
}
