<?php

namespace App\Http\Controllers;

use App\Models\SupCompany;
use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\SuperActiveCompany;
use Illuminate\Support\Facades\Auth;

class SupCompanyController extends Controller
{
    
    public function index(Request $request)
    {
        try {
            $companies = Company::all();
            $user = auth()->user();
            $query = User::Query();
            $company = $user->company;
            
            $query->whereHas('roles', function ($q) {
                $q->whereIn('name', ['SupCompany']);
            });


            if ($request->has('sort') && !is_null($request->sort)) {
                $query->where('status', $request->sort);
            }

            if ($request->has('search') && !empty($request->search)) {
                $query->where(function ($q) use ($request) {
                    $q->where('name', 'like', "%{$request->search}%")
                        ->orWhere('email', 'like', "%{$request->search}%")
                        ->orWhere('phone', 'like', "%{$request->search}%");
                });
            }
            $users = $query->orderBy('id','desc')->paginate(15);

            if ($request->ajax()) {
                return view('panel.sup-company-crud.partial_data', compact('users', 'companies'))->render();
            }
            
            return view('panel.sup-company-crud.index-sup-company', compact('users', 'companies'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __($e->getMessage()));
        }
    }

    public function assignCompany(Request $request)
    {
        $request->validate([
            'company_id' => 'required|exists:companies,id',
            'user_id' => 'required|exists:users,id',
        ]);

        $companyId = $request->company_id;
        $userId = $request->user_id;

        $company = Company::find($companyId);

        if($userId != $company->admin_id && $company->user->hasRole('SupCompany')){
            return redirect()->back()->with('error',__('This company is already assigned to another sup-company user.'));
        }

        if (Company::where('id', $companyId)->where('admin_id',$userId)->exists()) {
            return redirect()->back()->with('error',__('This company is already assigned to this user.'));
        }

        if (SupCompany::where('company_id', $companyId)->where('user_id',$userId)->exists()) {
            return redirect()->back()->with('error',__('This company is already assigned to this user.'));
        }

        if (SupCompany::where('company_id', $companyId)->exists()) {
            return redirect()->back()->with('error',__('This company is already assigned to another sup-company user.'));
        }

        

        $record = SupCompany::create([
            'user_id'    => $userId,
            'company_id' => $companyId,
            'status'     => 'active',
        ]);

        return redirect()->back()->with('success',__('Company Assigned Successfully.'));
    }

    public function removeCompany($userId, $companyId)
    {
        $record = SupCompany::where('user_id', $userId)
            ->where('company_id', $companyId)
            ->first();

        if (!$record) {
            // return response()->json([
            //     'message' => 'This company is not assigned to the user.'
            // ], 404);
            return redirect()->back()->with('error',__('This company is not assigned to the user.'));
        }

        $record->delete();

        return redirect()->back()->with('success',__('Company Removed Successfully.'));
    }

    public function switchCompany($id)
    {
        $user = Auth::user();

        if (!$user->hasRole('SupCompany')) {
            abort(403, 'You are not allowed to switch companies.');
        }

        SuperActiveCompany::updateOrCreate(
            ['user_id' => $user->id],
            ['company_id' => $id]
        );

        return back()->with('success', 'Company switched successfully!');
    }


    public function switchDomain($id)
    {
        if ($id == 0) {
            session()->forget('active_domain_id');
            session()->forget('active_domain');

            return back();
        }

        $apiKey = auth()->user()
            ->company
            ->apikeys()
            ->where('id', $id)
            ->first();

        if (!$apiKey) {
            return back()->with('error', __('Invalid domain selected.'));
        }

        session([
            'active_domain_id' => $apiKey->id,
            'active_domain'    => $apiKey->allowed_url,
        ]);

        return redirect()->route('getInvoices');
    }

}
