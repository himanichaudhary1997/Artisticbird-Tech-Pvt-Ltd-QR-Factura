<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Providers;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;

class ProvidersController extends Controller
{
    // Function for Crud operation for Providers
    public function indexProviders(Request $request)
    {
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $company = $user->company;

            $provider = Providers::where('id',2)->first();

            // $createClient = $this->fiskaly->createClient($provider);
            // dd($createClient);

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

                $query = Providers::query();

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('gst_no', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            

            if(isset($formdata['status'])){
                $query->where('status',$formdata['status']);
            }

            $providers = $query->orderBy('id','Desc')->paginate(15);
            // dd($providers);
            if ($request->ajax()) {
                return view('panel.providers.partial_data', compact('providers'))->render();
            }

            return view('panel.providers.index-provider', compact('providers'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateProviderstatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
    
            // Find the inventory item
           
            $provider = Providers::findOrFail($id);
            $provider->status = $request->status;
            $provider->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Provider status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Providers status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }

    public function getProviders(Request $request)
    {
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Base query excluding the authenticated user and filtering by role ID 2
            if (!empty($company)) {
                $query = Providers::query();

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('mobile_no', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            } else {
                $query = User::where('id', '!=', $user->id)
                    ->whereHas('roles', function ($query) {
                        $query->where('id', 2); // Filter by role ID 2
                    });

                // Apply search filter
                if (isset($formdata['search']) && !empty($formdata['search'])) {
                    $query->where(function ($q) use ($formdata) {
                        $q->where('name', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('email', 'like', '%' . $formdata['search'] . '%')
                            ->orWhere('phone', 'like', '%' . $formdata['search'] . '%');
                    });
                }
            }


            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }



            // Fetch paginated results with related data
            $providers = $query->orderBy('id', 'DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Providers retrieved successfully.',
                'data' => $providers,
                'company' => $company ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve providers.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function addProviders()
    {
        try{
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.providers.add-provider', compact('country', 'states'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editProviders($id)
    {
        try{
            $user = auth()->user();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

            
            $provider = Providers::FindorFail($id);
            // $provider = Providers::FindorFail($id);
            $country = CountryModel::all();
            $states = StateModel::all();
            return view('panel.providers.edit-provider', compact('provider', 'country', 'states'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditProviders(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            // Extract form data
            $formdata = $request->all();

            $client_id = $formdata['id'] ?? null;

            // if (!empty($company)) {
                $dynamicTableName = (new Providers())->getTable();
            // } else {
            //     $dynamicTableName = (new User())->getTable();
            // }

            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'extra.address' => 'required|string|max:255',
                'extra.locality' => 'nullable|string',
                'extra.zip_code' => 'required|string',
                'extra.state_name' => 'nullable|string',
                'extra.country_code' => 'required|string',
                 // GST number as a string
            ];
            // if(!empty($company)){
                $rules['gst_no'] = 'required|string|max:15|unique:'.$dynamicTableName.',gst_no,' . $client_id; 
            // }
            // Validate the input data  
            $messages = [
                'extra.company_name.required' => __('validation.custom.extra.company_name.required'),
                'extra.company_name.string' => __('validation.custom.extra.company_name.string'),
                'extra.company_name.max' => __('validation.custom.extra.company_name.max'),
            ];

            // dd($formdata);
            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
                
            $client_data = [
                'name' => $formdata['name'],
                // 'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
                
                'gst_no' => $formdata['gst_no'],
                'extra' => $formdata['extra'] ?? null,

            ];

            // dd($client_data);

            if (!empty($client_id)) {
                $provider = Providers::find($client_id);
            
                // Decode existing extra data
                $existingExtra = is_array($provider->extra) ? $provider->extra : json_decode($provider->extra, true) ?? [];
            
                // Merge with new extra data
                $updatedExtra = array_merge($existingExtra, $formdata['extra'] ?? []);
            
                // Add merged extra back to the update array
                $client_data['extra'] = $updatedExtra;
            
                // Update provider
                $provider->update($client_data);
            } else {
                // New provider: assign extra directly
                $client_data['extra'] = $formdata['extra'] ?? [];
                $provider = Providers::create($client_data);
            }
            


            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Provider updated successfully.')
                    : __('Provider created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditClient: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function importProviders(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|mimes:xlsx,xls,csv,ods'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation Failed',
                'errors' => $validator->errors()
            ], 200);
        }

        try {
            $file = $request->file('file');

            // Load the file and count sheets
            $spreadsheet = IOFactory::load($file->getRealPath());
            $sheetCount = $spreadsheet->getSheetCount();

            if ($sheetCount > 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Excel file should contain only one sheet. Found ' . $sheetCount
                ], 200);
            }

            $import = new ProvidersImport();
            Excel::import($import, $file);

            return response()->json([
                'success' => $import->success,
                'message' => $import->message
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => [$e->getMessage()]
            ], 200);
        }
    }


    public function deleteProviders($id)
    {
        try {
            // $allUserPermissions = auth()->user()->getAllUserPermissions();
            // // dd($allUserPermissions['companies']);
            // if (isset($allUserPermissions['users'])) {
            //     if (!empty($allUserPermissions['users']['children'])) {
            //         if (!in_array('delete provider', $allUserPermissions['users']['children'])) {
            //             return;
            //         }
            //     }
            // } else {
            //     return;
            // }

            // Attempt to delete the user by ID
            Providers::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Provider deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting Invoice Type: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Provider. Please try again.')], 500);
        }
    }
}
