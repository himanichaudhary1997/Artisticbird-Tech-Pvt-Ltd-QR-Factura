<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inventory;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class InventoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function indexInventorys(Request $request)
    {
        try {
            // $services = Services::paginate(10);
            $query = Inventory::query();

            if ($request->has('sort') && !is_null($request->sort)) {
                // dd($request->sort);
                $query->where('status', $request->sort);
            }
            if ($request->has('search') && !empty($request->search)) {
                $query->where(function ($q) use ($request) {
                    $q->where('name', 'like', "%{$request->search}%");
                });
            }

            $inventories = $query->orderBy('id','DESC')->paginate(20);
            // dd($clients);
            if ($request->ajax()) {
                return view('panel.inventory.partial_data', compact('inventories'))->render();
            }
    
            return view('panel.inventory.index-inventory', compact('inventories'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
    
            // Find the inventory item
            $inventory = Inventory::findOrFail($id);
            $inventory->status = $request->status;
            $inventory->save();
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Product status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating inventory status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }
    
    

    public function editInventory($id)
    {
        try {
        $inventory = Inventory::where('id', $id)->first();
        return view('panel.inventory.edit-inventory', compact('inventory'));
        } 
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function getInventories(Request $request)
    {
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 10;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = Inventory::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%')
                        ->orWhere('sku', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            if (isset($formdata['scope']) && !empty($formdata['scope'])) {
                $query->where('scope', $formdata['scope']); // Assuming `status` is a column in the `users` table
            }

            // Fetch paginated results with related data
            $inventories = $query->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Product retrieved successfully.',
                'data' => $inventories,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Product.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function addInventory()
    {
        try {
        return view('panel.inventory.add-inventory');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }


    public function addOrEditInventory(Request $request)
    {

        try {
            // Extract form data
            $formdata = $request->all();

            $dynamicTableName = (new Inventory())->getTable();

            $inventory_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:' . $dynamicTableName . ',name,' . $inventory_id,
                // 'sku' => 'required|string|max:255|unique:'.$dynamicTableName.',sku,' . $inventory_id,
                'quantity'   => 'required|numeric|min:0|max:255',
                'price'      => 'required',
                // 'tax_rate'   => 'required|numeric|min:0|max:255',
                'discount'   => 'required|string|min:0',
                // 'description' => 'sometimes|string|max:255', // Status should be an integer and can only be 0 or 1
            ];
            // Validate the input data  


            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }
            // Step 1: Normalize the price format
            // Step 1: Check if the price is already in European format (e.g., 3.675,00)
            // if (preg_match('/^\d{1,3}(\.\d{3})*,\d{2}$/', $formdata['price'])) {
            //     // Price is already in European format; do nothing
            // } else {
            //     // Step 2: Handle US format (3,675.00 → 3675.00) and simple numbers
            //     if (preg_match('/^\d{1,3}(,\d{3})*\.\d{2}$/', $formdata['price'])) {
            //         // US format (thousands separated by commas, decimals by dot)
            //         $numericPrice = str_replace(',', '', $formdata['price']); // Remove commas
            //     } else {
            //         // Plain number (3675) or incorrectly formatted input
            //         $numericPrice = $formdata['price'];
            //     }

            //     // Convert to float
            //     $numericPrice = floatval(str_replace(',', '.', $numericPrice)); 

            //     // Step 3: Convert to European format (thousands separated by dot, decimals by comma)
            //     $integerPart = floor($numericPrice);
            //     $decimalPart = fmod($numericPrice, 1); // Get decimal part

            //     // Ensure decimal part has two digits
            //     $decimalStr = sprintf('%02d', round($decimalPart * 100));

            //     // Convert integer part to European thousands format (e.g., 3675 → 3.675)
            //     $formattedInteger = number_format($integerPart, 0, '', '.');

            //     // Combine the integer and decimal parts
            //     $formdata['price'] = $formattedInteger . ',' . $decimalStr;
            // }

            // dd($formdata['price']);
            // Step 2: Convert back to correct Euro format (thousands separator as dot, decimal as comma)
            // $formdata['price'] = number_format($formdata['price'], 2, ',', '.');



            $inventory_data = [
                'name' => $formdata['name'],
                'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
                // 'sku' => $formdata['sku'],
                'quantity'   => $formdata['quantity'],
                'price'=> parseInventoryServicePrice($formdata['price']),
                // 'tax_rate'   => $formdata['tax_rate'],
                'discount'   => $formdata['discount'] ?? null,
                'description' => $formdata['description'] ?? null,
            ];

            if (!empty($inventory_id)) {
                $inventoryData = Inventory::where('id', $inventory_id)->first();
                Inventory::where('id', $inventory_id)->update($inventory_data);
                $inventory = Inventory::where('id', $inventory_id)->first();
            } else {
                $inventory = Inventory::create($inventory_data);
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id'])
                    ? __('Product updated successfully.')
                    : __('Product created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoiceType: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function deleteInventory($id)
    {
        try {
            // Attempt to delete the user by ID
            Inventory::destroy($id);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Product deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Inventory. Please try again.')], 200);
        }
    }

    public function updatePrice(Request $request)
    {
        try {
            $formData = $request->all();
            if (!isset($formData['percentage']) && empty($formData['percentage'])) {
                return response()->json(['success' => false, 'message' => __('Percentage Is Missing')], 200);
            }
            // Validate the percentage input
            // $formData = $request->validate([
            //     'percentage' => 'required|numeric', // Ensure percentage is a valid number
            // ]);

            $percentageIncrease = $formData['percentage']; // Get percentage value
            // dd($percentageIncrease);
            // Fetch all inventory items
            $inventories = Inventory::all();

            foreach ($inventories as $inventory) {
                // Normalize the price format
                $normalizedPrice = parseNumber($inventory->price);

                // Increase price by percentage
                $newPrice = $normalizedPrice + ($normalizedPrice * ($percentageIncrease / 100));

                // Convert back to Euro format before saving
                $inventory->price = parseNumber($newPrice);
                $inventory->save();
            }

            return response()->json(['success' => true, 'message' => __('Price updated successfully.')], 200);
        } catch (\Exception $e) {
            Log::error('Error updating inventory prices: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => __('Failed to update Product prices. Please try again.')], 200);
        }
    }

    /**
     * Normalize different price formats to float.
     */
    private function normalizePrice($price)
    {
        // Check if price is in Euro format (4.000.000,00 -> 4000000.00)
        if (preg_match('/\.\d{3},\d{2}$/', $price)) {
            return (float) str_replace(',', '.', preg_replace('/\.(?=\d{3})/', '', $price));
        }

        // Check if price is in US/INR format (4,000,000.00 -> 4000000.00)
        if (preg_match('/\d{1,3}(,\d{3})*\.\d{2}$/', $price)) {
            return (float) str_replace(',', '', $price);
        }

        // If already a simple number, return as float
        return (float) $price;
    }


    public function exportToCsv()
    {
        try {
            $inventories = Inventory::all();
            $filename = "inventories.csv";

            $headers = [
                "Content-Type"        => "text/csv; charset=UTF-8",
                "Content-Disposition" => "attachment; filename=\"{$filename}\"",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            ];

            $callback = function() use ($inventories) {
                // clear any previous output that may corrupt CSV
                if (ob_get_level() > 0) {
                    ob_end_clean();
                }

                $file = fopen('php://output', 'w');

                // Add UTF-8 BOM so Excel doesn’t break accents/special chars
                fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

                
                // Header row
                fputcsv($file, [
                    __('Name'),
                    __('Quantity'),
                    __('Price'),
                    __('Discount (in %)'),
                    __('Description'),
                ]);
                

                // Data rows
                foreach ($inventories as $inventory) {

                    fputcsv($file, [
                        $inventory->name,
                        $inventory->quantity,
                        $inventory->price,
                        $inventory->discount,
                        $inventory->description,
                    ]);
                }

                fclose($file);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Exception $e) {
            Log::error('Error updating inventory prices: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => __('Failed to update Product prices. Please try again.')], 200);
        }
    }
}
