<?php

namespace App\Http\Controllers;

use App\Services\PrestashopInvoicePdf;
use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Clients;
use App\Models\Company;
use App\Models\Services;
use App\Models\InvoiceType;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Templates;
use App\Models\User;
use PDF;
use Illuminate\Support\Facades\DB;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use setasign\Fpdi\Fpdi;
use Illuminate\Support\Facades\Hash;
use App\Models\Inventory;
use App\Traits\ContentDataTrait;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ClientAccountantRelation;
use App\Jobs\SendBulkInvoiceEmailsJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\TaxRules;
use App\Imports\ClientsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\InvoicePrefix;
use App\Jobs\DuplicatePeriodicInvoices;
use App\Jobs\SendPeridoicInvoices;
use App\Jobs\SendBulkEmails;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\Process\Process;
use function base_path as artisan_path;
use App\Jobs\SendBulkInvoicesPdfEmailJob;
use App\Services\FiskalyInvoiceService;
use Exception;
use App\Models\ActivityLog;
use PhpOffice\PhpSpreadsheet\IOFactory;


use App\Services\InvoiceService;
use App\Services\InvoiceXmlService;


use DOMDocument;
use DOMXPath;

class CompanyInvoicesController extends Controller
{

    use ContentDataTrait;
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $fiskaly;

    public function __construct(FiskalyInvoiceService $fiskaly)
    {
        $this->fiskaly = $fiskaly;
        $this->middleware('auth');
    }

    public function indexcompanyInvoice($company_slug,Request $request)
    {
        try {
            $user = auth()->user();
            $company = Company::where('company_slug', $company_slug)->first();
            $companyId = $company->id;
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $statuses = getStatuses();
            $query = (new Invoice())->setDynamicTableName($companyId)->newQuery();

            if (!empty($formdata['from_date']) && !empty($formdata['to_date']) && $formdata['to_date'] < $formdata['from_date']) {
                return response()->json([
                    'success' => false,
                    'message' => 'The to date must be greater than or equal to from date.',
                ], 200);
            }
            
            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata,$company) {
                    $searchTerm = $formdata['search'];
                    
                    $q->where('invoice_id', 'like', '%' . $searchTerm . '%');
                    if(!empty($company)){
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                        });
                    }else{
                        $q->orWhereHas('client', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                            $query->orWhereHas('singleCompany', function ($query) use ($searchTerm) {
                                $query->where('company_name', 'like', '%' . $searchTerm . '%');
                            });
                        });
                    }
                });
            }
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); 
            }

            if (isset($formdata['invoice_type']) && !is_null($formdata['invoice_type'])) {
                $query->where('invoice_type', $formdata['invoice_type']); 
            }

            if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
                $query->whereBetween('issue_date', [$formdata['from_date'], $formdata['to_date']]);
            } elseif (!empty($formdata['from_date'])) {
                $query->where('issue_date', '>=', $formdata['from_date']);
            } elseif (!empty($formdata['to_date'])) {
                $query->where('issue_date', '<=', $formdata['to_date']);
            }

            // Check if the user is not an Admin and role is neither 1 nor 2
            if (!$user->hasRole('Admin') && !$user->hasRole('Company') ) {
                $query->where('created_by', $user->id);
            }


            $invoices = $query->orderBy('id','DESC')->with(['client','invoiceType','paymentMethod'])->paginate($limit);

            // dd($invoices);
            $invoicesTypes = InvoiceType::all();

            if ($request->ajax()) {
                return view('panel.company-invoice.partial_data', compact('invoices','statuses', 'invoicesTypes','company'))->render();
            }

            return view('panel.company-invoice.index-invoice', compact('invoices', 'invoicesTypes','company'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editCompanyInvoice($company_slug,$id)
    {
        try {
        $user = Auth()->user();
        $role = $user->roles->pluck('id')->first();
        $company = Company::where('company_slug', $company_slug)->first();
        $companyId = $company->id;
       
        $invoice = (new Invoice())->setDynamicTableName($companyId)->where('id',$id)->first();
        //    dd($invoice);
        $clients = (new Clients())->setDynamicTableName($companyId)->get();
        $invoicePrefixs = (new InvoicePrefix())->setDynamicTableName($companyId)->where('status',1)->get();
        // $services = Services::where('status',1)->get();
        $invoiceType = InvoiceType::where('status', 1)->get();
        $paymentMethods = PaymentMethods::where('status', 1)->get();
        // $templates = Templates::get();
        $favouriteTemplates = [];

        $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
        $defaultCurrency = $company->extra['currency'] ?? '€';
        $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
        
        
        $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
        $services = (new Services())->setDynamicTableName($companyId)->where('status', 1)->get();
        $inventories = (new Inventory())->setDynamicTableName($companyId)->where('status', 1)->get();
        return view('panel.company-invoice.edit-invoice', compact('invoice','company','paymentMethods', 'inventories', 'services', 'invoiceType', 'clients', 'defaultCurrency','tax_slab','invoicePrefixs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
    public function deleteCompanyInvoice($company_slug,$id)
    {
        try {

            $company = Company::where('company_slug', $company_slug)->first();
            $companyId = $company->id;

            (new Invoice())->setDynamicTableName($companyId)->where('id', $id)->delete();
            // Invoice::destroy($id);
            // Return success response
            return response()->json(['success' => true, 'message' => __('Invoice deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Invoice. Please try again.')], 500);
        }
    }
    public function addCompanyInvoice(Request $request, $company_slug)
    {
        try {
        $user = Auth()->user();
        $role = $user->roles->pluck('id')->first();
        $company = Company::where('company_slug', $company_slug)->first();
        $companyId = $company->id;
       
        // $invoice = Invoice::where('id',$id)->first();
       
        $clients = (new Clients())->setDynamicTableName($companyId)->get();
        $invoicePrefixs = (new InvoicePrefix())->setDynamicTableName($companyId)->where('status',1)->get();
        // $services = Services::where('status',1)->get();
        $invoiceType = InvoiceType::where('status', 1)->get();
        $paymentMethods = PaymentMethods::where('status', 1)->get();
        // $templates = Templates::get();
        $favouriteTemplates = [];

        $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
        $defaultCurrency = $company->extra['currency'] ?? '€';
        $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
        
        
        $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
        $services = (new Services())->setDynamicTableName($companyId)->where('status', 1)->get();
        $inventories = (new Inventory())->setDynamicTableName($companyId)->where('status', 1)->get();
        return view('panel.company-invoice.add-invoice', compact('company','paymentMethods', 'inventories', 'services', 'invoiceType', 'clients', 'defaultCurrency','tax_slab','invoicePrefixs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addCompanyNegativeInvoice(Request $request, $company_slug){
        try {
        $user = Auth()->user();
        $role = $user->roles->pluck('id')->first();
        $company = Company::where('company_slug', $company_slug)->first();
        $companyId = $company->id;
       
        // $invoice = Invoice::where('id',$id)->first();
       
        $clients = (new Clients())->setDynamicTableName($companyId)->get();
        $invoicePrefixs = (new InvoicePrefix())->setDynamicTableName($companyId)->where('status',1)->get();
        // $services = Services::where('status',1)->get();
        $invoiceType = InvoiceType::where('status', 1)->get();
        $paymentMethods = PaymentMethods::where('status', 1)->get();
        // $templates = Templates::get();
        $favouriteTemplates = [];

        $favouriteTemplates = $company->extra['favourite_templates'] ?? [];
        $defaultCurrency = $company->extra['currency'] ?? '€';
        $tax_slab_id = $company->extra['tax_slab'] ?? TaxRules::where('tax_type', 'iva')->orderBy('id', 'asc')->pluck('id')->first();
        
        
        $tax_slab = TaxRules::where('id',$tax_slab_id)->first();
        $services = (new Services())->setDynamicTableName($companyId)->where('status', 1)->get();
        $inventories = (new Inventory())->setDynamicTableName($companyId)->where('status', 1)->get();
        return view('panel.company-invoice.add-negative-invoice', compact('company','paymentMethods', 'inventories', 'services', 'invoiceType', 'clients', 'defaultCurrency','tax_slab','invoicePrefixs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditCompanyInvoices(Request $request,$company_slug)
    {

         try {
            // Extract form data
            $formdata = $request->all();
            $user = Auth::user();
            $company = Company::where('company_slug', $company_slug)->first();
            $companyId = $company->id;
            $invoice_id = $formdata['id'] ?? null;
        
            // Validate request data
            $validator = $this->validateCompanyInvoice($formdata);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $items = $this->processCompanyInvoiceItems($formdata['items'], $formdata['currency'],$company);
    
            if ($formdata['client_id'] === 'new-client') {
                $client = $this->handleCompanyNewClient($formdata, $company);
                $formdata['client_id'] = $client->id;
            }
        
            $invoice_data = [
                'client_id'     => $formdata['client_id'],
                'issue_date'     => $formdata['issue_date'],
                'due_date'       => $formdata['due_date'],
                'currency'       => $formdata['currency'],
                'invoice_type'   => $formdata['invoice_type'],
                'payment_method' => $formdata['payment_method'],
                'ref_no'         => $formdata['ref_no'] ?? null,
                'items'          => $items,
                'subtotal'       => $formdata['subtotal'] ?? null,
                'totalDiscount'  => $formdata['totalDiscount'] ?? null,
                'totalTax'       => $formdata['totalTax'] ?? null,
                'totalRetencion' => $formdata['totalRetencion'] ?? null,
                'grandTotal'     => $formdata['grandTotal'] ?? null,
                'extra'          => $formdata['extra'] ?? null,
                
            ];
            // dd($formdata['extra']);

            
            // $invoice_data['invoice_id'] = $this->generateInvoiceId($formdata['issue_date'], $company, $user,$formdata['client_id'],$formdata);

            if (empty($invoice_id)) {
                $invoice_data['invoice_id'] = $this->generateCompanyInvoiceId($formdata['issue_date'], $company, $user,$formdata['client_id'],$formdata);
                // if(isset($formdata['status'])){
                    $invoice_data['status']= $formdata['status'] ?? 0;
                // }
                $invoice_data['created_by'] = $user->id;
                $invoice = (new Invoice())->setDynamicTableName($companyId)->create($invoice_data);
            } else {
                $oldInvoice = (new Invoice())->setDynamicTableName($companyId)->find($invoice_id);

                // dd($oldInvoice->extra['invoice_prefix']);
                if($formdata['extra']['invoice_prefix'] != $oldInvoice->extra['invoice_prefix']){
                    $invoice_data['invoice_id'] = $this->generateInvoiceId($formdata['issue_date'], $company, $user,$formdata['client_id'],$formdata);
                }
                // dd($invoice_data);
                (new Invoice())->setDynamicTableName($companyId)->where('id', $invoice_id)->update($invoice_data);
                $invoice = (new Invoice())->setDynamicTableName($companyId)->find($invoice_id);
            }

            return response()->json([
                'success' => true,
                'message' => $invoice_id ? __('Invoice updated successfully.') : __('Invoice created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditInvoice: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    private function validateCompanyInvoice($data)
    {
        try {
            return Validator::make($data, [
                'client_id'      => 'required',
                'issue_date'      => 'required|date',
                'due_date'        => 'required|date|after_or_equal:issue_date',
                'currency'        => 'required|string|max:10',
                'invoice_type'    => 'required|integer',
                'payment_method'  => 'required|integer',
                'ref_no'          => 'sometimes|max:255',
                'items'           => 'required|array|min:1',
                'items.*.name' => 'required',
                'items.*.quantity'=> 'required|numeric|min:1',
                'items.*.price'   => 'required|min:0',
                'items.*.discount'=> 'nullable|min:0',
                'items.*.tax'     => 'nullable|min:0|max:100',
                'items.*.amount'  => 'required',
                'client_email'    => 'required_if:client_id,new-client',
                'client_name'     => 'required_if:client_id,new-client',
                'extra.note' => 'nullable|string|max:300',
            ], [
                'client_email.required_if' => __('Client email is required for a new client.'),
                'client_name.required_if'  => __('Client name is required for a new client.'),
                'client_email.email'       => __('Please provide a valid email address for the client.'),
                'items.required'            => __('At least one item is required in the invoice.'),
                'items.*.name.required'  => __('Please Select any item.'),
                'items.*.quantity.required' => __('Each item must have a quantity.'),
                'items.*.quantity.numeric'  => __('The quantity must be a valid number.'),
                'items.*.quantity.min'      => __('The quantity must be at least 1.'),
                'items.*.price.required'    => __('Each item must have a price.'),
                'items.*.price.min'         => __('The price must be at least 0.'),
                'items.*.discount.min'      => __('The discount must be at least 0.'),
                'items.*.tax.min'           => __('The tax percentage must be at least 0.'),
                'items.*.tax.max'           => __('The tax percentage cannot exceed 100%.'),
                'items.*.amount.required'   => __('Each item must have an amount.'),
                'extra.note.string' => __('The note must be a valid text.'),
                'extra.note.max' => __('The note cannot be longer than 300 characters.'),
            ]);
        } catch (\Exception $e) {
            throw new \Exception(__('Something went wrong.'));
        }
    }


    private function processCompanyInvoiceItems($items, $currency,$company)
    {
        $processedItems = [];

        foreach ($items as $item) {
            
           
            if ($item['name'] === 'new-item') {
                $item['name'] = $this->createCompanyNewServiceItem($item,$company);
            }

            if ($item['name'] === 'new-inventory') {
                // dd($item);
                $item['name'] = $this->createCompanyNewInventoryItem($item,$company);
            }

            $processedItems[] = $item;
        }

        return $processedItems;
    }


    private function createCompanyNewServiceItem($item,$company)
    {
        try {
            $companyId = $company->id;
            if (!$item['new_item']) {
                throw new Exception(__('Please enter service name.'));
            }
        
            if ($existingItem = (new Services())->setDynamicTableName($companyId)->where('name', $item['new_item'])->first()) {
                throw new Exception(__('Item ' . $item['new_item'] . ' already exists.'));
            }
        
            $service = (new Services())->setDynamicTableName($companyId)->create(['name' => $item['new_item'],'slug' => str_replace(' ', '-', strtolower($item['new_item'])),'status' => 1,'price'     => $item['price'],'tax_rate'  => $item['tax'],'discount'  => $item['discount'],]);
            return $service->name;
        } catch (\Exception $e) {
                throw new \Exception(__('Something went wrong.'));
            }
    }
    

    private function createCompanyNewInventoryItem($item,$company)
    {
        try {
            $companyId = $company->id;
            if (!$item['new_inventory']) {
                throw new Exception(__('Please enter Inventory name.'));
            }
        
            if ($existingItem = (new Inventory())->setDynamicTableName($companyId)->where('name', $item['new_inventory'])->first()) {
                throw new Exception(__('Item ' . $item['new_inventory'] . ' already exists.'));
            }
        
            $inventory = (new Inventory())->setDynamicTableName($companyId)->create([
                'name'      => $item['new_inventory'],
                'slug' => str_replace(' ', '-', strtolower($item['new_inventory'])),
                'price'     => $item['price'],
                'quantity'  => 0,
                'tax_rate'  => $item['tax'],
                'discount'  => $item['discount'],
                'status'    => 1,
            ]);

            return $inventory->name;
        } catch (\Exception $e) {
            throw new \Exception(__('Something went wrong.'));
        }
    }
    
    private function handleCompanyNewClient($formdata, $company)
    {
        try {
            $companyId = $company->id;
            if ($company) {
                return (new Clients())->setDynamicTableName($companyId)->create([
                    'name'     => $formdata['client_name'],
                    'email'    => $formdata['client_email'],
                    'mobile_no'=> $formdata['client_phone'],
                    'status'   => 1,
                ]);
            }
        } catch (\Exception $e) {
            throw new \Exception(__('Something went wrong while creating the client.'));
        }
    }

    private function generateCompanyInvoiceId($issue_date, $company, $user,$client_id,$formdata)
    {
        try {
            $companyId = $company->id;

            $client = (new Clients())->setDynamicTableName($companyId)->where('id',$client_id)->first();
            // dd($formdata['extra']['invoice_prefix']);
            $invoicePrefixData = '';
            if(isset($formdata['extra']['invoice_prefix']) && !empty($formdata['extra']['invoice_prefix'])){
                $invoicePrefixData = explode('/',$formdata['extra']['invoice_prefix']);
            }
            // dd($invoicePrefixData);
            // Get the invoice starting series from company or user, if available
            $invoice_starting_series = $invoicePrefixData[1] ?? null;

            $year = date('Y', strtotime($issue_date));
            $companyInitials = $invoicePrefixData[0] ??  strtoupper(substr($company->company_name ?? $user->extra['company_name'] ?? '', 0, 2));

            // Get the latest invoice for the current year and company
            $latestInvoice = (new Invoice())->setDynamicTableName($companyId)->whereYear('issue_date', $year)
                ->where('invoice_id', 'LIKE', "$year/$companyInitials/%")
                ->orderBy('id', 'desc')
                ->first();

            // Determine the next invoice number
            if ($invoice_starting_series) {
                // If invoice_starting_series is provided, use it as the starting point
                $nextInvoiceNumber = (int) $invoice_starting_series;
            } else {
                // If no invoice_starting_series is provided, start from 1 or increment from the latest invoice
                $nextInvoiceNumber = $latestInvoice ? ((int) substr($latestInvoice->invoice_id, -4)) + 1 : 1;
            }

            // Ensure the next invoice number does not conflict with existing invoices
            while ((new Invoice())->setDynamicTableName($companyId)->where('invoice_id', sprintf('%s/%s/%04d', $year, $companyInitials, $nextInvoiceNumber))->exists()) {
                $nextInvoiceNumber++;
            }

            return sprintf('%s/%s/%04d', $year, $companyInitials, $nextInvoiceNumber);
        } catch (\Exception $e) {
            throw new \Exception(__('Something went wrong.'));
        }
    }

    public function previewCompanyInvoice($company_slug, $invoiceId)
    {
        try {
            $authUser = auth()->user();
            $company = Company::where('company_slug', $company_slug)->first();
            
            $user = User::where('id', $company->admin_id)->first();
            $companyId = $company->id;
            $invoice = (new Invoice())->setDynamicTableName($companyId)->findOrFail($invoiceId);
            // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??  Templates::where('status', 1)->value('id');
            $templateId = getTemplateId(!empty($company) ? $company : $user);
            $template = Templates::where('id', $templateId)->first();

            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            $datahtml = PrestashopInvoicePdf::previewHtml($invoice, $company)
                ?? parseInvoiceSortcodes($template->template_html, $invoice, $company);

            $client = (new Clients())->setDynamicTableName($companyId)->where('id',$invoice->client_id)->first();
            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' =>$client->name ?? null,
            ];



            return view('invoice.preview', ['templateHtml' => $datahtml, 'data' => $data]);    
        } catch (\Exception $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function updateCompanyInvoiceStatus(Request $request,$company_slug)
    {
        try {
            $formdata = $request->all();
            $company = Company::where('company_slug', $company_slug)->first();
            $companyId = $company->id;
            $user = User::where('id', $company->admin_id)->first();
            if (!isset($formdata['status']) || is_null($formdata['status'])) {
                return response()->json(['success' => false, 'message' => __('Status is required')], 200);
            }

            if (!isset($formdata['id']) || empty($formdata['id'])) {
                return response()->json(['success' => false, 'message' => __('Invoice id is required')], 200);
            }
            // Attempt to delete the user by ID
            (new Invoice())->setDynamicTableName($companyId)->where('id', $formdata['id'])->update(['status' => $formdata['status']]);


            // Return success response
            return response()->json(['success' => true, 'message' => __('Status updated successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user:' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 200);
        }
    }


    public function downloadCompanyInvoice($company_slug, $invoiceId)
    {
        try {
        $authUser = auth()->user();
        $company = Company::where('company_slug', $company_slug)->first();
        $companyId = $company->id;
        if ($company) {
            $user = User::where('id', $company->admin_id)->first();
        } else {
            // $user = $authUser;
            $user = User::where('id', 1)->first();
        }
        $invoice = (new Invoice())->setDynamicTableName($companyId)->findOrFail($invoiceId);
        // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
        $templateId = getTemplateId(!empty($company) ? $company : $user);
        $template = Templates::where('id', $templateId)->first();
        
        if(empty($template) || $template->status != 1){
            $template = Templates::where('status', 1)->first();
        }

        $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);
        // Get the storage path dynamically
        $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

        // Get the base URL dynamically
        $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

        // Ensure correct trailing slashes
        $storagePath = rtrim($storagePath, '/') . '/';
        $baseUrl = rtrim($baseUrl, '/') . '/';


        $datahtml = preg_replace_callback(
            '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
            function ($matches) use ($storagePath) {
                return $storagePath . ltrim($matches[1], '/');
            },
            $datahtml
        );
        // dd($datahtml);
        // Generate PDF from the rendered template
        // The shop's own PDF (or PrestaShop layout) for invoices from the PrestaShop module
        $prestashopPdf = PrestashopInvoicePdf::pdfFor($invoice, $company);
        if ($prestashopPdf !== null) {
            return PrestashopInvoicePdf::downloadResponse($prestashopPdf, "invoice-{$invoiceId}-{$invoice->issue_date}.pdf");
        }

        $pdf = PDF::loadHTML($datahtml)->setPaper('a4', 'portrait');

        return $pdf->download("invoice-{$invoiceId}-{$invoice->issue_date}.pdf");
    } catch (\Exception $e) {
        throw new \Exception(__('Something went wrong.'));
    }
    }

    public function sendCompanyEmail(Request $request,$company_slug)
    {
        try {
            $authUser = auth()->user();
            $company = Company::where('company_slug', $company_slug)->first();
            $companyId = $company->id;
            $dynamicTableName = 'invoices_'.$companyId;
            // Validate request input
            $formdata = $request->validate([
                'id' => 'required|integer|exists:'.$dynamicTableName.',id', // Ensure the invoice exists
                'comment' => 'nullable|string',
            ]);
            // dd($formdata);

            $invoiceId = $formdata['id'];

            
            $user = User::where('id', $company->admin_id)->first();

            $invoice = (new Invoice())->setDynamicTableName($companyId)->findOrFail($invoiceId);
            // $templateId = $company->extra['favouraite_template'] ?? $user->extra['favouraite_template'] ??   Templates::where('status', 1)->value('id');
            $templateId = getTemplateId(!empty($company) ? $company : $user);
            $template = Templates::where('id', $templateId)->first();
            if(empty($template) || $template->status != 1){
                $template = Templates::where('status', 1)->first();
            }
            // dd($template);
            $datahtml = parseInvoiceSortcodes($template->template_html, $invoice, $company);

            $client = (new Clients())->setDynamicTableName($companyId)->where('id',$invoice->client_id)->first();

            $data = [
                'id' => $invoice->id,
                'invoice_no' => $invoice['invoice_id'] ?? null,
                'customer_name' => $client->name ?? null,
                'comment'=>$formdata['comment'] ?? null,
                'company_name'=>$company->company_name ?? $user->extra['company_name'],
                'company'=>$company,
            ];

            // Generate PDF from the rendered template
            // $pdfContent = PDF::loadHTML($datahtml)->output();

            // Get the storage path dynamically
            $storagePath = public_path('storage/'); // Example: "/home/1438367.cloudwaysapps.com/jjcpdtxaep/public_html/storage/app/public"

            // Get the base URL dynamically
            $baseUrl = asset('storage'); // Example: "https://yourdomain.com/storage"

            // Ensure correct trailing slashes
            $storagePath = rtrim($storagePath, '/') . '/';
            $baseUrl = rtrim($baseUrl, '/') . '/';

            $data['templateHtml'] = PrestashopInvoicePdf::emailHtml($invoice, $company)
                ?? preg_replace('/\s+/', ' ', $datahtml);

            $datahtml = preg_replace_callback(
                '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
                function ($matches) use ($storagePath) {
                    return $storagePath . ltrim($matches[1], '/');
                },
                $datahtml
            );
            // dd($datahtml);
            
            // Generate PDF from the modified HTML (the shop's own PDF for PrestaShop invoices)
            $pdfContent = PrestashopInvoicePdf::pdfFor($invoice, $company) ?? PDF::loadHTML($datahtml)->output();
            
            if(!empty($company)){
                $email = $client->extra['alternative_email'] ?? $client->email;
            }else{
                $clientCompany = Company::where('admin_id',$invoice->client->id)->first();
                $email = $clientCompany->extra['alternative_email'] ?? $invoice->client->email;
            }
            
            // Ensure client email exists
            if (empty($email)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client email not found.',
                ], 200);
            }

            // Send email with the PDF attachment
            Mail::to($email)->send(new SystemEmail(
                __('Please check your invoice'),
                'emails.invoice-template', // Replace with your Blade view path
                $data, // Dynamic data
                $pdfContent, // Attach generated PDF content
                "invoice-{$invoiceId}.pdf", // Optional file name for the PDF,
                'info@artisticbird.com',
                $company->company_name ?? $user->extra['company_name'],
                null,
                $company->user->email ?? 'info@artisticbird.com',
                $company->company_name ?? $user->extra['company_name'] 
            ));

            if($invoice->status != self::PAID_INVOICE && $invoice->status != self::NEGATIVE_INVOICE){
                $invoice->status = self::SEND_INVOICE; //2 represents 'sent'
            }
            $invoice->save();
            return response()->json([
                'success' => true,
                'message' => 'Invoice sent successfully.',
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while sending the invoice.',
                'error' => $e->getMessage(),
            ], 200);
        }
    }


    public function downloadCompanyBulkInvoices(Request $request)
    {
        try {
            $invoiceIds = $request->input('ids', []);
            $company_slug = $request->input('company_slug', null);

            if (empty($invoiceIds)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No invoices selected for bulk download.',
                ], 200);
            }

            $company = Company::where('company_slug', $company_slug)->first();
            $user = User::where('id', $company->admin_id)->first();
            // Initialize FPDI for PDF merging
            $pdf = new Fpdi();
            $timestamp = now()->format('Y-m-d_H-i-s');

            foreach ($invoiceIds as $invoiceId) {
                // Fetch the invoice with related template
                $invoice =  Invoice::forUsers($company->id)->where('id', $invoiceId)->first();

                // Check if a template is assigned
                if (isset($invoice->extra['template_id']) && !empty($invoice->extra['template_id'])) {
                    $template = Templates::where('id', $invoice->extra['template_id'])->first();
                }
                // Fetch related data for the invoice
                $invoice->client = $invoice->client($company->id, $invoice->client_id);

                // Prepare dynamic data for the template
                $data = [
                    // 'invoice_name' => $invoice->name, 
                    'invoice_no' => $invoice['invoice_id'],
                    'currency' => $invoice->currency,
                    'issue_date' => date('j M, Y', strtotime($invoice->issue_date)),
                    'due_date' => date('j M, Y', strtotime($invoice->due_date)),
                    'ref_no' => $invoice->ref_no,
                    'items' => $invoice->items,
                    'subtotal' => $invoice->extra['subtotal'] ?? null,
                    'totalDiscount' => $invoice->extra['totalDiscount'] ?? null,
                    'totalTax' => $invoice->extra['totalTax'] ?? null,
                    'grandTotal' => $invoice->extra['grandTotal'] ?? null,
                    'customer_name' => $invoice->client->name ?? null,
                    'customer_email' => $invoice->client->email ?? null,
                    'customer_mobile_no' => $invoice->client->phone ?? null,
                    'customer_gst_no' => $invoice->client->company->gst_no ?? null,
                    'customer_address' => $invoice->client->extra['address'] ?? $invoice->client->company->extra['company_address'] ?? null,
                    'payment_method' => $invoice->paymentMethod->name ?? null,
                    'invoice_type' => $invoice->invoiceType->name ?? null,
                    'company_id' => $company->id ?? null,
                    'user_name' => $user->name ?? null,
                    'user_email' => $user->email ?? null,
                    'user_mobile' => $user->phone ?? null,
                    'user_company_name' => $company->company_name ?? $user->extra['company_name'] ?? null,
                    'user_company_email' => $company->company_email ?? $user->email,
                    'user_company_gst_no' => $company->gst_no ?? $user->extra['gst_no'] ?? null,
                    'user_company_address' => $company->extra['company_address'] ?? $user->extra['company_address'] ?? null,
                    'user_company_logo' => $company->extra['company_logo'] ?? $user->extra['company_logo'] ?? null,
                ];

                // Save the PDF to a temporary file
                $tempFilePath = storage_path('app/public/invoices/invoice-' . $company->company_slug . '-' . $invoiceId . '.pdf');

                // The shop's own PDF (or PrestaShop layout) for invoices from the PrestaShop module, all pages
                $prestashopPdf = PrestashopInvoicePdf::pdfFor($invoice, $company);
                if ($prestashopPdf !== null) {
                    file_put_contents($tempFilePath, $prestashopPdf);
                    $pageCount = $pdf->setSourceFile($tempFilePath);
                    for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                        $pdf->AddPage();
                        $pdf->useTemplate($pdf->importPage($pageNo));
                    }
                    continue;
                }

                // Render the template
                $templateHtml = $this->renderTemplate($template->template_html, $data);

                // Generate the PDF for the invoice using DomPDF
                $invoicePdf = PDF::loadHTML($templateHtml)->setPaper('a4', 'portrait');
                $invoicePdf->save($tempFilePath);

                // Add the saved PDF to the FPDI object
                $pdf->AddPage();
                $pdf->setSourceFile($tempFilePath);
                $templateIndex = $pdf->importPage(1);
                $pdf->useTemplate($templateIndex);
            }

            // Save the merged PDF with a timestamp
            $mergedPdfPath = storage_path("app/public/invoices/all-{$company->company_slug}-invoices-{$timestamp}.pdf");
            $pdf->Output('F', $mergedPdfPath);

            // Return the URL to the user for downloading
            return response()->json([
                'success' => true,
                'message' => 'Invoices downloaded successfully.',
                'downloadUrl' => asset("storage/invoices/all-{$company->company_slug}-invoices-{$timestamp}.pdf")
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('Something went wrong.'),
            ], 500);
        }
    }
}
