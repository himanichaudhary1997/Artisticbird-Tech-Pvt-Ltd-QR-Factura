<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VerifactuApiKeysModel;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Company;
use App\Models\InvoicePrefix;


class VerifactuApiKeysController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request){
        try {
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;

            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
        
            $query = VerifactuApiKeysModel::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                // dd($formdata);
                $query->where(function ($q) use ($formdata) {
                    $q->where('allowed_url', 'like', '%' . $formdata['search'] . '%');
                });
            }  

            if($company){
                $query->where('company_id',$company->id);
            }

        
            // Fetch paginated results with related data
            $apis = $query->orderBy('id','DESC')->paginate($limit);
            
            if ($request->ajax()) {
                return view('panel.site-apis.partial_data', compact('apis'))->render();
            }

            return view('panel.site-apis.index', compact('apis'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __($e->getMessage()));
        }
    }

    public function addSiteApis(){
        try {
            $companies = Company::all();

            return view('panel.site-apis.add-api',compact('companies'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editSiteApis($id){
        try {
            $api = VerifactuApiKeysModel::find($id);
            $prefixs= InvoicePrefix::all();
            return view('panel.site-apis.edit-api',compact('api','prefixs'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditSiteApis(Request $request)
    {
        try {
            $formdata = $request->all();
            $user = auth()->user();

            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            // ✅ Validation rules
            if(isset($formdata['id'])){
                $rules = [
                    'name'=>'required',
                ];
            }else{
                $rules = [
                    'name'=>'required',
                    'allowed_url' => [
                        'required',
                        'url', // must be valid URL
                        function ($attribute, $value, $fail) {
                            // Remove trailing slash
                            $normalizedUrl = rtrim($value, '/');
    
                            // Check if URL already exists in DB
                            if (VerifactuApiKeysModel::where('allowed_url', $normalizedUrl)->exists()) {
                                $fail(__('The URL has already been taken.'));
                            }
                        }
                    ],
                ];
            }
            

            $validator = Validator::make($formdata, $rules);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors(),
                ], 200);
            }

            if(!isset($formdata['id'])){
                // ✅ Normalize URL (remove trailing slash)
                $allowedUrl = rtrim($formdata['allowed_url'], '/');
    
                // ✅ Generate unique 40-char API key
                do {
                    $apiKey = Str::random(40);
                } while (VerifactuApiKeysModel::where('api_key', $apiKey)->exists());
    
                // ✅ Save record
                $apiData = VerifactuApiKeysModel::create([
                    'name'=>$formdata['name'],
                    'allowed_url' => $allowedUrl,
                    'api_key'     => $apiKey,
                    'company_id' => $formdata['company_id'] ?? $company->id
                ]);
    
                return response()->json([
                    'success' => true,
                    'message' => __('API Key created successfully.'),
                    'data'    => $apiData,
                ], 200);
            }else{
                $apiData = VerifactuApiKeysModel::where('id',$formdata['id'])->update([
                    'name'=>$formdata['name'],
                    'prefix_id'=>$formdata['prefix_id'],
                    'extra'=>$formdata['extra']
                ]);
    
                return response()->json([
                    'success' => true,
                    'message' => __('API Key created successfully.'),
                    'data'    => $apiData,
                ], 200);
            }

        } catch (\Exception $e) {
            Log::error('Error in addOrEditSiteApis: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error'   => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ], 500);
        }
    }

    public function deleteSiteApis($id){
        try {
            VerifactuApiKeysModel::destroy($id);
            return response()->json(['success'=>true,'message' => 'Api Key deleted successfully']);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete Api key. Please try again.'
            ], 500);
        }
    }

}
