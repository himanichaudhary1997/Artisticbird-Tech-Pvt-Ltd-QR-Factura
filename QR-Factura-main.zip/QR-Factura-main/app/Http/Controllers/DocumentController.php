<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Clients;
use App\Models\DocuemntsModel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\ClientAccountantRelation;
use App\Models\DocumentCategories;
use App\Models\DocumentCategoriesRelation;

class DocumentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function indexDocuments(Request $request)
    {
        try {
        $user = auth()->user();
        $role = $user->roles->pluck('id')->first();
        $limit = $formdata['limit'] ?? 15;
        $formdata = $request->all();
        // Base query excluding the authenticated user and filtering by role ID 2
        $query = DocuemntsModel::query();
        if (isset($formdata['search']) && !empty($formdata['search'])) {
            $query->where(function ($q) use ($formdata) {
                $q->where('title', 'like', '%' . $formdata['search'] . '%');
            });
        }

        if (!empty($formdata['category_id'])) {
            $query->whereHas('categories', function ($q) use ($formdata) {
                $q->where('category_id', $formdata['category_id']);
            });
        }
        // Apply status filter
        if (isset($formdata['status']) && !is_null($formdata['status'])) {
            // dd($formdata);
            $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
        }
        // if (isset($formdata['client_id']) && !empty($formdata['client_id'])) {
        //     $query->where('client_id', $formdata['client_id']); // Assuming `status` is a column in the `users` table
        // } 

        if($role == 4){
            $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
            ->pluck('client_id')
            ->toArray();
            // dd($currentAccountantClients);
            $query->where(function ($q) use ($currentAccountantClients) {
                foreach ($currentAccountantClients as $clientId) {
                    $q->orWhereJsonContains('client_id', $clientId);
                }
            });
        }

        // Fetch paginated results with related data
        $documents = $query->orderBy('id','DESC')->paginate($limit);
        // dd($documents);
        $categories = DocumentCategories::where('status', 1)->get();
        if ($request->ajax()) {
            return view('panel.document.partial_documents', compact('documents','categories'))->render();
        }
        // Return JSON response
        return view('panel.document.index-document',compact('documents','categories'));
    } 
    catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
}


    public function getDocuments(Request $request){
        try {
            $user = auth()->user();
            $company = $user->company;
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            $role = $user->roles->pluck('id')->first();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = DocuemntsModel::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('title', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                // dd($formdata);
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }
            // if (isset($formdata['client_id']) && !empty($formdata['client_id'])) {
            //     $query->where('client_id', $formdata['client_id']); // Assuming `status` is a column in the `users` table
            // } 

            if($role == 4){
                $currentAccountantClients = ClientAccountantRelation::where('accountant_id', $user->id)
                ->pluck('client_id')
                ->toArray();
                // dd($currentAccountantClients);
                $query->where(function ($q) use ($currentAccountantClients) {
                    foreach ($currentAccountantClients as $clientId) {
                        $q->orWhereJsonContains('client_id', $clientId);
                    }
                });
            }

            // Fetch paginated results with related data
            $documents = $query->orderBy('id','DESC')->paginate($limit);

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Documents retrieved successfully.',
                'data' => $documents,
                'user_role_id' => $user->roles->pluck('id')->first(), // User's role ID
                'company_id' => $company->id ?? null,           
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve Documents.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function statusupdate(Request $request, $id)
    {
    try {
        // Validate the request
        $request->validate([
            'status' => 'required|string'
        ]);
        $user = auth()->user();
        $formdata = $request->all();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        
        $document = DocuemntsModel::findOrFail($id);
        $document->status = $request->status;
        $document->save();

        // Return success response
        return response()->json([
            'success' => true, 
            'message' => __('Document status updated successfully')
        ], 200);
    } catch (\Exception $e) {
        // Log the exception for debugging
        Log::error('Error updating Clients status: ' . $e->getMessage());

        // Return error response
        return response()->json([
            'success' => false, 
            'message' => __('Failed to update status. Please try again.')
        ], 500);
    }
    }

    public function addDocuments()
    {
    try {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if(!empty($company)){
            $clients = Clients::get();
        }else{
            $clients = User::whereHas('roles', function ($query) {
                $query->where('id', 2); // Accountant role ID
            })->get();
        }
        $categories = DocumentCategories::where('status', 1)->get();
        return view('panel.document.add-document',compact('clients','categories'));
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editDocuments($id){
        try {
        $user = auth()->user();
        $company = $user->company;
        $document = DocuemntsModel::where('id',$id)->first();
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if(!empty($company)){
            $clients = Clients::get();
        }else{
            $clients = User::whereHas('roles', function ($query) {
                $query->where('id', 2); // Accountant role ID
            })->get();
        }
        $categories = DocumentCategories::where('status', 1)->get();
        return view('panel.document.edit-document',compact('clients','document','categories'));
    }
        catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function addOrEditDocuments(Request $request){
        try {
            // Extract form data
            $formdata = $request->all();
            $dynamicTableName = (new DocuemntsModel())->getTable();
            $document_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'title' => 'required|string|max:255|unique:'.$dynamicTableName.',title,' . $document_id,
                'document_url'=>'required',
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $document_data = [
                'title'=> $formdata['title'],
                'client_id' => $formdata['client_id'] ?? null,
                'document_url'=>$formdata['document_url']

            ];

            if (!empty($document_id)) {
                $methodData = DocuemntsModel::where('id',$document_id)->first();
                DocuemntsModel::where('id', $document_id)->update($document_data);
                $method = DocuemntsModel::where('id',$document_id)->first();
    
                
            } else {
                // Create a new invoice
                $method = DocuemntsModel::create($document_data);
            }
        
            if (isset($formdata['category_id']) && !empty($formdata['category_id'])) {
                $categoryIds = is_array($formdata['category_id']) ? $formdata['category_id'] : [$formdata['category_id']];
    
                // Remove old category relations if updating
                if (!empty($document_id)) {
                    DocumentCategoriesRelation::where('document_id', $document_id)->delete();
                }
    
                // Insert new category relations
                foreach ($categoryIds as $categoryId) {
                    DocumentCategoriesRelation::create([
                        'document_id' => $method->id,
                        'category_id' => $categoryId
                    ]);
                }
            }
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Document updated successfully.') 
                    : __('Document created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditPaymentMethod: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    
    
    public function deleteDocuments($id)
    {
        try {
            // Attempt to delete the user by ID
            DocuemntsModel::destroy($id);

            // Return success response
            return response()->json(['success' => true, 'message' => __('Document deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Plan. Please try again.')], 500);
        }
    }


    public function indexDocumentsCategories(Request $request)
    {
        try {
        $user = auth()->user();
        $role = $user->roles->pluck('id')->first();
        $limit = $formdata['limit'] ?? 15;
        $formdata = $request->all();
        // Base query excluding the authenticated user and filtering by role ID 2
        $query = DocumentCategories::query();
        if (isset($formdata['search']) && !empty($formdata['search'])) {
            $query->where(function ($q) use ($formdata) {
                $q->where('name', 'like', '%' . $formdata['search'] . '%');
            });
        }
        // Apply status filter
        if (isset($formdata['status']) && !is_null($formdata['status'])) {
            // dd($formdata);
            $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
        }

        // Fetch paginated results with related data
        $documentCategories = $query->orderBy('id','DESC')->paginate($limit);
        // dd($documents);
        if ($request->ajax()) {
            return view('panel.document-categories.partial_category', compact('documentCategories'))->render();
        }
        // Return JSON response
        return view('panel.document-categories.index-categories',compact('documentCategories'));
    } 
    catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
}

    public function updateCategoryStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }

            
            $document = DocumentCategories::findOrFail($id);
            $document->status = $request->status;
            $document->save();

            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Document Category status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Category status: ' . $e->getMessage());

            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
    }

    public function addDocumentsCategories(){
        try {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        return view('panel.document-categories.add-category');
    }
    catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
}

    public function editDocumentsCategories($id){
        try {
        $user = auth()->user();
        $company = $user->company;
        $category = DocumentCategories::where('id',$id)->first();
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        return view('panel.document-categories.edit-category',compact('category'));
    }
    catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
}

    public function addOrEditDocumentsCategories(Request $request){
        try {
            // Extract form data
            $formdata = $request->all();
            $dynamicTableName = (new DocumentCategories())->getTable();
            $category_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255|unique:'.$dynamicTableName.',name,' . $category_id,
            ];
            // Validate the input data  
            

            // $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $document_data = [
                'name'=> $formdata['name'],

            ];

            if (!empty($category_id)) {
                $methodData = DocumentCategories::where('id',$category_id)->first();
                DocumentCategories::where('id', $category_id)->update($document_data);
                $method = DocumentCategories::where('id',$category_id)->first();
    
                
            } else {
                // Create a new invoice
                $method = DocumentCategories::create($document_data);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Category updated successfully.') 
                    : __('Category created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditCategory: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    
    
    public function deleteDocumentsCategories($id)
    {
        try {
            // Attempt to delete the user by ID
            DocumentCategories::destroy($id);

            // Return success response
            return response()->json(['success' => true, 'message' => __('Category deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Category. Please try again.')], 200);
        }
    }
}
