<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\SubscriptionPlans;
use App\Models\SubscriptionItems;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class Subscriptions extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index(Request $request){
        try{
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = SubscriptionPlans::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $subscriptions = $query->orderBy('id','DESC')->paginate($limit);

            $subscriptions->getCollection()->transform(function ($plan) {
                // Decode the JSON array of item IDs
                $itemIds = $plan->items;
    
                if (is_array($itemIds) && !empty($itemIds)) {
                    // Fetch the corresponding service names
                    $services = SubscriptionItems::whereIn('id', $itemIds)->pluck('name')->toArray();
    
                    // Convert to comma-separated string
                    $plan->service_names = implode(', ', $services);
                } else {
                    $plan->service_names = 'No Services';
                }
    
                return $plan;
            });
            
            if($request->ajax())
            {
                return view('panel.subscriptions.partial_subscription_plan', compact('subscriptions' ))->render();

            }
        // $subscriptions = SubscriptionPlans::paginate(10);
        // return view('panel.subscriptions.subscriptions-index',compact('subscriptions'));
        return view('panel.subscriptions.subscriptions-index',compact('subscriptions'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }
    
    public function indexItems(Request $request){        
        try{
            $user = auth()->user();
            $formdata = $request->all();
            $limit = $formdata['limit'] ?? 15;
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = SubscriptionItems::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $items = $query->orderBy('id','DESC')->paginate($limit);
            // $subscriptions = SubscriptionPlans::paginate(10);
            if ($request->ajax()) {
                return view('panel.subscriptions.partial_subscription_items', compact('items' ))->render();
            }
    
            return view('panel.subscriptions.items-index', compact('items'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
        // return view('panel.subscriptions.items-index',compact('subscriptions'));
    }

    public function addSubscription(){
    try{
        $items = SubscriptionItems::where('status',1)->get();
        return view('panel.subscriptions.add-subscription',compact('items'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function addItem(){
        try{
        // $items = SubscriptionItems::where('status',1)->get();
        return view('panel.subscriptions.add-item');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editSubscription($id){
        try{
        $items = SubscriptionItems::where('status',1)->get();
        $subscription = SubscriptionPlans::where('id',$id)->first();
        // if (!auth()->user()->can('edit plan')) {
        //     return redirect()->route('access.denied'); // Redirect if no permission to edit
        // }
        return view('panel.subscriptions.edit-subscription',compact('subscription','items'));
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', __('Something went wrong.'));
        }
    }

    public function editItem($id){
        try{
        // $items = SubscriptionItems::where('status',1)->get();
        $item = SubscriptionItems::where('id',$id)->first();
        // if (!auth()->user()->can('edit plan')) {
        //     return redirect()->route('access.denied'); // Redirect if no permission to edit
        // }
        return view('panel.subscriptions.edit-item',compact('item'));
    } catch (\Throwable $e) {
        return redirect()->back()->with('error', __('Something went wrong.'));
    }
    }

    public function deleteSubscription($id)
    {
        try {
            // Attempt to delete the user by ID
            SubscriptionPlans::destroy($id);

            // Return success response
            return response()->json(['success' => true, 'message' => __('Plan deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Plan. Please try again.')], 500);
        }
    }

    public function deleteItem($id){
        try {
            // Attempt to delete the user by ID
            SubscriptionItems::destroy($id);

            // Return success response
            return response()->json(['success' => true, 'message' => __('Item deleted successfully')], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error deleting user: ' . $e->getMessage());

            // Return error response
            return response()->json(['success' => false, 'message' => __('Failed to delete Item. Please try again.')], 500);
        }
    }


    public function addOrEditSubscription(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $subscription_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'price' => 'required|integer',
                'time_period' => 'required|integer',
                'receipts' => 'nullable|string|max:255',
                'invoices' => 'nullable|string|max:255',
            ];
            // Validate the input data  
            

            $SubscriptionPlans = new SubscriptionPlans();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $subscription_data = [
                'name'=> $formdata['name'],
                'price'=> $formdata['price'],
                'time_period'=> $formdata['time_period'],
                'receipts'=> $formdata['receipts'],
                'invoices'=> $formdata['invoices'],
            ];

            if(!empty($subscription_id)){
                $subscription = SubscriptionPlans::where('id', $subscription_id)->update($subscription_data);
            }else{

                $subscription = SubscriptionPlans::create($subscription_data);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Subscription updated successfully.') 
                    : __('Subscription created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditSubscription: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }

    public function getPlans(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = SubscriptionPlans::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $plans = $query->orderBy('id','DESC')->paginate($limit);

            $plans->getCollection()->transform(function ($plan) {
                // Decode the JSON array of item IDs
                $itemIds = $plan->items;
    
                if (is_array($itemIds) && !empty($itemIds)) {
                    // Fetch the corresponding service names
                    $services = SubscriptionItems::whereIn('id', $itemIds)->pluck('name')->toArray();
    
                    // Convert to comma-separated string
                    $plan->service_names = implode(', ', $services);
                } else {
                    $plan->service_names = 'No Services';
                }
    
                return $plan;
            });

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Plans retrieved successfully.',
                'data' => $plans,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve plans.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function getItems(Request $request){
        try {
            $user = auth()->user();
            $limit = $formdata['limit'] ?? 15;
            $formdata = $request->all();
            // Base query excluding the authenticated user and filtering by role ID 2
            $query = SubscriptionItems::query();

            // Apply search filter
            if (isset($formdata['search']) && !empty($formdata['search'])) {
                $query->where(function ($q) use ($formdata) {
                    $q->where('name', 'like', '%' . $formdata['search'] . '%');
                });
            }

            // Apply status filter
            if (isset($formdata['status']) && !is_null($formdata['status'])) {
                $query->where('status', $formdata['status']); // Assuming `status` is a column in the `users` table
            }

            

            // Fetch paginated results with related data
            $items = $query->orderBy('id','DESC')->paginate($limit);

            

            // Return JSON response
            return response()->json([
                'success' => true,
                'message' => 'Items retrieved successfully.',
                'data' => $items,
            ], 200);

        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve plans.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function addOrEditSubscriptionItems(Request $request)
    {
        try {
            // Extract form data
            $formdata = $request->all();

            $subscription_items_id = $formdata['id'] ?? null;
            // dd($userId);
            // Validation rules
            $rules = [
                'name' => 'required|string|max:255',
            ];
            // Validate the input data  
            

            $SubscriptionItems = new SubscriptionItems();

            $validator = Validator::make($formdata, $rules);

            // If validation fails, return errors
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('Validation failed.'),
                    'errors' => $validator->errors()
                ], 200);
            }

            $subscription_items_data = [
                'name'=> $formdata['name'],
                'slug' => str_replace(' ', '-', strtolower($formdata['name'])),
            ];

            if(!empty($subscription_items_id)){
                $subscriptionItems = SubscriptionItems::where('id', $subscription_items_id)->update($subscription_items_data);
            }else{

                $subscriptionItems = SubscriptionItems::create($subscription_items_data);
            }
            
            // Return success response
            return response()->json([
                'success' => true,
                'message' => isset($formdata['id']) 
                    ? __('Subscription items updated successfully.') 
                    : __('Subscription items created successfully.')
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            Log::error('Error in addOrEditSubscriptionItems: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => __('An error occurred. Please try again.'),
                'error' => $e->getMessage(), // Error message
                'line' => $e->getLine(),     // Line number where the error occurred
                'file' => $e->getFile(),     // File where the error occurred
            ], 500);
        }
    }
    public function statusupdate(Request $request, $id)
     {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            // $company = $user->company;

            // if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            //     // If it's a collection, take the first item
            //     $company = $company->first();
            // }
    
            // Find the inventory item
            
                $user = SubscriptionItems::findOrFail($id);
                $user->status = $request->status;
                $user->save();
            
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Items status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Clients status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
     }

     public function partialplanstatusupdate(Request $request, $id)
     {
        try {
            // Validate the request
            $request->validate([
                'status' => 'required|string'
            ]);
            $user = auth()->user();
            $formdata = $request->all();
            // $company = $user->company;

            // if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            //     // If it's a collection, take the first item
            //     $company = $company->first();
            // }
    
            // Find the inventory item
            
                $user = SubscriptionPlans::findOrFail($id);
                $user->status = $request->status;
                $user->save();
            
    
            // Return success response
            return response()->json([
                'success' => true, 
                'message' => __('Plans status updated successfully')
            ], 200);
        } catch (\Exception $e) {
            // Log the exception for debugging
            Log::error('Error updating Clients status: ' . $e->getMessage());
    
            // Return error response
            return response()->json([
                'success' => false, 
                'message' => __('Failed to update status. Please try again.')
            ], 500);
        }
     }
     
     public function deletePlan($id)
     {
         try {
             // Attempt to delete the user by ID
             SubscriptionPlans::destroy($id);
 
             // Return success response
             return response()->json(['success' => true, 'message' => __('Plan deleted successfully')], 200);
         } catch (\Exception $e) {
             // Log the exception for debugging
             Log::error('Error deleting user: ' . $e->getMessage());
 
             // Return error response
             return response()->json(['success' => false, 'message' => __('Failed to delete Plan. Please try again.')], 500);
         }
     }
}
