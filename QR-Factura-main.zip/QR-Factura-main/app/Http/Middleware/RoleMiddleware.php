<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Spatie\Permission\Models\Permission;


class RoleMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect('/admin/login');
        }

        $user = Auth::user();

        if (!$user->hasAnyRole($user->roles)) {
            abort(403, 'Unauthorized action.');
        }

        $currentUrl = preg_replace('/^admin\//', '', $request->path());
        $allPermissions = $user->getAllPermissions()->pluck('name');

        // foreach ($allPermissions as $permissionName) {
        //     $permission = Permission::where('name', $permissionName)->first();
        //     if ($permission && $this->matchUrlPattern($permission->name, $currentUrl)) {
        //         Log::info('Permission granted for URL: ' . $currentUrl);
        //         return $next($request);
        //     }else{
        //         return redirect()->route('access.denied');
        //         abort(403, 'Unauthorized action.');
        //     }
        // }

        return $next($request);
    }

    private function matchUrlPattern($pattern, $url)
    {
        $pattern = str_replace('*', '.*', preg_quote($pattern, '/')); // Convert wildcard to regex
        return preg_match('/^' . $pattern . '$/', $url);
    }

}

