<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\TokenOrigin;

class CheckTokenOrigin
{
    public function handle(Request $request, Closure $next)
    {
    
        $user = $request->user();
        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => __('Unauthenticated'),
            ], 401);
        }
        $token = $user->token();
        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => __('Token not found'),
            ], 401);
        }


        $tokenOrigin = TokenOrigin::where('token_id', $token->id)->first();
        $requestOrigin = $request->headers->get('origin') ?? $request->headers->get('referer');
        $tokenOriginUrl = parse_url($tokenOrigin->origin, PHP_URL_HOST);
        $requestOrigin = parse_url($requestOrigin, PHP_URL_HOST);

        // return $requestHost === $allowedHost;
        if (!$tokenOrigin || $tokenOriginUrl !== $requestOrigin) {
            return response()->json([
                'success' => false,
                'message' => __('Origin not match'),
            ], 403);
        }

        return $next($request);
    }
}
