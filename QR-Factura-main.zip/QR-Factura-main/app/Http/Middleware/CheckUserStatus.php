<?php

    namespace App\Http\Middleware;

    use Closure;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Carbon\Carbon;
    use App\Models\UserSubscriptions;
    use App\Models\User;

    class CheckUserStatus
    {
        public function handle(Request $request, Closure $next)
        {
            $user = Auth::user();
            
            // Check if the user's account is disabled
            if ($user && !$user->status) {  // Assuming 'status' is a boolean field, where 0 = disabled, 1 = active
                Auth::logout();  // Logout the user
                return redirect(route('login'))->with('error', __('Your account is disabled.'));  // Redirect to login with an error message
            }
           
            $role = $user->roles->first() ?? null;
            if($user && $role && $role->name == 'Company' || $role->name == 'CompanyStaff' || $role->name == 'CompanyAdmin'){
                $company = $user->company;
                // dd($company);
                if(empty($company)){
                    Auth::logout();  // Logout the user
                    return redirect(route('login'))->with('error', __('Your Company is disabled.'));
                }
                // dd($company);

                $adminUser = User::where('id',$company->admin_id)->first();
                if($adminUser && $adminUser->status == 0){
                    Auth::logout();  // Logout the user
                    return redirect(route('login'))->with('error', __('Your account is disabled.'));  // Redirect to login with an error message
                }
                
                $subscription = UserSubscriptions::where('user_id',$company->admin_id)->where('status',1)->orderBy('id','desc')->first();
                if (!$subscription) {
                    // If no subscription or the subscription has expired
                    Auth::logout();  // Optionally log the user out if the subscription is expired
                    return redirect(route('login'))->with('error', __('You don\'t have any active plan.')); // Redirect to login with an error message
                }
                if(Carbon::parse($subscription->end_date)->isPast()){
                    // If no subscription or the subscription has expired
                    Auth::logout();  // Optionally log the user out if the subscription is expired
                    return redirect(route('login'))->with('error', __('You plan is expired please renew it.')); // Redirect to login with an error message
                }
                
            }
            return $next($request);
        }
    }

