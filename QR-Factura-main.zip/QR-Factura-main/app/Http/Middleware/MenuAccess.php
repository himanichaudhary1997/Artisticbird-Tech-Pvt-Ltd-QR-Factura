<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Menu;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\View;
use Spatie\Permission\Models\Role;
class MenuAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $currentUrl = $request->fullUrl(); 
        // $currentUrl = $request->fullUrl(); // Get the full URL including query parameters

        // Parse the URL and remove the query string
        $parsedUrl = parse_url($currentUrl);

        // Rebuild the URL without the query parameters
        $currentUrl = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] . '://' : '';
        $currentUrl .= isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
        $currentUrl .= isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
        // dd($currentUrl);

        $menu = Menu::where('url', $currentUrl)->first();
        

        // dd($menu);
        
        if (!$menu) {
            return redirect()->route('access.denied'); // If menu doesn't exist, redirect
        }
        
        // Check if the user has permission for the menu or its parent
        $permissionName = strtolower($menu->name);
        $parentMenu = $menu->parent;
        // dd($permissionName);
        if ($parentMenu) {
            $parentPermissionName = strtolower($parentMenu->name);
    
            if (auth()->user()->can($parentPermissionName)) {
                // User has parent permission, now check for child permissions
    
                $childPermissions = $parentMenu->children->map(function ($childMenu) {
                    return strtolower($childMenu->name); // Get the child permission names
                });
                // dd($childPermissions);
    
                // Scenario 1: If the user has parent permission and no specific child permission
                // Allow access to parent menu and all its child menus
                if (auth()->user()->hasAnyPermission($childPermissions)) {
                    // User has at least one child permission, check for specific child
                    if (auth()->user()->can(strtolower($menu->name))) {
                        return $next($request);
                    } else {
                        return redirect()->route('access.denied'); // Deny access if child permission is not found
                    }
                } else {
                    // Scenario 2: If user has parent permission, but no child permissions assigned
                    return $next($request); // Allow access to parent menu and all child menus
                }
            } else {
                // Scenario 3: User does not have parent permission, deny access
                return redirect()->route('access.denied');
            }
        } else {
            // If the parent menu doesn't exist (it's a child menu)
            if (!auth()->user()->can(strtolower($menu->name))) {
                // User does not have permission for this child menu, deny access
                return redirect()->route('access.denied');
            }
        }
        

        return $next($request);
    }
}
