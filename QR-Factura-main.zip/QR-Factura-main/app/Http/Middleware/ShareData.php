<?php

namespace App\Http\Middleware;

use App\Models\Company;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Menu;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\View;
use Spatie\Permission\Models\Role;
use App\Models\Issues;
use App\Models\Messages;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ShareData
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = auth()->user();
        // dd($user->company);
        $company = $user->company;
        if (Auth::check()) {
            $role = $user->roles->first() ?? null;
            if($role->name != 'Accountant' && $role->name != 'CompanyAccountant'){
                $locale = $user->extra['language'] ?? $user->company->extra['language'] ?? 'es';
            }else{
                $locale = $user->extra['language'] ?? 'es';
            }
            // dd($locale);
            App::setLocale($locale);
        }
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();
        }
        // $role = $user->roles->first();
        // $roleName = optional($role)->name;

        // $currentUrl = $request->path(); 
        // // $permissionName = str_replace('admin/', '', $currentUrl); 
        // $permissionName = $request->route()->getName();
        // $permissionName = Str::lower($request->route()->getName());
        // // dd($permissionName);

        // if ($role && !$role->hasPermissionTo($permissionName)) {
        //     abort(403, 'You do not have permission to access this resource.'.$permissionName);
        // }

        // $allMenus = Menu::where('status', 1)
        //             ->where('parent_id', 0)
        //             ->when(empty($company), function ($query) {
        //                 return $query->where('url', '!=', 'getClients'); // Exclude 'getClients' if company is empty
        //             })
        //             ->orderBy('order', 'asc')
        //             ->with(['children' => function ($query) use ($company) {
        //                 if (empty($company)) {
        //                     $query->where('url', '!=', 'getClients'); // Exclude 'getClients' from children if company is empty
        //                 }
        //             }])
        //             ->get()
        //             ->map(function ($menu) use ($roleName) {
                    
        //                 $parentPermissionName = Str::lower($menu->url);

        //                 $hasParentPermission = auth()->check() && auth()->user()->can($parentPermissionName);

        //                 $filteredChildren = $menu->children->filter(function ($childMenu) {
        //                     $childPermissionName = Str::lower($childMenu->url);
        //                     return auth()->check() && auth()->user()->can($childPermissionName);
        //                 });
                        
        //                 if ($hasParentPermission || $filteredChildren->isNotEmpty()) {
        //                     $menu->children = $filteredChildren;
        //                     return $menu;
        //                 }
        //                 return null;
        //             })
        //             ->filter()
        //             ->values();

        $roles = $user->roles; // Get all assigned roles

        $currentUrl = $request->path();
        $permissionName = Str::lower($request->route()->getName());
        // $permissionName = $request->route()->getName();
        // dd($request->route()->getName());
        // Check if the user has at least one role that grants the required permission
        $hasPermission = $roles->contains(function ($role) use ($permissionName) {
            return $role->hasPermissionTo($permissionName);
        });

        if (!$hasPermission) {
            abort(403, 'You do not have permission to access this resource: ' . $permissionName);
        }

        $allMenus = Menu::where('status', 1)
            ->where('parent_id', 0)
            ->when(empty($company), function ($query) {
                $query->whereNotIn('url', ['getClients', 'allCompanyAdmins']); // Exclude 'getClients' if company is empty
            })
            ->when(!empty($company), function ($query) use ($company) {
                if($company->id != 13){
                    $query->whereNotIn('url', ['getDocuments', 'getDocumentsCategories','media.index']); // Exclude 'getClients' if company is empty
                }
                
                // if($company->id != 3){
                //     $query->whereNotIn('url', ['faqs.index','tutorials.index']); // Exclude 'getClients' if company is empty
                // }


                // if(!$company->is_verifactu){
                //     $query->whereNotIn('url', ['indexSiteApis']); // Exclude 'getClients' if company is empty
                // }
            })
            ->orderBy('order', 'asc')
            ->with(['children' => function ($query) use ($company) {
                if (empty($company)) {
                    $query->whereNotIn('url', ['getClients', 'allCompanyAdmins']); // Exclude 'getClients' from children if company is empty
                }
                if(!empty($company) && $company->id != 13){
                    $query->whereNotIn('url', ['allAccountants']); // Exclude 'getClients' if company is empty
                }
            }])
            ->get()
            ->map(function ($menu) use ($roles) {
                $parentPermissionName = Str::lower($menu->url);
                // dd($parentPermissionName);
                // Check if any assigned role has the permission for the parent menu
                $hasParentPermission = '';
                if($menu->url != '#'){
                    $hasParentPermission = $roles->contains(function ($role) use ($parentPermissionName) {
                        return auth()->check() && $role->hasPermissionTo($parentPermissionName);
                    });
                }

                

                // Filter children based on permissions for multiple roles
                $filteredChildren = $menu->children->filter(function ($childMenu) use ($roles) {
                    $childPermissionName = Str::lower($childMenu->url);

                    return $roles->contains(function ($role) use ($childPermissionName) {
                        return auth()->check() && $role->hasPermissionTo($childPermissionName);
                    });
                });

                if ($hasParentPermission || $filteredChildren->isNotEmpty()) {
                    $menu->children = $filteredChildren;
                    return $menu;
                }
                return null;
            })
            ->filter()
            ->values();

// dd($allMenus);
                $allPermissions = auth()->user()->getAllPermissions();
                $allUserPermissions = [];
        
                // Loop through each permission and classify them into parent-child structure
                foreach ($allPermissions as $permission) {
                    if ($permission->parent_id === null) {
                        // If permission is a parent (parent_id is null), add to the userPermissions structure
                        $allUserPermissions[$permission->name] = [
                            'parent' => $permission,
                            'children' => []
                        ];
                    }
                }

        
                // Loop through again to assign children to their respective parents
                foreach ($allPermissions as $permission) {
                    if ($permission->parent_id !== null) {
                        // Find the parent of this permission and add it to the parent’s children
                        $userParentPermission = $allPermissions->firstWhere('id', $permission->parent_id);
                        if ($userParentPermission) {
                            $allUserPermissions[$userParentPermission->name]['children'][] = $permission->name;
                        }
                    }
                }

        $allCompanies = Company::get();


        // Step 1: Get all unread messages for all issues (filtered by company)
        // $unreadMessages = Messages::where('is_read', 0)
        //     ->when(isset($user->company) && !empty($company), function ($query) use ($company) {
        //         $query->whereHas('issue', function ($subQuery) use ($company) {
        //             $subQuery->where('company_id', $company->id);
        //         });
        //     })
        //     ->where('user_id', '!=', $user->id)
        //     ->orderBy('created_at', 'DESC')
        //     ->get();

        // // Step 2: Get issue IDs that have unread messages
        // $issuesWithUnread = $unreadMessages->pluck('issue_id')->unique();

        // // Step 3: Get issue IDs that DO NOT have unread messages (filtered by company)
        // $issuesWithoutUnread = Issues::whereNotIn('id', $issuesWithUnread)
        //     ->when(isset($company) && !empty($company), function ($query) use ($company) {
        //         $query->where('company_id', $company->id);
        //     })
        //     ->pluck('id');

        // // Step 4: Get latest 2 read messages for issues that do not have unread messages (filtered by company)
        // $readMessages = Messages::whereIn('issue_id', $issuesWithoutUnread)
        //     ->where('is_read', 1)
        //     ->where('user_id', '!=', $user->id)
        //     ->when(isset($company) && !empty($company), function ($query) use ($company) {
        //         $query->whereHas('issue', function ($subQuery) use ($company) {
        //             $subQuery->where('company_id', $company->id);
        //         });
        //     })
        //     ->orderBy('created_at', 'DESC')
        //     ->get()
        //     ->groupBy('issue_id')
        //     ->map(function ($messages) {
        //         return $messages->take(2); // Get only the latest 2 read messages per issue
        //     })
        //     ->collapse(); // Flatten the collection
        // $unreadMessages = $unreadMessages->merge($readMessages);

        // Step 1: Get all open issues (filtered by company)
        // Step 1: Get all open issues for the company
            $openIssues = Issues::where('status', 0)
            ->when(isset($company) && !empty($company), function ($query) use ($company) {
                $query->where('company_id', $company->id);
            })
            ->pluck('id');

            // Step 2: Get all unread messages for open issues
            $unreadMessages = Messages::where('is_read', 0)
            ->whereIn('issue_id', $openIssues)
            ->where('user_id', '!=', $user->id)
            ->orderBy('id', 'DESC')
            ->get();

            // Step 3: Get issue IDs that have unread messages
            $issuesWithUnread = $unreadMessages->pluck('issue_id')->unique();

            // Step 4: Get open issue IDs that DO NOT have unread messages
            $issuesWithoutUnread = $openIssues->diff($issuesWithUnread);

            // Step 5: Fetch the latest 2 read messages for open issues that do not have unread messages
            $readMessages = Messages::whereIn('issue_id', $issuesWithoutUnread)
            ->where('is_read', 1)
            ->where('user_id', '!=', $user->id)
            ->orderBy('id', 'DESC')
            ->get()
            ->groupBy('issue_id')
            ->map(function ($messages) {
                return $messages->take(2); // Get only the latest 2 read messages per issue
            })
            ->collapse(); // Flatten the collection

            // Step 6: Merge unread messages first, followed by read messages
            $allMessages = $unreadMessages->merge($readMessages);

            // Step 7: Fetch issues separately and manually merge
            $issuesWithUnreadList = Issues::whereIn('id', $issuesWithUnread)
            ->orderBy('id', 'DESC') // Latest unread issues first
            ->get();

            $issuesWithoutUnreadList = Issues::whereIn('id', $issuesWithoutUnread)
            ->orderBy('id', 'DESC') // Latest read issues next
            ->get();

            // Step 8: Manually merge collections to maintain correct order
            $orderedIssues = $issuesWithUnreadList->merge($issuesWithoutUnreadList);

        
        
        // dd($allMenus);
        // To share all menus in all the view files
        View::share('allMenus', $allMenus);
        View::share('allCompanies', $allCompanies);
        View::share('allUserPermissions', $allUserPermissions);
        View::share('unreadMessages', $unreadMessages);
        View::share('orderedIssues',$orderedIssues);

        // if (
        //     $company && 
        //     !$company->is_agree && 
        //     request()->route()->getName() !== 'profile' && request()->route()->getName() !== 'getstates'  && request()->route()->getName() !== 'updateAdminUser'
        // ) {
        //     return redirect()->route('profile')->with('error','Please fill the required details to continue with our invoicing system.');
        // }



        return $next($request);
    }
}
