<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
// use Illuminate\Broadcasting\ShouldBroadcast;
use Illuminate\Queue\SerializesModels;
use App\Models\Messages;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class NewMessage implements ShouldBroadcast
{
    // use InteractsWithSockets, SerializesModels;

    // public $message;

    // public function __construct(Messages $message)
    // {
    //     $this->message = $message;
    // }

    // public function broadcastOn()
    // {
    //     return new PrivateChannel('issue.' . $this->message->issue_id);
    // }

    // public function broadcastWith()
    // {
    //     return [
    //         'id' => $this->message->id,
    //         'message' => $this->message->message,
    //         'user' => $this->message->user->name,
    //         'created_at' => $this->message->created_at->toDateTimeString(),
    //     ];
    // }

    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;

    public function __construct(Messages $message)
    {
        $this->message = $message;
        // dd($this->message); 
    }

    public function broadcastOn()
    {
        // dd($this->message->issue_id);
        return  [
            new Channel('issue.' . $this->message->issue_id),
        ];
    }

    public function broadcastAs()
    {
        return 'support-message'; // Pusher event name
    }
}