<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tutorials extends Model
{
    use HasFactory;

    protected $table = 'tutorials';

    protected $fillable = [
        'name',
        'video_url',
        'thumbnail',
        'extra',

    ];

    protected $casts = [
        'extra' => 'array'
    ];

}
