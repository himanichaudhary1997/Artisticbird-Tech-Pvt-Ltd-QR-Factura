<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Company;


class CompanyUsers extends Model
{
    use HasFactory;

    protected $table = 'company_users';

    protected $fillable = [
        'user_id',
        'admin_id',
        'extra'
    ];


    protected $casts = [
        'extra' => 'array'
    ];

    // public function company(){
    //     return $this->hasOne(Company::class, 'id', 'company_id');
    // }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class, 'admin_id', 'admin_id');
    }

    
}

