<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Company;

class Issues extends Model
{
    use HasFactory;

    protected $table = 'issues';

    protected $fillable = [
        'title',
        'company_id',
        'status',
        'extra',
    ];

    protected $casts = [
        'extra' => 'array',
    ];


    public function messages()
    {
        return $this->hasMany(Messages::class, 'issue_id', 'id');
    }

    public function company()
    {
        return $this->belongsTo(Company::class, 'company_id', 'id');
    }
}
