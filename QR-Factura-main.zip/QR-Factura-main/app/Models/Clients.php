<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use App\Models\Company;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class Clients extends Model
{
    use HasFactory;

    // protected $table = 'clients';
    protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'name',
        'slug',
        'email',
        'mobile_no',
        'gst_no',
        'isCompany',
        'status',
        'extra'
    ];
    protected $hidden = ['dynamicTableName'];
    protected $casts = [
        'extra' => 'array',
        'isCompany' => 'boolean',
    ];

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("clients_{$branchId}");
        return $instance;
    }
    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */

    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }


    // public function setDynamicTableName($id = null)
    // {
    //     if (App::runningInConsole() && App::runningUnitTests() === false) {
    //         return;
    //     }
    //     if ($id) {
    //         $dynamicTableName = 'clients_' . $id;
    //     } else {
    //         $user = Auth::user();
    //         $role = $user->roles->first() ?? null;

    //         if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
    //             $company = $user->company;
    //             if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //                 // If it's a collection, take the first item
    //                 $company = $company->first();
    //             }
    //             $companyId = $company->id ?? null;

    //             if ($companyId) {
    //                 $dynamicTableName = 'clients_' . $companyId;
    //             }
    //         }
    //     }

    //     if (!empty($dynamicTableName)) {
    //         // dd($dynamicTableName);
    //         // Check if the table exists, create it if not
    //         if (!Schema::hasTable($dynamicTableName)) {
    //             try {
    //                 // dd('hi');
    //                 $this->createDynamicTable($dynamicTableName);
    //             } catch (\Exception $e) {
    //                 logger()->error('Failed to create dynamic table: ' . $e->getMessage());
    //             }
    //         }

    //         $this->dynamicTableName = $dynamicTableName;
    //     }
    //     // dd($this->dynamicTableName);
    //     return $this;
    // }

    public function setDynamicTableName($id = null)
    {
        // Skip if running in console (artisan)
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return $this;
        }

        if ($id) {
            $dynamicTableName = 'clients_' . $id;
        } else {
            $user = Auth::user();

            // Guest-safe: return immediately if no user
            if (!$user) {
                return $this;
            }

            $role = $user->roles->first() ?? null;

            if ($role && $role->id != 1 && !in_array($role->name, ['Accountant', 'CompanyAccountant'])) {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;

                if ($companyId) {
                    $dynamicTableName = 'clients_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name');
    //         $table->string('email')->nullable();
    //         $table->string('mobile_no')->nullable();
    //         $table->string('gst_no')->unique()->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'clients';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }

    public function singleCompany()
    {
        return $this->hasOne(Company::class, 'admin_id', 'id'); 
        
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class, 'client_id', 'id'); 
        
    }

}
