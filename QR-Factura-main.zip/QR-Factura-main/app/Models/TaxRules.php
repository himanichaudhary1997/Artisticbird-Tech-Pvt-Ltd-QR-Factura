<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TaxRules extends Model
{
    use HasFactory;

    protected $table = 'tax_rules';

    protected $fillable = [
        'name',
        'type',
        'value',
        'RE_value',
        'status',
        'tax_type',
        'extra'
    ];

    protected $casts = [
        'extra' => 'array',
    ];
}
