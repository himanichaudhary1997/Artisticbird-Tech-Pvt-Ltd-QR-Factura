<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class ClientAccountantRelation extends Model
{
    use HasFactory;

    protected $table = 'accountant_clients';
    private $dynamicTableName;
    protected $fillable = ['client_id', 'accountant_id', 'extra','admin_id'];

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("accountant_clients{$branchId}");
        return $instance;
    }

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }

    return $this->dynamicTableName ?: parent::getTable();
    }


    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        // dd($id);
        if ($id) {
            $dynamicTableName = 'accountant_clients_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company()->first(); // Ensure it's a single record
                $companyId = $company->id ?? null;

                if ($companyId) {
                    $dynamicTableName = 'accountant_clients_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('client_id')->nullable();
    //         $table->foreignId('accountant_id')->nullable()->constrained('users')->onDelete('set null');
    //         $table->json('extra')->nullable();
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'accountant_clients';

        if (Schema::hasTable($tableName)) {
            return;
        }

        try {
            DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");

            $fkName = "{$tableName}_accountant_id_foreign_key";
            DB::statement("
                ALTER TABLE `{$tableName}`
                ADD CONSTRAINT `{$fkName}`
                FOREIGN KEY (`accountant_id`)
                REFERENCES `users`(`id`)
                ON DELETE SET NULL
            ");
        } catch (\Throwable $e) {
            Schema::dropIfExists($tableName);
            throw $e;
        }
    }




    public function client(): BelongsTo
    {
        return $this->belongsTo(User::class, 'client_id');
    }


    
    public function accountant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'accountant_id');
    }

}
