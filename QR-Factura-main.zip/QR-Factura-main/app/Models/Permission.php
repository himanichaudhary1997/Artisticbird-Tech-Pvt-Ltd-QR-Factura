<?php

namespace App\Models;

use Spatie\Permission\Models\Permission as SpatiePermission;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

use Spatie\Permission\Models\Role;
use Illuminate\Database\Eloquent\Model;

class Permission extends SpatiePermission
{
    protected static function boot()
    {
        parent::boot();

        static::created(function ($permission) {
            $adminRole = Role::where('name', 'Admin')->first();
            if ($adminRole) {
                $adminRole->givePermissionTo($permission);
            }
        });
    }

    public function children(): HasMany
    {
        return $this->hasMany(Permission::class, 'parent_id')->with('children');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Permission::class, 'parent_id');
    }
}
