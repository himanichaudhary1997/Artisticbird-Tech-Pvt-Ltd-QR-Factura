<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Projects;
use App\Models\Clients;
use App\Models\InvoiceType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class Performa extends Model
{
    use HasFactory;

    protected $table = 'performas';
    // protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'performa_id',
        // 'name',
        'client_id',
        'currency',
        'issue_date',
        'due_date',
        'payment_method',
        'items',
        'extra',
        'status',
        'subtotal',
        'totalDiscount',
        'totalTax',
        'grandTotal',
        'created_by',
        'domain_id'
    ];
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $casts = [
        'extra' => 'array',
        'items' => 'array',
    ];
    


    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("performas_{$branchId}");
        return $instance;
    }

    


    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    // elseif (session()->has('sup_company_id')) {
    //         // Case 2: User selected a company from UI
    //         $companyId = session('sup_company_id');
    //         $dynamicTableName = 'performas_' . $companyId;
    //     }

    public function setDynamicTableName($id = null)
    {
        // if (App::runningInConsole() && App::runningUnitTests() === false) {
        //     return;
        // }
        if (!empty($id)) {
            $dynamicTableName = 'performas_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'performas_' . $companyId;
                }
            }
        }
        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd($this->dynamicTableName);
        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        $parts = explode('_', $tableName);
        $id = end($parts);
        $originalInvoiceTable = 'performas';

        if (!Schema::hasTable($tableName)) {
            // Duplicate structure
            DB::statement("CREATE TABLE {$tableName} LIKE {$originalInvoiceTable}");

            // Make sure the column has proper type before FK
            $fkName = "{$tableName}_created_by_foreign_key";

            DB::statement("
                ALTER TABLE `{$tableName}`
                ADD CONSTRAINT `{$fkName}`
                FOREIGN KEY (`created_by`)
                REFERENCES `users`(`id`)
                ON DELETE SET NULL
            ");
            DB::statement("ALTER TABLE {$tableName} MODIFY client_id BIGINT UNSIGNED NULL");

            // Now safely add the new foreign key constraint
            DB::statement("
                ALTER TABLE `{$tableName}` 
                ADD CONSTRAINT `{$tableName}_client_id_foreign_key` 
                FOREIGN KEY (`client_id`) 
                REFERENCES `clients_{$id}`(`id`) 
                ON DELETE SET NULL
            ");
        }
    }


    public function contract()
    {
        return $this->hasOne(Contracts::class, 'performa_id');
    }

    public function client($companyId = null, $productId =null)
    {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if($companyId && $productId){
            $clients = Clients::forUsers($companyId)->where('id', $productId)->first();
            // dd($companyId);
            return $clients;
        }else{
            if(empty($company)){
                return $this->belongsTo(User::class, 'client_id');
            }else{
                // dd('hi');
                return $this->belongsTo(Clients::class, 'client_id');
            }
        }

        

    }

    public function invoice()
    {
        // 'extra->performa_id' tells MySQL to look inside the JSON
        return Invoice::where('extra->performa_id', $this->id)->first();
    }
    
    public function adminClient($companyId = null, $productId =null)
    {
        return $this->belongsTo(User::class, 'client_id');
    }

    public function invoiceType()
    {
        return $this->belongsTo(InvoiceType::class, 'invoice_type');
    }


    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethods::class, 'payment_method');
    }

    

    public function generateInvoiceQrCode()
    {
        $user = Auth::user();
        $company = $user->company;
        $uniqueString = Str::random(40); // Generate a random unique string
        $nameString = Str::random(10);
        $nif = $company->gst_no ?? null;
        $numserie = $this->invoice_id;
        $fecha = \Carbon\Carbon::parse($this->issue_date)->format('d-m-Y');

        $importe = truncateToTwoDecimals(parseNumber($this->grandTotal));

        $downloadUrl = "https://www2.agenciatributaria.gob.es/wlpl/TIKE-CONT/ValidarQRNoVerifactu?nif={$nif}&numserie={$numserie}&fecha={$fecha}&importe={$importe}";


        $filePath = "qrcodes/{$company->company_slug}/invoice_{$nameString}.png";
        if (!empty($this->extra['qr_code']) && Storage::disk('public')->exists($this->extra['qr_code'])) {
            Storage::disk('public')->delete($this->extra['qr_code']);
        }
        // Generate and store QR Code
        $qrCode = QrCode::format('png')->size(400)->margin(1)->generate($downloadUrl);
        Storage::disk('public')->put($filePath, $qrCode);

        // Save QR Code path
        $this->extra = array_merge($this->extra ?? [], ['qr_code' => $filePath]);
        $this->save();
    }
}
