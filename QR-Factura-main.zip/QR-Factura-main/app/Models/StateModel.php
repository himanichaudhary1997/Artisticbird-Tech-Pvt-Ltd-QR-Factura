<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StateModel extends Model
{
    use HasFactory;

    protected $table = 'states';

    protected $fillable = [
        'name',
        'state_code',
        'country_id',
        'extra',
    ];

    protected $casts = [
        'extra' => 'array',
    ];

    public function country()
    {
        return $this->belongsTo(CountryModel::class, 'country_id');
    }
}
