<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class InvoicePrefix extends Model
{
    use HasFactory;

    protected $table = 'invoice_prefix_series';
    private $dynamicTableName;
    protected $fillable = [
        'prefix',
        'series',
        'extra',
        'status',
    ];

    protected $hidden = ['dynamicTableName'];
    protected $casts = [
        'extra' => 'array'
    ];

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("invoice_prefix_series_{$branchId}");
        return $instance;
    }
    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */

    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }


    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        if ($id) {
            $dynamicTableName = 'invoice_prefix_series_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;

            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;

                if ($companyId) {
                    $dynamicTableName = 'invoice_prefix_series_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd($this->dynamicTableName);
        return $this;
    }

    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('prefix')->nullable();
    //         $table->string('series')->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'invoice_prefix_series';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }
}
