<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
use Laravel\Passport\HasApiTokens;
use App\Models\Company;
use Spatie\Permission\Traits\HasRoles;
use App\Models\UserSubscriptions;
use App\Models\Role;
use Spatie\Permission\Contracts\Permission;
use Spatie\Permission\Traits\HasPermissions;
use App\Models\CompanyUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles, HasPermissions;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'qr_code',
        'password',
        'phone',
        'status',
        'is_email_verified',
        'email_verified_at',
        'extra',
    ];
    public $timestamps = true;

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'extra' => 'array',
    ];

    public function generateRandomPassword($length = 12, $includeSpecialChars = true) {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $specialChars = '!@#$%^&*()-_=+[]{}|;:,.<>?';
    
        // Include special characters if required
        if ($includeSpecialChars) {
            $characters .= $specialChars;
        }
    
        $password = '';
        $maxIndex = strlen($characters) - 1;
    
        for ($i = 0; $i < $length; $i++) {
            $password .= $characters[random_int(0, $maxIndex)];
        }
    
        return $password;
    }

    public function getStartAndEndDate($months) {
    
        $startDate = date('Y-m-d');
        // $startDate = '2025-02-01';
    
        $endDate = date('Y-m-d', strtotime("+$months months", strtotime($startDate)));
      
        return [
            'start_date' => $startDate,
            'end_date' => $endDate,
        ];
    }


    // public function permissions()
    // {
    //     return $this->morphToMany(Permission::class, 'model', 'model_has_permissions', 'model_id', 'permission_id');
    // }
    
    
    // public function hasPermissionForUrl($url)
    // {
    //     if ($this->roles->isEmpty()) {
    //         Log::warning('User has no roles assigned.', ['user_id' => $this->id]);
    //         return false;
    //     }

    //     $allPermissions = $this->getAllPermissions();

    //     // $permissions = $this->permissions()->pluck('name');
        
    //     foreach ($allPermissions as $permissionName) {
    //         $permission = Permission::where('name', $permissionName)->first();
    //         if ($permission && $this->matchUrlPattern($permission->url_pattern, $url)) {
    //             Log::info('Permission granted for URL: ' . $url);
    //             return true;
    //         }
    //     }
    //     return false;
    // }

    
    // public function company()
    // {
    //     return $this->hasOne(Company::class, 'admin_id', 'id');
    // }

    // public function company()
    // {
    //     $user = Auth::user();
    //     $role = $user->roles->first() ?? null;
        
    //     if ($user && $role && ($role->id == 2 || $role->id == 1)) { 
    //         return $this->hasOne(Company::class, 'admin_id', 'id');
    //     } else {
    //         $companyUser = CompanyUsers::where('user_id', $user->id)->with('company')->first();
    //         return $this->belongsToMany(Company::class, 'company_users', 'admin_id', 'admin_id');
    //     }
    // }

    public function company()
    {
        $user = Auth::user();
        $role = $this->roles->first(); // Get the first assigned role

        if (!$role) {
            return null; // No role assigned
        }

        // dd($this->activeCompany);
        // if ($this->hasRole('SupCompany') && $this->activeCompany) {
        //     return $this->hasOneThrough(
        //         Company::class,         // Final model
        //         SuperActiveCompany::class, // Intermediate model
        //         'user_id',              // FK on super_active_companies -> users.id
        //         'id',                   // FK on companies -> companies.id
        //         'id',                   // Local key on users table
        //         'company_id'            // Local key on super_active_companies table
        //     );
        // }


        if ($role->name === 'Admin' || $role->name == 'Company') {
            return $this->hasOne(Company::class, 'admin_id', 'id'); 
        } 
        
        if (in_array($role->name, ['Staff', 'Support', 'CompanyStaff','CompanyAdmin'])) {
            return $this->hasOneThrough(Company::class, CompanyUsers::class, 'user_id', 'admin_id', 'id', 'admin_id');
        }

        if (in_array($role->name, ['Accountant','CompanyAccountant'])) {
            return $this->hasManyThrough(Company::class, CompanyUsers::class, 'user_id', 'admin_id', 'id', 'admin_id');
        }
        
    }

    public function activeCompany()
    {
        return $this->hasOne(SuperActiveCompany::class, 'user_id', 'id');
    }


    // public function getCompanyAttribute()
    // {
    //     $role = $this->roles->first();
    //     if (!$role) return null;

    //     // If SupCompany → return session selected
    //     if ($this->hasRole('SupCompany') && session()->has('sup_company_id')) {
    //         return Company::find(session('sup_company_id'));
    //     }

    //     // Admin/Company
    //     if ($role->name == 'Company') {
    //         return $this->hasOne(Company::class, 'admin_id', 'id')->first(); 
    //     }

    //     // Staff / Support / CompanyStaff / CompanyAdmin
    //     if (in_array($role->name, ['Staff','Support','CompanyStaff','CompanyAdmin'])) {
    //         return $this->hasOneThrough(
    //             Company::class,
    //             CompanyUsers::class,
    //             'user_id',
    //             'admin_id',
    //             'id',
    //             'admin_id'
    //         )->first();
    //     }

    //     // Accountant / CompanyAccountant
    //     if (in_array($role->name, ['Accountant','CompanyAccountant'])) {
    //         return $this->hasManyThrough(
    //             Company::class,
    //             CompanyUsers::class,
    //             'user_id',
    //             'admin_id',
    //             'id',
    //             'admin_id'
    //         )->first();
    //     }

    //     return null;
    // }

    // public function company()
    // {
    //     $role = $this->roles->first();

    //     // Role: SupCompany → dynamic company based on session
    //     if ($this->hasRole('SupCompany') && session()->has('sup_company_id')) {
    //         $supCompanyId = session('sup_company_id');

    //         return $this->belongsTo(Company::class, 'id', 'admin_id')
    //                     ->where('companies.id', $supCompanyId);
    //     }

    //     // Admin / Company
    //     if ($role && in_array($role->name, ['Admin', 'Company'])) {
    //         return $this->hasOne(Company::class, 'admin_id', 'id');
    //     }

    //     // Staff / CompanyStaff / Support
    //     if ($role && in_array($role->name, ['Staff', 'Support', 'CompanyStaff', 'CompanyAdmin'])) {
    //         return $this->hasOneThrough(
    //             Company::class,
    //             CompanyUsers::class,
    //             'user_id',
    //             'admin_id',
    //             'id',
    //             'admin_id'
    //         );
    //     }

    //     // Accountants → many companies
    //     if ($role && in_array($role->name, ['Accountant', 'CompanyAccountant'])) {
    //         return $this->hasManyThrough(
    //             Company::class,
    //             CompanyUsers::class,
    //             'user_id',
    //             'admin_id',
    //             'id',
    //             'admin_id'
    //         );
    //     }

    //     // Default
    //     return $this->hasOne(Company::class, 'admin_id', 'id');
    // }



    public function singleCompany()
    {
        return $this->hasOne(Company::class, 'admin_id', 'id'); 
        
    }





    public function subscriptionDetails()
    {
        return $this->hasOne(UserSubscriptions::class, 'user_id', 'id')
                    ->where('status', 1)
                    ->latest('id');
    }


    public function companyUsers()
    {
        return $this->hasMany(CompanyUsers::class, 'user_id', 'id');
    }

    public function getAllUserPermissions()
    {
        $allPermissions = $this->getAllPermissions();
        $allUserPermissions = [];

        // Classify permissions into parent-child structure
        foreach ($allPermissions as $permission) {
            if ($permission->parent_id === null) {
                $allUserPermissions[$permission->name] = [
                    'parent' => $permission,
                    'children' => []
                ];
            }
        }

        // Assign children to their respective parents
        foreach ($allPermissions as $permission) {
            if ($permission->parent_id !== null) {
                $parentPermission = $allPermissions->firstWhere('id', $permission->parent_id);
                if ($parentPermission) {
                    $allUserPermissions[$parentPermission->name]['children'][] = $permission->name;
                }
            }
        }

        return $allUserPermissions;
    }

    public function companyUser(): HasOne
    {
        return $this->hasOne(CompanyUsers::class, 'user_id');
    }
    

    public function assignedCompanies()
    {
        return $this->hasManyThrough(Company::class, CompanyUsers::class, 'user_id', 'id', 'id', 'company_id');
    }

    public function getCompanyIdAttribute()
    {
        return optional($this->companyUser)->company_id;
    }

    public function assignedClients(): HasMany
    {
        return $this->hasMany(ClientAccountantRelation::class, 'accountant_id')->with('client');
            
    }

    // public function dynamicClients()
    // {
    //     if ($this->hasRole('company_accountant')) {
    //         $companyId = $this->company_id;
            
    //         if ($companyId) {
    //             // Raw Query: Fetch from dynamic table
    //             return collect(DB::table("clients_{$companyId}")
    //                 ->where('accountant_id', $this->id)
    //                 ->get());
    //         }
    //     }

    //     // Default relationship for normal accountants
    //     return $this->hasMany(ClientAccountantRelation::class, 'accountant_id')->with('client');
    // }

    
    // public function dynamicClients(): HasMany
    // {
    //     return $this->hasMany(ClientAccountantRelation::class, 'accountant_id')
    //         ->with(['client' => function ($query) {
    //             if ($this->hasRole('Company_Accountant')) {
    //                 $companyId = $this->company_id;
    //                 if ($companyId) {
    //                     $query->from("clients_{$companyId}")->select("clients_{$companyId}.*");
    //                 }
    //             }
    //         }]);
    // }




    // public function dynamicClients(): HasMany
    // {
    //     $query = $this->hasMany(ClientAccountantRelation::class, 'accountant_id')->with('client');

    //     if ($this->hasRole('Company_Accountant')) {
    //         $companyId = $this->company_id;
    //         if ($companyId) {
    //             return $query->whereRaw("EXISTS (SELECT * FROM clients_{$companyId} WHERE clients_{$companyId}.id = accountant_clients{$companyId}.client_id)");
    //         }
    //     }

    //     return $query;
    // }

    


    public function getclient()
    {
        // Ensure user is authenticated
        if (!Auth::check()) {
            return collect([]); // Return empty collection if user is not authenticated
        }

        $user = Auth::user();

        // Ensure the user is a Company_Accountant and has a company_id
        if ($user->hasRole('Company_Accountant') && !empty($user->company_id)) {
            $companyId = $user->company_id;
            $accountantId = $user->id;

            // Construct dynamic table names
            $accountantClientsTable = "accountant_clients{$companyId}";
            $clientsTable = "clients_{$companyId}";

            // Check if the dynamic tables exist before querying (fixing MariaDB issue)
            $checkAccountantClientsTable = DB::select("SHOW TABLES LIKE '{$accountantClientsTable}'");
            $checkClientsTable = DB::select("SHOW TABLES LIKE '{$clientsTable}'");

            if (empty($checkAccountantClientsTable) || empty($checkClientsTable)) {
                return collect([]); // Return empty collection if tables do not exist
            }

            // Run safe raw SQL query with dynamic table names
            $query = DB::select("
                SELECT * FROM {$accountantClientsTable}
                WHERE accountant_id = ? 
                AND accountant_id IS NOT NULL 
                AND EXISTS (
                    SELECT * FROM {$clientsTable} 
                    WHERE {$clientsTable}.id = {$accountantClientsTable}.client_id
                )
            ", [$accountantId]);

            return collect($query); // Convert array result to collection
        }

        return collect([]); // Default empty response for non-Company_Accountant users
    }

    public function generateQrCode()
    {
        $uniqueString = Str::random(40); // Generate a random unique string
        $downloadUrl = route('downloadUserXml', ['id' => $this->id, 'token' => $uniqueString]);

        $filePath = "qrcodes/user_{$this->id}.png";

        // Generate and store QR Code
        $qrCode = QrCode::format('png')->size(350)->margin(1)->generate($downloadUrl);
        Storage::disk('public')->put($filePath, $qrCode);

        // Save QR Code path
        $this->update(['qr_code' => $filePath]);
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class, 'client_id', 'id'); 
    }


    public function supCompanies()
    {
        return $this->hasMany(SupCompany::class);
    }

    public function companies()
    {
        return $this->hasManyThrough(
            Company::class,
            SupCompany::class,
            'user_id',     // Foreign key on sup_companies
            'id',          // Foreign key on companies
            'id',          // Local key on users
            'company_id'   // Local key on sup_companies
        );
    }

    public function allCompanies()
    {
        $single = $this->singleCompany ? collect([$this->singleCompany]) : collect();

        $sup = $this->companies ?? collect();

        return $single->merge($sup)->unique('id')->values();
    }


}
