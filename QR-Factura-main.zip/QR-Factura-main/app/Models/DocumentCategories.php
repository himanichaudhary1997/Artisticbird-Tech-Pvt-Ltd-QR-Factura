<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DocumentCategories extends Model
{
    use HasFactory;

    protected $table = 'document_categories';

    protected $fillable = ['name','extra','status'];

    private $dynamicTableName;
    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        $user = Auth::user();
        $company_slug = $_COOKIE['accountant_company_slug'] ?? null;

        if(empty($company_slug) || $company_slug == 'undefined'){
            $authcompany = $user->company;
            if ($authcompany instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $authcompany = $authcompany->first();
            }
            $company_slug= $authcompany->company_slug ?? null;
        }
        
        if ($id) {
            $dynamicTableName = 'document_categories_' . $id;
        } else {
            
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'document_categories_' . $companyId;
                }
            }elseif(!empty($company_slug) && ($role->name == 'Accountant' || $role->name == 'CompanyAccountant')){
                $company = Company::where('company_slug',$company_slug)->first();
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'document_categories_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd($this);
        return $this;
        // dd();
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     // dd('hi');
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name')->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'document_categories';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }
}
