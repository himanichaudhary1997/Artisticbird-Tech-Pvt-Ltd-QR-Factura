<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use App\Models\DocumentCategories;
use App\Models\DocumentCategoriesRelation;
use App\Models\Company;
use App\Models\Clients;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DocuemntsModel extends Model
{
    use HasFactory;

    protected $table = 'documents';

    protected $fillable = [
        'client_id',
        'title',
        'document_url',
        'status',
        'extra',
    ];

    private $dynamicTableName;

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("documents_{$branchId}");
        return $instance;
    }

    protected $casts = [
        'extra' => 'array',
        'client_id' => 'array'
    ];

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        if ($id) {
            $dynamicTableName = 'documents_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'documents_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
        // dd();
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     // dd('hi');
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->json('client_id')->nullable();
    //         $table->string('title')->nullable();
    //         $table->string('document_url')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->json('extra')->nullable();
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'documents';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }

    public function categories()
    {   
        $relation_table_name = 'document_categories_relation';
        $user = Auth::user();
        $role = $user->roles->first() ?? null;
        // dd($role);
        if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
            $company = $user->company;

            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                // If it's a collection, take the first item
                $company = $company->first();
            }
            $companyId = $company->id ?? null;
            // dd($user->company);
            if ($companyId) {
                $relation_table_name = 'document_categories_relation_' . $companyId;
                if (!Schema::hasTable($relation_table_name)) {
                    $createTableModel = new DocumentCategoriesRelation();
                    $createTable = $createTableModel->setDynamicTableName($companyId);
                }
            }

            // $createTable = DocumentCategoriesRelation::setDynamicTableName($companyId);
        }
        return $this->belongsToMany(DocumentCategories::class, $relation_table_name, 'document_id', 'category_id');
    }


    public function accountantCategories()
    {
        $relation_table_name = 'document_categories_relation';
        $user = Auth::user();
        $role = $user->roles->first() ?? null;
        // dd($user->company->first()->company_slug);
        $company_slug = $_COOKIE['accountant_company_slug'] ?? null;

        if(empty($company_slug) || $company_slug == 'undefined'){
            $company_slug= $user->company->first()->company_slug ?? null;
        }
        // dd($company_slug);
        $company = Company::where('company_slug',$company_slug)->first();
        // dd($company);
        $companyId = $company->id ?? null;
        if ($companyId) {
            $relation_table_name = 'document_categories_relation_' . $companyId;
        }
        // dd($storedData);
        return $this->belongsToMany(DocumentCategories::class, $relation_table_name, 'document_id', 'category_id');
    }


    public function category_ids()
    {
        return $this->hasMany(DocumentCategoriesRelation::class, 'document_id');
    }

    public function clients()
    {
        $user = Auth::user();
        $company = $user->company;

        // Determine dynamic table names
        $clientsTable = !empty($company) ? "clients_{$company->id}" : "users"; // Use users if no company

        if(!empty($this->client_id)){
            if(!empty($company)){
                return Clients::whereIn('id', $this->client_id) // Decode JSON to array
                    ->get();
            }else{
                return User::whereIn('id', $this->client_id) // Decode JSON to array
                    ->get();
            }
        }

        return collect();
    }



}
