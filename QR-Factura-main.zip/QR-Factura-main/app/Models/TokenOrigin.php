<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TokenOrigin extends Model
{
    protected $fillable = [
        'token_id',
        'origin',
        'api_key_id'
    ];

    // Link to Passport token
    public function token()
    {
        return $this->belongsTo(\Laravel\Passport\Token::class, 'token_id', 'id');
    }
}
