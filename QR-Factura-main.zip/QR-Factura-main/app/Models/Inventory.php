<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class Inventory extends Model
{
    use HasFactory;
    protected $table;
    private $dynamicTableName;
    protected $fillable = [
        'name',
        'slug',
        'price',
        'quantity',
        // 'tax_rate',
        'discount',
        'description',
        'extra',
        'status'
    ];

    protected $casts = [
        'extra' => 'array',
    ];
    protected $hidden = ['dynamicTableName'];

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("inventories_{$branchId}");
        return $instance;
    }

    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }


    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        if ($id) {
            $dynamicTableName = 'inventories_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;

            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;

                if ($companyId) {
                    $dynamicTableName = 'inventories_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
        // dd();
    }

    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name');
    //         $table->string('slug')->nullable();
    //         // $table->string('sku')->unique();
    //         $table->string('price');
    //         $table->integer('quantity')->nullable();
    //         // $table->string('tax_rate')->nullable();
    //         $table->string('discount')->nullable();
    //         $table->text('description')->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'inventories';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }

    public function getPriceAttribute()
    {
        $user = Auth::user();

        $company = $user->company;

        if(!empty($company)){
            $currency = $company->extra['currency'] ?? '€';
        }else{
            $adminUser = User::where('id',1)->first();
            $currency = $adminUser->extra['currency'] ?? '€';
        }
        
        $price = $this->attributes['price'];
        $price = parseNumber($price);
        $price = formatValue($price,$currency);
        // Format price with currency symbol
        return $price;
    }
}
