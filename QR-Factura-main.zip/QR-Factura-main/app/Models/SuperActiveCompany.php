<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuperActiveCompany extends Model
{
    protected $fillable = ['user_id', 'company_id'];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
