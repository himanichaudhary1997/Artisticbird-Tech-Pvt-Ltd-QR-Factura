<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BulkDownload extends Model
{
    use HasFactory;

    protected $fillable = ['company_id', 'created_by', 'status', 'file_path','extra', 'error'];

    protected $casts = [
        'extra'=>'array'
    ];

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}