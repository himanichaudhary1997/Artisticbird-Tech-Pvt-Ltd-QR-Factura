<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserSubscriptions extends Model
{
    use HasFactory;

    protected $table = 'user_subscriptions';

    protected $fillable = [
        'subscription_id',
        'user_id',
        'time',
        'start_date',
        'end_date',
        'invoices',
        'receipts',
        'extra',
        'status'
    ];

    protected $casts = [
        'extra' => 'array',
    ];

    public function subscription()
    {
        return $this->belongsTo(SubscriptionPlans::class, 'subscription_id');
    }

    public function getFormattedStartDateAttribute()
    {
        return $this->start_date ? \Carbon\Carbon::parse($this->start_date)->format('d M Y') : null;
    }

    public function getFormattedEndDateAttribute()
    {
        return $this->end_date ? \Carbon\Carbon::parse($this->end_date)->format('d M Y') : null;
    }

}
