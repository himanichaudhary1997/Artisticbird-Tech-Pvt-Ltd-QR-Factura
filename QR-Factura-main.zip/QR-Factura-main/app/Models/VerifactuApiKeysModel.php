<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VerifactuApiKeysModel extends Model
{
    use HasFactory;

    protected $table = 'verifactu_api_keys';

    protected $fillable = [
        'name',
        'company_id',
        'api_key',
        'allowed_url',
        'status'
    ];

    public function company()
    {
        return $this->hasOne(Company::class, 'id', 'company_id'); 
    }

    protected $casts = [
        'extra' => 'array',
    ];
}
