<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\SubscriptionItems;

class SubscriptionPlans extends Model
{
    use HasFactory;

    protected $table = 'subscriptions_plans';  

    protected $fillable = [
        'name',
        'price',
        'time_period',
        'status'
    ];  


    protected $casts = [
        'items' => 'array',
    ];

    // public function getSubscriptionItemsAttribute()
    // {
    //     return SubscriptionItems::whereIn('id', $this->items)->get();
    // }

    

}
