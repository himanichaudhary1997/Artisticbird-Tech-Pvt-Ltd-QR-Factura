<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class SubUser extends Model
{
    use HasFactory;

    protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'status',
        'is_email_verified',
        'email_verified_at',
        'extra',
    ];

    protected $hidden = ['dynamicTableName'];
    protected $guard_name = 'company_user';
    
    protected $casts = [
        'extra' => 'array'
    ];

    /**
     * Set the table dynamically based on the provided company ID.
     * 
     * @param int $companyId
     * @return SubUser
     */
    public static function forCompany($companyId)
    {
        $instance = new self();
        $instance->setTable("users_{$companyId}");
        return $instance;
    }

    /**
     * Get the table name for this model instance.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    /**
     * Set the dynamic table name based on the company ID or logged-in user's company.
     *
     * @param int|null $companyId
     */
    public function setDynamicTableName($companyId = null)
    {
        if ($companyId) {
            $this->dynamicTableName = 'users_' . $companyId;
        } else {
            // If company ID is not passed, use the logged-in user's company ID
            $user = Auth::guard('web')->user();
            $companyId = $user->company->id ?? null;

            if ($companyId) {
                $this->dynamicTableName = 'users_' . $companyId;
            }
        }

        // If the dynamic table name is set, check if the table exists; if not, create it.
        if (!empty($this->dynamicTableName) && !Schema::hasTable($this->dynamicTableName)) {
            $this->createDynamicTable($this->dynamicTableName);
        }
    }

    /**
     * Create the dynamic table for users in a specific company.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        Schema::create($tableName, function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->bigInteger('phone')->nullable();
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->boolean('is_email_verified')->default(false);
            $table->boolean('status')->default(false);
            $table->string('password');
            $table->json('extra')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function generateRandomPassword($length = 12, $includeSpecialChars = true) {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $specialChars = '!@#$%^&*()-_=+[]{}|;:,.<>?';
    
        // Include special characters if required
        if ($includeSpecialChars) {
            $characters .= $specialChars;
        }
    
        $password = '';
        $maxIndex = strlen($characters) - 1;
    
        for ($i = 0; $i < $length; $i++) {
            $password .= $characters[random_int(0, $maxIndex)];
        }
    
        return $password;
    }
}
