<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class Services extends Model
{
    use HasFactory;

    protected $table = 'services';
    private $dynamicTableName;

    protected $fillable = [
        'name',
        'slug',
        'extra',
        'status',
        'desc',
        'scope',
        'quantity',
        'price',
        // 'tax_rate',
        'discount'
    ];

    protected $casts = [
        'extra' => 'array',
    ];

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }


    public function setDynamicTableName($id = null)
    {
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return;
        }
        if ($id) {
            $dynamicTableName = 'services_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'services_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd();
        return $this;
    }

    // /**
    //  * Create a dynamic table using the specified schema.
    //  *
    //  * @param string $tableName
    //  */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name');
    //         $table->string('slug')->nullable();
    //         $table->string('desc')->nullable();
    //         $table->string('price');
    //         // $table->string('tax_rate')->nullable();
    //         $table->string('discount')->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'services';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }
    public function getPriceAttribute()
    {
        $user = Auth::user();

        $company = $user->company;

        if(!empty($company)){
            $currency = $company->extra['currency'] ?? '€';
        }else{
            $adminUser = User::where('id',1)->first();
            $currency = $adminUser->extra['currency'] ?? '€';
        }
        
        $price = $this->attributes['price'];
        $price = parseNumber($price);
        $price = formatValue($price,$currency);
        // Format price with currency symbol
        return $price;
    }

    // private function getTableId()
    // {
    //     if (!$this->dynamicTableName) {
    //         $this->setDynamicTableName();
    //     }
    //     // dd($this->getTable());
    //     // dd(str_replace('services_', '', $this->getTable()));
    //     return str_replace('services_', '', $this->getTable());
    // }
}
