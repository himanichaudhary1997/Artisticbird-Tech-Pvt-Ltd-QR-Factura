<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionItems extends Model
{
    use HasFactory;

    protected $table = 'subscriptions_items';

    protected $fillable = [
        'name',
        'slug',
        'extra',
        'status',
    ];


    protected $casts = [
        'extra' => 'array',
    ];
}
