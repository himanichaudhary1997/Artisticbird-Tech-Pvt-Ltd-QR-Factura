<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class Invoices extends Model
{
    use HasFactory;

    protected $table; // Dynamically set table name
    protected static $dynamicTableName;
    protected $fillable = [
        'invoice_id',
        'name',
        'client_id',
        'currency',
        'issue_date',
        'due_date',
        'invoice_type',
        'payment_method',
        'ref_no',
        'items',
        'extra',
        'status',
        'created_by'
    ];


    protected $casts = [
        'extra' => 'array',
        'items' => 'array',
    ];
    
    public static function forUsers($id)
    {
        // Create an instance of the model
        $instance = new self();

        // Dynamically generate the table name
        $tableName = "invoices_{$id}";

        // Check if the table exists, and create it if not
        if (!Schema::hasTable($tableName)) {
            Schema::create($tableName, function ($table) {
                $table->id();
                $table->string('invoice_id')->nullable();
                $table->string('name');
                $table->unsignedBigInteger('client_id')->nullable();
                $table->string('currency')->nullable();
                $table->dateTime('issue_date')->nullable();
                $table->dateTime('due_date')->nullable();
                $table->integer('invoice_type')->nullable();
                $table->integer('payment_method')->nullable();
                $table->string('ref_no')->nullable();
                $table->json('items')->nullable();
                $table->json('extra')->nullable();
                $table->boolean('status')->default(false);
                $table->timestamps();
            });

            \Log::info("forUsers: Table {$tableName} created successfully.");
        }

        // Set the dynamically generated table name on the model instance
        $instance->setTable($tableName);

        \Log::info("forUsers: Table dynamically set to {$tableName}");

        return $instance;
    }


    protected function getUserId()
    {
        $tableName = self::$dynamicTableName;
        \Log::info("getUserId: Table name is {$tableName}");
        preg_match('/invoices_(\d+)/', $tableName, $matches);
        return $matches[1] ?? null;
    }

    public function client($companyId, $productId)
    {
        $clients = Clients::forUsers($companyId)->where('id', $productId)->first();
        return $clients;
    }


    
}
