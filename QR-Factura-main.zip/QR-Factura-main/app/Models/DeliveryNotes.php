<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Projects;
use App\Models\Clients;
use App\Models\InvoiceType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class DeliveryNotes extends Model
{
    use HasFactory;

    protected $table = 'delivery_notes';
    // protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'delivery_note_id',
        // 'name',
        'client_id',
        'currency',
        'issue_date',
        'due_date',
        'payment_method',
        'items',
        'extra',
        'status',
        'subtotal',
        'totalDiscount',
        'totalTax',
        'grandTotal',
        'created_by',
        'domain_id'
    ];
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;

    protected $casts = [
        'extra' => 'array',
        'items' => 'array',
    ];
    


    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("delivery_notes_{$branchId}");
        return $instance;
    }

    public function client($companyId = null, $productId =null)
    {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if($companyId && $productId){
            $clients = Clients::forUsers($companyId)->where('id', $productId)->first();
            // dd($companyId);
            return $clients;
        }else{
            if(empty($company)){
                return $this->belongsTo(User::class, 'client_id');
            }else{
                // dd('hi');
                return $this->belongsTo(Clients::class, 'client_id');
            }
        }

        

    }
    
    public function adminClient($companyId = null, $productId =null)
    {
        return $this->belongsTo(User::class, 'client_id');
    }

    public function invoiceType()
    {
        return $this->belongsTo(InvoiceType::class, 'invoice_type');
    }


    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethods::class, 'payment_method');
    }

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    public function setDynamicTableName($id = null)
    {
        // if (App::runningInConsole() && App::runningUnitTests() === false) {
        //     return;
        // }
        if (!empty($id)) {
            $dynamicTableName = 'delivery_notes_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'delivery_notes_' . $companyId;
                }
            }
        }
        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd($this->dynamicTableName);
        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        $parts = explode('_', $tableName);
        $id = end($parts);
        $originalInvoiceTable = 'delivery_notes';

        if (!Schema::hasTable($tableName)) {
            // Duplicate structure
            DB::statement("CREATE TABLE {$tableName} LIKE {$originalInvoiceTable}");

            // Make sure the column has proper type before FK
            $fkName = "{$tableName}_created_by_foreign_key";

            DB::statement("
                ALTER TABLE `{$tableName}`
                ADD CONSTRAINT `{$fkName}`
                FOREIGN KEY (`created_by`)
                REFERENCES `users`(`id`)
                ON DELETE SET NULL
            ");
            DB::statement("ALTER TABLE {$tableName} MODIFY client_id BIGINT UNSIGNED NULL");

            // Now safely add the new foreign key constraint
            DB::statement("
                ALTER TABLE `{$tableName}` 
                ADD CONSTRAINT `{$tableName}_client_id_foreign_key` 
                FOREIGN KEY (`client_id`) 
                REFERENCES `clients_{$id}`(`id`) 
                ON DELETE SET NULL
            ");
        }

        // dd('hi');
        // Schema::create($tableName, function (Blueprint $table) use ($id) {
        //     $table->id();
        //     $table->unsignedBigInteger('reference_id')->nullable();
        //     $table->string('invoice_id')->unique();
        //     $table->unsignedBigInteger('client_id')->nullable();
        //     $table->foreign('client_id')->references('id')->on('clients_' . $id)->onDelete('set null');
        //     $table->string('currency')->nullable();
        //     $table->dateTime('issue_date')->nullable();
        //     $table->dateTime('due_date')->nullable();
        //     $table->integer('invoice_type')->nullable();
        //     $table->integer('payment_method')->nullable();
        //     $table->integer('ref_no')->nullable();
        //     $table->string('subtotal')->nullable();
        //     $table->string('totalDiscount')->nullable();
        //     $table->string('totalTax')->nullable();
        //     $table->string('totalRetencion')->nullable();
        //     $table->string('grandTotal')->nullable();
        //     $table->json('items')->nullable();
        //     $table->json('extra')->nullable();
        //     $table->boolean('status')->default(true);
        //     $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
        //     $table->timestamps();
        // });
    }
}
