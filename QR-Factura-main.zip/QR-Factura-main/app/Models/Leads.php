<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leads extends Model
{
    use HasFactory;

    protected $table = 'leads';

    protected $fillable = [
        'name',
        'last_name',
        'email',
        'phone',
        'message',
        'extra'
    ];

    protected $casts = [
        'extra' => 'array'
    ];
}
