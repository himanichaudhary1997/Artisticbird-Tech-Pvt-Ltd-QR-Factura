<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use App\Models\Company;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;


class Providers extends Model
{
    use HasFactory;

    // protected $table = 'clients';
    protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'name',
        'gst_no',
        'status',
        'extra'
    ];
    protected $hidden = ['dynamicTableName'];
    protected $casts = [
        'extra' => 'array'
    ];

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("providers_{$branchId}");
        return $instance;
    }
    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */

    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }


    public function setDynamicTableName($id = null)
    {
        // Skip if running in console (artisan)
        if (App::runningInConsole() && App::runningUnitTests() === false) {
            return $this;
        }

        if ($id) {
            $dynamicTableName = 'providers_' . $id;
        } else {
            $user = Auth::user();

            // Guest-safe: return immediately if no user
            if (!$user) {
                return $this;
            }

            $role = $user->roles->first() ?? null;

            if ($role && $role->id != 1 && !in_array($role->name, ['Accountant', 'CompanyAccountant'])) {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;

                if ($companyId) {
                    $dynamicTableName = 'providers_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name');
    //         $table->string('gst_no')->unique()->nullable();
    //         $table->json('extra')->nullable();
    //         $table->boolean('status')->default(true);
    //         $table->timestamps();
    //     });
    // }

    private function createDynamicTable($tableName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException("Invalid table name: {$tableName}");
        }

        $originalTable = 'providers';

        if (Schema::hasTable($tableName)) {
            return;
        }

        DB::statement("CREATE TABLE `{$tableName}` LIKE `{$originalTable}`");
    }

    public function invoices()
    {
        return $this->hasMany(AutoInvoice::class, 'client_id', 'id'); 
        
    }
}
