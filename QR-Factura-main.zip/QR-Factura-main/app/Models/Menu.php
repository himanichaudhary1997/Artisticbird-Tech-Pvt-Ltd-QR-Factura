<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Models\Permission;

class Menu extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'url', 'parent_id', 'icon', 'status','order'];

    // public function children()
    // {
    //     return $this->hasMany(Menu::class, 'parent_id')->with('children'); // Recursive children loading
    // }

    // Relationship for submenus
    public function children()
    {
        return $this->hasMany(Menu::class, 'parent_id')->where('status',1)->orderBy('order','Asc');
    }

    public function parent()
    {
        return $this->belongsTo(Menu::class, 'parent_id');
    }

    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'role_has_permissions', 'permission_id', 'role_id');
    }

}

