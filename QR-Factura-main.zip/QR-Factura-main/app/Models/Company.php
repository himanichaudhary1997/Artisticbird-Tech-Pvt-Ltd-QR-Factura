<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Models\CompanyVerifactu;
use App\Models\Invoices;

class Company extends Model
{
    use HasFactory;

    protected $table = 'companies';

    protected $fillable = [
        'company_name',
        'company_slug',
        'company_email',
        'url',
        'privacy',
        'admin_id',
        'gst_no',
        'extra',
        'type',
        'territory',
        'is_agree',
        'is_verifactu',
        'dnia'
    ];

    protected $casts = [
        'extra' => 'array'
    ];

    public function user(){
        return $this->belongsTo(User::class, 'admin_id', 'id');
    }

    public function invoices(){
        return (new Invoice())->setDynamicTableName($this->id)->get();
    }

    public function organization_details() {
        return $this->hasOne(CompanyVerifactu::class, 'company_id', 'id');
    }



    public function users()
    {
        $adminQuery = $this->user()
        ->select('users.*', 
                 DB::raw('NULL as pivot_company_id'), 
                 DB::raw('NULL as pivot_user_id'));

    $usersQuery = $this->belongsToMany(User::class, 'company_users', 'company_id', 'user_id')
        ->select('users.*', 'company_users.company_id as pivot_company_id', 'company_users.user_id as pivot_user_id');

    return $usersQuery->union($adminQuery)
                      ->orderByRaw("pivot_company_id IS NULL DESC");
    }

    public function adminUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    // Relationship: Get all users from company_users table
    public function companyUsers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'company_users', 'admin_id', 'user_id');
    }

    // ✅ Custom method to fetch all users (admin + company users)
    public function getAllUsers()
    {
        return User::whereIn('id', function ($query) {
            $query->select('user_id')
                ->from('company_users')
                ->where('admin_id', $this->admin_id);
        })->orWhere('id', $this->admin_id) // Include admin user
          ->get(); // Fetch all results
    }

    public function apikeys()
    {
        return $this->hasMany(VerifactuApiKeysModel::class, 'company_id', 'id'); 
    }

    public function supCompanies()
    {
        return $this->hasMany(SupCompany::class);
    }

    
}
