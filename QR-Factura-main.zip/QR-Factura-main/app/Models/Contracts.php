<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class Contracts extends Model
{
    use HasFactory;

    protected $table = 'contracts';
    protected $dynamicTableName;

    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("contracts_{$branchId}");
        return $instance;
    }

    


    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    // elseif (session()->has('sup_company_id')) {
    //         // Case 2: User selected a company from UI
    //         $companyId = session('sup_company_id');
    //         $dynamicTableName = 'performas_' . $companyId;
    //     }

    public function setDynamicTableName($id = null)
    {
        // if (App::runningInConsole() && App::runningUnitTests() === false) {
        //     return;
        // }
        if (!empty($id)) {
            $dynamicTableName = 'contracts_' . $id;
        } else {
            $user = Auth::user();
            $role = $user->roles->first() ?? null;
            // dd($role);
            if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
                $company = $user->company;

                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    // If it's a collection, take the first item
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                // dd($user->company);
                if ($companyId) {
                    $dynamicTableName = 'contracts_' . $companyId;
                }
            }
        }
        if (!empty($dynamicTableName)) {
            // dd($dynamicTableName);
            // Check if the table exists, create it if not
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    // dd('hi');
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }

            $this->dynamicTableName = $dynamicTableName;
        }
        // dd($this->dynamicTableName);
        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        $parts = explode('_', $tableName);
        $id = end($parts);
        $originalInvoiceTable = 'contracts';

        if (!Schema::hasTable($tableName)) {
            // Duplicate structure
            DB::statement("CREATE TABLE {$tableName} LIKE {$originalInvoiceTable}");

            // Make sure the column has proper type before FK
            $fkName = "{$tableName}_created_by_foreign_key";

          
        }
    }

    protected $fillable = [
        'performa_id',
        'contract_date',
        'status',
    ];

    public function performa()
    {
        return $this->belongsTo(Performa::class, 'performa_id');
    }

    protected $casts = [
        'contract_date' => 'datetime',
    ];
}
