<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Projects;
use App\Models\Clients;
use App\Models\VerifactuApiKeysModel;
use App\Models\InvoicePrefix;
use App\Models\InvoiceType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\PaymentMethods;
use Illuminate\Support\Facades\App;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Vinkla\Hashids\Facades\Hashids;

class Invoice extends Model
{
    use HasFactory;

    protected $table = 'invoices';
    // protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'reference_id',
        'ref_invoice_number',
        'invoice_id',
        'verifactu_id',
        'client_id',
        'currency',
        'issue_date',
        'due_date',
        'invoice_type',
        'payment_method',
        'ref_no',
        'items',
        'extra',
        'status',
        'subtotal',
        'totalDiscount',
        'totalTax',
        'extraTax',
        'totalRetencion',
        'grandTotal',
        'qr_code',
        'created_by',
        'needs_validation',
        'domain_id'
    ];
    const PAID_INVOICE = 1;
    const SEND_INVOICE = 2;
    const INVOICE_TYPE_PERIODIC = 2;
    const NEGATIVE_INVOICE = 4;


    const DRAFT  = '0';
    const PAID   = '1';
    const SENT   = '2';
    const NOTPAID = '3';
    const NEGATIVE = '4';
    const UNPAID = '5';
    const OVERDUE = '6';
    
    protected $casts = [
        'extra' => 'array',
        'items' => 'array',
    ];
    


    public static function forUsers($branchId)
    {
        $instance = new self();
        // dd($branchId);
        $instance->setTable("invoices_{$branchId}");
        return $instance;
    }

    public function client($companyId = null, $productId =null)
    {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if($companyId && $productId){
            $clients = Clients::forUsers($companyId)->where('id', $productId)->first();
            // dd($companyId);
            return $clients;
        }else{
            if(empty($company)){
                return $this->belongsTo(User::class, 'client_id');
            }else{
                // dd('hi');
                return $this->belongsTo(Clients::class, 'client_id');
            }
        }

        

    }
    
    public function adminClient($companyId = null, $productId =null)
    {
        return $this->belongsTo(User::class, 'client_id');
    }

    public function invoiceType()
    {
        return $this->belongsTo(InvoiceType::class, 'invoice_type');
    }


    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethods::class, 'payment_method');
    }

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    
// elseif (session()->has('sup_company_id')) {
//             // Case 2: User selected a company from UI
//             $companyId = session('sup_company_id');
//             $dynamicTableName = 'invoices_' . $companyId;
//         }
    public function setDynamicTableName($id = null)
    {
        if (!empty($id)) {
            $dynamicTableName = 'invoices_' . $id;
        } else {
            $user = Auth::user();
            if (!$user) {
                return $this; // guest: don't try roles
            }

            $role = $user->roles->first() ?? null;
            if ($role && $role->id != 1 && !in_array($role->name, ['Accountant','CompanyAccountant'])) {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                if ($companyId) {
                    $dynamicTableName = 'invoices_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }
            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
    }




    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        $parts = explode('_', $tableName);
        $id = end($parts);
        $originalInvoiceTable = 'invoices';

        if (!Schema::hasTable($tableName)) {
            // Duplicate structure
            DB::statement("CREATE TABLE {$tableName} LIKE {$originalInvoiceTable}");

            // Make sure the column has proper type before FK
            $fkName = "{$tableName}_created_by_foreign_key";

            DB::statement("
                ALTER TABLE `{$tableName}`
                ADD CONSTRAINT `{$fkName}`
                FOREIGN KEY (`created_by`)
                REFERENCES `users`(`id`)
                ON DELETE SET NULL
            ");
            DB::statement("ALTER TABLE {$tableName} MODIFY client_id BIGINT UNSIGNED NULL");

            // Now safely add the new foreign key constraint
            DB::statement("
                ALTER TABLE `{$tableName}` 
                ADD CONSTRAINT `{$tableName}_client_id_foreign_key` 
                FOREIGN KEY (`client_id`) 
                REFERENCES `clients_{$id}`(`id`) 
                ON DELETE SET NULL
            ");
        }

        
    }

    public function generateInvoiceQrCode()
    {
        $user = Auth::user();
        $company = $user->company;
        $nameString = Str::random(10);

        // Encode both IDs
        $encodedCompany = Hashids::connection('company')->encode($company->id);
        $encodedInvoice = Hashids::connection('invoice')->encode($this->id);

        $downloadUrl = route('preveiwInvoice', [$encodedCompany, $encodedInvoice]);

        $filePath = "qrcodes/{$company->company_slug}/invoice_{$nameString}.png";

        if (!empty($this->qr_code) && Storage::disk('public')->exists($this->qr_code)) {
            Storage::disk('public')->delete($this->qr_code);
        }

        $qrCode = QrCode::format('png')->size(400)->margin(1)->generate($downloadUrl);
        Storage::disk('public')->put($filePath, $qrCode);

        $this->qr_code = $filePath;
        $this->save();
    }

    public function negativeInvoices()
    {
        return $this->hasMany(Invoice::class, 'reference_id', 'id');
    }

    public function parentInvoice()
    {
        return $this->belongsTo(Invoice::class, 'reference_id', 'id');
    }

    public function domain()
    {
        return $this->belongsTo(VerifactuApiKeysModel::class, 'domain_id');
    }

    public function getPrefixDomainAttribute()
    {
        $prefix = $this->extra['invoice_prefix'] ?? null;

        if (!$prefix) {
            return null;
        }

        $prefixRecord = InvoicePrefix::where('prefix', $prefix)->first();

        if (!$prefixRecord) {
            return null;
        }

        return VerifactuApiKeysModel::where('prefix_id', $prefixRecord->id)->first();
    }

}
