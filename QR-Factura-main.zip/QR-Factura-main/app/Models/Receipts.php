<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Clients;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\App;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Vinkla\Hashids\Facades\Hashids;

class Receipts extends Model
{
    use HasFactory;

    protected $table = 'receipts';
    // protected $table;
    private $dynamicTableName;

    protected $fillable = [
        'reference_id',
        'ref_invoice_number',
        'ref_no',
        'receipt_id',
        'verifactu_receipt_id',
        'client_id',
        'provider_id',
        'subtotal',
        'totalDiscount',
        'totalTax',
        'extraTax',
        'grandTotal',
        'qr_code',
        'items',
        'extra',
        'is_verified',
        'created_by',
        'domain_id'
    ];

    protected $casts = [
        'extra' => 'array',
        'items' => 'array',
    ];
    


    public static function forUsers($branchId)
    {
        $instance = new self();
        $instance->setTable("receipts_{$branchId}");
        return $instance;
    }

    public function client($companyId = null, $productId =null)
    {
        $user = auth()->user();
        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }

        if($companyId && $productId){
            $clients = Clients::forUsers($companyId)->where('id', $productId)->first();
            return $clients;
        }else{
            if(empty($company)){
                return $this->belongsTo(User::class, 'client_id');
            }else{
                // dd('hi');
                return $this->belongsTo(Clients::class, 'client_id');
            }
        }

    }


    public function provider($companyId = null, $productId =null)
    {
        // $user = auth()->user();
        // $company = $user->company ?? null;

        // if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
        //     // If it's a collection, take the first item
        //     $company = $company->first();
        // }

        // if($companyId && $productId){
        //     $clients = Providers::forUsers($companyId)->where('id', $productId)->first();
        //     // dd($companyId);
        //     return $clients;
        // }else{
            return $this->belongsTo(Providers::class, 'provider_id');
        // }

    }
    
    public function adminClient($companyId = null, $productId =null)
    {
        return $this->belongsTo(User::class, 'client_id');
    }

    public function invoiceType()
    {
        return $this->belongsTo(InvoiceType::class, 'invoice_type');
    }


    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethods::class, 'payment_method');
    }

    protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        if (!$this->dynamicTableName) {
            $this->setDynamicTableName();
        }
        return $this->dynamicTableName ?: parent::getTable();
    }

    // public function setDynamicTableName($id = null)
    // {
    //     // if (App::runningInConsole() && App::runningUnitTests() === false) {
    //     //     return;
    //     // }
    //     if (!empty($id)) {
    //         $dynamicTableName = 'receipts_' . $id;
    //     } else {
    //         $user = Auth::user();
    //         $role = $user->roles->first() ?? null;
    //         // dd($role);
    //         if ($user && $role && $role->id != 1 && $role->name != 'Accountant' && $role->name != 'CompanyAccountant') {
    //             $company = $user->company;

    //             if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
    //                 // If it's a collection, take the first item
    //                 $company = $company->first();
    //             }
    //             $companyId = $company->id ?? null;
    //             // dd($user->company);
    //             if ($companyId) {
    //                 $dynamicTableName = 'receipts_' . $companyId;
    //             }
    //         }
    //     }
    //     if (!empty($dynamicTableName)) {
    //         // dd($dynamicTableName);
    //         // Check if the table exists, create it if not
    //         if (!Schema::hasTable($dynamicTableName)) {
    //             try {
    //                 // dd('hi');
    //                 $this->createDynamicTable($dynamicTableName);
    //             } catch (\Exception $e) {
    //                 logger()->error('Failed to create dynamic table: ' . $e->getMessage());
    //             }
    //         }

    //         $this->dynamicTableName = $dynamicTableName;
    //     }
    //     // dd($this->dynamicTableName);
    //     return $this;
    // }

    public function setDynamicTableName($id = null)
    {
        // dd('hi')

        if (!empty($id)) {
            $dynamicTableName = 'receipts_' . $id;
        } else {
            $user = Auth::user();
            if (!$user) {
                return $this; // guest: don't try roles
            }

            $role = $user->roles->first() ?? null;
            if ($role && $role->id != 1 && !in_array($role->name, ['Accountant','CompanyAccountant'])) {
                $company = $user->company;
                if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                    $company = $company->first();
                }
                $companyId = $company->id ?? null;
                if ($companyId) {
                    $dynamicTableName = 'receipts_' . $companyId;
                }
            }
        }

        if (!empty($dynamicTableName)) {
            if (!Schema::hasTable($dynamicTableName)) {
                try {
                    $this->createDynamicTable($dynamicTableName);
                } catch (\Exception $e) {
                    logger()->error('Failed to create dynamic table: ' . $e->getMessage());
                }
            }
            $this->dynamicTableName = $dynamicTableName;
        }

        return $this;
    }


    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    private function createDynamicTable($tableName)
    {
        $parts = explode('_', $tableName);
        $id = end($parts);
        $originalInvoiceTable = 'receipts';

        if (!Schema::hasTable($tableName)) {
            // Duplicate structure
            DB::statement("CREATE TABLE {$tableName} LIKE {$originalInvoiceTable}");

            // Make sure the column has proper type before FK
            $fkName = "{$tableName}_created_by_foreign_key";

            DB::statement("
                ALTER TABLE `{$tableName}`
                ADD CONSTRAINT `{$fkName}`
                FOREIGN KEY (`created_by`)
                REFERENCES `users`(`id`)
                ON DELETE SET NULL
            ");
            DB::statement("ALTER TABLE {$tableName} MODIFY client_id BIGINT UNSIGNED NULL");

            // Now safely add the new foreign key constraint
            DB::statement("
                ALTER TABLE `{$tableName}` 
                ADD CONSTRAINT `{$tableName}_client_id_foreign_key` 
                FOREIGN KEY (`client_id`) 
                REFERENCES `clients_{$id}`(`id`) 
                ON DELETE SET NULL
            ");
        }
    }

    

    public function generateReceiptsQrCode()
    {
        $user = Auth::user();
        $company = $user->company;
        $nameString = Str::random(10);

        // Encode both IDs
        $encodedCompany = Hashids::connection('company')->encode($company->id);
        $encodedRecipt = Hashids::connection('receipt')->encode($this->id);


        $downloadUrl = route('previewReceipt', [$encodedCompany, $encodedRecipt]);

        $filePath = "qrcodes/receipts/{$company->company_slug}/receipt_{$nameString}.png";

        if (!empty($this->qr_code) && Storage::disk('public')->exists($this->qr_code)) {
            Storage::disk('public')->delete($this->qr_code);
        }

        $qrCode = QrCode::format('png')->size(400)->margin(1)->generate($downloadUrl);
        Storage::disk('public')->put($filePath, $qrCode);

        $this->qr_code = $filePath;
        $this->save();
    }
}
