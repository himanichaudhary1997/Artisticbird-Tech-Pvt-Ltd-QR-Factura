<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class Templates extends Model
{
    use HasFactory;

    protected $table = 'templates';
    private $dynamicTableName;

    protected $fillable= [
        'name',
        'template_html',
        'extra',
        'variable_info',
        'scope'
    ];

    protected $casts = [
        'extra' => 'array',
    ];

    // protected $hidden = ['dynamicTableName'];

    /**
     * Override the `getTable` method to dynamically set the table name.
     *
     * @return string
     */
    public function getTable()
    {
        return $this->dynamicTableName ?: parent::getTable();
    }

    // public function setDynamicTableName()
    // {
    //     $user = Auth::user();
    //     $role = $user->roles->first() ?? null;
    //     if ($user  && $role->id == 2 ) {
    //         $companyId = $user->company->id ?? null;

    //         if ($companyId) {
    //             $dynamicTableName = 'templates_' . $companyId;

    //             // Check if the table exists, create it if not
    //             if (!Schema::hasTable($dynamicTableName)) {
    //                 try {
    //                     $this->createDynamicTable($dynamicTableName);
    //                 } catch (\Exception $e) {
    //                     // Log the error or handle it as required
    //                     logger()->error('Failed to create dynamic table: ' . $e->getMessage());
    //                 }
    //             }

    //             // Store the dynamic table name
    //             $this->dynamicTableName = $dynamicTableName;
    //         }
    //     }
    // }

    /**
     * Create a dynamic table using the specified schema.
     *
     * @param string $tableName
     */
    // private function createDynamicTable($tableName)
    // {
    //     Schema::create($tableName, function (Blueprint $table) {
    //         $table->id();
    //         $table->string('name');
    //         $table->text('template_html');
    //         $table->json('extra')->nullable();
    //         $table->json('variable_info')->nullable();
    //         $table->timestamps();
    //     });
    // }
}
