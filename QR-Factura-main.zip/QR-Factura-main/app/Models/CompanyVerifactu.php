<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyVerifactu extends Model
{
    use HasFactory;

    protected $table = 'companies_verifactu_details';

    protected $fillable = [
        'company_id',
        'organization_id',
        'api_keys',
        'is_verified',
        'agreement',
        'signed_agreement',
        'extra'
    ];


    protected $casts = [
        'extra' => 'array',
        'api_keys'=>'array'
    ];

}
