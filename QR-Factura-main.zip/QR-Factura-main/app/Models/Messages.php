<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Messages extends Model
{
    use HasFactory;

    protected $table = 'messages';

    protected $fillable = [
        'issue_id',
        'message',
        'extra',
        'user_id',
        'attachments',
    ];

    protected $casts = [
        'extra' => 'array',
        'attachments' => 'array',
    ];

    public function issue()
    {
        return $this->belongsTo(Issues::class, 'issue_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
