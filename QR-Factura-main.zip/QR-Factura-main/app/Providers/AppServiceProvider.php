<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Opcodes\LogViewer\Facades\LogViewer;
use App\Models\Invoice;
use App\Models\Receipts;
use App\Observers\InvoiceObserver;
use App\Observers\ReceiptObserver;

use Illuminate\Support\Facades\Blade;
use App\View\Components\ChartJs;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Paginator::defaultView('pagination.custom-pagination-design'); // Use your custom file
        Paginator::defaultSimpleView('pagination.custom-pagination-design'); // For simple pagination
        Blade::component('chartjs', ChartJs::class);
        if (Auth::check()) {
            $user = Auth::user();
            // dd($user);
            $locale = $user->company->extra['lanuguage'] ?? $user->extra['lanuguage'] ?? 'es';
            // dd($user->company->extra['lanuguage']);
            App::setLocale($locale);
        }

        LogViewer::auth(function ($request) {
            // Only allow logged-in users who are Admin
            return $request->user() && $request->user()->hasRole('Admin');
            // If you use an 'is_admin' boolean flag:
            // return $request->user()?->is_admin;
        });

        Invoice::observe(InvoiceObserver::class);
        Receipts::observe(ReceiptObserver::class);
    }
}
