<?php

namespace App\Imports;

use App\Models\User;
use App\Models\Clients;
use App\Models\Company;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use App\Models\CountryModel;
use Maatwebsite\Excel\Concerns\Importable;
use App\Models\StateModel;
use Illuminate\Support\Str;



class ClientsImport implements ToCollection, WithHeadingRow
{

    use Importable;
    public $success = true;  // To store success state
    public $message = '';

    public function headingRow(): int
    {
        return 1;
    }

    public function mapHeader($header)
    {
        return Str::slug(trim($header), '_');
    }


    public function collection(Collection $rows)
    {
        $errors = [];
        $successCount = 0;

        foreach ($rows as $index => $row) {
            
            if ($index === 0) {
                Log::info('Detected headers:', array_keys($row->toArray()));
            }

            if ($row->filter()->isEmpty()) continue;

            $row = collect($row)->mapWithKeys(function ($value, $key) {
                return [Str::slug(trim($key), '_') => $value];
            });

            Log::info('Mapped Row:', $row->toArray());

            Log::info('Client Data:', $row->toArray());
            try {
                // dd($row);
                $dynamicTableName = (new Clients())->getTable();
                // dd($dynamicTableName);
                $validator = Validator::make($row->toArray(), [
                    'nombre_obligatorio' => 'required|string',
                    'correo_electronico_obligatorio' => 'required',
                    'cif_obligatorio' => [
                        'required',
                        'max:15',
                        'regex:/^[A-Za-z0-9]+$/', // Allows only alphabets and numbers
                        Rule::unique($dynamicTableName, 'gst_no')
                    ],
                    'nombre_empresa_obligatorio'=>'required',
                    'direccion_obligatorio'=>'required',
                    'localidad_obligatorio'=>'required',
                    'pais_obligatorio'=>'required',
                    'provincia_obligatorio'=>'required',
                    'codigo_postal_obligatorio'=>'required'
                ]);
                
            
                if ($validator->fails()) {
                    $errorMessages = implode(', ', $validator->errors()->all());
                    $errors[] = "Row " . ($index + 2) . " ({$row['nombre_obligatorio']}): $errorMessages" . "<br>";
                    continue;  // Continue to the next row
                }
                
                Log::info('Starting transaction for client creation '. $row['nombre_obligatorio'] . '.');
            
                $country = '';
                $state = '';
                if(isset($row['pais_obligatorio']) && !empty($row['pais_obligatorio'])){
                    $country = CountryModel::where('country_code', $row['pais_obligatorio'])
                    ->orWhere('name', $row['pais_obligatorio'])
                    ->first();
                }

                // if(isset($row['provincia_obligatorio']) && !empty($row['provincia_obligatorio'])){
                //     $state = StateModel::where('state_code', $row['provincia_obligatorio'])
                //     ->orWhere('name', $row['provincia_obligatorio'])
                //     ->first();
                // }

                $client = Clients::create([
                    'name' => $row['nombre_obligatorio'] ?? null,
                    'email' => $row['correo_electronico_obligatorio'] ?? null,
                    'mobile_no' => $row['telefono_no_obligatorio'] ?? null,
                    'gst_no' => $row['cif_obligatorio'] ?? null,
                    'extra' => [
                        'company_name' => $row['nombre_empresa_obligatorio'] ?? null,
                        'address' => $row['direccion_obligatorio'] ?? null,
                        'locality'=>$row['localidad_obligatorio'] ?? null,
                        'state_name' => $row['provincia_obligatorio'] ?? null,
                        'country_code' => $country->country_code ?? null,
                        'zip_code' => $row['codigo_postal_obligatorio'] ?? null,
                        'surname' => $row['apelidos_no_obligatorio'] ?? null,
                        'alternative_email' => $row['email_recibir_facturas_no_obligatorio'] ?? null,
                    ]
                ]);
            
                
            
                $successCount++;  // Count successful import
            } catch (\Exception $e) {
            
                $errors[] = "Row " . ($index + 2) . " ({$row['nombre_obligatorio']}): " . $e->getMessage();
                continue;  // Continue even after exception
            }
        }

        if (!empty($errors)) {
            $errorReport = implode('  ', $errors);
            $this->success = false;
            $this->message = "Imported $successCount client(s). Errors: " . implode(' | ', $errors);
            // throw new \Exception("Imported $successCount user(s) successfully. <br> Errors: $errorReport");
            return ['success'=>false,'message'=>"Imported $successCount client(s) successfully. <br> Errors: $errorReport"];
        }else{
            $this->success = true;
            $this->message = "Successfully imported $successCount client(s).";
            return ['success'=>true,'message'=>"Imported $successCount client(s) successfully."];
        }
    }

}

