<?php
namespace App\Imports;

use App\Models\Client;
use App\Models\Invoice;
use App\Models\Clients;
use App\Models\CountryModel;
use App\Models\StateModel;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsErrors; // Import the trait
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use App\Services\InvoiceService;
use App\Models\Inventory;
use Illuminate\Validation\Rule;


class InvoiceImport implements ToModel, WithHeadingRow, WithValidation, SkipsOnFailure, WithChunkReading, SkipsEmptyRows,SkipsOnError   
{
    use Importable, SkipsFailures,SkipsErrors;

    protected $rowCount = 0;
    protected $invoiceService;

    public function __construct()
    {
        $this->invoiceService = new InvoiceService();
    }
    /**
     * Validate item-level and row-level arithmetic
     *
     * @param array $row   Mapped row (keys after mapColumns)
     * @param array $items Parsed items (as returned from parseItems)
     * @throws \Illuminate\Validation\ValidationException
     */
    // private function validateCalculations(array $row, array $items)
    // {
    //     // tolerance for float differences
    //     $tol = 0.01;

    //     $calculatedSubtotal = 0.0;

    //     foreach ($items as $idx => $item) {
    //         // ensure numeric forms
    //         $qty = is_numeric($item['quantity']) ? (float) str_replace(',', '.', $item['quantity']) : 1.0;
    //         $price = $this->normalizeNumber($item['price'] ?? 0);
    //         $discount = $this->normalizeNumber($item['discount'] ?? 0);

    //         // canonical calculation: price * qty - discount
    //         $calcAmount = round(($price * $qty) - $discount, 2);

    //         // parsed amount from file (may be 0)
    //         $parsedAmount = $this->normalizeNumber($item['amount'] ?? 0);
    //         $parsedAmount = round($parsedAmount, 2);

    //         // if parsed amount is zero and calcAmount > 0 we still compare (we want to flag)
    //         if (abs($calcAmount - $parsedAmount) > $tol) {
    //             throw ValidationException::withMessages([
    //                 'items' => ["Row #{$this->rowCount}: item '{$item['name']}' amount mismatch. Parsed amount = {$parsedAmount}, expected (price × qty − discount) = {$calcAmount}."]
    //             ]);
    //         }

    //         $calculatedSubtotal += $calcAmount;
    //     }

    //     $calculatedSubtotal = round($calculatedSubtotal, 2);

    //     // Row-level numbers
    //     $rowSubtotal = $this->normalizeNumber($row['sub_total'] ?? 0);
    //     $rowTax = $this->normalizeNumber($row['tax'] ?? 0); // your sheet appears to give absolute tax (Iva 0)
    //     $rowTotal = $this->normalizeNumber($row['total'] ?? 0);

    //     $rowSubtotal = round($rowSubtotal, 2);
    //     $rowTax = round($rowTax, 2);
    //     $rowTotal = round($rowTotal, 2);

    //     // Verify subtotal
    //     if (abs($calculatedSubtotal - $rowSubtotal) > $tol) {
    //         throw ValidationException::withMessages([
    //             'sub_total' => ["Row #{$this->rowCount}: SubTotal mismatch. Parsed SubTotal = {$rowSubtotal}, expected sum of items = {$calculatedSubtotal}."]
    //         ]);
    //     }

    //     // Verify total = subtotal + tax (adjust if your tax is percentage)
    //     $expectedTotal = round($calculatedSubtotal + $rowTax, 2);
    //     if (abs($expectedTotal - $rowTotal) > $tol) {
    //         throw ValidationException::withMessages([
    //             'total' => ["Row #{$this->rowCount}: Total mismatch. Parsed Total = {$rowTotal}, expected SubTotal + Iva = {$expectedTotal}."]
    //         ]);
    //     }
    // }
    private function validateCalculations(array $row, array $items, string $conceptoText)
    {
        $tol = 0.01;
        $errors = [];   // <--- Collect ALL ERRORS here

        /* ----------------------------------------------------------
        * 1. Validate Concepto string format
        * ---------------------------------------------------------- */
        // Must contain: Qty:, Precio:, Iva:, Total:
        $requiredLabels = ['Qty:', 'Precio:', 'Iva:', 'Total:'];

        foreach ($requiredLabels as $label) {
            if (!str_contains($conceptoText, $label)) {
                $errors[] = "Row #{$this->rowCount}: Concepto format invalid. Missing '{$label}'.";
            }
        }

        // Reject Total; (wrong semicolon)
        if (preg_match('/Total;/', $conceptoText)) {
            $errors[] = "Row #{$this->rowCount}: Concepto format invalid. Found 'Total;' — correct label is 'Total:'.";
        }

        // Reject wrong date label (FECHA must be Fecha:)
        if (preg_match('/FECHA/i', $conceptoText) && !preg_match('/Fecha:/i', $conceptoText)) {
            $errors[] = "Row #{$this->rowCount}: Invalid date format. Use 'Fecha: DD/MM/YYYY'.";
        }

        // Optional: Detect unnecessary commas before date
        // if (preg_match('/,\s*Fecha:/i', $conceptoText)) {
        //     $errors[] = "Row #{$this->rowCount}: Remove comma before Fecha: (invalid format).";
        // }

        /* ----------------------------------------------------------
        * 2. Validate item-level calculations
        * ---------------------------------------------------------- */
        $calculatedSubtotal = 0.0;

        foreach ($items as $item) {
            $qty = $this->normalizeNumber($item['quantity'] ?? 1);
            $price = $this->normalizeNumber($item['price'] ?? 0);
            $discount = $this->normalizeNumber($item['discount'] ?? 0);
            $parsedAmount = round($this->normalizeNumber($item['amount'] ?? 0), 2);

            $base = round(($qty * $price) - $discount, 2);

            $taxPercent = $this->normalizeNumber($item['tax'] ?? 0);
            $taxAmount  = round($base * ($taxPercent / 100), 2);

            $calcItemTotal = round($base + $taxAmount, 2);

            if (abs($parsedAmount - $calcItemTotal) > $tol) {
                $errors[] = "Row #{$this->rowCount}: Item '{$item['name']}' amount mismatch. "
                    ."Found {$parsedAmount}, expected {$calcItemTotal}.";
            }

            // Add *base*, tax will be validated later
            $calculatedSubtotal += $base;
        }

        $calculatedSubtotal = round($calculatedSubtotal, 2);

        /* ----------------------------------------------------------
        * 3. Validate SubTotal / IVA / Total
        * ---------------------------------------------------------- */
        $rowSubtotal = round($this->normalizeNumber($row['sub_total'] ?? 0), 2);
        $rowTax      = round($this->normalizeNumber($row['tax'] ?? 0), 2);
        $rowTotal    = round($this->normalizeNumber($row['total'] ?? 0), 2);

        if (abs($rowSubtotal - $calculatedSubtotal) > $tol) {
            $errors[] = "Row #{$this->rowCount}: SubTotal mismatch. Found {$rowSubtotal}, expected {$calculatedSubtotal}.";
        }

        $expectedTotal = round($calculatedSubtotal + $rowTax, 2);

        if (abs($rowTotal - $expectedTotal) > $tol) {
            $errors[] = "Row #{$this->rowCount}: Total mismatch. Found {$rowTotal}, expected {$expectedTotal}.";
        }

        /* ----------------------------------------------------------
        * 4. Throw ALL errors at once
        * ---------------------------------------------------------- */
        if (!empty($errors)) {
            throw ValidationException::withMessages([
                "row_{$this->rowCount}" => $errors
            ]);
        }
    }

    private function storeInInventory(array $item)
    {
        $name = trim($item['name']);

        if (!$name) {
            return; // empty name, skip
        }

        // Check if exists
        $exists = Inventory::whereRaw('LOWER(name) = ?', strtolower($name))->first();

        if ($exists) {
            return; // already in inventory
        }

        // Create new inventory item
        Inventory::create([
            'name'     => $name,
            'slug'     => Str::slug($name),
            'price'    => normalizePrice($item['price'] ?? 0, 2, 'IN'),
            'quantity' => normalizePrice($item['quantity'] ?? 0,2, 'IN'),
        ]);
    }

    private function parseItemsFromConcepto(string $conceptText): array
    {
        $items = [];

        // Capture ALL occurrences of Qty:, Precio:, Iva:, Total:
        preg_match_all(
            '/Qty:\s*([\d\.]+)\s*,\s*Precio:\s*([\d\.]+)\s*,\s*Iva:\s*([\d\.]+)\s*,\s*Total:\s*([\d\.]+)/i',
            $conceptText,
            $matches,
            PREG_SET_ORDER
        );

        foreach ($matches as $match) {
            $items[] = [
                'name'     => 'Item',     // optional
                'quantity' => $match[1],
                'price'    => $match[2],
                'iva'      => $match[3],
                'amount'   => $match[4],
                'discount' => 0
            ];
        }

        return $items;
    }




    private function mapColumns(array $row): array
    {   
        // Convert all keys to lowercase for consistency
        $mapped = [];
        $row = array_change_key_case($row, CASE_LOWER);

        
        // Define column mapping from Excel → internal code keys
        $map = [
            'nombre' => 'name',
            'empresa' => 'company_name',
            'cif' => 'cif',
            'email' => 'email',
            'direccion' => 'address',
            'localidad' => 'locality',
            'codigopostal' => 'zip_code',
            'pais' => 'country',
            'provincia' => 'state',
            'fechaemision' => 'issue',
            'fechavencimiento' => 'expiration',
            'tipofactura' => 'invoice_type',
            'metodopago' => 'payment_method',
            'concepto' => 'items',
            'subtotal' => 'sub_total',
            'iva' => 'tax',
            'total' => 'total',
            'paciente' => 'patient',
            'profesional' => 'professional',
        ];
        // Replace Excel column names with internal system keys
        foreach ($row as $key => $value) {
            $key = str_replace(' ', '', $key); // handle keys like "Sub Total"
            $mapped[$map[$key] ?? $key] = $value;
        }

        return $mapped;
    }


    public function prepareForValidation($data, $index)
    {
        return $this->mapColumns($data);
    }


    private function normalize($value)
    {
        return Str::of($value)
            ->lower()
            ->ascii()   // removes accents: Coruña → coruna
            ->trim();
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:191',
            'cif' => 'required|string|max:191',
            'email' => 'required|email|max:191',
            'issue' => 'required|string',
            'expiration' => 'required|string',
            'sub_total' => 'required',
            'tax' => 'nullable',
            'total' => 'required',
            'status' => 'nullable|in:Sent,Paid,Pending,Draft',
            'country' => [
                'required',
                'string',
                Rule::exists('country', 'name'),
            ],

            'state' => [
                'required',
                'string',
            ],
        ];
    }


    // public function withValidator($validator)
    // {
    //     $validator->after(function ($validator) {
    //         foreach ($validator->getData() as $rowIndex => $row) {

    //             $countryName = $row['country'] ?? null;
    //             $stateName   = $row['state'] ?? null;

    //             if (!$countryName || !$stateName) {
    //                 continue;
    //             }

    //             $countryId = \DB::table('country')
    //                 ->where('name', $countryName)
    //                 ->value('id');

    //             if (!$countryId) {
    //                 $validator->errors()->add(
    //                     "{$rowIndex}.country",
    //                     "Country '{$countryName}' does not exist."
    //                 );
    //                 continue;
    //             }

    //             $stateExists = \DB::table('states')
    //                 ->where('name', $stateName)
    //                 ->where('country_id', $countryId)
    //                 ->exists();

    //             if (!$stateExists) {
    //                 $validator->errors()->add(
    //                     "{$rowIndex}.state",
    //                     "State '{$stateName}' does not belong to country '{$countryName}'."
    //                 );
    //             }
    //         }
    //     });
    // }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            $data = $validator->getData();

            foreach ($data as $rowIndex => &$row) {

                $countryName = $row['country'] ?? null;
                $stateName   = $row['state'] ?? null;

                if (!$countryName || !$stateName) {
                    continue;
                }

                $normalizedCountry = $this->normalize($countryName);
                $normalizedState   = $this->normalize($stateName);

                // -----------------------------
                // Country lookup (normalized)
                // -----------------------------
                $country = \DB::table('country')
                    ->get()
                    ->first(function ($c) use ($normalizedCountry) {
                        // dd($this->normalize($c->name),$normalizedCountry);
                        return $this->normalize($c->name) == $normalizedCountry;
                    });

                // dd($country,$normalizedCountry);
                if (!$country) {
                    $validator->errors()->add(
                        "{$rowIndex}.country",
                        "Country '{$countryName}' does not exist."
                    );
                    continue;
                }

                // -----------------------------
                // State lookup (normalized)
                // -----------------------------
                $state = \DB::table('states')
                    ->where('country_id', $country->id)
                    ->get()
                    ->first(function ($s) use ($normalizedState) {
                        return $this->normalize($s->name) == $normalizedState;
                    });

                if (!$state) {
                    $validator->errors()->add(
                        "{$rowIndex}.state",
                        "State '{$stateName}' does not belong to country '{$country->name}'."
                    );
                    continue;
                }

                $companyName = $row['company_name'] ?? null;
                $cif = $row['cif'] ?? null;

                if (!$companyName || !$cif) {
                    continue;
                }

                $exists = Clients::whereRaw(
                    "LOWER(JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))) = ?",
                    [strtolower($companyName)]
                )
                ->where('gst_no', '!=', $cif)
                ->exists();

                if ($exists) {
                    $validator->errors()->add(
                        "{$rowIndex}.company_name",
                        "Company name '{$companyName}' already exists with another CIF."
                    );
                }

                // ✅ IMPORTANT: overwrite with correct DB values
                $row['country'] = $country->name; // e.g. A Coruña
                $row['state']   = $state->name;   // canonical value
            }

            // 🔥 push corrected data back
            $validator->setData($data);
        });
    }

    private function resolveCountry($countryName)
    {
        if (!$countryName) return null;

        $normalized = $this->normalize($countryName);

        return \DB::table('country')
            ->get()
            ->first(fn ($c) => $this->normalize($c->name) == $normalized);
    }

    private function resolveState($stateName, $countryId)
    {
        if (!$stateName || !$countryId) return null;

        $normalized = $this->normalize($stateName);

        return \DB::table('states')
            ->where('country_id', $countryId)
            ->get()
            ->first(fn ($s) => $this->normalize($s->name) == $normalized);
    }



    public function customValidationMessages()
    {
        return [
            'name.required' => __('Customer name is required.'),
            'cif.required' => __('Customer CIF is required.'),
            'email.required' => __('Customer email is required.'),
            'email.email' => __('Customer email must be a valid email address.'),
            'issue.required' => _('Issue date is required.'),
            'expiration.required' => __('Expiration date is required.'),
            'sub_total.required' => __('Sub Total is required.'),
            'total.required' => __('Total amount is required.'),
            'status.in' => __('Status must be one of Sent, Paid, Pending, or Draft.'),
        ];
    }

    private function mapInvoiceType(?string $type): int
    {
        $type = strtolower(trim($type ?? ''));

        $map = [
            'normal' => 1,
            'rectificativa' => 2,
            'abono' => 3,
            'proforma' => 4,
        ];

        return $map[$type] ?? 1; // default to Normal
    }

    private function mapPaymentMethod(?string $method): int
    {
        $method = strtolower(trim($method ?? ''));

        $map = [
            'transferencia bancaria' => 1,
            'tarjeta' => 2,
            'efectivo' => 3,
            'paypal' => 4,
            'bizum' => 5,
        ];

        return $map[$method] ?? 1; // default to Transferencia bancaria
    }


    // public function model(array $row)
    // {
    //     $user = auth()->user();
    //     $this->rowCount++;
    //     $row = $this->mapColumns($row);
    //     // dd($row);
    //     // $row = array_change_key_case($row, CASE_LOWER);

    //     return DB::transaction(function () use ($row, $user) {
    //         $items = $this->parseItems($row['items'] ?? '');
    //         // dd($items);

    //         $this->validateCalculations($row, $items);

    //         // 🧩 Step 1: Validate or create client
    //         $client = $this->validateOrCreateClient($row);
    //         // $client->delete();
    //         // dd($row, $client);

        
    //         $subTotal = normalizePrice($row['sub_total'] ?? 0, 2, 'IN');
    //         $tax = normalizePrice($row['tax'] ?? 0, 2, 'IN');
    //         $total = normalizePrice($row['total'] ?? 0, 2, 'IN');

    //         // 🕓 Step 3: Date normalization
    //         $issue_date = $this->normalizeDate($row['issue'] ?? now());
    //         // dd($issue_date);
    //         $due_date = $this->normalizeDate($row['expiration'] ?? now());

    //         // 🧮 Step 4: Prepare invoice payload
    //         $invoiceData = [
    //             'invoice_id' => $this->invoiceService->generateInvoiceId($issue_date, $user->company,'invoice'),
    //             'client_id' => $client->id,
    //             'issue_date' => $issue_date,
    //             'due_date' => $due_date,
    //             'currency' => '€',
    //             'invoice_type' => 1,
    //             'payment_method' => 16,
    //             'ref_no' => $row['invoice_id'] ?? null,

    //             'subtotal' => $subTotal,
    //             'totalDiscount' => 0,
    //             'totalTax' => $tax,
    //             'grandTotal' => $total,

    //             'items' => $items,

    //             'extra' => [
    //                 'source' => 'imported_excel',
    //                 'company_name' => $row['company_name'] ?? ($row['cust_name'] ?? null),
    //                 'item_type' => "product",
    //                 'original_invoice_ref' => $row['invoice_id'] ?? null,
    //                 'patient' => $row['patient'] ?? null,
    //                 'profesional' => $row['professional'] ?? null,
    //             ],

    //             'status' => 0,
    //             'is_verified' => 0,
    //             'created_by' => $user->id ?? null,
    //         ];

    //         // 🧾 Step 5: Create and return invoice
    //         return Invoice::create($invoiceData);
    //     });
    // }

    public function model(array $row)
    {
        $user = auth()->user();
        $this->rowCount++;
        $row = $this->mapColumns($row);

        try {

            return DB::transaction(function () use ($row, $user) {

                $items = $this->parseItems($row['items'] ?? '');
                // dd($items);
                // ⛔ Catch calculation mistakes
                // $this->validateCalculations($row, $items);
                // $conceptoText = $row['concepto'] ?? '';

                $this->validateCalculations($row, $items, $row['items']);

                foreach ($items as $item) {
                    $this->storeInInventory($item);
                }
                // ⛔ Client creation validation
                $client = $this->validateOrCreateClient($row);

                $subTotal = normalizePrice($row['sub_total'] ?? 0, 2, 'IN');
                $tax = normalizePrice($row['tax'] ?? 0, 2, 'IN');
                $total = normalizePrice($row['total'] ?? 0, 2, 'IN');

                $issue_date = $this->normalizeDate($row['issue'] ?? now());
                $due_date = $this->normalizeDate($row['expiration'] ?? now());

                $invoiceData = [
                    'invoice_id' => $this->invoiceService->generateInvoiceId($issue_date, $user->company,'invoice'),
                    'client_id' => $client->id,
                    'issue_date' => $issue_date,
                    'due_date' => $due_date,
                    'currency' => '€',
                    'invoice_type' => 1,
                    'payment_method' => 16,
                    'ref_no' => $row['invoice_id'] ?? null,

                    'subtotal' => $subTotal,
                    'totalDiscount' => 0,
                    'totalTax' => $tax,
                    'grandTotal' => $total,

                    'items' => $items,

                    'extra' => [
                        'source' => 'imported_excel',
                        'company_name' => $row['company_name'] ?? null,
                        'item_type' => "product",
                        'original_invoice_ref' => $row['invoice_id'] ?? null,
                        'patient' => $row['patient'] ?? null,
                        'profesional' => $row['professional'] ?? null,
                    ],

                    'status' => 0,
                    'is_verified' => 0,
                    'created_by' => $user->id ?? null,
                ];

                return Invoice::create($invoiceData);
            });

        } catch (\Throwable $e) {

            // 🔥 Report row failure to Laravel-Excel (very important)
            $this->onFailure(
                new \Maatwebsite\Excel\Validators\Failure(
                    $this->rowCount,
                    'row',
                    [$e->getMessage()],
                    $row
                )
            );

            // Skip the row
            return null;
        }
    }



    public function chunkSize(): int
    {
        return 300;
    }

    public function getRowCount()
    {
        return $this->rowCount;
    }

    private function validateOrCreateClient(array $row)
    {
        $cif = trim($row['cif'] ?? '');
        $name = trim($row['name'] ?? '');
        $email = trim($row['email'] ?? '');
        $existing = Clients::where('gst_no', $cif)->first();

        $country = $this->resolveCountry($row['country']);
        $state   = $this->resolveState($row['state'], $country->id);

        // dd($email, $existing);
        if ($existing) {
            // Validate match for CIF + Name + Email
            if (
                strtolower($existing->email) !== strtolower($email)
            ) {
                throw ValidationException::withMessages([
                    'cust_cif' => ["Client with CIF {$cif} already exists but email don't match."]
                ]);
            }

            return $existing;
        }

        // $companyName = $row['company_name'] ?? null;
        // $companyExists = Clients::whereRaw(
        //     "LOWER(JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))) = ?",
        //     [strtolower($companyName)]
        // )
        // ->where('gst_no', '!=', $cif)
        // ->exists();

        // if ($companyExists) {
        //     throw ValidationException::withMessages([
        //         'empresa' => [
        //             "Company name '{$companyName}' already exists with another CIF."
        //         ]
        //     ]);
        // }



        $countryCode=   CountryModel::whereName($row['country'])->value('country_code');
        // $stateCode  =   StateModel::whereName($row['state'])->value('id');
        // dd($countryCode, $stateCode);

        // Create a new client
        return Clients::create([
            'name' => $name,
            'email' => $email,
            'mobile_no' => $row['mobile_no'] ?? null,
            'gst_no' => $cif,
            'extra' => [
                'company_name' => $row['company_name'] ?? null,
                'address' => $row['address'] ?? null,
                'locality' => $row['locality'] ?? null,
                'zip_code' => $row['zip_code'] ?? null,
                'country_name' => $row['country'] ?? null,
                'country_code' => $country->country_code ?? null,
                'state_name' => $state->name ?? null,
                'alternative_email' => $row['email'] ?? null,
            ],
            'status' => 1,
        ]);

    }
  
    // private function parseItems($itemsString)
    // {
    //     if (empty($itemsString)) return [];

    //     $lines = preg_split("/\r\n|\n|\r/", trim($itemsString));

    //     $items = [];
    //     // dd($lines);
    //     foreach ($lines as $line) {
    //         $line = trim($line);
    //         if (!$line) continue;

    //         // if (preg_match('/^(.*?)\s*\(Qty:\s*([\d.,]+),\s*Precio|Price:\s*([\d.,]+),\s*Iva|Tax:\s*([\d.,]+),\s*Descuento|Discount:\s*([\d.,]+),\s*Total|Amount:\s*([\d.,]+)\)$/i', $line, $matches)) {
    //         //     $items[] = [
    //         //         'name' => trim($matches[1]),
    //         //         'quantity' => $matches[2],
    //         //         'price' => normalizePrice($matches[3]),
    //         //         'tax' => trim($matches[4]??0),
    //         //         'discount' => trim($matches[5]??0),
    //         //         'amount' => normalizePrice($matches[6]??0),
    //         //         'use_tax_percentage' =>true,
    //         //         'tax_type' => 'percentage',

    //         //     ];
    //         // }
    //         $pattern = '/^(.*?)\s*\(Qty:\s*([\d.,]+)?(?:,\s*(?:Precio|Price):\s*([\d.,]+))?(?:,\s*(?:Iva|Tax):\s*([\d.,]+))?(?:,\s*(?:Descuento|Discount):\s*([\d.,]+))?(?:,\s*(?:Total|Amount):\s*([\d.,]+))?\)$/iu';

    //         if (preg_match($pattern, $line, $matches)) {
    //             $items[] = [
    //                 'name' => trim($matches[1] ?? ''),
    //                 'quantity' => trim($matches[2] ?? '1'),
    //                 'price' => normalizePrice($matches[3] ?? 0),
    //                 'tax' => $matches[4] ?? 0,
    //                 'discount' => normalizePrice($matches[5] ?? 0),
    //                 'amount' => normalizePrice($matches[6] ?? 0),
    //                 'use_tax_percentage' => true,
    //                 'tax_type' => 'percentage',
    //                 "item_type"=>"product"
    //             ];
    //         } else {
    //             // Handle fallback when line doesn't match pattern at all
    //             $items[] = [
    //                 'name' => $line, // Treat full line as item name if no structured data
    //                 'quantity' => '1',
    //                 'price' => 0,
    //                 'tax' => 0,
    //                 'discount' => 0,
    //                 'amount' => 0,
    //                 'use_tax_percentage' => true,
    //                 'tax_type' => 'percentage',
    //                 "item_type"=>"product"
    //             ];
    //         }
    //     }

    //     return $items;
    // }

    private function parseItems($itemsString)
    {
        if (empty($itemsString)) return [];

        $lines = preg_split("/\r\n|\n|\r/", trim($itemsString));

        $items = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if (!$line) continue;

            // Pattern to match structured item lines
            $pattern = '/^(.*?)\s*\(Qty:\s*([\d.,]+)?(?:,\s*(?:Precio|Price):\s*([\d.,]+))?(?:,\s*(?:Iva|Tax):\s*([\d.,]+))?(?:,\s*(?:Descuento|Discount):\s*([\d.,]+))?(?:,\s*(?:Total|Amount):\s*([\d.,]+))?\)$/iu';

            if (preg_match($pattern, $line, $matches)) {
                $name = trim($matches[1] ?? '');
                $quantity = trim($matches[2] ?? '1');
                $price = normalizePrice($matches[3] ?? 0);
                $tax = $matches[4] ?? 0;
                $discount = normalizePrice($matches[5] ?? 0);
                $amount = normalizePrice($matches[6] ?? 0);

                // Optional: Extract date from name and validate basic format
                if (preg_match('/Fecha:\s*(\d{2}\/\d{2}\/\d{4})/', $name, $dateMatch)) {
                    $dateStr = $dateMatch[1];
                    try {
                        \Carbon\Carbon::createFromFormat('d/m/Y', $dateStr);
                    } catch (\Exception $e) {
                        // append warning in name or log if needed
                    }
                }

                $items[] = [
                    'name' => $name,
                    'quantity' => $quantity,
                    'price' => $price,
                    'tax' => $tax,           // percentage
                    'discount' => $discount,
                    'amount' => $amount,
                    'use_tax_percentage' => true,
                    'tax_type' => 'percentage',
                    'item_type' => 'product'
                ];
            } else {
                // fallback for unstructured line
                $items[] = [
                    'name' => $line,
                    'quantity' => '1',
                    'price' => 0,
                    'tax' => 0,
                    'discount' => 0,
                    'amount' => 0,
                    'use_tax_percentage' => true,
                    'tax_type' => 'percentage',
                    'item_type' => 'product'
                ];
            }
        }

        return $items;
    }


    
    private function normalizeNumber($value)
    {
        if (empty($value)) return 0;

        // Remove currency symbols and spaces
        $value = preg_replace('/[^\d,.\-]/', '', $value);

        // Handle European decimal formats
        if (strpos($value, ',') !== false && strpos($value, '.') !== false) {
            $lastComma = strrpos($value, ',');
            $lastDot = strrpos($value, '.');
            if ($lastComma > $lastDot) {
                $value = str_replace('.', '', $value);
                $value = str_replace(',', '.', $value);
            } else {
                $value = str_replace(',', '', $value);
            }
        } elseif (strpos($value, ',') !== false) {
            $value = str_replace('.', '', $value);
            $value = str_replace(',', '.', $value);
        }

        return is_numeric($value) ? (float)$value : 0;
    }

    private function normalizeDate($value)
    {
        if ($value === null || $value === '') {
            return now()->format('Y-m-d');
        }

        // If value is numeric-like (45936 or 45936.0) -> Excel serial
        if (is_numeric($value)) {
            try {
                // Ensure float -> pass to excelToDateTimeObject
                $floatVal = (float) $value;
                // PhpSpreadsheet expects numeric serials; this returns a DateTime
                $dt = ExcelDate::excelToDateTimeObject($floatVal);
                return Carbon::instance($dt)->format('Y-m-d');
            } catch (\Throwable $e) {
                // fallback to other parsing below
            }
        }

        // If it's an ISO-like date/time e.g. "2025-10-06 00:00:00" or "2025-10-06T00:00:00Z"
        if (preg_match('/^\d{4}-\d{2}-\d{2}/', trim($value))) {
            try {
                return Carbon::parse(substr(trim($value), 0, 10))->format('Y-m-d');
            } catch (\Throwable $e) {
                // continue to generic parse
            }
        }

        // Generic parse (handles dd/mm/yyyy, mm/dd/yyyy depending on locale)
        try {
            return Carbon::parse($value)->format('Y-m-d');
        } catch (\Throwable $e) {
            // Last resort fallback
            return now()->format('Y-m-d');
        }
    }

    // private function normalizeDate($value)
    // {
    //     if ($value === null || $value === '') {
    //         return now()->format('Y-m-d');
    //     }

    //     // 1️⃣ Excel serial
    //     if (is_numeric($value)) {
    //         try {
    //             $dt = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject((float) $value);
    //             return Carbon::instance($dt)->format('Y-m-d');
    //         } catch (\Throwable $e) {
    //             // Continue below
    //         }
    //     }

    //     // 2️⃣ European format: DD/MM/YYYY
    //     if (preg_match('/^\d{1,2}\/\d{1,2}\/\d{4}$/', trim($value))) {
    //         try {
    //             return Carbon::createFromFormat('d/m/Y', trim($value))->format('Y-m-d');
    //         } catch (\Throwable $e) {
    //             // Continue below
    //         }
    //     }

    //     // 3️⃣ ISO format
    //     if (preg_match('/^\d{4}-\d{2}-\d{2}/', trim($value))) {
    //         return Carbon::parse(substr(trim($value), 0, 10))->format('Y-m-d');
    //     }

    //     // 4️⃣ Last chance generic parse
    //     try {
    //         return Carbon::parse($value)->format('Y-m-d');
    //     } catch (\Throwable $e) {
    //         return now()->format('Y-m-d');
    //     }
    // }


    private function normalizeZipCode($zip)
    {
        if (empty($zip)) return null;

        if (is_numeric($zip)) {
            $zip = (string)(int)$zip; // convert to integer string, removes ".0"
        } else {
            $zip = trim((string)$zip);
        }

        return $zip;
    }
}
