<?php

namespace App\Imports;

use App\Models\User;
use App\Models\Company;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;


class UsersImport implements ToCollection, WithHeadingRow
{

    public $success = true;  // To store success state
    public $message = '';
    public function collection(Collection $rows)
    {
        $errors = [];
        $successCount = 0;
       $userModel = new User();

        foreach ($rows as $index => $row) {
            Log::info('User Data:', $row->toArray());
            try {
               
                $validator = Validator::make($row->toArray(), [
                    'name' => 'required|string',
                    'email' => 'required|email|unique:users,email',
                    'phone' => 'nullable|unique:users,phone',
                    'company_name' => 'required|string',
                    'company_email' => 'required|email|unique:companies,company_email',
                    'gst_no' => 'nullable|unique:companies,gst_no',
                    
                ]);
                
            
                if ($validator->fails()) {
                    $errorMessages = implode(', ', $validator->errors()->all());
                    $errors[] = "Row " . ($index + 2) . " ({$row['name']}): $errorMessages" . "<br>";
                    continue;  // Continue to the next row
                }
                do {
                    // Get digits 1 to 9 and shuffle them
                    $digits = range(1, 9);
                    shuffle($digits);
                
                    // Add an extra random digit from 1 to 9 to make it 10 digits
                    $slug = implode('', $digits) . rand(1, 9);
                } while (Company::where('company_slug', $slug)->exists());
                
               
                Log::info('Starting transaction for user creation '. $row['name'] . '.');
            
                $user = User::create([
                    'name' => $row['name'] ?? null,
                    'email' => $row['email'] ?? null,
                    'phone' => $row['phone'] ?? null,
                    'password' => Hash::make($userModel->generateRandomPassword()),
                ]);
            
                $user->syncRoles(['Company']);
            
                $company = Company::create([
                    'company_name' => $row['company_name'] ?? $user->name ?? null,
                    'company_slug' => $slug ?? null,
                    'company_email' => $row['company_email'] ?? $user->email ?? null,
                    'admin_id' => $user->id ?? null,
                    'gst_no' => $row['gst_no'] ?? null
                ]);
            
                $successCount++;  // Count successful import
            } catch (\Exception $e) {
            
                $errors[] = "Row " . ($index + 2) . " ({$row['name']}): " . $e->getMessage();
                continue;  // Continue even after exception
            }
        }

        if (!empty($errors)) {
            $errorReport = implode('  ', $errors);
            $this->success = false;
            $this->message = "Imported $successCount user(s). Errors: " . implode(' | ', $errors);
            // throw new \Exception("Imported $successCount user(s) successfully. <br> Errors: $errorReport");
            return ['success'=>false,'message'=>"Imported $successCount user(s) successfully. <br> Errors: $errorReport"];
        }else{
            $this->success = true;
            $this->message = "Successfully imported $successCount user(s).";
            return ['success'=>true,'message'=>"Imported $successCount user(s) successfully."];
        }
    }

}

