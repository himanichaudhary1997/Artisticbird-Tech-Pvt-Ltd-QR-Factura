<?php

namespace App\Imports;

use App\Models\User;
use App\Models\Clients;
use App\Models\Company;
use App\Models\UserSubscriptions;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;



class InvoicesImport implements ToCollection, WithHeadingRow
{

    public $success = true;  // To store success state
    public $message = '';
    public function collection(Collection $rows)
    {
        $errors = [];
        $successCount = 0;

        foreach ($rows as $index => $row) {
            Log::info('Client Data:', $row->toArray());
            try {
                $dynamicTableName = (new Clients())->getTable();
                $validator = Validator::make($row->toArray(), [
                    'name' => 'required|string',
                    'email' => 'required|email|unique:'.$dynamicTableName.',email',
                   'gst_no' => [
                        'required',
                        'max:15',
                        'regex:/^[A-Za-z0-9]+$/', // Allows only alphabets and numbers
                        Rule::unique($dynamicTableName, 'gst_no')
                    ]
                ]);
                
            
                if ($validator->fails()) {
                    $errorMessages = implode(', ', $validator->errors()->all());
                    $errors[] = "Row " . ($index + 2) . " ({$row['name']}): $errorMessages" . "<br>";
                    continue;  // Continue to the next row
                }
                
                Log::info('Starting transaction for client creation '. $row['name'] . '.');
            
                $client = Clients::create([
                    'name' => $row['name'] ?? null,
                    'email' => $row['email'] ?? null,
                    'mobile_no' => $row['phone'] ?? null,
                    'gst_no' => $row['gst_no'] ?? null,
                    'extra'=>[
                        'company_name'=>$row['company_name'] ?? null,
                        'address'=>$row['address'] ?? null,
                        'state_code'=>$row['state_code'] ?? null,
                        'country_code'=>$row['country_code'] ?? null,
                        'zip_code'=>$row['zip_code'] ?? null,
                        'alternative_email'=>$row['alternative_email'] ?? null,
                    ]
                ]);
            
                
            
                $successCount++;  // Count successful import
            } catch (\Exception $e) {
            
                $errors[] = "Row " . ($index + 2) . " ({$row['name']}): " . $e->getMessage();
                continue;  // Continue even after exception
            }
        }

        if (!empty($errors)) {
            $errorReport = implode('  ', $errors);
            $this->success = false;
            $this->message = "Imported $successCount client(s). Errors: " . implode(' | ', $errors);
            // throw new \Exception("Imported $successCount user(s) successfully. <br> Errors: $errorReport");
            return ['success'=>false,'message'=>"Imported $successCount client(s) successfully. <br> Errors: $errorReport"];
        }else{
            $this->success = true;
            $this->message = "Successfully imported $successCount client(s).";
            return ['success'=>true,'message'=>"Imported $successCount client(s) successfully."];
        }
    }

}

