<?php

namespace App\Listeners;

use App\Models\ActivityLog;
use Illuminate\Auth\Events\Logout;
use Illuminate\Support\Facades\Request;

class LogSuccessfulLogout
{
    public function handle(Logout $event)
    {
        $company = $event->user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            // If it's a collection, take the first item
            $company = $company->first();
        }
        ActivityLog::create([
            'user_id' => $event->user->id,
            'company_id'=>$company->id ?? null,
            'action' => 'Logout',
            'ip_address' => Request::ip(),
        ]);
    }
}

