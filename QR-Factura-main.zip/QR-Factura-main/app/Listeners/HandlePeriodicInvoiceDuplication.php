<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Events\PeriodicInvoiceDuplicationRequested;

class HandlePeriodicInvoiceDuplication implements ShouldQueue
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(PeriodicInvoiceDuplicationRequested $event)
    {
        // Your duplication logic or dispatch a job
        \App\Jobs\DuplicatePeriodicInvoices::dispatch(
            $event->userId,
            $event->issueDate,
            $event->dueDate
        );
    }
}
