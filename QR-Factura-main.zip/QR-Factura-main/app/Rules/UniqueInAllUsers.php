<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class UniqueInAllUsers implements Rule
{
    protected $column;
    protected $excludeId;

    /**
     * Create a new rule instance.
     *
     * @param string $column
     * @param int|null $excludeId
     */
    public function __construct($column, $excludeId = null)
    {
        $this->column = $column;
        $this->excludeId = $excludeId;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $tables = ['users']; // Base users table
        $companies = DB::table('companies')->pluck('id'); // Retrieve company IDs

        foreach ($companies as $companyId) {
            $table = 'users_' . $companyId;
            if (Schema::hasTable($table)) {
                $query = DB::table($table)->where($this->column, $value);

                // Exclude the record if $excludeId is set
                if ($this->excludeId) {
                    $query->where('id', '!=', $this->excludeId);
                }

                if ($query->exists()) {
                    return false;
                }
            }
        }

        // Check the base users table
        $query = DB::table('users')->where($this->column, $value);
        if ($this->excludeId) {
            $query->where('id', '!=', $this->excludeId);
        }

        return !$query->exists();
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return "The :attribute has already been taken.";
    }
}
