<?php

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\User;
use App\Models\Clients;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use App\Models\TaxRules;
use App\Models\Providers;
use App\Models\Templates;

if (!function_exists('getUserRoles')) {
    function getUserRoles()
    {
       
        $user = auth()->user();

        if (!$user) {
            return 'user'; // Fallback role for guests
        }

        if ($user->hasRole('Admin')) {
            return 'admin';
        }

        if ($user->hasRole('Company')) {
            return 'company';
        }

        return 'user'; // Default role if not explicitly set
    }
}

if (!function_exists('getCompanyId')) {
    function getCompanyId()
    {
       return auth()->user()->company->id;;
    }
}

// if (!function_exists('parseInvoiceSortcodes')) {
//     function parseInvoiceSortcodes($content, $invoice, $company)
//     {
//         // Match all shortcodes inside square brackets []
//         preg_match_all('/\[(.*?)\]/', $content, $matches);

//         if (!empty($matches[1])) {
//             foreach ($matches[1] as $shortcode) {
//                 $replacement = handleShortcode($shortcode, $invoice, $company);
//                 $content = str_replace("[$shortcode]", $replacement, $content);
//             }
//         }

//         return $content;
//     }
// }

if (!function_exists('parseInvoiceSortcodes')) {
    function parseInvoiceSortcodes($content, $invoice, $company)
    {
        // ---- Conditional blocks by source ----
        $extra  = is_array($invoice->extra ?? null) ? $invoice->extra : [];
        $source = strtolower((string)($extra['source'] ?? 'default'));

        // [if source="prestashop"] ... [/if]  (comma se multiple: "prestashop,wordpress")
        $content = preg_replace_callback(
            '/\[if source="([^"]+)"\](.*?)\[\/if\]/s',
            function ($m) use ($source) {
                $allowed = array_map('trim', explode(',', strtolower($m[1])));
                return in_array($source, $allowed, true) ? $m[2] : '';
            },
            $content
        );

        // [ifnot source="prestashop"] ... [/ifnot]
        $content = preg_replace_callback(
            '/\[ifnot source="([^"]+)"\](.*?)\[\/ifnot\]/s',
            function ($m) use ($source) {
                $blocked = array_map('trim', explode(',', strtolower($m[1])));
                return !in_array($source, $blocked, true) ? $m[2] : '';
            },
            $content
        );

        // ---- Normal shortcodes ----
        preg_match_all('/\[(.*?)\]/', $content, $matches);

        if (!empty($matches[1])) {
            foreach ($matches[1] as $shortcode) {
                $replacement = handleShortcode($shortcode, $invoice, $company);
                $content = str_replace("[$shortcode]", $replacement, $content);
            }
        }

        return $content;
    }
}

if (!function_exists('handleShortcode')) {
    function handleShortcode($shortcode, $invoice, $company)
    {
        if(isset($company->admin_id)){
            $user = User::where('id',$company->admin_id)->first();
            $client = (new Clients())
            ->setDynamicTableName($company->id) // Set dynamic table
            ->newQuery() // Get a new query builder instance
            ->where('id',$invoice->client_id)->first();
            $provider = (new Providers())
            ->setDynamicTableName($company->id) // Set dynamic table
            ->newQuery()->where('id',$invoice->client_id)->first();
        }else{
            $user = User::where('id',1)->first();
            $client = User::where('id',$invoice->client_id)->first();
            $provider = Providers::where('id',$invoice->client_id)->first();
        }

        if($invoice->preview){
            $client = User::where('id',1)->first();
        }

        // ---------- PrestaShop PDF data (invoice->extra) ----------
        $psExtra = is_array($invoice->extra ?? null) ? $invoice->extra : [];
        $psMoney = function ($v) { return number_format((float)$v, 2, ',', '.') . ' €'; };
        $psRate  = function ($r) { return number_format((float)$r, 3, '.', '') . ' %'; };
        $psAddr  = function ($a) {
            if (empty($a) || !is_array($a)) {
                return '';
            }
            $lines = [
                trim(($a['firstname'] ?? '') . ' ' . ($a['lastname'] ?? '')),
                $a['company'] ?? '',
                $a['dni'] ?? '',
                $a['address1'] ?? '',
                $a['address2'] ?? '',
                $a['state'] ?? '',
                trim(($a['postcode'] ?? '') . ' ' . ($a['city'] ?? '')),
                $a['country'] ?? '',
                !empty($a['phone_mobile']) ? $a['phone_mobile'] : ($a['phone'] ?? ''),
            ];
            $lines = array_filter($lines, function ($l) { return trim((string)$l) !== ''; });
            return implode('<br>', array_map('e', $lines));
        };

        switch ($shortcode) {
            
            case 'userName':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'User Name';
                }
                return  $user->name ?? null;

            case 'user_company_name':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Company Name';
                }
                return  $company->company_name ?? $user->extra['company_name'] ?? null;

            
            case 'user_company_address':
                if(isset($invoice->preview) && $invoice->preview == true){
                    $addressParts = ['Company Address'];
                    return implode(', ', $addressParts);
                }
                $country = CountryModel::where('country_code', $company->extra['country_code'] ?? $user->extra['country_code'] ?? null)->first();
                $state = StateModel::where('state_code', $company->extra['state_code'] ?? $user->extra['state_code'] ?? null)->first();
            
                $addressParts = array_filter([
                    $company->extra['company_address'] ?? $user->extra['company_address'] ?? null,
                    ($company->extra['street_number'] ?? $user->extra['street_number'] ?? null) ? ($company->extra['street_number'] ?? $user->extra['street_number']) : null,
                    ($company->extra['locality'] ?? $user->extra['locality'] ?? null) ? '<br>' . ($company->extra['locality'] ?? $user->extra['locality']) : null,
                    ($company->extra['zip_code'] ?? $user->extra['zip_code'] ?? null) ? ' - ' . ($company->extra['zip_code'] ?? $user->extra['zip_code']). ', ' : null,
                    !empty($state) ? $state->name. ', ' : null,
                    $country->name ?? null
                ]);
                
                
                return implode('', $addressParts);

            case 'user_single_company_address':
                if(isset($invoice->preview) && $invoice->preview == true){
                    $addressParts = ['Company Address'];
                    return implode(', ', $addressParts);
                }
                $country = CountryModel::where('country_code', $company->extra['country_code'] ?? $user->extra['country_code'] ?? null)->first();
                $state = StateModel::where('state_code', $company->extra['state_code'] ?? $user->extra['state_code'] ?? null)->first();
            
                $addressParts = array_filter([
                    $company->extra['company_address'] ?? $user->extra['company_address'] ?? null,
                    ($company->extra['street_number'] ?? $user->extra['street_number'] ?? null) ? ($company->extra['street_number'] ?? $user->extra['street_number']) : null,
                    ($company->extra['locality'] ?? $user->extra['locality'] ?? null) ? '' . ($company->extra['locality'] ?? $user->extra['locality']) : null,
                    ($company->extra['zip_code'] ?? $user->extra['zip_code'] ?? null) ? ' - ' . ($company->extra['zip_code'] ?? $user->extra['zip_code']). ', ' : null,
                    !empty($state) ? $state->name. ', ' : null,
                    $country->name ?? null
                ]);
                
                
                return implode('', $addressParts);
                
              
                
            case 'alumina':     
                if(isset($invoice->extra['patient'])){
                    return  '<br><span style="margin:0;">A: </span>'.$invoice->extra['patient'];
                }else{
                    return '';
                }    
            case 'professional':  
                if(isset($invoice->extra['profesional'])){
                    return  '<br><span style="margin:0;">P: </span>'.$invoice->extra['profesional'];
                }else{
                    return '';
                }    
                

            case 'invoiceNumber':   
                if(isset($invoice->invoice_id)){
                    // dd($invoice);
                    if($invoice->status == 4){
                        $invoice_id = ($invoice->ref_no ?? $invoice->invoice_id);
                    }else{
                        $invoice_id = $invoice->ref_no ?? $invoice->invoice_id;
                    }
                    return  '<span style="margin:0;">'.__('Invoice Number: ').'</span>'. ($invoice_id);
                }elseif($invoice->performa_id){
                    return  '<span style="margin:0;">'.__('Proposal: ').'</span>'.$invoice->performa_id;
                }elseif($invoice->delivery_note_id){
                    return  '<span style="margin:0;">'.__('Delivery Note id: ').'</span>'.$invoice->delivery_note_id;
                }

                return null;
            case 'invoiceDate':
                $invoicedate = ($invoice->issue_date? '<span>'.__('Issue Date : ').'</span>' .Carbon::parse($invoice->issue_date)->format('d/m/Y'):'');
                return  $invoicedate;
          
            case 'orderNumber':

                if (isset($invoice->preview) && $invoice->preview == true) {
                        return 'Order Number';
                }

              //  return $invoice->extra['order_number'] ?? '';
                 if (!empty($invoice->extra['order_number'])) {
                    return '<span>' . __('Order Number:') . '</span>' .
                        $invoice->extra['order_number'];
                }

                return '';

            case 'orderReference':

                if (isset($invoice->preview) && $invoice->preview == true) {
                        return 'Order Reference';
                }

              //  return $invoice->extra['order_number'] ?? '';
                 if (!empty($invoice->extra['order_reference'])) {
                    return '<span>' . __('Order Reference:') . '</span>' .
                        $invoice->extra['order_reference'];
                }

                return '';

            case 'orderDate':

                if (isset($invoice->preview) && $invoice->preview == true) {
                    return 'Order Date';
                }

                if (!empty($invoice->extra['order_date'])) {
                    return '<span>' . __('Order Date:') . '</span>' .
                        Carbon::parse($invoice->extra['order_date'])->format('d/m/Y');
                }

            
                
            case 'dueDate':
                $dueDate = ($invoice->due_date? ' <span>'.__('Due Date : ').'</span>' .Carbon::parse($invoice->due_date)->format('d/m/Y'):'');
                return  $dueDate;

            case 'validityDate':
                $dueDate = ($invoice->due_date? ' <span>'.__('Validity Date : ').'</span>' .Carbon::parse($invoice->due_date)->format('d/m/Y'):'');
                return  $dueDate;
            case 'ref_no':
                return  $invoice->ref_no ? '<span>'.__('Ref: ').'</span>'.$invoice->ref_no.'<br>' : null;

                
            
            case 'providerName':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Client Name';
                }
                $clientName = $provider->name ?? null;
                return  $clientName;
            case 'company_user_name':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Company User Name';
                }
                $companyUserName = $client->name ?? null; 
                return  $companyUserName;


            case 'customerName':
                // dd($client);
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Client Name';
                }
                $fullClientName = trim(($client->name ?? '') . ' ' . ($client->extra['surname'] ?? ''));
                $clientName = $client->company->company_name ?? $client->extra['company_name'] ?? ($fullClientName !== '' ? $fullClientName : null);
                return  isset($client->name) && !empty($client->name) ? '<span style="margin:0; font-size:16px">'.$clientName.'</span>' : null;

                case 'user_company_phone':
                    if(isset($invoice->preview) && $invoice->preview == true){
                        return 'T (+34) 000 000 000';
                    }
                    $phone = $user->phone ?? null;
                    return !empty($phone) ? 'T ' . $phone : '';

                case 'user_company_email':
                    if(isset($invoice->preview) && $invoice->preview == true){
                        return 'info@company.com';
                    }
                    $email = $company->company_email ?? $user->email ?? null;
                    return $email ?? '';

                case 'user_company_website':
                    if(isset($invoice->preview) && $invoice->preview == true){
                        return 'www.company.com';
                    }

                    // Try the platform this invoice actually came from (WooCommerce, Prestashop, etc.)
                    $systemRecord = \App\Models\VerifactuSystemRecord::where('invoice_id', $invoice->id)
                        ->where(function($q){
                            $q->whereNull('type')->orWhere('type', '!=', 'receipt');
                        })
                        ->first();

                    $website = (!empty($systemRecord->origin)) ? $systemRecord->origin : ($company->url ?? null);

                    if (empty($website)) {
                        return '';
                    }

                    $host = parse_url($website, PHP_URL_HOST) ?: preg_replace('#^https?://#i', '', $website);
                    $url  = preg_match('/^https?:\/\//i', $website) ? $website : 'https://' . $website;

                    return '<a href="' . e($url) . '" style="color:#000000; text-decoration:none;" target="_blank">' . e($host) . '</a>';

                    case 'customerPhone':
                        if(isset($invoice->preview) && $invoice->preview == true){
                            return 'Client Phone';
                        }
                        $clientPhone = $client->mobile_no ?? null;
                        return !empty($clientPhone) ? $clientPhone : '';

            case 'customer_gst_no':
                // dd($client);
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Client Name';
                }
                $gst_no = $client->company->gst_no ?? $client->gst_no ?? null;
                return  '<span style="margin:0; font-size:13px">'.$gst_no.'</span>';
    
            case 'provider_gst_no':
                // dd($client);
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Client Name';
                }
                $gst_no =$provider->gst_no ?? null;
                return  '<span style="margin:0; font-size:13px">'.$gst_no.'</span>';
    
            case 'customerAddress':
                if(isset($invoice->preview) && $invoice->preview == true){
                    $country = CountryModel::where('country_code', $client->extra['country_code'] ?? null)->first();
                    $state = StateModel::where('state_code', $client->extra['state_code'] ?? null)->first();
                
                    $addressParts = ['Client Address'];
                }else{
                    if(!empty($company)){
                        $country = CountryModel::where('country_code', $client->extra['country_code'] ?? null)->first();
                        // $state = StateModel::where('state_code', $client->extra['state_code'] ?? null)->first();
                        $addressParts = array_filter([
                            $client->extra['address'] ?? null,
                            (isset($client->extra['locality']) && !empty($client->extra['locality'])) ? '<br>' . ($client->extra['locality']) : null,
                            (isset($client->extra['zip_code']) && !empty($client->extra['zip_code'])) ? '<br>' . ($client->extra['zip_code']). ', ' : null,
                            (isset($client->extra['state_name']) && !empty($client->extra['state_name'])) ?  ($client->extra['state_name']). ', ' : null,// Get state name
                            $country->name ?? null // Get country name
                        ]);
                    }else{
                        $country = CountryModel::where('country_code', $client->company->extra['country_code'] ?? null)->first();
                        $state = StateModel::where('state_code', $client->company->extra['state_code'] ?? null)->first();
                    
                        $addressParts = array_filter([
                            $client->company->extra['company_address'] ?? null,
                            (isset($client->company->extra['locality']) && !empty($client->company->extra['locality'])) ? '<br>' . ($client->company->extra['locality']) : null,
                            (isset($client->company->extra['zip_code']) && !empty($client->company->extra['zip_code'])) ? '<br>' . ($client->company->extra['zip_code']). ', ' : null,
                            !empty($state) ? $state->name. ', ' : null,  //   // Get state name
                            $country->name ?? null // Get country name
                        ]);
                        
                        
                    }
                }
                
                // dd($addressParts);
                // Implode with '<br>' to generate the HTML output
                return $addressHtml = implode('', $addressParts);

            case 'providerAddress':
                if(isset($invoice->preview) && $invoice->preview == true){
                    $country = CountryModel::where('country_code', $client->extra['country_code'] ?? null)->first();
                    $state = StateModel::where('state_code', $client->extra['state_code'] ?? null)->first();
                
                    $addressParts = ['Client Address'];
                }else{
                    $countries = getProviderCountries();
                    // $state = StateModel::where('state_code', $client->extra['state_code'] ?? null)->first();
                
                    $addressParts = array_filter([
                        $invoice->client->extra['address'] ?? null,
                        (isset($provider->extra['locality']) && !empty($provider->extra['locality'])) ? '<br>' . ($provider->extra['locality']) : null,
                        (isset($provider->extra['zip_code']) && !empty($provider->extra['zip_code'])) ? '<br>' . ($provider->extra['zip_code']). ', ' : null,
                        (isset($provider->extra['state_name']) && !empty($provider->extra['state_name'])) ?  ($provider->extra['state_name']). ', ' : null,// Get state name
                        $countries[$provider->extra['country_code'] ?? 'ES'] // Get country name
                    ]);
                }
                
                // dd($addressParts);
                // Implode with '<br>' to generate the HTML output
                return $addressHtml = implode('', $addressParts);
            case 'userEmail':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'User Email';
                }
                return  $user->email ?? null;
            
            case 'todayDate':
                return  now()->format('d/m/Y');
            
            case 'contractDate':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Contract Date';
                }
                return optional($invoice->contract->contract_date)
                ->format('d/m/Y');

            case 'nextYear' :
                return  now()->addYear()->format('Y');
            case 'totalPrice':
                return  formatCurrency($invoice->grandTotal, $invoice->currency);

            // case 'totalPriceInWord':
            //     $locale = app()->getLocale(); // use app locale

            //     $formatter = new \NumberFormatter($locale, \NumberFormatter::SPELLOUT);

            //     $amount = round($invoice->grandTotal, 2);

            //     $integerPart = floor($amount);
            //     $decimalPart = round(($amount - $integerPart) * 100);

            //     $words = ucfirst($formatter->format($integerPart));

            //     if ($decimalPart > 0) {
            //         $words .= ' ' . __('and') . ' ' . $formatter->format($decimalPart);
            //     }

            //     return $words;

            case 'totalPriceInWord':

                $locale = app()->getLocale(); // ex: es_ES, en_US, fr_FR

                $formatter = new \NumberFormatter($locale, \NumberFormatter::SPELLOUT);

                $amount = round($invoice->grandTotal, 2);

                $integerPart = (int) $amount;
                $decimalPart = (int) round(($amount - $integerPart) * 100);

                // locale-based words
                $currencyMain = __('euro');      // "euros"
                $currencySub  = __('cent');      // "céntimos"
                $connector    = __('with');      // "con"

                $words = ucfirst($formatter->format($integerPart)) . ' ' . $currencyMain;

                if ($decimalPart > 0) {
                    $words .= ' ' . $connector . ' ' . $formatter->format($decimalPart) . ' ' . $currencySub;
                }

                return $words;

    
            case 'customerGST':
                
                return  $client->gst_no ? '<br><span>'.__('C.I.F: ').'</span>'.$client->gst_no.'<br>' : null;
                
            case 'user_company_gst_no':
                if (isset($invoice->preview) && $invoice->preview == true) {
                    return 'Company Gst No';
                }
                
                $gstNo = null;
                if (!empty($company) && isset($company->gst_no)) {
                    $gstNo = $company->gst_no;
                } elseif (!empty($user->extra['gst_no'])) {
                    $gstNo = $user->extra['gst_no'];
                }
                
                return __('GST: ') . $gstNo;
                
            case 'shipping_details':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return __('Shipping Details');
                }
                if(isset($invoice->extra['shipping_details']) && !empty($invoice->extra['shipping_details'])){
                    return  __('Shipping Details:').$invoice->extra['shipping_details'] ?? null;
                }else{
                    return  '';
                }

            case 'invoice_note':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return __('Invoice Note');
                }
                if(isset($invoice->extra['note']) && !empty($invoice->extra['note'])){
                    return  __('Note: ').$invoice->extra['note'] ?? null;
                }else{
                    return  '';
                }
            
            case 'payment_method':
                // dd($company);
                if(isset($invoice->preview) && $invoice->preview == true){
                    return $html = '<span> ' .__("Payment method:") . '</span>Texto here. <br> <span>' .__("Bank details:") .' </span>Texto here.';
                }
                $iban =   $company->extra['iban_number'] ?? $user->extra['iban_number'] ?? null;
                $iban = nl2br($iban);
                $html = '';
                if($invoice->paymentMethod){
                    $html .= '<span>'.__("Payment method:").' </span>' . $invoice->paymentMethod->name;
                }
                if($invoice->paymentMethod && $invoice->paymentMethod->name == 'Transferencia bancaria' && !empty($iban)){
                    $html .= '<br><span>'.__("Bank details:").' </span><br><span style="font-size: 13px;">' . $iban .'</span>';
                }
                // dd($iban);
                return  $html;
                
           
                case 'companylogo':
                    $domain = $invoice->domain ?? $invoice->prefix_domain ?? null;
                    if(isset($domain->extra['company_logo']) && !empty($domain->extra['company_logo'])){
                        $companyLogo = $domain->extra['company_logo'] ?? null;
                    }else{
                        $companyLogo = $company->extra['company_logo'] ?? null;
                    }
                    $userLogo = $user->extra['company_logo'] ?? null;
                
                    // Function to ensure URL has full domain
                    $ensureFullUrl = function($path) {
                        if (empty($path)) {
                            return null;
                        }
                        
                        // If it's already a full URL, return as-is
                        if (filter_var($path, FILTER_VALIDATE_URL)) {
                            return $path;
                        }
                        
                        // If it starts with storage path, convert to URL
                        if (str_starts_with($path, '/storage/')) {
                            return asset($path);
                        }
                        
                        // Default case (for other relative paths)
                        return url($path);
                    };
                
                    if (!empty($companyLogo)) {
                        $logoUrl = $ensureFullUrl($companyLogo);
                        return '<img src="' . e($logoUrl) . '" style="height: 50px;width: auto;" alt="Company Logo" />';
                    } elseif (!empty($userLogo)) {
                        $logoUrl = $ensureFullUrl($userLogo);
                        return '<img src="' . e($logoUrl) . '" style="height: 50px;width: auto;" alt="User Company Logo" />';
                    } else {
                        return '<h3><strong>'. $company->company_name ?? $user->extra['company_name'] .'</strong></h3>' ;
                    }

            case 'user_qr':
                    if(isset($invoice->preview) && $invoice->preview == true){
                        return $html = '<strong>Your Qr Code</strong>';
                    }
                    if(!empty(getUserQrCode($user->id))){
                        return '<img src="' . getUserQrCode($user->id) . '" style="max-width:200px;" />';
                    }else{
                        return '';
                    }

            case 'invoice_qr':
                if(isset($invoice->preview) && $invoice->preview == true){
                    return $html = '<strong>Your Qr Code</strong>';
                }
                if(isset($invoice->invoice_id) && isset($invoice->qr_code) && !empty($invoice->qr_code) && isset($company->extra['country_code']) && $company->extra['country_code'] == 'ES'){
                    return '<img src="' .asset('storage/' . $invoice->qr_code) . '?t=' . now()->timestamp . '" style="max-width:95px;min-width: 95px;" />';
                }else{
                    return '';
                }

                case 'psInvoiceNumber':
                    return e($psExtra['ps_invoice_number'] ?? ($invoice->ref_no ?? $invoice->invoice_id ?? ''));

                case 'psInvoiceDate':
                    $d = $psExtra['ps_invoice_date'] ?? $invoice->issue_date ?? null;
                    return $d ? Carbon::parse($d)->format('d/m/Y') : '';

                case 'psOrderReference':
                    return e($psExtra['order_reference'] ?? '');

                case 'psOrderDate':
                    return !empty($psExtra['order_date']) ? Carbon::parse($psExtra['order_date'])->format('d/m/Y') : '';

                case 'psDeliveryAddress':
                    return $psAddr($psExtra['delivery_address'] ?? null);

                case 'psInvoiceAddress':
                    return $psAddr($psExtra['invoice_address'] ?? null);

                case 'psProductsTable':
                    // PS data nahi hai (purane invoices) to purani list
                    if (empty($psExtra['products'])) {
                        return renderSortcode($invoice, 'itemAnadeanaList', $company);
                    }
                    $th = 'padding:8px 6px; font-weight:bold; text-align:%s; background:#f2f2f2; border-bottom:1px solid #000000; font-size:12px;';
                    $html  = '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse; font-size:13px;">';
                    $html .= '<tr>'
                        . '<td style="' . sprintf($th, 'left') . ' width:14%;">Referencia</td>'
                        . '<td style="' . sprintf($th, 'left') . ' width:34%;">Producto</td>'
                        . '<td style="' . sprintf($th, 'center') . ' width:10%;">Tasa de impuesto</td>'
                        . '<td style="' . sprintf($th, 'right') . ' width:16%;">Precio unitario (Impuestos excl.)</td>'
                        . '<td style="' . sprintf($th, 'center') . ' width:8%;">Cant.</td>'
                        . '<td style="' . sprintf($th, 'right') . ' width:18%;">Total (Impuestos excl.)</td>'
                        . '</tr>';
                    foreach ($psExtra['products'] as $p) {
                        $td = 'padding:8px 6px; border-bottom:1px solid #dddddd;';
                        $html .= '<tr>'
                            . '<td style="' . $td . '">' . e($p['reference'] ?? '') . '</td>'
                            . '<td style="' . $td . '">' . e($p['name'] ?? '') . '</td>'
                            . '<td style="' . $td . ' text-align:center;">' . rtrim(rtrim(number_format((float)($p['tax_rate'] ?? 0), 3, '.', ''), '0'), '.') . ' %</td>'
                            . '<td style="' . $td . ' text-align:right;">' . $psMoney($p['unit_price_excl'] ?? 0) . '</td>'
                            . '<td style="' . $td . ' text-align:center;">' . (int)($p['quantity'] ?? 0) . '</td>'
                            . '<td style="' . $td . ' text-align:right;">' . $psMoney($p['total_excl'] ?? 0) . '</td>'
                            . '</tr>';
                    }
                    return $html . '</table>';

                case 'psTaxBreakdown':
                    if (empty($psExtra['tax_breakdown'])) {
                        return '';
                    }
                    $labels = ['products' => 'Productos', 'shipping' => 'Envío'];
                    $html  = '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse; font-size:12px; border:1px solid #dddddd;">';
                    $html .= '<tr style="background:#f2f2f2;">'
                        . '<td style="padding:6px; font-weight:bold;">Desglose impuestos</td>'
                        . '<td style="padding:6px; font-weight:bold; text-align:center;">Tasa de impuesto</td>'
                        . '<td style="padding:6px; font-weight:bold; text-align:right;">Total impuesto</td>'
                        . '</tr>';
                    foreach ($psExtra['tax_breakdown'] as $t) {
                        $html .= '<tr>'
                            . '<td style="padding:6px; border-top:1px solid #dddddd;">' . e($labels[$t['label'] ?? ''] ?? ($t['label'] ?? '')) . '</td>'
                            . '<td style="padding:6px; border-top:1px solid #dddddd; text-align:center;">' . $psRate($t['rate'] ?? 0) . '</td>'
                            . '<td style="padding:6px; border-top:1px solid #dddddd; text-align:right;">' . $psMoney($t['total_amount'] ?? 0) . '</td>'
                            . '</tr>';
                    }
                    return $html . '</table>';

                case 'psPayment':
                    if (empty($psExtra['payment']) && empty($psExtra['carrier'])) {
                        return '';
                    }
                    $html  = '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse; font-size:12px; border:1px solid #dddddd;">';
                    if (!empty($psExtra['payment'])) {
                        $html .= '<tr>'
                            . '<td style="padding:6px; font-weight:bold; background:#f2f2f2; width:35%;">Método de pago</td>'
                            . '<td style="padding:6px; text-align:center;">' . e($psExtra['payment']['method'] ?? '') . '</td>'
                            . '<td style="padding:6px; text-align:right;">' . $psMoney($psExtra['payment']['amount'] ?? 0) . '</td>'
                            . '</tr>';
                    }
                    if (!empty($psExtra['carrier'])) {
                        $html .= '<tr>'
                            . '<td style="padding:6px; font-weight:bold; background:#f2f2f2; border-top:1px solid #dddddd;">Transportista</td>'
                            . '<td style="padding:6px; text-align:center; border-top:1px solid #dddddd;" colspan="2">' . e($psExtra['carrier']) . '</td>'
                            . '</tr>';
                    }
                    return $html . '</table>';

                case 'psTotals':
                    if (empty($psExtra['totals'])) {
                        return '';
                    }
                    $tt  = $psExtra['totals'];
                    $row = function ($label, $value, $bold = false) {
                        $w = $bold ? 'font-weight:bold;' : '';
                        return '<tr>'
                            . '<td style="padding:7px 10px; text-align:right; ' . $w . '">' . $label . '</td>'
                            . '<td style="padding:7px 10px; text-align:right; ' . $w . '">' . $value . '</td>'
                            . '</tr>';
                    };
                    $html  = '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse; font-size:13px; background:#f7f7f7;">';
                    $html .= $row('Total Productos', $psMoney($tt['total_products_excl'] ?? 0));
                    if ((float)($tt['discounts_excl'] ?? 0) > 0) {
                        $html .= $row('Descuentos', '-' . $psMoney($tt['discounts_excl']));
                    }
                    $html .= $row('Gastos de envío', !empty($tt['is_free_shipping']) ? 'Envío gratis' : $psMoney($tt['shipping_excl'] ?? 0));
                    $html .= $row('Total (Imp. excl.)', $psMoney($tt['total_excl'] ?? 0), true);
                    $html .= $row('Total impuesto', $psMoney($tt['total_tax'] ?? 0), true);
                    $html .= $row('Total', $psMoney($tt['total'] ?? 0), true);
                    return $html . '</table>';

            case 'year':
                return now()->format('Y');

            case 'itemList':
                return renderSortcode($invoice, 'itemList',$company);
            case 'itemAnadeanaList':
                return renderSortcode($invoice, 'itemAnadeanaList', $company);
            case 'copyright':
                return '';
                if(isset($invoice->preview) && $invoice->preview == true){
                    return 'Company Name'
                        . ' © ' . Carbon::now()->year . ' - ' . __('All rights reserved') . '.';
                }
                return ($company->company_name ?? $user->extra['company_name'] ?? null) 
                        . ' © ' . Carbon::now()->year . ' - ' . __('All rights reserved') . '.';
                return "[Unknown shortcode: $shortcode]";
                
        }
    }
}


// if (!function_exists('renderSortcode')) {
//     function renderSortcode($sortcode, $type,$company = null)
//     {
//         $data = compact('sortcode'); 

//         switch ($type) {

//             case 'itemList':
//                 $data['invoice'] = $sortcode ?? []; 
//                 $data['company'] = $company ?? []; 
//                 break;
//         }

//         $view = match ($type) {
//             'itemList' => 'shortcodes.itemList',
//             default => null,
//         };

//         if (!$view) {
//             return "<p>Unsupported sortcode type: $type</p>";
//         }
//         //dd($view, $data);

//         return View::make($view, $data)->render();
//     }
// }
if (!function_exists('renderSortcode')) {
    function renderSortcode($sortcode, $type, $company = null)
    {
        $data = compact('sortcode');

        switch ($type) {
            case 'itemList':
            case 'itemAnadeanaList':
                $data['invoice'] = $sortcode ?? [];
                $data['company'] = $company ?? [];
                break;
        }

        $view = match ($type) {
            'itemList'         => 'shortcodes.itemList',
            'itemAnadeanaList' => 'shortcodes.itemAnadeanaList',
            default            => null,
        };

        if (!$view) {
            return "<p>Unsupported sortcode type: $type</p>";
        }

        return View::make($view, $data)->render();
    }
}

if (!function_exists('formatCurrency')) {
    // function formatCurrency($amount, $currency)
    // {
    //     if (!is_numeric($amount)) {
    //         return $amount;
    //     }

    //     switch ($currency) {
    //         case '€': // Euro format (comma for decimals, dot for thousands)
    //             return number_format($amount, 2, ',', '.').'€';
    //         case '$': // US Dollar format
    //             return '$ ' . number_format($amount, 2, '.', ',');
    //         case '₹': // Indian Rupee format
    //             return "INR " . number_format($amount, 2, '.', ',');
    //         default: // Default formatting
    //             return number_format($amount, 2);
    //     }
    // }
    function formatCurrency($amount, $currency) {
        // Convert to standard float: remove thousand separators and replace decimal commas with dots
        if (!is_numeric($amount)) {
            // Remove any currency symbols or non-numeric characters (except comma, dot)
            $amount = preg_replace('/[^\d,.-]/', '', $amount);

            // If the string uses a comma as a decimal separator (common in Europe), fix it
            if (strpos($amount, ',') !== false && strpos($amount, '.') === false) {
                $amount = str_replace(',', '.', $amount);
            } elseif (strpos($amount, ',') !== false && strpos($amount, '.') !== false) {
                // If both are present, assume European format: '1.234,56' => '1234.56'
                $amount = str_replace('.', '', $amount); // remove thousand sep
                $amount = str_replace(',', '.', $amount); // replace decimal sep
            }

            // Now it's safe to convert to float
            if (!is_numeric($amount)) {
                return $amount; // Still invalid
            }
        }

        $amount = floatval($amount);

        switch ($currency) {
            case '€': // Euro
                return number_format($amount, 2, ',', '.') . ' €';
            case '$': // Dollar
                return '$ ' . number_format($amount, 2, '.', ',');
            case '₹': // Rupee
                return 'INR ' . number_format($amount, 2, '.', ',');
            default:
                return number_format($amount, 2);
        }
    }

}


function getFileImage($publicUrl)
{
    // Allowed MIME types
    $allowedMimes = [
        'image_all' => ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'image/svg+xml'],
        'image' => ['image/jpeg', 'image/png', 'image/jpg'],
        'spreadsheet' => ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        'document' => ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'video' => ['video/mp4', 'video/mov', 'video/avi', 'video/mkv'],
    ];

    // Default response
    $defaultIcon = asset('uploads/images/file-icon.png');

    try {
        // Convert public URL to storage path
        $filePath = str_replace('/storage/', 'public/', $publicUrl);
        
        // Get MIME type
        $mimeType = Storage::mimeType($filePath);

        if (!$mimeType) {
            return $defaultIcon;
        }

        // Return the original URL if it's an image
        if (in_array($mimeType, $allowedMimes['image_all'])) {
            return $publicUrl;
        }
        
        // Return appropriate icons for other types
        if ($mimeType === 'application/pdf') {
            return asset('uploads/images/pdf-icon.png');
        }
        
        if (in_array($mimeType, $allowedMimes['document'])) {
            return asset('uploads/images/word.png');
        }
        
        if (in_array($mimeType, $allowedMimes['spreadsheet'])) {
            return asset('uploads/images/excel-icon.jpeg');
        }

        return $defaultIcon;
    } catch (\Exception $e) {
        return $defaultIcon;
    }
}

if (!function_exists('getUserQrCode')) {
    function getUserQrCode($userId)
    {
        $user = User::find($userId);
        return $user && $user->qr_code 
        ? asset('storage/' . $user->qr_code) . '?t=' . now()->timestamp 
        : null;
    }
}


function getStatuses(){
    return [
        '0'=>'Draft', 
        '1'=>'Paid', 
        '2'=>'Sent', 
        // '3'=>'Partially Paid',
        // '4'=>'Negative',
        '5'=>'Not Paid',
        '6'=>'Overdue',
    ];
}

function sanitizeCompanyName($name) {
    // Convert to lowercase
    $name = strtolower($name);

    // Replace spaces and underscores with hyphens
    $name = str_replace([' ', '_'], '-', $name);

    // Remove all characters except a-z, 0-9, and hyphen
    $name = preg_replace('/[^a-z0-9\-]/', '', $name);

    // Remove multiple hyphens in a row
    $name = preg_replace('/-+/', '-', $name);

    // Trim hyphens from start and end
    $name = trim($name, '-');

    // Ensure the string is 3 to 30 characters
    $name = substr($name, 0, 30);

    // Pad with a if too short
    if (strlen($name) < 3) {
        $name = str_pad($name, 3, 'a');
    }

    return $name;
}

function getTerritories(){
    return [
        'SPAIN_OTHER',
        'ARABA',
        'BIZKAIA',
        'GIPUZKOA',
        'NAVARRE',
        'CANARY_ISLANDS',
        'CEUTA',
        'MELILLA'
    ];
}


function getProviderCountries(){
    $countries = [
        "AD" => "Andorra",
        "AE" => "United Arab Emirates",
        "AF" => "Afghanistan",
        "AG" => "Antigua and Barbuda",
        "AI" => "Anguilla",
        "AL" => "Albania",
        "AM" => "Armenia",
        "AO" => "Angola",
        "AR" => "Argentina",
        "AS" => "American Samoa",
        "AT" => "Austria",
        "AU" => "Australia",
        "AW" => "Aruba",
        "AX" => "Åland Islands",
        "AZ" => "Azerbaijan",
        "BA" => "Bosnia and Herzegovina",
        "BB" => "Barbados",
        "BD" => "Bangladesh",
        "BE" => "Belgium",
        "BF" => "Burkina Faso",
        "BG" => "Bulgaria",
        "BH" => "Bahrain",
        "BI" => "Burundi",
        "BJ" => "Benin",
        "BL" => "Saint Barthélemy",
        "BM" => "Bermuda",
        "BN" => "Brunei Darussalam",
        "BO" => "Bolivia",
        "BQ" => "Bonaire, Sint Eustatius and Saba",
        "BR" => "Brazil",
        "BS" => "Bahamas",
        "BT" => "Bhutan",
        "BV" => "Bouvet Island",
        "BW" => "Botswana",
        "BY" => "Belarus",
        "BZ" => "Belize",
        "CA" => "Canada",
        "CC" => "Cocos (Keeling) Islands",
        "CD" => "Congo (Democratic Republic)",
        "CF" => "Central African Republic",
        "CG" => "Congo",
        "CH" => "Switzerland",
        "CI" => "Côte d’Ivoire",
        "CK" => "Cook Islands",
        "CL" => "Chile",
        "CM" => "Cameroon",
        "CN" => "China",
        "CO" => "Colombia",
        "CR" => "Costa Rica",
        "CU" => "Cuba",
        "CV" => "Cabo Verde",
        "CW" => "Curaçao",
        "CX" => "Christmas Island",
        "CY" => "Cyprus",
        "CZ" => "Czechia",
        "DE" => "Germany",
        "DJ" => "Djibouti",
        "DK" => "Denmark",
        "DM" => "Dominica",
        "DO" => "Dominican Republic",
        "DZ" => "Algeria",
        "EC" => "Ecuador",
        "EE" => "Estonia",
        "EG" => "Egypt",
        "EH" => "Western Sahara",
        "ER" => "Eritrea",
        "ES" => "Spain",
        "ET" => "Ethiopia",
        "FI" => "Finland",
        "FJ" => "Fiji",
        "FK" => "Falkland Islands",
        "FM" => "Micronesia",
        "FO" => "Faroe Islands",
        "FR" => "France",
        "GA" => "Gabon",
        "GB" => "United Kingdom",
        "GD" => "Grenada",
        "GE" => "Georgia",
        "GF" => "French Guiana",
        "GG" => "Guernsey",
        "GH" => "Ghana",
        "GI" => "Gibraltar",
        "GL" => "Greenland",
        "GM" => "Gambia",
        "GN" => "Guinea",
        "GP" => "Guadeloupe",
        "GQ" => "Equatorial Guinea",
        "GR" => "Greece",
        "GT" => "Guatemala",
        "GU" => "Guam",
        "GW" => "Guinea-Bissau",
        "GY" => "Guyana",
        "HK" => "Hong Kong",
        "HN" => "Honduras",
        "HR" => "Croatia",
        "HT" => "Haiti",
        "HU" => "Hungary",
        "ID" => "Indonesia",
        "IE" => "Ireland",
        "IL" => "Israel",
        "IM" => "Isle of Man",
        "IN" => "India",
        "IO" => "British Indian Ocean Territory",
        "IQ" => "Iraq",
        "IR" => "Iran",
        "IS" => "Iceland",
        "IT" => "Italy",
        "JE" => "Jersey",
        "JM" => "Jamaica",
        "JO" => "Jordan",
        "JP" => "Japan",
        "KE" => "Kenya",
        "KG" => "Kyrgyzstan",
        "KH" => "Cambodia",
        "KI" => "Kiribati",
        "KM" => "Comoros",
        "KN" => "Saint Kitts and Nevis",
        "KP" => "North Korea",
        "KR" => "South Korea",
        "KW" => "Kuwait",
        "KY" => "Cayman Islands",
        "KZ" => "Kazakhstan",
        "LA" => "Lao People’s Democratic Republic",
        "LB" => "Lebanon",
        "LC" => "Saint Lucia",
        "LI" => "Liechtenstein",
        "LK" => "Sri Lanka",
        "LR" => "Liberia",
        "LS" => "Lesotho",
        "LT" => "Lithuania",
        "LU" => "Luxembourg",
        "LV" => "Latvia",
        "LY" => "Libya",
        "MA" => "Morocco",
        "MC" => "Monaco",
        "MD" => "Moldova",
        "ME" => "Montenegro",
        "MF" => "Saint Martin",
        "MG" => "Madagascar",
        "MH" => "Marshall Islands",
        "MK" => "North Macedonia",
        "ML" => "Mali",
        "MM" => "Myanmar",
        "MN" => "Mongolia",
        "MO" => "Macao",
        "MP" => "Northern Mariana Islands",
        "MQ" => "Martinique",
        "MR" => "Mauritania",
        "MS" => "Montserrat",
        "MT" => "Malta",
        "MU" => "Mauritius",
        "MV" => "Maldives",
        "MW" => "Malawi",
        "MX" => "Mexico",
        "MY" => "Malaysia",
        "MZ" => "Mozambique",
        "NA" => "Namibia",
        "NC" => "New Caledonia",
        "NE" => "Niger",
        "NF" => "Norfolk Island",
        "NG" => "Nigeria",
        "NI" => "Nicaragua",
        "NL" => "Netherlands",
        "NO" => "Norway",
        "NP" => "Nepal",
        "NR" => "Nauru",
        "NU" => "Niue",
        "NZ" => "New Zealand",
        "OM" => "Oman",
        "PA" => "Panama",
        "PE" => "Peru",
        "PF" => "French Polynesia",
        "PG" => "Papua New Guinea",
        "PH" => "Philippines",
        "PK" => "Pakistan",
        "PL" => "Poland",
        "PM" => "Saint Pierre and Miquelon",
        "PN" => "Pitcairn",
        "PR" => "Puerto Rico",
        "PS" => "Palestine",
        "PT" => "Portugal",
        "PW" => "Palau",
        "PY" => "Paraguay",
        "QA" => "Qatar",
        "RE" => "Réunion",
        "RO" => "Romania",
        "RS" => "Serbia",
        "RU" => "Russian Federation",
        "RW" => "Rwanda",
        "SA" => "Saudi Arabia",
        "SB" => "Solomon Islands",
        "SC" => "Seychelles",
        "SD" => "Sudan",
        "SE" => "Sweden",
        "SG" => "Singapore",
        "SH" => "Saint Helena",
        "SI" => "Slovenia",
        "SJ" => "Svalbard and Jan Mayen",
        "SK" => "Slovakia",
        "SL" => "Sierra Leone",
        "SM" => "San Marino",
        "SN" => "Senegal",
        "SO" => "Somalia",
        "SR" => "Suriname",
        "SS" => "South Sudan",
        "ST" => "Sao Tome and Principe",
        "SV" => "El Salvador",
        "SX" => "Sint Maarten",
        "SY" => "Syrian Arab Republic",
        "SZ" => "Eswatini",
        "TC" => "Turks and Caicos Islands",
        "TD" => "Chad",
        "TF" => "French Southern Territories",
        "TG" => "Togo",
        "TH" => "Thailand",
        "TJ" => "Tajikistan",
        "TK" => "Tokelau",
        "TL" => "Timor-Leste",
        "TM" => "Turkmenistan",
        "TN" => "Tunisia",
        "TO" => "Tonga",
        "TR" => "Türkiye",
        "TT" => "Trinidad and Tobago",
        "TV" => "Tuvalu",
        "TZ" => "Tanzania",
        "UA" => "Ukraine",
        "UG" => "Uganda",
        "UM" => "U.S. Outlying Islands",
        "US" => "United States",
        "UY" => "Uruguay",
        "UZ" => "Uzbekistan",
        "VA" => "Holy See (Vatican City State)",
        "VC" => "Saint Vincent and the Grenadines",
        "VE" => "Venezuela",
        "VG" => "Virgin Islands (British)",
        "VI" => "Virgin Islands (U.S.)",
        "VN" => "Vietnam",
        "VU" => "Vanuatu",
        "WF" => "Wallis and Futuna",
        "WS" => "Samoa",
        "YE" => "Yemen",
        "YT" => "Mayotte",
        "ZA" => "South Africa",
        "ZM" => "Zambia",
        "ZW" => "Zimbabwe",
    ];

    return $countries;
}

function getTaxTypes($type){
    return TaxRules::where('status',1)->where('tax_type',$type)->get();
}


function getAllowedPrograms(){
    return [
        'delphi'
    ];
}



if (!function_exists('parseUniversalNumber')) {
    function parseUniversalNumber($number): float
    {
        if (!is_string($number)) {
            return (float) $number;
        }

        $number = trim($number);
        if (strpos($number, '.') !== false && strpos($number, ',') !== false) {
            if (strrpos($number, '.') > strrpos($number, ',')) {
                $number = str_replace(',', '', $number);
            } else {
                $number = str_replace('.', '', $number);
                $number = str_replace(',', '.', $number);
            }
        }
        elseif (strpos($number, ',') !== false) {
            $number = str_replace(',', '.', $number);
        }
        else {
            // do nothing
        }

        return (float) $number;
    }
}


if (!function_exists('getCurrency')) {
    function getCurrency()
    {
        $user = Auth::user();
        if (!$user || !$user->company) {
            return 'INR';
        }

        $company = $user->company;

        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();
        }
        $currency = $company->extra['currency'] ?? 'INR';

        return strtoupper($currency);
    };
}


if (!function_exists('getCountryByCurrency')) {
    function getCountryByCurrency()
    {
        $currency = getCurrency();

        $map = [
            '€' => 'ES',
        ];

        return $map[$currency] ?? 'IN';
    };
}


if (!function_exists('normalizePrice')) {
    function normalizePrice($value, $decimals = 2, $toFormat = 'ES')
    {
        $value = trim((string)$value);
    
        $value = preg_replace('/[^\d\.,-]/', '', $value);
    
        $hasComma = strpos($value, ',') !== false;
        $hasDot   = strpos($value, '.') !== false;
        $isEuropean = false;
        if ($hasComma && preg_match('/,\d+$/', $value)) {
            $isEuropean = true;
        } elseif ($hasDot && preg_match('/^\d{1,3}(\.\d{3})+$/', $value)) {
            $isEuropean = true;
        }
    
        // if ($toFormat === 'ES') {
        //     $tmp = $value;
        //     if ($isEuropean) {
        //         $tmp = str_replace('.', '', $tmp);
        //         if (strpos($tmp, ',') !== false) {
        //             $tmp = str_replace(',', '.', $tmp); 
        //         }
        //     } else {
        //         if ($hasComma && !$hasDot) {
        //             $tmp = str_replace(',', '.', $tmp);
        //         } else {
        //             $tmp = str_replace(',', '', $tmp);
        //         }
        //     }

        //     $floatVal = (float) $tmp;
        //     $result = number_format($floatVal, $decimals, ',', '');
        //     return $result;
        // }
        // if ($toFormat === 'ES') {
        //     $tmp = $value;

        //     if ($isEuropean) {
        //         // Remove thousand dots like 1.234,56 → 1234,56
        //         $tmp = str_replace('.', '', $tmp);

        //         // Replace decimal comma with dot to parse as float
        //         if (strpos($tmp, ',') !== false) {
        //             $tmp = str_replace(',', '.', $tmp);
        //         }
        //     } else {
        //         // Handle input like 4000.00 or 4,245678
        //         if ($hasComma && !$hasDot) {
        //             $tmp = str_replace(',', '.', $tmp); // treat as decimal
        //         } else {
        //             $tmp = str_replace(',', '', $tmp); // remove thousand commas
        //         }
        //     }

        //     // Now $tmp is numeric with dot decimal
        //     $floatVal = (float) $tmp;

        //     // ✅ Use '.' for thousands and ',' for decimals
        //     $result = number_format($floatVal, $decimals, ',', '.');
        //     return $result;
        // }

        if ($toFormat === 'ES') {
            $tmp = $value;

            if ($isEuropean) {
                // Remove thousand dots like 1.234,56 → 1234,56
                $tmp = str_replace('.', '', $tmp);

                // Replace decimal comma with dot to parse as float
                if (strpos($tmp, ',') !== false) {
                    $tmp = str_replace(',', '.', $tmp);
                }
            } else {
                // Handle input like 4000.00 or 4,245678
                if ($hasComma && !$hasDot) {
                    $tmp = str_replace(',', '.', $tmp); // treat as decimal
                } else {
                    $tmp = str_replace(',', '', $tmp); // remove thousand commas
                }
            }

            // Now $tmp is numeric with dot decimal
            $floatVal = (float) $tmp;

            // ✅ Detect special case: values like 1.25 → multiply by 100 for cents-based systems
            // if ($floatVal > 0 && $floatVal < 10 && preg_match('/^\d+\.\d{2}$/', $tmp)) {
            //     $floatVal = $floatVal * 100;
            // }

            // ✅ Use '.' for thousands and ',' for decimals
            $result = number_format($floatVal, $decimals, ',', '.');
            return $result;
        }


    
        if ($toFormat === 'IN') {
            $tmp = $value;
    
            if ($isEuropean) {
                $tmp = str_replace('.', '', $tmp);
                $tmp = str_replace(',', '.', $tmp);
            } else {
                $tmp = str_replace(',', '', $tmp);
            }
    
            $match = null;
            preg_match('/\.(\d+)$/', $tmp, $match);
            $actualDecimals = isset($match[1]) ? strlen($match[1]) : 0;
            $useDecimals = max($decimals, min(6, $actualDecimals));
    
            $floatVal = (float) $tmp;
            $result = number_format($floatVal, $useDecimals, '.', '');
            if ($useDecimals > $decimals) {
                $result = number_format($floatVal, $decimals, '.', '');
            }
    
            return $result;
        }
    
        $floatVal = (float) str_replace(',', '.', str_replace('.', '', $value));
        return number_format($floatVal, $decimals, '.', '');
    }

}


if (!function_exists('getCompany')) {
    function getCompany($key, $default = null)
    {
        $user = Auth::user();
        if (!$user) {
            return $default;
        }

        $company = $user->company;

        if (!$company) {
            return $default;
        }

        return $company->$key ?? $default;
    }
}

if (!function_exists('getCountry')) {
    function getCountry($code = 'ES')
    {
        $name = CountryModel::where('country_code', $code)->value('name');
        return $name;
    }
}

if (!function_exists('getState')) {
    function getState($code = 'MD')
    {
        $name = StateModel::where('state_code', $code)->value('name');
        return $name;
    }
}

if (!function_exists('addressString')) {
    function addressString($address)
    {
        $addressString = implode(', ', array_filter([
            $address['company_address'] ?? $address['address'] ?? '',
            $address['locality'] ?? '',
            $address['street_number'] ?? '',
            getState($address['state_code']??'MD'),
            getCountry($address['country_code']??'ES'),
            $address['zip_code'] ?? ''
        ]));

        return $addressString;
    }
}

  
if (!function_exists('formatValueCurrency')) { 
    function formatValueCurrency($amount, $targetCurrency)
    {
        switch ($targetCurrency) {
            case '€':
                return  $amount.'€ ';
            case '₹':
                return 'INR ' . $amount;
            case '£':
                return '£ ' . $amount;
            case '$':
            default:
                return '$ ' . $amount;
        }
        
    }
}

if (!function_exists('getFormatFromCurrency')) { 
    function getFormatFromCurrency(string $currency= '€'): string
    {
        $currency = trim($currency);

        // Map currency symbols to number formats
        $map = [
            '€'  => 'ES', // European format (1.200,50)
            '₹'  => 'IN', // Indian format   (1,20,000.50)
            '$'  => 'US', // US format       (1,200,000.50)
            '£'  => 'UK', // UK format
            'CHF'=> 'CH', // Swiss Franc
            '¥'  => 'JP', // Japanese Yen
        ];

        return $map[$currency] ?? 'ES'; // Default = ES
    }
}


// if (!function_exists('spanishMonths')) {
//     function spanishMonths()
//     {
//         // return [
//         //     'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
//         //     'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
//         // ];
//         return [
//             'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
//             'Jul', 'Agos', 'Sep', 'Oct', 'Nov', 'Dic'
//         ];
//     }
// }

// if (!function_exists('spanishMonthFromDate')) {
//     function spanishMonthFromDate($date)
//     {
//         $months = spanishMonths();
//         $index = date('n', strtotime($date)) - 1;
//         return $months[$index] ?? null;
//     }
// }

if (!function_exists('getDomainId')) {
    function getDomainId()
    {
        return session('active_domain_id');
    }
}

if (!function_exists('getTemplateId')) {
    function getTemplateId($company)
    {
        if (!empty($company->extra['favouraite_template'])) {
            return $company->extra['favouraite_template'];
        }

        return Templates::where('status', 1)
            ->where('scope', $company->id)
            ->value('id')
            ?? Templates::where('status', 1)->value('id');
    }
}