<?php

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\User;
use App\Models\Clients;

// function parseNumber($value)
// {
//     // Remove all unwanted characters except digits, dot, comma, and minus sign
//     $cleanValue = preg_replace('/[^0-9,\.\-]/', '', $value);

//     // Keep the minus sign at the start
//     if (substr($cleanValue, 0, 1) !== '-' && strpos($cleanValue, '-') !== false) {
//         $cleanValue = str_replace('-', '', $cleanValue);
//     }

//     // If the value contains both comma and dot, determine the format
//     if (strpos($cleanValue, ',') !== false && strpos($cleanValue, '.') !== false) {
//         if (strrpos($cleanValue, ',') > strrpos($cleanValue, '.')) {
//             // Euro format: "5.000,00"
//             $cleanValue = str_replace('.', '', $cleanValue); // Remove thousands separator
//             $cleanValue = str_replace(',', '.', $cleanValue); // Convert comma to dot for decimal
//         } else {
//             // USD/GBP/INR format: "5,000.00"
//             $cleanValue = str_replace(',', '', $cleanValue); // Remove thousands separator
//         }
//     } elseif (strpos($cleanValue, ',') !== false) {
//         // If only commas are present, assume Euro format (e.g., "500,00")
//         if (substr_count($cleanValue, ',') === 1) {
//             $cleanValue = str_replace(',', '.', $cleanValue);
//         } else {
//             $cleanValue = str_replace(',', '', $cleanValue);
//         }
//     } elseif (strpos($cleanValue, '.') !== false) {
//         // If only dots are present, assume USD format (leave it as is)
//         $cleanValue = str_replace(',', '', $cleanValue);
//     }

//     return (float) $cleanValue;
// }

// function parseNumber($value)
// {
//     // Remove unwanted characters except digits, comma, dot, minus
//     $cleanValue = preg_replace('/[^0-9,\.\-]/', '', $value);

//     // Handle misplaced minus signs
//     if (substr($cleanValue, 0, 1) !== '-' && strpos($cleanValue, '-') !== false) {
//         $cleanValue = str_replace('-', '', $cleanValue);
//     }

//     $hasComma = strpos($cleanValue, ',') !== false;
//     $hasDot   = strpos($cleanValue, '.') !== false;

//     if ($hasComma && $hasDot) {
//         // Both present → decide which is decimal based on last occurrence
//         if (strrpos($cleanValue, ',') > strrpos($cleanValue, '.')) {
//             // Euro style "1.234,56"
//             $cleanValue = str_replace('.', '', $cleanValue);  // remove thousands
//             $cleanValue = str_replace(',', '.', $cleanValue); // decimal to dot
//         } else {
//             // USD/INR style "1,234.56"
//             $cleanValue = str_replace(',', '', $cleanValue); // remove thousands
//         }
//     } elseif ($hasComma) {
//         // Only comma → need to decide if it's decimal or thousand
//         $parts = explode(',', $cleanValue);
//         if (count($parts) === 2 && strlen($parts[1]) <= 2) {
//             // Looks like decimal (e.g. "1234,50")
//             $cleanValue = str_replace(',', '.', $cleanValue);
//         } else {
//             // Looks like thousands (e.g. "16,000")
//             $cleanValue = str_replace(',', '', $cleanValue);
//         }
//     } elseif ($hasDot) {
//         // Only dot → same logic as above
//         $parts = explode('.', $cleanValue);
//         if (count($parts) === 2 && strlen($parts[1]) <= 2) {
//             // Decimal format like "1234.56"
//             // leave as is
//         } else {
//             // Thousand separator like "16.000"
//             $cleanValue = str_replace('.', '', $cleanValue);
//         }
//     }

//     // Convert safely to float
//     $number = (float) $cleanValue;

//     // Always return string with 2 decimals
//     return number_format($number, 2, '.', '');
// }

// function parseNumber($value)
// {
//     // Remove unwanted characters except digits, comma, dot, minus
//     $cleanValue = preg_replace('/[^0-9,\.\-]/', '', $value);

//     // Handle misplaced minus signs
//     if (substr($cleanValue, 0, 1) !== '-' && strpos($cleanValue, '-') !== false) {
//         $cleanValue = str_replace('-', '', $cleanValue);
//     }

//     $hasComma = strpos($cleanValue, ',') !== false;
//     $hasDot   = strpos($cleanValue, '.') !== false;

//     if ($hasComma && $hasDot) {
//         // Both present → decide which is decimal based on last occurrence
//         if (strrpos($cleanValue, ',') > strrpos($cleanValue, '.')) {
//             // Euro style "1.234,56"
//             $cleanValue = str_replace('.', '', $cleanValue);
//             $cleanValue = str_replace(',', '.', $cleanValue);
//         } else {
//             // USD/INR style "1,234.56"
//             $cleanValue = str_replace(',', '', $cleanValue);
//         }
//     } elseif ($hasComma) {
//         // Only comma → decimal or thousand
//         $parts = explode(',', $cleanValue);
//         if (count($parts) === 2 && strlen($parts[1]) > 0 && strlen($parts[1]) <= 3) {
//             // Decimal like 1234,5 / 1234,50 / 1234,500
//             $cleanValue = str_replace(',', '.', $cleanValue);
//         } else {
//             // Thousand separator
//             $cleanValue = str_replace(',', '', $cleanValue);
//         }
//     } elseif ($hasDot) {
//         // Only dot → decimal or thousand
//         $parts = explode('.', $cleanValue);

//         if (count($parts) === 2 && strlen($parts[1]) > 0 && strlen($parts[1]) <= 6) {
//             // Decimal format (e.g. 946.825, 12.34, etc.)
//             // Keep as is
//         } else {
//             // Thousand separator (e.g. 16.000, 1.000.000)
//             $cleanValue = str_replace('.', '', $cleanValue);
//         }
//     }

//     // Convert safely to float
//     $number = (float) $cleanValue;

//     // Always return string with up to 4 decimals (handles .825 correctly)
//     $decimalCount = strlen(substr(strrchr($cleanValue, "."), 1));
//     $decimalCount = $decimalCount > 0 && $decimalCount <= 4 ? $decimalCount : 2;

//     return number_format($number, $decimalCount, '.', '');
// }

function parseNumber($value)
{
    // Remove unwanted characters except digits, comma, dot, minus
    $cleanValue = preg_replace('/[^0-9,\.\-]/', '', $value);

    // Handle misplaced minus signs
    if (substr($cleanValue, 0, 1) !== '-' && strpos($cleanValue, '-') !== false) {
        $cleanValue = str_replace('-', '', $cleanValue);
    }

    $hasComma = strpos($cleanValue, ',') !== false;
    $hasDot   = strpos($cleanValue, '.') !== false;

    if ($hasComma && $hasDot) {
        // Both present → decide which is decimal based on last occurrence
        if (strrpos($cleanValue, ',') > strrpos($cleanValue, '.')) {
            // Euro style "1.234,56"
            $cleanValue = str_replace('.', '', $cleanValue);
            $cleanValue = str_replace(',', '.', $cleanValue);
        } else {
            // USD/INR style "1,234.56"
            $cleanValue = str_replace(',', '', $cleanValue);
        }
    } elseif ($hasComma) {
        // Only comma
        $parts = explode(',', $cleanValue);
        $afterStr = $parts[1] ?? '';
        if (strlen($afterStr) === 3 && preg_match('/^0{3}$/', $afterStr)) {
            $cleanValue = str_replace(',', '', $cleanValue);
        } elseif (count($parts) === 2 && strlen($afterStr) > 0 && strlen($afterStr) <= 4) {
            $cleanValue = str_replace(',', '.', $cleanValue);
        } else {
            $cleanValue = str_replace(',', '', $cleanValue);
        }
    } elseif ($hasDot) {
        // Only dot
        $dotCount = substr_count($cleanValue, '.');
        if ($dotCount > 1) {
            // Multiple dots = thousand separators
            $cleanValue = str_replace('.', '', $cleanValue);
        } else {
            // Single dot → decimal
            $parts = explode('.', $cleanValue);
            $afterStr = $parts[1] ?? '';
            if (strlen($afterStr) === 3 && preg_match('/^0{3}$/', $afterStr)) {
                // 16.000 => 16000
                $cleanValue = str_replace('.', '', $cleanValue);
            } else {
                // Keep decimal like 946.825 or 16000.5895
                // leave as is
            }
        }
    }

    // Convert safely to float
    if ($cleanValue === '' || $cleanValue === '-' || $cleanValue === '.' || $cleanValue === ',') {
        $number = 0.0;
        $cleanValue = "0";
    } else {
        $number = (float) $cleanValue;
    }

    // Preserve decimal precision (up to 4)
    $decimalCount = 0;
    if (strpos($cleanValue, '.') !== false) {
        $decimalCount = strlen(substr(strrchr($cleanValue, "."), 1));
        if ($decimalCount <= 0 || $decimalCount > 4) {
            $decimalCount = 4;
        }
    } else {
        $decimalCount = 2;
    }

    return number_format($number, $decimalCount, '.', '');
}

function parseInventoryServicePrice($value)
{
     // Remove unwanted characters except digits, dot, comma, and minus
     $cleanValue = preg_replace('/[^0-9,\.\-]/', '', $value);

     // Preserve minus sign at the start only
     if (substr($cleanValue, 0, 1) !== '-' && strpos($cleanValue, '-') !== false) {
         $cleanValue = str_replace('-', '', $cleanValue);
     }
 
     $hasComma = strpos($cleanValue, ',') !== false;
     $hasDot = strpos($cleanValue, '.') !== false;
 
     // Case 1: Contains both comma and dot
     if ($hasComma && $hasDot) {
         if (strrpos($cleanValue, ',') > strrpos($cleanValue, '.')) {
             // European format: "1.234,56"
             $cleanValue = str_replace('.', '', $cleanValue); // remove thousands
             $cleanValue = str_replace(',', '.', $cleanValue); // convert decimal
         } else {
             // International format: "1,234.56"
             $cleanValue = str_replace(',', '', $cleanValue); // remove thousands
         }
     }
 
     // Case 2: Only comma
     elseif ($hasComma) {
         if (preg_match('/,\d{3}$/', $cleanValue)) {
             // Comma is thousand separator: "1,500"
             $cleanValue = str_replace(',', '', $cleanValue);
         } else {
             // Comma is decimal separator: "500,50"
             $cleanValue = str_replace(',', '.', $cleanValue);
         }
     }
 
     // Case 3: Only dot
     elseif ($hasDot) {
         if (preg_match('/\.\d{3}$/', $cleanValue)) {
             // Dot is thousand separator: "1.500"
             $cleanValue = str_replace('.', '', $cleanValue);
         }
         // Else, dot is decimal separator: leave as-is
     }
 
     return (float) $cleanValue;
}

 
function formatValue($amount, $targetCurrency = '₹' )
{
    switch ($targetCurrency) {
        case '€': // Euro format
            return number_format($amount, 2, ',', '.');

        case '₹': // Indian Rupee format
        case '£': // British Pound format
        case '$': // USD format
        default:
            return number_format($amount, 2, '.', ',');
    }
}

function formatPrice($amount, $targetCurrency = '₹' )
{
    // Normalize amount (convert comma to dot if needed)
    $amount = str_replace(',', '.', $amount);

    // Convert to float but keep precision
    $decimalCount = 0;
    if (strpos($amount, '.') !== false) {
        $decimalCount = strlen(rtrim(substr($amount, strpos($amount, '.') + 1), '0'));
        $decimalCount = min($decimalCount, 4); // allow up to 4 decimals
    }

    switch ($targetCurrency) {
        case '€': // Euro format
            return number_format((float)$amount, $decimalCount, ',', '.');

        case '₹':
        case '£':
        case '$':
        default:
            return number_format((float)$amount, $decimalCount, '.', ',');
    }
}


function getExchangeRates($baseCurrency)
{
    // Example rates - should be fetched from a live API in production
    $rates = [
        '€' => ['€' => 1, '$' => 1.08, '₹' => 90.25, '£' => 0.86],
        '$' => ['€' => 0.93, '$' => 1, '₹' => 83.33, '£' => 0.79],
        '₹' => ['€' => 0.011, '$' => 0.012, '₹' => 1, '£' => 0.0095],
        '£' => ['€' => 1.16, '$' => 1.26, '₹' => 105.26, '£' => 1]
    ];

    return $rates[$baseCurrency] ?? ['€' => 1, '$' => 1, '₹' => 1, '£' => 1];
}

function truncateToTwoDecimals($number)
{
    return floor($number * 100) / 100;
}

