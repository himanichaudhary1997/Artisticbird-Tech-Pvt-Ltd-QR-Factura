<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class ChartJs extends Component
{
   
    public $id;
    public $type;
    public $labels;
    public $datasets;
    public $height;

    public function __construct($id, $type = 'bar', $labels = [], $datasets = [], $height = 240)
    {
        $this->id = $id;
        $this->type = $type;
        $this->labels = $labels;
        $this->datasets = $datasets;
        $this->height = $height;
    }

    public function render()
    {
        return view('components.chart-js');
    }

}
