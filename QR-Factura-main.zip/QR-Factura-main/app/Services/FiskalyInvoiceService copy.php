<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use App\Models\Company;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CompanyVerifactu;
use Illuminate\Support\Facades\Storage;

use App\Models\User;


use App\Services\InvoiceService;

class FiskalyInvoiceService
{
    protected $dashboard;
    protected $managed;
    protected $baseUrl;
    protected $testUrl;
    protected $apiKey;
    protected $apiSecret;

    public function __construct()
    {
        $this->dashboard = config('services.fiskaly.dashboard_url');
        $this->managed = config('services.fiskaly.managed_id');
        $this->baseUrl = config('services.fiskaly.base_url');
        $this->testUrl = config('services.fiskaly.test_url');
        $this->apiKey = config('services.fiskaly.api_key');
        $this->apiSecret = config('services.fiskaly.api_secret');
    }

   
    public function getBearerToken()
    {
        try {
            Cache::flush();
                $response = Http::acceptJson()
                    ->post("{$this->baseUrl}/auth", [
                        'content' => [
                            'api_key' => $this->apiKey,
                            'api_secret' => $this->apiSecret,
                        ],
                    ]);

                if ($response->successful()) {
                    return $response->json('content.access_token.bearer');
                }

                \Log::error('Fiskaly auth failed', ['response' => $response->body()]);
                return null;
        } catch (\Exception $e) {
            \Log::error('Exception in getBearerToken: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);
            return null;
        }
    }



    public function getBearerTokenCompany($company)
    {
        try {
        $response = Http::acceptJson()
                ->post("{$this->baseUrl}/auth", [
                    'content' => [
                        'api_key' => $company->organization_details->api_keys['key'],
                        'api_secret' => $company->organization_details->api_keys['secret'],
                    ],
                ]);

            if ($response->successful()) {
                return $response->json('content.access_token.bearer');
            }

            \Log::error('Fiskaly auth failed', ['response' => $response->body()]);
            return null;

        } catch (\Exception $e) {
            \Log::error('Exception in getBearerTokenCompany: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);
            return null;
        }
    }


    public function listOrganizations()
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->dashboard}/organizations");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        } catch (\Exception $e) {
            \Log::error('Exception in listOrganizations: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while fetching organizations'];
        }
    }

    public function  createOrganisation($company)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();

            $data = [
                'name' => $company->company_name,
                'address_line1' => $company->extra['company_address'],
                'address_line2' => $company->extra['street_number'],
                'zip' => $company->extra['zip_code'],
                'town' => $company->extra['locality'],
                'country_code' => 'ESP', // ISO 3166-1 alpha-3 code
                'managed_by_organization_id' => $this->managed, // Replace if needed
                'tax_number' => $company->gst_no,
                'state'=>$state->name ?? null,
            ];

            // dd($this->managed, $company, $data);

            $response = Http::withToken($token)
                ->acceptJson()
                ->post("{$this->dashboard}/organizations", $data);

            $apiResponse = $response->json();

            if($apiResponse['_id']){
                CompanyVerifactu::create([
                    'company_id'=>$company->id,
                    'organization_id'=>$apiResponse['_id']
                ]);
                $apiKeys = $this->createOrganisationKey($company,$apiResponse['_id']);
            }

            return $apiResponse;
        } catch (\Exception $e) {
            \Log::error('Exception in createOrganisation: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'company_id' => $company->id ?? null,
            ]);

            return ['error' => 'An unexpected error occurred while creating the organization.'];
        }
    }

    public function createOrganisationKey($company,$organization_id)
    {
        try {
        $token = $this->getBearerToken();

        if (!$token) {
            return ['error' => 'Unable to authenticate with Fiskaly'];
        }

        $data = [
            'name'      => sanitizeCompanyName($company->company_name),
            'status'    => 'enabled'
        ];

        $response = Http::withToken($token)
            ->acceptJson()
            ->post("{$this->dashboard}/organizations/$organization_id/api-keys", $data);

        $apiResponse = $response->json();

        CompanyVerifactu::where('organization_id',$organization_id)->update([
           'api_keys'=>[
                'key'=>$apiResponse['key'],
                'secret'=>$apiResponse['secret']
            ]
        ]);
        if ($response->successful()) {
            return $response->json();
        }

        return $apiResponse;

    } catch (\Exception $e) {
        \Log::error('Exception in createOrganisationKey: ' . $e->getMessage(), [
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'company_id' => $company->id ?? null,
            'organization_id' => $organization_id,
        ]);

        return ['error' => 'An unexpected error occurred while creating the organization API key.'];
    }
    }

    public function listOrganizationlkeys($organization_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->dashboard}/organizations/{$organization_id}/api-keys");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        }
        catch (\Exception $e) {
            \Log::error('Exception in listOrganizationlkeys: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'organization_id' => $organization_id,
            ]);
    
            return ['error' => 'An unexpected error occurred while fetching organization API keys.'];
        }
    }


    public function deleteOrganizationApiKey($organization_id,$key_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->delete("{$this->dashboard}/organizations/{$organization_id}/api-keys/{$key_id}");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        } catch (\Exception $e) {
            \Log::error('Exception in deleteOrganizationApiKey: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'organization_id' => $organization_id,
                'key_id' => $key_id
            ]);

            return ['error' => 'An unexpected error occurred while deleting the organization API key.'];
        }
    }

    // public function createTaxPayer($company)
    // {
    //     $token = $this->getBearerTokenCompany($company);
       
    //     if (!$token) {
    //         return ['error' => 'Authentication failed'];
    //     }

    //     // dd($this->baseUrl);
    //     $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
    //     $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
    
    //     $addressParts = array_filter([
    //         $company->extra['address'] ?? null,
    //         (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
    //         (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
    //         $state->name ?? null,  // Get state name
    //         $country->name ?? null // Get country name
    //     ]);
    //     $response = Http::withToken($token)
    //         ->acceptJson()
    //         ->put("{$this->baseUrl}/taxpayer", [
    //             'content' => [
    //                 'issuer'=>[
    //                     'legal_name'=> $company->company_name,
    //                     'tax_number'=>$company->gst_no
    //                 ],
    //                 'territory'=>$company->territory,
    //                 'email'=> $company->user->email,
    //                 'address'=> [
    //                     'municipality'=>$company->extra['company_address'] ?? null,
    //                     'city'=>$state->name,
    //                     'street'=>$company->extra['locality'] ?? null,
    //                     'postal_code'=>$company->extra['zip_code'] ?? null,
    //                     'number'=>$company->extra['street_number'] ?? null,
    //                     'country_code'=>'ES',
    //                 ],
    //             ]
    //         ]);

        
    //     // dd($response->json());
    //     return $response->json();
    // }

    public function createTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                Log::error('Authentication failed for company ID: ' . $company->id);
                return ['error' => 'Authentication failed'];
            }

            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();

            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,
                $country->name ?? null
            ]);

            // Log the request payload before sending
            $payload = [
                'content' => [
                    'issuer'=>[
                        'legal_name'=> $company->company_name,
                        'tax_number'=>$company->gst_no
                    ],
                    'territory'=>$company->territory,
                    'email'=> $company->user->email,
                    'address'=> [
                        'municipality'=>$company->extra['locality'] ?? null,
                        'city'=>$state->name,
                        'street'=>$company->extra['company_address'] ?? null,
                        'postal_code'=>$company->extra['zip_code'] ?? null,
                        'number'=>$company->extra['street_number'] ?? null,
                        'country_code'=>'ES',
                    ],
                ]
            ];

            Log::info('Sending createTaxPayer request', [
                'company_id' => $company->id,
                'payload' => $payload
            ]);

            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$this->baseUrl}/taxpayer", $payload);

            // Log the response
            if ($response->successful()) {
                Log::info('createTaxPayer response', [
                    'company_id' => $company->id,
                    'response' => $response->json()
                ]);
            } else {
                Log::error('createTaxPayer failed', [
                    'company_id' => $company->id,
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while creating the taxpayer.'];
        }
    }

    public function updateTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$this->baseUrl}/taxpayer", [
                    'content' => [
                        'state'=>'DISABLED'
                    ]
                ]);

            
            // dd($response->json());
            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while updating the taxpayer.'];
        }
    }

    public function getTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            // dd($this->baseUrl);
            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->baseUrl}/taxpayer");

            
            // dd($response);
            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in getTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while fetching taxpayer data.'];
        }
    }


    public function generateAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            
            $country = CountryModel::where('country_code', $company->extra['personal']['country_code'] ?? null)->first();

            $state = StateModel::where('state_code', $company->extra['personal']['state_code'] ?? null)->first();

            $payloadData = [
                'content' => [
                    "representative"=>[
                        'full_name'=>$company->user->name,
                        'tax_number'=>$company->dnia,
                        'address'=> [
                            'municipality'=>$company->extra['personal']['locality'] ?? null,
                            'city'=>$state->name,
                            'street'=>$company->extra['personal']['address'] ?? null,
                            'postal_code'=>$company->extra['personal']['zip_code'] ?? null,
                            'number'=>$company->extra['personal']['street_number'] ?? null,
                            'country_code'=>'ES',
                        ],
                    ]
                ]
            ];

            // dd($payloadData);
            $response = Http::withToken($token)
                ->acceptJson()
                ->post("{$this->baseUrl}/taxpayer/agreement", $payloadData);

            // return $response->json();
            // dd($response->json());
            if ($response->failed()) {
                return ['error' => 'Failed to generate agreement'];
            }
            $fileName = 'agreement_' . $company->id . '_' . time() . '.pdf';
            $filePath = 'agreements/' . $fileName;

            Storage::disk('public')->put($filePath, $response->body());

            // Save file path in organization_details->agreement
            $organizationDetails = $company->organization_details;
            $organizationDetails->agreement = 'storage/' . $filePath;
            $organizationDetails->save();

            return [
                'success' => true,
                'file_path' => asset('storage/' . $filePath)
            ];
        } catch (\Exception $e) {
            \Log::error('Exception in generateAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => $e->getMessage()];
        }
    }

    public function getAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();

            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);

            $payloadData = [
                'content' => [
                    "representative"=>[
                        'full_name'=>$company->company_name,
                        'tax_number'=>$company->gst_no,
                        'address'=> [
                            'municipality'=>$company->extra['locality'] ?? null,
                            'city'=>$state->name,
                            'street'=>$company->extra['company_address'] ?? null,
                            'postal_code'=>$company->extra['zip_code'] ?? null,
                            'number'=>$company->extra['street_number'] ?? null,
                            'country_code'=>'ES',
                        ],
                    ]
                ]
            ];

            // dd($payloadData);
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->baseUrl}/taxpayer/agreement");

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in getAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while fetching agreement.'];
        }
    }

    public function uploadAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);

            if (!$token) {
                return ['error' => true, 'message' => 'Authentication failed'];
            }

            // Path of signed agreement
            $filePath = public_path($company->organization_details->signed_agreement);

            if (!file_exists($filePath)) {
                return ['error' => 'Signed agreement file not found'];
            }

            $organizationDetails = $company->organization_details;
            // Encode PDF file as Base64
            $fileContent = file_get_contents($filePath);
            // return response()->download($filePath);
            $base64Content = base64_encode($fileContent);
            // dd($base64Content);
            $payload = [
                'content' => [
                    'binary' => $base64Content
                ]
            ];
            
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$this->baseUrl}/taxpayer/agreement", $payload);

            
            if ($response->failed()) {
                return $response->json();
            }
            
            $organizationDetails->is_verified = true;
            $organizationDetails->save();

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in uploadAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while uploading agreement.'];
        }
    }

    public function createSigner($user)
    {
        try {
            $token = $this->getBearerTokenCompany($user->company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $guid = Str::uuid();
            $baseUrl = config('services.fiskaly.base_url'); 

            $country = CountryModel::where('country_code', $user->company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $user->company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $user->company->extra['address'] ?? null,
                (isset($user->company->extra['locality']) && !empty($user->company->extra['locality'])) ? ($user->company->extra['locality']) : null,
                (isset($user->company->extra['zip_code']) && !empty($user->company->extra['zip_code'])) ? ($user->company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            // dd($user->phone );
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/signers/{$guid}", [
                    'metadata' => [
                        'full_name'       => $user->name,
                        'email'           => $user->email,
                        'mobile_no'           => "$user->phone" ??'',
                        'nif'             => $user->company->gst_no??'',
                        'company_name'    => $user->company->company_name ?? null,
                        'address'=> implode(',', $addressParts)
                    ]
                ]);

            if ($response->successful()) {
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createSigner: ' . $e->getMessage(), [
                'user_id'   => $user->id ?? null,
                'company_id'=> $user->company->id ?? null,
                'line'      => $e->getLine(),
                'file'      => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while creating signer.'];
        }
    }

    public function updateSigner($company,$signerId)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $baseUrl = config('services.fiskaly.base_url'); 

            // dd($user->phone );
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/signers/{$signerId}", [
                    'content'=>[
                        'state'=>'DISABLED'
                    ]
                ]);

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateSigner: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'signer_id'  => $signerId,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating signer.'
            ];
        }
    }

    public function createClient($user)
    {
        try {
            $token = $this->getBearerTokenCompany($user->company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $guid = Str::uuid();
            $baseUrl = config('services.fiskaly.base_url'); 

            $country = CountryModel::where('country_code', $user->company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $user->company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $user->company->extra['address'] ?? null,
                (isset($user->company->extra['locality']) && !empty($user->company->extra['locality'])) ? ($user->company->extra['locality']) : null,
                (isset($user->company->extra['zip_code']) && !empty($user->company->extra['zip_code'])) ? ($user->company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$guid}", [
                    'metadata' => [
                        'full_name'       => $user->name,
                        'email'           => $user->email,
                        'mobile_no'           => $user->mobile_no??'',
                        'nif'             => $user->company->gst_no??'',
                        'company_name'    => $user->company->company_name ?? null,
                        'address'=> implode(',', $addressParts)
                    ]
                ]);

            if ($response->successful()) {
                $verifactuDetails = $user->company->organization_details;
                $verifactuDetails->client_id = $response['content']['id'];
                $verifactuDetails->save();
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createClient: ' . $e->getMessage(), [
                'user_id'    => $user->id ?? null,
                'company_id' => $user->company->id ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error'   => 'An unexpected error occurred while creating client.'
            ];
        }
    }

    public function updateClient($company,$clientId)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $baseUrl = config('services.fiskaly.base_url'); 

            
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/clients/{$clientId}", [
                    'content'=>[
                        'state'=>'DISABLED'
                    ]
                ]);

            if ($response->successful()) {
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateClient: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'client_id'  => $clientId ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating client.'
            ];
        }
    }


    public function createInvoice($company,$invoiceData)
    {
        try{

            $clientId = $company->organization_details->client_id; 
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $invoiceData->delete();
            $series = strtok($invoiceData->invoice_id, '/'); // gets '2025'
            $number = substr($invoiceData->invoice_id, strlen($series)); // gets '/EN/123'
            $fullAmount = parseNumber($invoiceData->grandTotal);
            // dd($fullAmount);
            $country = CountryModel::where('country_code', $invoiceData->client->extra['country_code'] ?? null)->first();
            // $state = StateModel::where('state_code', $invoiceData->client->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $invoiceData->client->extra['address'] ?? null,
                (isset($invoiceData->client->extra['locality']) && !empty($invoiceData->client->extra['locality'])) ? ($invoiceData->client->extra['locality']) : null,
                (isset($invoiceData->client->extra['zip_code']) && !empty($invoiceData->client->extra['zip_code'])) ? ($invoiceData->client->extra['zip_code']) : null,
                (isset($invoiceData->client->extra['state_name']) && !empty($invoiceData->client->extra['state_name'])) ? ($invoiceData->client->extra['state_name']) : null, // Get state name
                $country->name ?? null // Get country name
            ]);
            if($fullAmount > 3000){
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $invoiceData->invoice_id,
                            "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)->format('d-m-Y H:i:s'),
                            "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                            "full_amount" => number_format(parseNumber($invoiceData->grandTotal+$invoiceData->totalRetencion), 2, '.', '')
                        ],
                        "recipients"=>[
                            [
                                'id'=>[
                                    "legal_name"=>$invoiceData->client->extra['company_name'] ?? $invoiceData->client->name,
                                    "tax_number"=>$invoiceData->client->gst_no
                                ],
                                'address_line'=>implode(',', $addressParts),
                                'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
                            ]
                        ]
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }

                    // dd($discount);
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['data']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }else{
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        'number' => $invoiceData->invoice_id,
                        "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)->format('d-m-Y H:i:s'),
                        "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                        "full_amount" => number_format(parseNumber($invoiceData->grandTotal+$invoiceData->totalRetencion), 2, '.', '')
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

                // dd($response->json());
            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
                // Build path
                $folderPath = "qrcodes/{$company->company_slug}";
                $fileName = "invoice_{$invoiceData->invoice_id}.png";
                $filePath = "{$folderPath}/{$fileName}";

                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));

                // Save in extra field
                // $invoiceData->extra = array_merge($invoiceData->extra ?? [], [
                //     'qr_code' => $filePath,
                // ]);

                $invoiceData->verifactu_id = $response['content']['id'] ?? null;
                $invoiceData->is_verified = 1;
                $invoiceData->qr_code = $filePath;
                $invoiceData->save();
            }
            return $response->json();
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }



    public function createReceipt($company,$receiptData)
    {
        try{

            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid();
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $payload = $this->buildPayload($receiptData, $company);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            if (isset($response['content']['error']) || 
                (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                $invoiceData->delete();
                // dd($payload, $response, $response['content']['error'], $response['content']['status'], $response['content']['message']);
                return response()->json([
                    'success' => false,
                    'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                    'message' => __('Validation Failed'),
                    ], 400);
            }

            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
                $folderPath = "qrcodes/receipts/{$company->company_slug}";
                $fileName = "receipt_{$receiptData->receipt_id}.png";
                $filePath = "{$folderPath}/{$fileName}";

                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));

                $receiptData->verifactu_id = $response['content']['id'] ?? null;
                $receiptData->is_verified = 1;
                $receiptData->qr_code = $filePath;
                $receiptData->save();
            }
            
            return $response->json();
        }
        catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    public function createPrestashopInvoice($company,$payload)
    {
        try {
            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $token = $this->getBearerTokenCompany($company);
            $baseUrl = config('services.fiskaly.base_url'); 
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createPrestashopInvoice: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'client_id'  => $company->organization_details->client_id ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while creating Prestashop invoice.'
            ];
        }
    }

    public function createAutoInvoice($company,$invoiceData)
    {
        try{

            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            $series = strtok($invoiceData->invoice_id, '/'); // gets '2025'
            $number = substr($invoiceData->invoice_id, strlen($series)); // gets '/EN/123'
            $fullAmount = parseNumber($invoiceData->grandTotal);
            // dd($fullAmount);
            // $state = StateModel::where('state_code', $invoiceData->client->extra['state_code'] ?? null)->first();
            $countryCode = $invoiceData->client->extra['country_code'] ?? 'ES';
            $countries = getProviderCountries();
            $country = $countries[$countryCode];

            $addressParts = array_filter([
                $invoiceData->client->extra['address'] ?? null,
                (isset($invoiceData->client->extra['locality']) && !empty($invoiceData->client->extra['locality'])) ? ($invoiceData->client->extra['locality']) : null,
                (isset($invoiceData->client->extra['state_name']) && !empty($invoiceData->client->extra['state_name'])) ? ($invoiceData->client->extra['state_name']) : null, // Get state name
                $country // Get country name
            ]);

            if($countryCode == 'ES'){
                $recipients = [
                    'id'=>[
                        "legal_name"=>$invoiceData->client->name,
                        "tax_number"=>$invoiceData->client->gst_no
                    ],
                    'address_line'=>implode(',', $addressParts),
                    'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
                ];
            }else{
                $recipients = [
                    'id'=>[
                        "legal_name"=>$invoiceData->client->name,
                        "type"=>"TAX_NUMBER",
                        "number"=>$invoiceData->client->gst_no,
                        'country_code'=>$countryCode
                    ],
                    'address_line'=>implode(',', $addressParts),
                    'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
                ];
            }
            if($fullAmount > 3000){
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $invoiceData->invoice_id,
                            "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)->format('d-m-Y H:i:s'),
                            "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                            "full_amount" => number_format(parseNumber($invoiceData->grandTotal), 2, '.', '')
                        ],
                        "recipients"=>[
                            $recipients
                        ]
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }

                    // dd($discount);
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['data']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }else{
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        'number' => $invoiceData->invoice_id,
                        "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)
                    ->format('d-m-Y H:i:s'),
                        "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                        "full_amount" => number_format(parseNumber($invoiceData->grandTotal+$invoiceData->totalRetencion), 2, '.', '')
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

                // dd($response->json());
            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
                // Build path
                $folderPath = "qrcodes/{$company->company_slug}";
                $fileName = "invoice_{$invoiceData->invoice_id}.png";
                $filePath = "{$folderPath}/{$fileName}";

                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));

                // Save in extra field
                // $invoiceData->extra = array_merge($invoiceData->extra ?? [], [
                //     'qr_code' => $filePath,
                // ]);

                $invoiceData->verifactu_id = $response['content']['id'] ?? null;
                $invoiceData->is_verified = 1;
                $invoiceData->qr_code = $filePath;
                $invoiceData->save();
            }
            return $response->json();
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }

    public function updateInvoice($company,$invoice)
    {
        try {
            $clientId = $company->organization_details->client_id; // or pass via $request
            
            $token = $this->getBearerTokenCompany($company);
            $invoice_id = $invoice->verifactu_id;
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            // dd($invoiceData->items);
            $payload = [
                "content" => [
                    "state" => "CANCELLED"
                ]
            ];
            
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/clients/{$clientId}/invoices/{$invoice_id}", $payload);


            return $response->json();

        } catch (\Exception $e) {
            \Log::error('Exception in updateInvoice: ' . $e->getMessage(), [
                'company_id'  => $company->id ?? null,
                'invoice_id'  => $invoice->id ?? null,
                'verifactu_id' => $invoice->verifactu_id ?? null,
                'line'        => $e->getLine(),
                'file'        => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating the invoice.'
            ];
        }
    }


    public function createNegativeInvoice($company, $invoiceData, $oldInvoice, $method)
    {
        try{
            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $payload = $this->buildPayload($invoiceData, $company, $oldInvoice, $method); 
            

            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

                if (isset($response['content']['error']) || 
                    (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                    $invoiceData->delete();
                    dd($payload, $response, $response['content']['error'], $response['content']['status'], $response['content']['message']);
                    // dd($payload, $response['content']['message']);
                    return response()->json([
                        'success' => false,
                        'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                        'message' => __('Validation Failed'),
                        ], 400);
                }

                
            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                //  dd($response['content']['message']);
                // Build path
                $folderPath = "qrcodes/{$company->company_slug}";
                $fileName = "invoice_{$invoiceData->invoice_id}.png";
                $filePath = "{$folderPath}/{$fileName}";

                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));


                $invoiceData->verifactu_id = $response['content']['id'] ?? null;
                $invoiceData->is_verified = 1;
                $invoiceData->qr_code = $filePath;
                $invoiceData->save();
            }
            // dd($response);
            return $response->json();
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }

    public function buildPayload($invoiceData, $company, $oldInvoice = [], $method = '')
    {
        $payload = [];
        $rawGrand = ($invoiceData->grandTotal ?? 0) + ($invoiceData->totalRetencion ?? 0);
        if (blank($oldInvoice)) {
            $grandTotal = normalizePrice(round($rawGrand, 2), 2, 'IN');
        }else{
            $grandTotal = abs(normalizePrice(round($rawGrand, 2), 2, 'IN'));
        }


        if ($grandTotal >= 3000) {
            if (blank($oldInvoice)) {
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $invoiceData->receipt_id,
                            "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                            "full_amount" => $grandTotal,
                            "items" => $this->buildInvoiceItemsPayload($invoiceData),
                        ],
                        "recipients"=>$this->buildRecipients($invoiceData),
                    ]
                ];
                return $payload;
            }else{

                $oldId = is_array($oldInvoice)
                    ? ($oldInvoice->verifactu_id ?? null)
                    : ($oldInvoice['verifactu_id'] ?? null);
                $payload = [
                    "content" => [
                        "type"   => "CORRECTING",
                        "id"     => $oldId,
                        "invoice" => [
                            "type"        => "COMPLETE",
                            "data"=>[
                                "type" => "SIMPLIFIED",
                                'number' => $invoiceData->receipt_id,
                                "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                                "full_amount" => normalizePrice(round($rawGrand, 2), 2, 'IN'),
                                "items" => $this->buildInvoiceItemsPayload($invoiceData),
                            ],
                            "recipients"=>$this->buildRecipients($oldInvoice), 
                            
                        ]
                    ]
                ];
                // $invoiceData->delete();
                // dd($payload);
                return $payload;
            }
        } else {
            if (blank($oldInvoice)) {
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        'number' => $invoiceData->receipt_id,
                        "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . 'for regular company.',
                        "full_amount" => $grandTotal,
                        "items" => $this->buildInvoiceItemsPayload($invoiceData),
                    ]
                ];
                return $payload;
            }else{
                
                $oldId = is_array($oldInvoice)
                    ? ($oldInvoice->verifactu_id ?? null)
                    : ($oldInvoice['verifactu_id'] ?? null);

                $payload = [
                    "content" => [
                        "type"   => "CORRECTING",
                        "id"     => $oldId,
                        "invoice" => [
                            "type"        => "SIMPLIFIED",
                            "number"      => $invoiceData->receipt_id,
                            "series"      => "ER",
                            "issued_at"   => \Carbon\Carbon::parse($invoiceData->issue_date)
                                                ->format('d-m-Y H:i:s'),
                            "text"        => $invoiceData->extra['note']
                                            ?? __("Created By ") . $company->company_name,
                            "full_amount" => $grandTotal,
                            "items"       => $this->buildInvoiceItemsPayload($invoiceData),
                        ],
                        "method" => $method ?? "DIFFERENCES",
                        "code"   => "CORRECTION_1",
                    ]
                ];
                return $payload;
            }


            
        }
    }


    function buildInvoiceItemsPayload($invoiceData)
    {
        $itemsPayload = [];

        foreach ($invoiceData->items as $item) {
            $price = normalizePrice($item['price'], 2, 'IN');
            $discount = normalizePrice($item['discount'], 2, 'IN');
            $tax = normalizePrice($item['tax'], 2, 'IN');
            $quantity = normalizePrice($item['quantity'], 2, 'IN');
            $amount = normalizePrice($item['amount'], 2, 'IN');
            // Adjust discount if not percentage based
            if (isset($item['use_percentage']) && $item['use_percentage'] === "true") {
                // Keep as is (already percentage-based)
            } else {
                $discount = $discount / max($quantity, 1);
            }

            // Build formatted item payload
            $itemsPayload[] = [
                "text" => $item['name'],
                "quantity" => $quantity,
                "unit_amount" => normalizePrice($price, 2, 'IN'),
                "full_amount" => normalizePrice($amount, 2, 'IN'),
                "discount" => normalizePrice($discount, 2, 'IN'),
                "vat_type" => "IVA",
                "system" => [
                    "type" => "REGULAR",
                    "category" => [
                        "type" => "VAT",
                        "rate" => normalizePrice($tax, 0, 'IN')
                    ]
                ]
            ];
        }

        return $itemsPayload;
    }

    function buildRecipients($invoiceData)
    {
        $address = implode(', ', array_filter([
            $invoiceData->client['extra']['address'] ?? '',
            $invoiceData->client['extra']['locality'] ?? '',
            $invoiceData->client['extra']['state_name'] ?? '',
            $invoiceData->client['extra']['country_name'] ?? ''
        ]));

        $recipients = [
            [
                "id" => [
                    "legal_name" => $invoiceData->client['extra']['company_name'] ?? '',
                    "tax_number" => $invoiceData->client['gst_no'] ?? ''
                ],
                "address_line" => $address??'MADRID',
                "postal_code" => $invoiceData->client['extra']['zip_code'] ?? ''
            ]
        ];

        return $recipients;
    }

    protected function buildReceiptItemsPayload($receiptData)
    {
        $items = is_string($receiptData->items)
            ? json_decode($receiptData->items, true)
            : (is_array($receiptData->items) ? $receiptData->items : []);

            //dd($items,$receiptData->items);
    
        $payloadItems = [];
    
        foreach ($items as $item) {
            $price = normalizePrice($item['price'], 2, 'IN');
            $discount = normalizePrice($item['discount'] ?? 0, 2, 'IN');
            $tax = normalizePrice($item['tax'] ?? 0, 2, 'IN');
            $quantity = (int) $item['quantity'];
            $amount = normalizePrice($item['amount'], 2, 'IN');
    
            if (isset($item['use_percentage']) && $item['use_percentage'] === "true") {
                // keep discount as-is
            } else {
                $discount = $discount / max($quantity, 1);
            }
    
            $taxPercentage = ($item['tax_type'] ?? 'percentage') === "fixed"
                ? ($tax / (($price * $quantity) - $discount)) * 100
                : $tax;
    
            $payloadItems[] = [
                "text" => $item['name'],
                "quantity" => $quantity,
                "unit_amount" => '-----'.$price,
                "full_amount" => $amount,
                "discount" => $discount,
                "vat_type" => "IVA",
                "system" => [
                    "type" => "REGULAR",
                    "category" => [
                        "type" => "VAT",
                        "rate" => (string) $taxPercentage
                    ]
                ]
            ];
        }
    
        return $payloadItems;
    }
    
    protected function handleVerifactuError($response, $invoiceData, $payload)
    {
        $status  = $response['content']['status'] ?? null;
        $error   = $response['content']['error'] ?? null;
        $message = $response['content']['message'] ?? null;

        // Check for API error or HTTP-like error
        if ($error || ($status !== null && $status >= 400)) {

            // Remove locally saved record
            if ($invoiceData) {
                $invoiceData->delete();
            }

            // Debug dump (only in local / debug mode)
            if (app()->environment(['local', 'development'])) {
                dd($payload, $response, $error, $status, $message);
            }

            // Return proper JSON error response
            return response()->json([
                'success' => false,
                'errors'  => $message ?? 'Bad request',
                'message' => __('Validation Failed'),
            ], 400);
        }

        // No error → return null (continue normal flow)
        return null;
    }


}
