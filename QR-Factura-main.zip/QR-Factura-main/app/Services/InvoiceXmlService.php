<?php

namespace App\Services;

class InvoiceXmlService
{
    /**
     * Generate invoice XML
     */
    public function generateInvoiceXML(array $invoice, array $items, array $company): string
    {
        $xml = new \SimpleXMLElement('<Invoice/>');
        // dd($company['company_name']);
        // =============================
        // Company Info
        // =============================
        $companyData = $xml->addChild('Company');
        $companyData->addChild('Name', $company['company_name'] ?? '');
        $companyData->addChild('Email', $company['company_email'] ?? '');
        $companyData->addChild('GSTIN', $company['gst_no'] ?? '');
        $companyData->addChild('Address',  addressString($company['extra']));

        // =============================
        // Invoice Header
        // =============================
        $xml->addChild('InvoiceNumber', $invoice['invoice_id']);
        $xml->addChild('InvoiceDate', $invoice['issue_date']);
        $xml->addChild('Currency', $invoice['currency'] ?? 'INR');
        $xml->addChild('SubTotal', $invoice['subtotal']);
        $xml->addChild('TotalDiscount', $invoice['totalDiscount']);
        $xml->addChild('TotalTax', $invoice['totalTax']);
        $xml->addChild('GrandTotal', $invoice['grandTotal']);

        // =============================
        // Customer Info
        // =============================
        $customer = $xml->addChild('Customer');
        $customer->addChild('Name', $invoice['client']['name'] ?? '');
        $customer->addChild('Email', $invoice['client']['email'] ?? '');
        $customer->addChild('Phone', $invoice['client']['mobile_no'] ?? '');
        $customer->addChild('GSTIN', $invoice['client']['gst_no'] ?? '');
        $customer->addChild('Address', addressString( $invoice['client']['extra']));

        // =============================
        // Item Level Data
        // =============================
        $itemsNode = $xml->addChild('Items');

        foreach ($items as $item) {
            $row = $itemsNode->addChild('Item');

            $row->addChild('Name', $item['name']);
            $row->addChild('Quantity', $item['quantity']);
            $row->addChild('Price', $item['price']);
            $row->addChild('Discount', $item['discount']);
            $row->addChild('TaxRate', $item['tax']);
            $row->addChild('Total', $item['amount']);
        }

        // Convert to formatted XML
        $dom = dom_import_simplexml($xml)->ownerDocument;
        $dom->formatOutput = true;

        return $dom->saveXML();
    }
}
