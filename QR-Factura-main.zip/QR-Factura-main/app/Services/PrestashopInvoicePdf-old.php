<?php

namespace App\Services;

use Barryvdh\DomPDF\Facade\Pdf;
use iio\libmergepdf\Merger;
use Illuminate\Support\Facades\Storage;

/**
 * PDFs for invoices sent by the PrestaShop module.
 *
 * Preferred: the shop's own invoice PDF, uploaded by the module after registration and kept on the
 * private disk (storePdf / storedPdfWith). Until it arrives, a layout matching the PrestaShop invoice
 * is rendered from extra.prestashop_pdf. Invoices with neither keep using the company template, so
 * every existing invoice renders exactly as before.
 */
class PrestashopInvoicePdf
{
    const EXTRA_FILE_KEY = 'prestashop_pdf_file';

    /**
     * PDF for a PrestaShop invoice: the shop's uploaded PDF, else the PrestaShop layout.
     * Null for any other invoice, so callers keep their own rendering.
     */
    public static function pdfFor($invoice, $company, array $negativeBodies = [], $privacyText = null): ?string
    {
        $stored = self::storedPdfWith($invoice, $negativeBodies, $privacyText);
        if ($stored !== null) {
            return $stored;
        }

        return self::supports($invoice)
            ? self::renderPdf(self::html($invoice, $company, $negativeBodies, $privacyText))
            : null;
    }

    public static function downloadResponse(string $pdf, string $fileName)
    {
        return response($pdf, 200, [
            'Content-Type'        => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . str_replace(['"', '/'], ['', '-'], $fileName) . '"',
        ]);
    }

    /**
     * Preview markup: the uploaded PDF shown inline, else the PrestaShop layout. Null for other invoices.
     */
    public static function previewHtml($invoice, $company): ?string
    {
        $stored = self::storedPdfWith($invoice);
        if ($stored !== null) {
            return view('pdf.partials.prestashop_pdf_embed', [
                'uid'      => 'ps-pdf-' . $invoice->id,
                'base64'   => base64_encode($stored),
                'fileName' => 'invoice-' . str_replace('/', '-', $invoice->ref_no ?? $invoice->invoice_id) . '.pdf',
            ])->render();
        }

        return self::supports($invoice) ? self::bodyHtml($invoice, $company) : null;
    }

    /**
     * Email body: the PrestaShop layout (emails cannot show the PDF inline; it is attached).
     * Null for other invoices.
     */
    public static function emailHtml($invoice, $company): ?string
    {
        return self::supports($invoice) ? preg_replace('/\s+/', ' ', self::bodyHtml($invoice, $company)) : null;
    }

    /**
     * Saves the shop's PDF for this invoice on the private disk and records its path in extra.
     */
    public static function storePdf($invoice, string $pdf): string
    {
        $path = 'prestashop-invoices/' . $invoice->getTable() . '/' . $invoice->id . '.pdf';
        Storage::disk('local')->put($path, $pdf);

        $extra = is_array($invoice->extra) ? $invoice->extra : [];
        $extra[self::EXTRA_FILE_KEY] = $path;
        $invoice->extra = $extra;
        $invoice->save();

        return $path;
    }

    /**
     * The shop's PDF, followed by rectifying invoices and privacy text when there are any.
     * Null when no PDF was uploaded, so callers fall back to rendering.
     */
    public static function storedPdfWith($invoice, array $negativeBodies = [], $privacyText = null): ?string
    {
        $path = self::storedPath($invoice);
        if (!$path) {
            return null;
        }

        $stored = Storage::disk('local')->get($path);
        if (empty($negativeBodies) && empty($privacyText)) {
            return $stored;
        }

        $merger = new Merger();
        $merger->addRaw($stored);
        $merger->addRaw(self::appendixPdf($negativeBodies, $privacyText));

        return $merger->merge();
    }

    protected static function storedPath($invoice): ?string
    {
        $path = is_array($invoice->extra ?? null) ? ($invoice->extra[self::EXTRA_FILE_KEY] ?? null) : null;

        return $path && Storage::disk('local')->exists($path) ? $path : null;
    }

    /**
     * Pages added after the shop's PDF, rendered like pdf.invoice renders them.
     */
    protected static function appendixPdf(array $negativeBodies, $privacyText): string
    {
        $parts = array_map(fn ($neg) => $neg['body'], $negativeBodies);
        if (!empty($privacyText)) {
            $parts[] = '<div style="color:#888; font-size:11px">' . $privacyText . '</div>';
        }

        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family: Arial, sans-serif">'
            . implode('<div style="page-break-before: always"></div>', $parts)
            . '</body></html>';

        return self::renderPdf($html);
    }

    protected static function renderPdf(string $html): string
    {
        return Pdf::loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'))
            ->setPaper('A4')
            ->setOption('isHtml5ParserEnabled', true)
            ->setOption('isRemoteEnabled', true)
            ->setOption('defaultFont', 'Arial')
            ->output();
    }

    public static function supports($invoice): bool
    {
        $extra = $invoice->extra ?? null;

        return is_array($extra) && !empty($extra['prestashop_pdf']['lines']);
    }

    /**
     * Invoice body with its own scoped styles, for the web preview.
     */
    public static function bodyHtml($invoice, $company): string
    {
        return view('pdf.partials.prestashop_invoice_body', self::viewData($invoice, $company))->render();
    }

    /**
     * Full document for dompdf. Rectifying invoices and privacy text are added as in pdf.invoice.
     */
    public static function html($invoice, $company, array $negativeBodies = [], $privacyText = null): string
    {
        $data = self::viewData($invoice, $company) + [
            'negativeBodies' => $negativeBodies,
            'privacyText'    => $privacyText,
        ];

        return view('pdf.prestashop_invoice', $data)->render();
    }

    protected static function viewData($invoice, $company): array
    {
        $ps = $invoice->extra['prestashop_pdf'];

        return [
            'ps'           => $ps,
            'invoice'      => $invoice,
            // The number registered in Verifactu, so the PDF matches the QR.
            'invoiceTitle' => $invoice->ref_no ?: ($ps['invoice']['number'] ?? $invoice->invoice_id),
            'qrSrc'        => self::qrSrc($invoice, $company),
            'currencySign' => $ps['invoice']['currency']['sign'] ?? '€',
        ];
    }

    /**
     * Same conditions as the [invoice_qr] shortcode; embedded so dompdf never fetches it over HTTP.
     */
    protected static function qrSrc($invoice, $company): ?string
    {
        if (empty($invoice->qr_code) || ($company->extra['country_code'] ?? null) !== 'ES') {
            return null;
        }

        $disk = Storage::disk('public');
        if (!$disk->exists($invoice->qr_code)) {
            return null;
        }

        return 'data:image/png;base64,' . base64_encode($disk->get($invoice->qr_code));
    }
}
