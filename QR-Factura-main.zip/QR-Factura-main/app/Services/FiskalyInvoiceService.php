<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use App\Models\Company;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CompanyVerifactu;
use Illuminate\Support\Facades\Storage;

use App\Models\User;
use App\Models\Invoice;
use App\Models\Receipts;


use App\Services\InvoiceService;

class FiskalyInvoiceService
{
    protected $dashboard;
    protected $managed;
    protected $baseUrl;
    protected $testUrl;
    protected $apiKey;
    protected $apiSecret;

    public function __construct()
    {
        $this->dashboard = config('services.fiskaly.dashboard_url');
        $this->managed = config('services.fiskaly.managed_id');
        $this->baseUrl = config('services.fiskaly.base_url');
        $this->testUrl = config('services.fiskaly.test_url');
        $this->apiKey = config('services.fiskaly.api_key');
        $this->apiSecret = config('services.fiskaly.api_secret');
    }

   
    public function getBearerToken()
    {
        try {
            Cache::flush();
                $response = Http::acceptJson()
                    ->post("{$this->baseUrl}/auth", [
                        'content' => [
                            'api_key' => $this->apiKey,
                            'api_secret' => $this->apiSecret,
                        ],
                    ]);

                if ($response->successful()) {
                    return $response->json('content.access_token.bearer');
                }

                \Log::error('Fiskaly auth failed', ['response' => $response->body()]);
                return null;
        } catch (\Exception $e) {
            \Log::error('Exception in getBearerToken: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);
            return null;
        }
    }



    public function getBearerTokenCompany($company)
    {
        try {
        $response = Http::acceptJson()
                ->post("{$this->baseUrl}/auth", [
                    'content' => [
                        'api_key' => $company->organization_details->api_keys['key'],
                        'api_secret' => $company->organization_details->api_keys['secret'],
                    ],
                ]);

            if ($response->successful()) {
                return $response->json('content.access_token.bearer');
            }

            \Log::error('Fiskaly auth failed', ['response' => $response->body()]);
            return null;

        } catch (\Exception $e) {
            \Log::error('Exception in getBearerTokenCompany: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);
            return null;
        }
    }


    public function listOrganizations()
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->dashboard}/organizations");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        } catch (\Exception $e) {
            \Log::error('Exception in listOrganizations: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while fetching organizations'];
        }
    }

    public function  createOrganisation($company)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();

            $data = [
                'name' => $company->company_name,
                'address_line1' => $company->extra['company_address'],
                'address_line2' => $company->extra['street_number'],
                'zip' => $company->extra['zip_code'],
                'town' => $company->extra['locality'],
                'country_code' => 'ESP', // ISO 3166-1 alpha-3 code
                'managed_by_organization_id' => $this->managed, // Replace if needed
                'tax_number' => $company->gst_no,
                'state'=>$state->name ?? null,
            ];

            // dd($this->managed, $company, $data);

            $response = Http::withToken($token)
                ->acceptJson()
                ->post("{$this->dashboard}/organizations", $data);

            $apiResponse = $response->json();

            if($apiResponse['_id']){
                CompanyVerifactu::create([
                    'company_id'=>$company->id,
                    'organization_id'=>$apiResponse['_id']
                ]);
                $apiKeys = $this->createOrganisationKey($company,$apiResponse['_id']);
            }

            return $apiResponse;
        } catch (\Exception $e) {
            \Log::error('Exception in createOrganisation: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'company_id' => $company->id ?? null,
            ]);

            return ['error' => 'An unexpected error occurred while creating the organization.'];
        }
    }

    public function createOrganisationKey($company,$organization_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $data = [
                'name'      => sanitizeCompanyName($company->company_name),
                'status'    => 'enabled'
            ];

            $response = Http::withToken($token)
                ->acceptJson()
                ->post("{$this->dashboard}/organizations/$organization_id/api-keys", $data);

            $apiResponse = $response->json();

            CompanyVerifactu::where('organization_id',$organization_id)->update([
            'api_keys'=>[
                    'key'=>$apiResponse['key'],
                    'secret'=>$apiResponse['secret']
                ]
            ]);
            if ($response->successful()) {
                return $response->json();
            }

            return $apiResponse;

        } catch (\Exception $e) {
            \Log::error('Exception in createOrganisationKey: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'company_id' => $company->id ?? null,
                'organization_id' => $organization_id,
            ]);

            return ['error' => 'An unexpected error occurred while creating the organization API key.'];
        }
    }

    public function listOrganizationlkeys($organization_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->dashboard}/organizations/{$organization_id}/api-keys");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        }
        catch (\Exception $e) {
            \Log::error('Exception in listOrganizationlkeys: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'organization_id' => $organization_id,
            ]);
    
            return ['error' => 'An unexpected error occurred while fetching organization API keys.'];
        }
    }


    public function deleteOrganizationApiKey($organization_id,$key_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->delete("{$this->dashboard}/organizations/{$organization_id}/api-keys/{$key_id}");

            if ($response->successful()) {
                return $response->json();
            }

            \Log::error('Failed to fetch organizations', ['response' => $response->body()]);
            return ['error' => 'Failed to fetch organizations'];
        } catch (\Exception $e) {
            \Log::error('Exception in deleteOrganizationApiKey: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'organization_id' => $organization_id,
                'key_id' => $key_id
            ]);

            return ['error' => 'An unexpected error occurred while deleting the organization API key.'];
        }
    }

    public function deleteOrganization($organization_id)
    {
        try {
            $token = $this->getBearerToken();

            if (!$token) {
                return ['error' => 'Unable to authenticate with Fiskaly'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->delete("{$this->dashboard}/organizations/{$organization_id}");

            $responseData = $response->json();
            if(isset($responseData['_success']) && $responseData['_success'] === true){
                return true;
            }else{
                return false;
            }
        } catch (\Exception $e) {
            \Log::error('Exception in deleteOrganizationApiKey: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'organization_id' => $organization_id,
                'key_id' => $key_id
            ]);

            return ['error' => 'An unexpected error occurred while deleting the organization API key.'];
        }
    }

    // public function createTaxPayer($company)
    // {
    //     $token = $this->getBearerTokenCompany($company);
       
    //     if (!$token) {
    //         return ['error' => 'Authentication failed'];
    //     }

    //     // dd($this->baseUrl);
    //     $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
    //     $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
    
    //     $addressParts = array_filter([
    //         $company->extra['address'] ?? null,
    //         (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
    //         (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
    //         $state->name ?? null,  // Get state name
    //         $country->name ?? null // Get country name
    //     ]);
    //     $response = Http::withToken($token)
    //         ->acceptJson()
    //         ->put("{$this->baseUrl}/taxpayer", [
    //             'content' => [
    //                 'issuer'=>[
    //                     'legal_name'=> $company->company_name,
    //                     'tax_number'=>$company->gst_no
    //                 ],
    //                 'territory'=>$company->territory,
    //                 'email'=> $company->user->email,
    //                 'address'=> [
    //                     'municipality'=>$company->extra['company_address'] ?? null,
    //                     'city'=>$state->name,
    //                     'street'=>$company->extra['locality'] ?? null,
    //                     'postal_code'=>$company->extra['zip_code'] ?? null,
    //                     'number'=>$company->extra['street_number'] ?? null,
    //                     'country_code'=>'ES',
    //                 ],
    //             ]
    //         ]);

        
    //     // dd($response->json());
    //     return $response->json();
    // }

    public function createTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                Log::error('Authentication failed for company ID: ' . $company->id);
                return ['error' => 'Authentication failed'];
            }

            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();

            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,
                $country->name ?? null
            ]);

            // Log the request payload before sending
            $payload = [
                'content' => [
                    'issuer'=>[
                        'legal_name'=> $company->company_name,
                        'tax_number'=>$company->gst_no
                    ],
                    'territory'=>$company->territory,
                    'email'=> $company->user->email,
                    'address'=> [
                        'municipality'=>$company->extra['locality'] ?? null,
                        'city'=>$state->name,
                        'street'=>$company->extra['company_address'] ?? null,
                        'postal_code'=>$company->extra['zip_code'] ?? null,
                        'number'=>$company->extra['street_number'] ?? null,
                        'country_code'=>'ES',
                    ],
                ]
            ];

            Log::info('Sending createTaxPayer request', [
                'company_id' => $company->id,
                'payload' => $payload
            ]);

            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$this->baseUrl}/taxpayer", $payload);

            // Log the response
            if ($response->successful()) {
                Log::info('createTaxPayer response', [
                    'company_id' => $company->id,
                    'response' => $response->json()
                ]);
            } else {
                Log::error('createTaxPayer failed', [
                    'company_id' => $company->id,
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while creating the taxpayer.'];
        }
    }

    public function updateTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$this->baseUrl}/taxpayer", [
                    'content' => [
                        'state'=>'DISABLED'
                    ]
                ]);

            
            // dd($response->json());
            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while updating the taxpayer.'];
        }
    }

    public function getTaxPayer($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            // dd($this->baseUrl);
            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->baseUrl}/taxpayer");

            
            // dd($response);
            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in getTaxPayer: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return ['error' => 'An unexpected error occurred while fetching taxpayer data.'];
        }
    }


    public function generateAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            
            $country = CountryModel::where('country_code', $company->extra['personal']['country_code'] ?? null)->first();

            $state = StateModel::where('state_code', $company->extra['personal']['state_code'] ?? null)->first();

            $payloadData = [
                'content' => [
                    "representative"=>[
                        'full_name'=>$company->user->name,
                        'tax_number'=>$company->dnia,
                        'address'=> [
                            'municipality'=>$company->extra['personal']['locality'] ?? null,
                            'city'=>$state->name,
                            'street'=>$company->extra['personal']['address'] ?? null,
                            'postal_code'=>$company->extra['personal']['zip_code'] ?? null,
                            'number'=>$company->extra['personal']['street_number'] ?? null,
                            'country_code'=>'ES',
                        ],
                    ]
                ]
            ];

            // dd($payloadData);
            $response = Http::withToken($token)
                ->acceptJson()
                ->post("{$this->baseUrl}/taxpayer/agreement", $payloadData);

            // return $response->json();
            // dd($response->json());
            if ($response->failed()) {
                return ['error' => 'Failed to generate agreement'];
            }
            $fileName = 'agreement_' . $company->id . '_' . time() . '.pdf';
            $filePath = 'agreements/' . $fileName;

            Storage::disk('public')->put($filePath, $response->body());

            // Save file path in organization_details->agreement
            $organizationDetails = $company->organization_details;
            $organizationDetails->agreement = 'storage/' . $filePath;
            $organizationDetails->save();

            return [
                'success' => true,
                'file_path' => asset('storage/' . $filePath)
            ];
        } catch (\Exception $e) {
            \Log::error('Exception in generateAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => $e->getMessage()];
        }
    }

    public function getAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $country = CountryModel::where('country_code', $company->extra['country_code'] ?? null)->first();

            $state = StateModel::where('state_code', $company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $company->extra['address'] ?? null,
                (isset($company->extra['locality']) && !empty($company->extra['locality'])) ? ($company->extra['locality']) : null,
                (isset($company->extra['zip_code']) && !empty($company->extra['zip_code'])) ? ($company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);

            $payloadData = [
                'content' => [
                    "representative"=>[
                        'full_name'=>$company->company_name,
                        'tax_number'=>$company->gst_no,
                        'address'=> [
                            'municipality'=>$company->extra['locality'] ?? null,
                            'city'=>$state->name,
                            'street'=>$company->extra['company_address'] ?? null,
                            'postal_code'=>$company->extra['zip_code'] ?? null,
                            'number'=>$company->extra['street_number'] ?? null,
                            'country_code'=>'ES',
                        ],
                    ]
                ]
            ];

            // dd($payloadData);
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$this->baseUrl}/taxpayer/agreement");

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in getAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while fetching agreement.'];
        }
    }

    public function uploadAgreement($company)
    {
        try {
            $token = $this->getBearerTokenCompany($company);

            if (!$token) {
                return ['error' => true, 'message' => 'Authentication failed'];
            }

            // Path of signed agreement
            $filePath = public_path($company->organization_details->signed_agreement);

            if (!file_exists($filePath)) {
                return ['error' => 'Signed agreement file not found'];
            }

            $organizationDetails = $company->organization_details;
            // Encode PDF file as Base64
            $fileContent = file_get_contents($filePath);
            // return response()->download($filePath);
            $base64Content = base64_encode($fileContent);
            // dd($base64Content);
            $payload = [
                'content' => [
                    'binary' => $base64Content
                ]
            ];
            
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$this->baseUrl}/taxpayer/agreement", $payload);

            
            if ($response->failed()) {
                return $response->json();
            }
            
            $organizationDetails->is_verified = true;
            $organizationDetails->save();

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in uploadAgreement: ' . $e->getMessage(), [
                'company_id' => $company->id,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while uploading agreement.'];
        }
    }

    public function createSigner($user)
    {
        try {
            $token = $this->getBearerTokenCompany($user->company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $guid = Str::uuid();
            $baseUrl = config('services.fiskaly.base_url'); 

            $country = CountryModel::where('country_code', $user->company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $user->company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $user->company->extra['address'] ?? null,
                (isset($user->company->extra['locality']) && !empty($user->company->extra['locality'])) ? ($user->company->extra['locality']) : null,
                (isset($user->company->extra['zip_code']) && !empty($user->company->extra['zip_code'])) ? ($user->company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            // dd($user->phone );
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/signers/{$guid}", [
                    'metadata' => [
                        'full_name'       => $user->name,
                        'email'           => $user->email,
                        'mobile_no'           => "$user->phone" ??'',
                        'nif'             => $user->company->gst_no??'',
                        'company_name'    => $user->company->company_name ?? null,
                        'address'=> implode(',', $addressParts)
                    ]
                ]);

            if ($response->successful()) {
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createSigner: ' . $e->getMessage(), [
                'user_id'   => $user->id ?? null,
                'company_id'=> $user->company->id ?? null,
                'line'      => $e->getLine(),
                'file'      => $e->getFile(),
            ]);

            return ['error' => 'An unexpected error occurred while creating signer.'];
        }
    }

    public function updateSigner($company,$signerId)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $baseUrl = config('services.fiskaly.base_url'); 

            // dd($user->phone );
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/signers/{$signerId}", [
                    'content'=>[
                        'state'=>'DISABLED'
                    ]
                ]);

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateSigner: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'signer_id'  => $signerId,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating signer.'
            ];
        }
    }

    public function createClient($user)
    {
        try {
            $token = $this->getBearerTokenCompany($user->company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $guid = Str::uuid();
            $baseUrl = config('services.fiskaly.base_url'); 

            $country = CountryModel::where('country_code', $user->company->extra['country_code'] ?? null)->first();
            $state = StateModel::where('state_code', $user->company->extra['state_code'] ?? null)->first();
        
            $addressParts = array_filter([
                $user->company->extra['address'] ?? null,
                (isset($user->company->extra['locality']) && !empty($user->company->extra['locality'])) ? ($user->company->extra['locality']) : null,
                (isset($user->company->extra['zip_code']) && !empty($user->company->extra['zip_code'])) ? ($user->company->extra['zip_code']) : null,
                $state->name ?? null,  // Get state name
                $country->name ?? null // Get country name
            ]);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$guid}", [
                    'metadata' => [
                        'full_name'       => $user->name,
                        'email'           => $user->email,
                        'mobile_no'           => $user->mobile_no??'',
                        'nif'             => $user->company->gst_no??'',
                        'company_name'    => $user->company->company_name ?? null,
                        'address'=> implode(',', $addressParts)
                    ]
                ]);

            if ($response->successful()) {
                $verifactuDetails = $user->company->organization_details;
                $verifactuDetails->client_id = $response['content']['id'];
                $verifactuDetails->save();
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createClient: ' . $e->getMessage(), [
                'user_id'    => $user->id ?? null,
                'company_id' => $user->company->id ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error'   => 'An unexpected error occurred while creating client.'
            ];
        }
    }

    public function updateClient($company,$clientId)
    {
        try {
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }

            $baseUrl = config('services.fiskaly.base_url'); 

            
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/clients/{$clientId}", [
                    'content'=>[
                        'state'=>'DISABLED'
                    ]
                ]);

            if ($response->successful()) {
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in updateClient: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'client_id'  => $clientId ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating client.'
            ];
        }
    }
    // public function updateClient($company, $clientId, $state = 'DISABLED')
    // {
    //     try {
    //         $token = $this->getBearerTokenCompany($company);
        
    //         if (!$token) {
    //             return ['error' => 'Authentication failed'];
    //         }

    //         $baseUrl = config('services.fiskaly.base_url'); 

    //         $response = Http::withToken($token)
    //             ->acceptJson()
    //             ->patch("{$baseUrl}/clients/{$clientId}", [
    //                 'content' => [
    //                     'state' => $state  // 'ENABLED' or 'DISABLED'
    //                 ]
    //             ]);

    //         if ($response->successful()) {
    //             return $response->json();
    //         }

    //         return $response->json();
    //     } catch (\Exception $e) {
    //         \Log::error('Exception in updateClient: ' . $e->getMessage(), [
    //             'company_id' => $company->id ?? null,
    //             'client_id'  => $clientId ?? null,
    //             'line'       => $e->getLine(),
    //             'file'       => $e->getFile(),
    //         ]);

    //         return ['error' => 'An unexpected error occurred while updating client.'];
    //     }
    // }



    public function createPrestashopInvoice($company,$payload)
    {
        try {
            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $token = $this->getBearerTokenCompany($company);
            $baseUrl = config('services.fiskaly.base_url'); 
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            return $response->json();
        } catch (\Exception $e) {
            \Log::error('Exception in createPrestashopInvoice: ' . $e->getMessage(), [
                'company_id' => $company->id ?? null,
                'client_id'  => $company->organization_details->client_id ?? null,
                'line'       => $e->getLine(),
                'file'       => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while creating Prestashop invoice.'
            ];
        }
    }

    public function createAutoInvoice($company,$invoiceData)
    {
        try{

            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            $series = strtok($invoiceData->invoice_id, '/'); // gets '2025'
            $number = substr($invoiceData->invoice_id, strlen($series)); // gets '/EN/123'
            $fullAmount = parseNumber($invoiceData->grandTotal);
            // dd($fullAmount);
            // $state = StateModel::where('state_code', $invoiceData->client->extra['state_code'] ?? null)->first();
            $countryCode = $invoiceData->client->extra['country_code'] ?? 'ES';
            $countries = getProviderCountries();
            $country = $countries[$countryCode];

            $addressParts = array_filter([
                $invoiceData->client->extra['address'] ?? null,
                (isset($invoiceData->client->extra['locality']) && !empty($invoiceData->client->extra['locality'])) ? ($invoiceData->client->extra['locality']) : null,
                (isset($invoiceData->client->extra['state_name']) && !empty($invoiceData->client->extra['state_name'])) ? ($invoiceData->client->extra['state_name']) : null, // Get state name
                $country // Get country name
            ]);

            // if($countryCode == 'ES'){
            //     $recipients = [
            //         'id'=>[
            //             "legal_name"=>$invoiceData->client->name,
            //             "tax_number"=>$invoiceData->client->gst_no
            //         ],
            //         'address_line'=>implode(',', $addressParts),
            //         'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
            //     ];
            // }else{
                $recipients = [
                    'id'=>[
                        "legal_name"=>$invoiceData->client->name,
                        "type"=>"TAX_NUMBER",
                        "number"=>$invoiceData->client->gst_no,
                        'country_code'=>$countryCode
                    ],
                    'address_line'=>implode(',', $addressParts),
                    'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
                ];
            // }
            if($fullAmount > 3000){
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $invoiceData->ref_no ?? $invoiceData->invoice_id,
                            "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)->format('d-m-Y H:i:s'),
                            "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                            "full_amount" => number_format(parseNumber($invoiceData->grandTotal), 2, '.', '')
                        ],
                        "recipients"=>[
                            $recipients
                        ]
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }

                    // dd($discount);
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['data']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => (string) $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }else{
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        'number' => $invoiceData->ref_no ?? $invoiceData->invoice_id,
                        "issued_at"=>\Carbon\Carbon::parse($invoiceData->issue_date)
                    ->format('d-m-Y H:i:s'),
                        "text" => __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                        "full_amount" => number_format(parseNumber($invoiceData->grandTotal+$invoiceData->totalRetencion), 2, '.', '')
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => (string) $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

                // dd($response->json());
            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
                // Build path
                $folderPath = "qrcodes/{$company->company_slug}";
                $fileName = "invoice_{$invoiceData->invoice_id}.png";
                $filePath = "{$folderPath}/{$fileName}";

                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));

                // Save in extra field
                // $invoiceData->extra = array_merge($invoiceData->extra ?? [], [
                //     'qr_code' => $filePath,
                // ]);

                $invoiceData->verifactu_id = $response['content']['id'] ?? null;
                $invoiceData->is_verified = 1;
                $invoiceData->qr_code = $filePath;
                $invoiceData->save();
            }
            return $response->json();
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }


     public function createAutoReceipt($company,$invoiceData)
    {
        try{

            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            // $series = strtok($invoiceData->receipt_id, '/'); // gets '2025'
            // $number = substr($invoiceData->receipt_id, strlen($series)); // gets '/EN/123'
            $fullAmount = parseNumber($invoiceData->grandTotal);
            // dd($invoiceData->provider);
            // dd($fullAmount);
            // $state = StateModel::where('state_code', $invoiceData->client->extra['state_code'] ?? null)->first();
            $countryCode = $invoiceData->provider->extra['country_code'] ?? 'ES';
            $countries = getProviderCountries();
            $country = $countries[$countryCode];

            $addressParts = array_filter([
                $invoiceData->provider->extra['address'] ?? null,
                (isset($invoiceData->provider->extra['locality']) && !empty($invoiceData->provider->extra['locality'])) ? ($invoiceData->provider->extra['locality']) : null,
                (isset($invoiceData->provider->extra['state_name']) && !empty($invoiceData->provider->extra['state_name'])) ? ($invoiceData->provider->extra['state_name']) : null, // Get state name
                $country // Get country name
            ]);

            // if($countryCode == 'ES'){
            //     $recipients = [
            //         'id'=>[
            //             "legal_name"=>$invoiceData->client->name,
            //             "tax_number"=>$invoiceData->client->gst_no
            //         ],
            //         'address_line'=>implode(',', $addressParts),
            //         'postal_code'=>$invoiceData->client->extra['zip_code'] ?? null
            //     ];
            // }else{
                $recipients = [
                    'id'=>[
                        "legal_name"=>$invoiceData->provider->name ?? null,
                        "type"=>"TAX_NUMBER",
                        "number"=>$invoiceData->provider->gst_no ?? null,
                        'country_code'=>$countryCode
                    ],
                    'address_line'=>implode(',', $addressParts),
                    'postal_code'=>$invoiceData->provider->extra['zip_code'] ?? null
                ];
            // }
            if($fullAmount > 3000){
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $invoiceData->ref_no ?? $invoiceData->receipt_id,
                            "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name,
                            "issued_at"=>\Carbon\Carbon::parse($invoiceData->created_at)->format('d-m-Y H:i:s'),
                            "full_amount" => number_format(parseNumber($invoiceData->grandTotal), 2, '.', '')
                        ],
                        "recipients"=>[
                            $recipients
                        ]
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }

                    // dd($discount);
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['data']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }else{
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name,
                        'number' =>  $invoiceData->ref_no ?? $invoiceData->receipt_id,
                        "issued_at"=>\Carbon\Carbon::parse($invoiceData->created_at)
                    ->format('d-m-Y H:i:s'),
                        "full_amount" => number_format(parseNumber($invoiceData->grandTotal), 2, '.', '')
                    ]
                ];
                
                foreach($invoiceData->items as $item){
                    $price = parseNumber($item['price']);
                    $discount = parseNumber($item['discount']);
                    $tax = parseNumber($item['tax']);
                    if(isset($item['use_percentage']) && $item['use_percentage']=="true"){
                        $discount = $discount;
                    }else{
                        $discount = $discount / $item['quantity'];
                    }
                    $amount = parseNumber($item['amount']);

                    if($item['tax_type'] == "fixed"){
                        $taxPercentage = ($tax / (($price*$item['quantity']) - $discount))*100; 
                    }else{
                        $taxPercentage = $tax;
                    }
                    
                    $payload['content']['items'][] = [
                        "text" => $item['name'],
                        "quantity" => $item['quantity'],
                        "unit_amount" =>  (string) $price,
                        "full_amount" =>  number_format(parseNumber($item['amount']), 2, '.', ''),
                        "discount"=>number_format(truncateToTwoDecimals($discount), 2, '.', ''),
                        "vat_type"=>"IVA",
                        "system" => [
                            "type" => "REGULAR",
                            "category" => [
                                "type" => "VAT",
                                "rate"=>"$taxPercentage"
                            ]
                        ]
                    ];
                }
            }
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

                // dd($response->json());
            // if (isset($response['content']['compliance']['code']['image']['data'])) {
            //     $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
            //     // Build path
            //     $folderPath = "qrcodes/{$company->company_slug}";
            //     $fileName = "invoice_{$invoiceData->invoice_id}.png";
            //     $filePath = "{$folderPath}/{$fileName}";

            //     // Make directory and save file
            //     Storage::disk('public')->makeDirectory($folderPath);
            //     Storage::disk('public')->put($filePath, base64_decode($qrBase64));

            //     // Save in extra field
            //     // $invoiceData->extra = array_merge($invoiceData->extra ?? [], [
            //     //     'qr_code' => $filePath,
            //     // ]);

            //     $invoiceData->verifactu_id = $response['content']['id'] ?? null;
            //     $invoiceData->is_verified = 1;
            //     $invoiceData->qr_code = $filePath;
            //     $invoiceData->save();
            // }
            return $response;
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }


    public function updateInvoice($company,$invoice)
    {
        try {
            $clientId = $company->organization_details->client_id; // or pass via $request
            
            $token = $this->getBearerTokenCompany($company);
            $invoice_id = $invoice->verifactu_id;
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            // dd($invoiceData->items);
            $payload = [
                "content" => [
                    "state" => "CANCELLED"
                ]
            ];
            
            
            // dd($payload);
            // dd($baseUrl);
            $response = Http::withToken($token)
                ->acceptJson()
                ->patch("{$baseUrl}/clients/{$clientId}/invoices/{$invoice_id}", $payload);


            return $response->json();

        } catch (\Exception $e) {
            \Log::error('Exception in updateInvoice: ' . $e->getMessage(), [
                'company_id'  => $company->id ?? null,
                'invoice_id'  => $invoice->id ?? null,
                'verifactu_id' => $invoice->verifactu_id ?? null,
                'line'        => $e->getLine(),
                'file'        => $e->getFile(),
            ]);

            return [
                'error' => 'An unexpected error occurred while updating the invoice.'
            ];
        }
    }


    public function createInvoice($company,$invoiceData)
    {
        try{

            $clientId = $company->organization_details->client_id; 
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $payload = $this->buildPayload($invoiceData, $company);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            // $this->checkValidations($company,$response['content']['id'],'invoice');

            return $response;
            
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }

    // public function validateGst($company,$gst_no,$country_code)
    // {
    //     try{
    //         return true;
            
    //         $clientId = $company->organization_details->client_id; 
            
    //         $token = $this->getBearerTokenCompany($company);
        
    //         if (!$token) {
    //             return ['error' => 'Authentication failed'];
    //         }
    //         $currency = '₹';
    //         $baseUrl = config('services.fiskaly.base_url'); 
            
    //         $payload = [
    //             "content"=>[
    //                 "type"=>"AEAT",
    //                 "entries"=>[
    //                     [
    //                         "tin"=>$gst_no,
    //                     ]
    //                 ]
    //             ]
    //         ];

            

    //         $response = Http::withToken($token)
    //             ->acceptJson()
    //             ->post("{$baseUrl}/validation/tin", $payload);

    //         // $this->checkValidations($company,$response['content']['id'],'invoice');

    //         $jsonResponse = $response->json();
    //         $valid = false;
    //         // dd($jsonResponse);
    //         if(isset($jsonResponse['results'][0]['content']['result']) && $jsonResponse['results'][0]['content']['result'] == 'VALID'){
    //             $valid = true;
    //         }
    //         // dd($jsonResponse,$valid);
    //         return $valid;
            
    //     }
    //     catch (\Exception $e) {
    //         return [
    //             'error' => $e->getMessage(),
    //             'line'  => $e->getLine(),
    //             'file'  => $e->getFile(),
    //         ];

    //     }
    // }

    public function validateGst($company, $gst_no, $country_code)
    {
        try {
            $gst_no = trim($gst_no);
            $country_code = strtoupper($country_code);

            switch ($country_code) {

                case 'ES': // Spain - CIF/NIF
                    // Must start with A or B + 8 digits (e.g. A12345678)
                    return (bool) preg_match('/^[A-Z][0-9]{8}$/', $gst_no);

                case 'IN': // India - GST
                    // 15-char: 2 digits state + 10 PAN + 1 entity + Z + 1 checksum
                    return (bool) preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', $gst_no);

                case 'GB': // UK - VAT
                    // GB + 9 digits or GB + 12 digits or GBGD/GBHA + 3 digits
                    return (bool) preg_match('/^GB([0-9]{9}|[0-9]{12}|(GD|HA)[0-9]{3})$/', $gst_no);

                case 'DE': // Germany - VAT
                    // DE + 9 digits
                    return (bool) preg_match('/^DE[0-9]{9}$/', $gst_no);

                case 'FR': // France - VAT
                    // FR + 2 alphanumeric + 9 digits
                    return (bool) preg_match('/^FR[A-Z0-9]{2}[0-9]{9}$/', $gst_no);

                case 'IT': // Italy - VAT
                    // IT + 11 digits
                    return (bool) preg_match('/^IT[0-9]{11}$/', $gst_no);

                case 'AU': // Australia - ABN
                    // 11 digits
                    return (bool) preg_match('/^[0-9]{11}$/', $gst_no);

                case 'CA': // Canada - BN
                    // 9 digits (Business Number)
                    return (bool) preg_match('/^[0-9]{9}$/', $gst_no);

                case 'US': // USA - EIN
                    // XX-XXXXXXX
                    return (bool) preg_match('/^[0-9]{2}-[0-9]{7}$/', $gst_no);

                case 'NL': // Netherlands - VAT
                    // NL + 9 alphanumeric + B + 2 digits
                    return (bool) preg_match('/^NL[0-9]{9}B[0-9]{2}$/', $gst_no);

                case 'PL': // Poland - VAT
                    // PL + 10 digits
                    return (bool) preg_match('/^PL[0-9]{10}$/', $gst_no);

                case 'PT': // Portugal - VAT
                    // PT + 9 digits
                    return (bool) preg_match('/^PT[0-9]{9}$/', $gst_no);

                case 'SE': // Sweden - VAT
                    // SE + 12 digits
                    return (bool) preg_match('/^SE[0-9]{12}$/', $gst_no);

                case 'CH': // Switzerland - VAT
                    // CHE + 9 digits + MWST/TVA/IVA
                    return (bool) preg_match('/^CHE[0-9]{9}(MWST|TVA|IVA)$/', $gst_no);

                default:
                    // Unknown country — allow it through
                    return true;
            }

        } catch (\Exception $e) {
            return false;
        }
    }

    public function getInvoice($company,$invoice_id)
    {
        try{

            $clientId = $company->organization_details->client_id; 
            // $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$baseUrl}/clients/{$clientId}/invoices/{$invoice_id}");

            // if(!empty($response['validations'])){
            //     if($type == 'invoice'){
            //         Invoice::where('verifactu_id',$invoice_id)->update(['needs_validation',true]);
            //     }
            // }

            // $this->

            return $response;
            
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }


    public function checkValidations($company,$invoice_id,$type='invoice')
    {
        try{

            $clientId = $company->organization_details->client_id; 
            // $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $response = Http::withToken($token)
                ->acceptJson()
                ->get("{$baseUrl}/clients/{$clientId}/invoices/{$invoice_id}");

            $data = $response->json();  

            // e.g. full JSON: dd($data);

            $validations = $data['content']['validations'] ?? [];
            // dd($data);
            // if (!empty($validations)) {
            //     if ($type === 'invoice') {
            //         Invoice::where('verifactu_id', $invoice_id)
            //                 ->update(['needs_validation' => true]);
            //     }
            // }

            return $validations;
            
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }

    public function createNegativeInvoice($company, $invoiceData, $oldInvoice, $method,$correction)
    {
        try{
            $clientId = $company->organization_details->client_id;
            $guid = Str::uuid(); 
            $epoch = floor(microtime(true) * 100); 
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $payload = $this->buildPayload($invoiceData, $company, $oldInvoice, $method,'negative',$correction); 
            // $invoiceData->delete();
            // dd($payload);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            // $validationResponse = $this->checkValidations($company,$response['content']['id'],'invoice');
            // dd($validationResponse);
            return $response;
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }


    public function createReceipt($company,$receiptData)
    {
        try{

            $clientId = $company->organization_details->client_id; // or pass via $request
            // dd($clientId);
            $guid = Str::uuid();
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            
            $payload = $this->buildPayload($receiptData, $company);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            if (isset($response['content']['error']) || 
                (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
                // $receiptData->delete();
                // dd($payload, $response, $response['content']['error'], $response['content']['status'], $response['content']['message']);
                return response()->json([
                    'success' => false,
                    'errors' =>  ($response['content']['message'] ?? 'Bad request'),
                    'message' => __('Validation Failed'),
                    ], 400);
            }
            if (isset($response['content']['compliance']['code']['image']['data'])) {
                $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
                $folderPath = "qrcodes/{$company->company_slug}";
                $fileName = "receipt_{$receiptData->ref_no}.png";
                $filePath = "{$folderPath}/{$fileName}";
                // Make directory and save file
                Storage::disk('public')->makeDirectory($folderPath);
                Storage::disk('public')->put($filePath, base64_decode($qrBase64));

                $receiptData->verifactu_id = $response['content']['id'] ?? null;
                $receiptData->is_verified = 1;
                $receiptData->qr_code = $filePath;
                $receiptData->save();
            }
            
            return $response->json();
        }
        catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }


    
    public function createEnrichmentInvoice($company, $invoiceData, $oldInvoice, $method)
    {
        try{

            $clientId = $company->organization_details->client_id; 
            $guid = Str::uuid(); // Laravel helper
            $epoch = floor(microtime(true) * 100); // Simulating Postman’s /10 trick
            $token = $this->getBearerTokenCompany($company);
        
            if (!$token) {
                return ['error' => 'Authentication failed'];
            }
            $currency = '₹';
            $baseUrl = config('services.fiskaly.base_url'); 
            

            // $invoiceData->delete();
            // ($invoiceData);
            $payload = $this->buildPayload($invoiceData, $company, $oldInvoice, $method);
            $response = Http::withToken($token)
                ->acceptJson()
                ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);
  

            return $response;

            // $response = Http::withToken($token)
            //     ->acceptJson()
            //     ->put("{$baseUrl}/clients/{$clientId}/invoices/{$guid}", $payload);

            // if (isset($response['content']['error']) || 
            //     (isset($response['content']['status']) && $response['content']['status'] >= 400)) {
            //     // dd($payload, $response, $response['content']['error'], $response['content']['status'], $response['content']['message']);
            //     // dd($response, $response['content']['error'], $response['content']['status'], $response['content']['message']);
            //     return response()->json([
            //         'success' => false,
            //         'errors' =>  ($response['content']['message'] ?? 'Bad request'),
            //         'message' => __('Validation Failed'),
            //         ], 400);
            // }

            
            // if (isset($response['content']['compliance']['code']['image']['data'])) {
            //     $qrBase64 = $response['content']['compliance']['code']['image']['data'];
                
            //     // Build path
            //     $folderPath = "qrcodes/{$company->company_slug}";
            //     $fileName = "invoice_{$invoiceData->invoice_id}.png";
            //     $filePath = "{$folderPath}/{$fileName}";

            //     // Make directory and save file
            //     Storage::disk('public')->makeDirectory($folderPath);
            //     Storage::disk('public')->put($filePath, base64_decode($qrBase64));

            //     // Save in extra field
            //     // $invoiceData->extra = array_merge($invoiceData->extra ?? [], [
            //     //     'qr_code' => $filePath,
            //     // ]);

            //     $invoiceData->verifactu_id = $response['content']['id'] ?? null;
            //     $invoiceData->is_verified = 1;
            //     $invoiceData->qr_code = $filePath;
            //     $invoiceData->save();
            // }
            // return $response->json();
        }
        catch (\Exception $e) {
            return [
                'error' => $e->getMessage(),
                'line'  => $e->getLine(),
                'file'  => $e->getFile(),
            ];

        }
    }

    public function buildPayload($invoiceData, $company, $oldInvoice = [], $method = '',$invoiceType = null)
    {
        
        $payload = [];
        $rawGrand = ($invoiceData->grandTotal ?? 0) + ($invoiceData->totalRetencion ?? 0);
        if (blank($oldInvoice)) {
            $grandTotal = normalizePrice(round($rawGrand, 2), 2, 'IN');
        }else{
            $grandTotal = abs(normalizePrice(round($rawGrand, 2), 2, 'IN'));
        }
        
        $type = $invoiceData instanceof \App\Models\Receipts ? 'receipt' : 'invoice';

        // if($invoiceType == 'negative'){
        //     $number = $type === 'receipt'
        //     ? $invoiceData->ref_no ?? $invoiceData->receipt_id
        //     : $invoiceData->invoice_id;
        // }else{
        //     $number = $type === 'receipt'
        //         ? $invoiceData->ref_no ?? $invoiceData->receipt_id
        //         : $invoiceData->ref_no ?? $invoiceData->invoice_id;
        // }


        $number = $type === 'receipt'
                ? $invoiceData->ref_no ?? $invoiceData->receipt_id
                : $invoiceData->ref_no ?? $invoiceData->invoice_id;
        
        $parts = $this->extractPrefixAndNumber($number);
            // ? $invoiceData->ref_no ?? $invoiceData->receipt_id
            // : $invoiceData->invoice_id;

        if ($method==='enrichment') {

            $oldId = is_array($oldInvoice)
                ? ($oldInvoice->verifactu_id ?? null)
                : ($oldInvoice['verifactu_id'] ?? null);
            $payload = [
                    "content" => [
                        "type" => "ENRICHMENT",
                        'id' => $oldId,
                        'number' => $number ,
                        "recipients"=>$this->buildRecipients($invoiceData),
                    ]
                ];
            return $payload;

        // }elseif ($method==='remedy') {

        //     $oldId = is_array($oldInvoice)
        //         ? ($oldInvoice->verifactu_id ?? null)
        //         : ($oldInvoice['verifactu_id'] ?? null);

        //     $payload = [
        //             "content" => [
        //                 "type" => "REMEDY",
        //                 'id' => $oldId,
        //                 "invoice" => [
        //                     "type" => "COMPLETE",
        //                     "data"=>[
        //                             "type" => "SIMPLIFIED",
        //                             'number' => $number ,
        //                             "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
        //                             "full_amount" => (string) $grandTotal,
        //                             "items" => $this->buildInvoiceItemsPayload($invoiceData),
        //                         ],
        //                     "recipients"=>$this->buildRecipients($invoiceData),
        //                 ]
        //             ]
        //         ];


        //     // dd($payload);
        //     return $payload;

        } elseif($grandTotal >= 3000) {
            if (blank($oldInvoice)) {
                $payload = [
                    "content" => [
                        "type" => "COMPLETE",
                        "data"=>[
                            "type" => "SIMPLIFIED",
                            'number' => $number ,
                            "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                            "full_amount" => $grandTotal,
                            "items" => $this->buildInvoiceItemsPayload($invoiceData),
                        ],
                        "recipients"=>$this->buildRecipients($invoiceData),
                    ]
                ];
                return $payload;
            }else{

                if($type == 'receipt'){
                    $alreadyExistsVaryFactu = Receipts::where('ref_invoice_number', $oldInvoice->receipt_id)->orderBy('created_at', 'desc')->skip(1)->first();
                }else{
                    $alreadyExistsVaryFactu = Invoice::where('status', Invoice::NEGATIVE)->where('ref_invoice_number', $oldInvoice->invoice_id)->orderBy('created_at', 'desc')->skip(1)->first();
                }
                log::info('Already exists VaryFactu: ', ['data' => $alreadyExistsVaryFactu->verifactu_id ?? $oldInvoice->verifactu_id ?? 'error']);
                
                $oldId = is_array($oldInvoice)
                    ? ($oldInvoice->verifactu_id ?? null)
                    : ($oldInvoice['verifactu_id'] ?? null);
                $payload = [
                    "content" => [
                        "type"   => "CORRECTING",
                        "id"     => $alreadyExistsVaryFactu->verifactu_id ?? $oldId,
                        "invoice" => [
                            "type" => "COMPLETE",
                            "data"=>[
                                "type" => "SIMPLIFIED",
                                "number"      => $parts['number'],
                                "series"      => $parts['prefix']?? "ER",
                                "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                                "full_amount" => normalizePrice(round($rawGrand, 2), 2, 'IN'),
                                "items" => $this->buildInvoiceItemsPayload($invoiceData),
                            ],
                            "recipients"=>$this->buildRecipients($oldInvoice), 
                            
                        ],
                        "method" => $method,
                        // "code"   => $correction ?? "CORRECTION_1",
                            "code"  => "CORRECTION_4"
                    ]
                ];
                // $invoiceData->delete();
                // dd($payload);
                return $payload;
            }
        } else {
            if (blank($oldInvoice)) {
                $payload = [
                    "content" => [
                        "type" => "SIMPLIFIED",
                        'number' => $number ,
                        "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . 'for regular company.',
                        "full_amount" => $grandTotal,
                        "items" => $this->buildInvoiceItemsPayload($invoiceData),
                    ]
                ];
                return $payload;
            }else{

                if($type == 'receipt'){
                    $alreadyExistsVaryFactu = Receipts::where('ref_invoice_number', $oldInvoice->receipt_id)->orderBy('created_at', 'desc')->skip(1)->first();
                }else{
                    $alreadyExistsVaryFactu = Invoice::where('status', Invoice::NEGATIVE)->where('ref_invoice_number', $oldInvoice->invoice_id)->orderBy('created_at', 'desc')->skip(1)->first();
                }
                log::info('Already exists VaryFactu: ', ['data' => $alreadyExistsVaryFactu->verifactu_id ?? $oldInvoice->verifactu_id ?? 'error']);
                log::info('Old Invoice: ', ['data' => $oldInvoice->receipt_id ?? $oldInvoice->invoice_id ?? 'error']);
                // dd($alreadyExistsVaryFactu);

                $oldId = is_array($oldInvoice)
                    ? ($oldInvoice->verifactu_id ?? null)
                    : ($oldInvoice['verifactu_id'] ?? null);


                if(empty($oldInvoice->client_id) && empty($invoiceData->client_id)) {
                    $payload = [
                        "content" => [
                            "type"   => "CORRECTING",
                            "id"     => $alreadyExistsVaryFactu->verifactu_id ?? $oldId,
                            "invoice" => [
                                "type"        => "SIMPLIFIED",
                                "number"      => $parts['number'],
                                "series"      => $parts['prefix']?? "ER",
                                "issued_at"   => \Carbon\Carbon::parse($invoiceData->issue_date)
                                                    ->format('d-m-Y H:i:s'),
                                "text"        => $invoiceData->extra['note']
                                                ?? __("Created By ") . $company->company_name,
                                "full_amount" =>  normalizePrice(round($rawGrand, 2), 2, 'IN'),
                                "items"       => $this->buildInvoiceItemsPayload($invoiceData),
                            ],
                            "method" => $method ?? "DIFFERENCES",
                            // "code"   => $correction ?? "CORRECTION_1",
                            "code"  => "CORRECTION_4"
                        ]
                    ];
                }else{
                    $payload = [
                        "content" => [
                            "type"   => "CORRECTING",
                            "id"     => $alreadyExistsVaryFactu->verifactu_id ?? $oldId,
                            "invoice" => [
                                "type" => "COMPLETE",
                                "data"=>[
                                    "type" => "SIMPLIFIED",
                                    "number"      => $parts['number'],
                                    "series"      => $parts['prefix']?? "ER",
                                    "text" => $invoiceData->extra['note'] ?? __("Created By ") . $company->company_name . __(" For ") . ($invoiceData->client->extra['company_name'] ?? $invoiceData->client->name),
                                    "full_amount" => normalizePrice(round($rawGrand, 2), 2, 'IN'),
                                    "items" => $this->buildInvoiceItemsPayload($invoiceData),
                                ],
                                "recipients"=>$this->buildRecipients($invoiceData), 
                                
                            ],
                            "method" => $method ?? "DIFFERENCES",
                            // "code"   => $correction ?? "CORRECTION_1",
                            "code"  => "CORRECTION_4"
                        ]
                    ];
                }
                
                return $payload;
            }            
        }
    }


    function buildInvoiceItemsPayload($invoiceData)
    {
        $itemsPayload = [];

        foreach ($invoiceData->items as $item) {
            $price = normalizePrice($item['price'], 2, 'IN');
            $discount = normalizePrice($item['discount'], 2, 'IN');
            $tax = normalizePrice($item['tax'], 2, 'IN');
            $addtax = normalizePrice($item['additionaltax']??0, 2, 'IN');
            $addtaxvalue = normalizePrice($item['additionaltaxvalue']??0, 2, 'IN');
            $quantity = normalizePrice($item['quantity'], 2, 'IN');
            $amount = normalizePrice($item['amount'], 2, 'IN');
            // Adjust discount if not percentage based
            if (isset($item['use_percentage']) && $item['use_percentage'] === "true") {
                // Keep as is (already percentage-based)
            } else {
                $discount = $discount / max($quantity, 1);
            }

            if($amount < 0){
                $quantity = $quantity * -1;
                $quantity = (string)$quantity;
            }


            // Build formatted item payload
            $itemsPayload[] = [
                "text" => $item['name'],
                "quantity" => $quantity,
                "unit_amount" => normalizePrice($price, 2, 'IN'),
                "full_amount" => normalizePrice($amount, 2, 'IN'),
                "discount" => normalizePrice($discount, 2, 'IN'),
                "vat_type" => "IVA",
                "system" => [
                    "type" => "REGULAR",
                    "category" => [
                        "type" => "VAT",
                        "rate" => normalizePrice($tax, 2, 'IN')
                    ]
                ]
            ];
            if ($invoiceData['extraTax']>0) {
                $lastIndex = count($itemsPayload) - 1;
                $itemsPayload[$lastIndex]['system']['category']['additional_vat'] = [
                    "rate" =>  normalizePrice($addtax, 2, 'IN'),
                    "amount" => normalizePrice($addtaxvalue, 2, 'IN'),
                ];
            }
        }

        return $itemsPayload;
    }

    function buildRecipients($invoiceData)
    {
        $address = implode(', ', array_filter([
            $invoiceData->client['extra']['address'] ?? '',
            $invoiceData->client['extra']['locality'] ?? '',
            $invoiceData->client['extra']['state_name'] ?? '',
            $invoiceData->client['extra']['country_name'] ?? ''
        ]));

        $recipients = [
            [
                "id" => [
                    "legal_name" => $invoiceData->client['extra']['company_name'] ?? $invoiceData->client['name'] ,
                    "tax_number" => $invoiceData->client['gst_no'] ?? ''
                ],
                "address_line" => $address??'MADRID',
                "postal_code" => (string) ($invoiceData->client['extra']['zip_code'] ?? '')
            ]
        ];

        return $recipients;
    }
    
    protected function handleVerifactuError($response, $invoiceData)
    {
        $status  = $response['content']['status'] ?? null;
        $error   = $response['content']['error'] ?? null;
        $message = $response['content']['message'] ?? null;

        // Check for API error or HTTP-like error
        if ($error || ($status !== null && $status >= 400)) {

            // Remove locally saved record
            if ($invoiceData) {
                $invoiceData->delete();
            }

            // Debug dump (only in local / debug mode)
            if (app()->environment(['local', 'development'])) {
                dd($response, $error, $status, $message);
            }

            // Return proper JSON error response
            return response()->json([
                'success' => false,
                'errors'  => $message ?? 'Bad request',
                'message' => __('Validation Failed'),
            ], 400);
        }

        // No error → return null (continue normal flow)
        return null;
    }


    public function extractPrefixAndNumber(string $number)
    {
        if (strpos($number, '-') !== false) {
            $pos = strrpos($number, '-');
            return [
                'prefix' => substr($number, 0, $pos + 1),  
                'number' => substr($number, $pos + 1)
            ];
        }

        preg_match('/^([^0-9]+)(\d+)$/', $number, $matches);

        if ($matches) {
            return [
                'prefix' => $matches[1],
                'number' => $matches[2]
            ];
        }

        return [
            'prefix' => $number,
            'number' => ''
        ];
    }


}
