<?php

namespace App\Services;

use App\Services\PrestashopInvoicePdf;
use Illuminate\Http\JsonResponse;
use App\Models\Clients;
use App\Models\Invoice;
use App\Models\InvoicePrefix;
use App\Models\Receipts;
use Illuminate\Support\Arr;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Storage;
use App\Models\Performa;
use App\Models\AutoInvoice;
use App\Models\DeliveryNotes;
use App\Models\TaxRules;


class InvoiceService
{
    protected $lastUsedTaxRule = null;

    public function getLastUsedTaxRule()
    {
        return $this->lastUsedTaxRule;
    }

    public function validateCalculations(array &$formdata, string $type = 'invoice'): array
    {
        // dd($formdata);
        $errors = [];
        $calculatedSubtotal  = 0.0;
        $calculatedTax       = 0.0;
        $calculatedDiscount  = 0.0;
        $calculatedGrand     = 0.0;
        $calculatedExtraTax     = 0.0;

        $firstItemTax = null;
        $firstItemExtra = null;
        // dd($formdata);
        // ✅ Loop through all items
        foreach ($formdata[$type]['items'] as $index => &$item) {
            $amount        = normalizePrice($item['amount'],6,'IN');
            $discount      = isset($item['discount']) ? normalizePrice($item['discount'],6,'IN') : 0;
            $taxPercentage = isset($item['tax_percentage']) ?  normalizePrice($item['tax_percentage'],2,'IN') : 0;
            $additionalTax = isset($item['additionalTax']) ?  normalizePrice($item['additionalTax'],2,'IN') : 0;

            // Convert formatted values
            $qty          = (float) $item['quantity'];
            $priceInput   = normalizePrice($item['price'], 6, 'IN');
            $amountInput  = normalizePrice($item['amount'], 6, 'IN');

            // Expected amount (price * qty) including tax
            $base = ($priceInput * $qty) - $discount;

            $itemExtraTax = $base * ($additionalTax / 100);
            
            $itemTax = $base * ($taxPercentage / 100);

            $expectedAmount = $base + $itemTax;

            if(isset($formdata[$type]['totalAdditionalTax']) && normalizePrice($formdata[$type]['totalAdditionalTax'], 2,'IN') > 0){

                if ($firstItemTax === null) {
                    // Capture the tax of first item
                    $firstItemTax = $taxPercentage;
                    $firstItemExtra = $additionalTax;
    
                    // find valid text rule
                    $rule = TaxRules::where('country','es')
                                    ->where('tax_type','iva')
                                    ->where('value', $firstItemTax)
                                    ->first();
    
                    $this->lastUsedTaxRule = $rule;                
                    // dd($rule);
                    if(!$rule){
                        $errors["{$type}.items.$index.tax_percentage"] = [
                            "Invalid IVA rate: {$firstItemTax}%"
                        ];
                    }
    
                    $requiredExtraTax = $rule->RE_value ?? null;
                }
    
                // Validate same tax for all items
                if ($taxPercentage != $firstItemTax) {
                    $errors["{$type}.items.$index.tax_percentage"] = [
                        "All items must use the same IVA rate ({$firstItemTax}%)."
                    ];
                }
    
                // Validate extra tax only if totalAdditionalTax > 0
                if (!empty($formdata[$type]['totalAdditionalTax']) 
                    && $additionalTax != $requiredExtraTax) {
    
                    $errors["{$type}.items.$index.additionalTax"] = [
                        "Invalid Recargo value. Expected " . normalizePrice($requiredExtraTax) . "% for IVA {$firstItemTax}%, got " . normalizePrice($additionalTax) . "%."
                    ];
                }
            }

            // dd($base, $amountInput, $itemExtraTax, $itemTax, $expectedAmount,$additionalTax);
            if(isset($formdata[$type]['totalAdditionalTax']) && normalizePrice($formdata[$type]['totalAdditionalTax'], 2,'IN') > 0){
                $expectedAmount = $expectedAmount + $itemExtraTax;
            }
                
            

            // $expectedAmount = $expectedAmount + $itemExtraTax;
            // dd($expectedAmount, $amountInput, $priceInput, $qty, $taxPercentage);
            // Compare
            if (round($expectedAmount, 2) !== round($amountInput, 2)) {
                $errors["{$type}.items.$index.amount"] = [
                    "Amount incorrecto. Esperado " . formatValue($expectedAmount, '€') .
                    " según la cantidad y el impuesto."
                ];
            }

            
            

            // dd((float) $amount);
            // Base price without tax (tax included in amount)
            $basePrice = $priceInput;
            // $taxAmount = $expectedAmount - $basePrice;
            $taxAmount = $itemTax;
            $defPrice = $basePrice + $discount;
            
            // Totals
            $calculatedSubtotal += $basePrice * $qty;
            $calculatedTax += $taxAmount;
            $calculatedDiscount += $discount;
            $calculatedGrand += $expectedAmount;
            $calculatedExtraTax += $itemExtraTax;

            // dd($calculatedSubtotal, $calculatedTax, $calculatedDiscount);

            // Update formatted item values back
            // $item['price']     = normalizePrice($defPrice,2);
            $item['price']     = normalizePrice($item['price'], 2);
            $item['discount']  = normalizePrice($discount,2);
            $item['taxamount'] = normalizePrice($calculatedTax,2);
            $item['amount']    = normalizePrice($amount);
            

            if(isset($formdata[$type]['totalAdditionalTax']) && normalizePrice($formdata[$type]['totalAdditionalTax'], 2,'IN') > 0){
                $item['additionaltaxvalue']    = normalizePrice($itemExtraTax,2,'IN');
                $item['additionaltax']    = $additionalTax;
            }
            
        }
        unset($item);

        $formdata[$type]['items'] = array_values($formdata[$type]['items']);

        // $calculatedGrand = $calculatedSubtotal + $calculatedTax;
        // dd($calculatedSubtotal,$calculatedTax,$calculatedGrand);
        $providedSubtotal   = normalizePrice($formdata[$type]['subtotal'], 2,'IN');
        $providedTax        = normalizePrice($formdata[$type]['totalTax'], 2,'IN');
        $providedDiscount        = normalizePrice($formdata[$type]['totalDiscount'] ?? 0, 2,'IN');
        $providedGrandTotal = normalizePrice($formdata[$type]['grandTotal'], 2,'IN');
        $providedExtraTax = normalizePrice($formdata[$type]['totalAdditionalTax'] ?? 0, 2,'IN');

        // ✅ Compare and build errors
        if (round($calculatedSubtotal, 2) !== round($providedSubtotal, 2)) {
            $errors["{$type}.subtotal"] = [
                "Desajuste del subtotal: esperado " . formatValue($calculatedSubtotal, '€') . ", consiguió " . formatValue($providedSubtotal, '€')
            ];
        }

        if (round($calculatedDiscount, 2) !== round($providedDiscount, 2)) {
            $errors["{$type}.totalDiscount"] = [
                "Discrepancia total en los impuestos: esperado " . formatValue($calculatedDiscount, '€') . ", consiguió " . formatValue($providedDiscount, '€')
            ];
        }

        if (round($calculatedTax, 2) !== round($providedTax, 2)) {
            $errors["{$type}.totalTax"] = [
                "Discrepancia total en los impuestos: esperado " . formatValue($calculatedTax, '€') . ", consiguió " . formatValue($providedTax, '€')
            ];
        }

        
        if (isset($formdata[$type]['totalAdditionalTax']) && normalizePrice($formdata[$type]['totalAdditionalTax'], 2,'IN') > 0 && round($calculatedExtraTax, 2) !== round($providedExtraTax, 2)) {
            $errors["{$type}.totalAdditionalTax"] = [
                "Discrepancia total en los impuestos: esperado " . formatValue($calculatedExtraTax, '€') . ", consiguió " . formatValue($providedExtraTax, '€')
            ];
        }

        if (round($calculatedGrand, 2) !== round($providedGrandTotal,2)) {
            $errors["{$type}.grandTotal"] = [
                "Desajuste fiscal total: esperado " . formatValue($calculatedGrand, '€') . ", consiguió " . formatValue($providedGrandTotal, '€')
            ];
        }


        // 💰 Threshold checks — dynamic for both invoice and receipt
        if (in_array($type, ['invoice', 'receipt', 'standard', 'over_3000'])) {

            // If standard type and grand total > 3000
            if ($type === 'standard' && round($calculatedGrand, 2) > 3000) {
                $errors["{$type}.threshold"] = [
                   "Para {$type}s superiores a 3000€, utilice /verifactu/{$type}-3000"
                ];
            }

            // If over_3000 type but total <= 3000
            if ($type === 'over_3000' && round($calculatedGrand, 2) <= 3000) {
                $errors["{$type}.threshold"] = [
                    "Para {$type}s iguales o inferiores a 3000 €, utilice /verifactu/{$type}"
                ];
            }

            // If negative grand total
            if (round($calculatedGrand, 2) < 0) {
                $errors["{$type}.negative"] = [
                    $type === 'receipt'
                        ? "Para recibos negativos, utilice la API /verifactu/receipt-negative"
                        : "Para facturas negativas, utilice la API /verifactu/invoice-negative"
                ];
            }
        }
       
        return $errors;
    }

    public function generateInvoiceId($issue_date, $company, $type = 'invoice', $prefix = null)
    {
        try {
            $year = date('Y', strtotime($issue_date));
            
            $invoicePrefix = InvoicePrefix::where('status', true)->first();
            $invoicePrefixArray = !empty($invoicePrefix) ? explode('-', $invoicePrefix->prefix) : null;
            // dd($invoicePrefixArray);
            $invoicePrefixInitial = $invoicePrefixArray[0] ?? $typeMap[strtolower($type)] ?? null;

            $companyInitials = $invoicePrefixInitial
                ?? strtoupper(substr($company->company_name ?? 'AB', 0, 2));

            $prefix = !empty($prefix) ? explode('-', $prefix) : null;
            
            $typeMap = [
                'invoice' => $companyInitials,
                'negative-invoice' => 'RE',
                'performa'=>'PRE',
                'auto-invoice'=>'AU',
                'delivery-note'=>'ALB',
                'ticket' => 'TK',
                'negative-ticket' => 'REC',
                'enrichment' => 'ER',
            ];

            $suffix = $prefix[0] ?? $typeMap[strtolower($type)] ?? 'AB';

            // dd($suffix);
            if($type == 'invoice'){
                $currentYear = date('Y');

                if (strpos($suffix, 'YYYY') !== false) {
                    $suffix = str_replace('YYYY', $currentYear, $suffix);
                }

                $pattern = "{$suffix}-%";
                // dd($pattern);
            }else{
                $pattern = "{$year}{$suffix}-%";
            }


            if($type == 'ticket' || $type == 'negative-ticket'){
                 $latestNumber = Receipts::where('receipt_id', 'LIKE', $pattern)
                    ->selectRaw("MAX(CAST(SUBSTRING_INDEX(receipt_id, '-', -1) AS UNSIGNED)) as max_number")
                    ->value('max_number');
            }elseif($type == 'performa'){
                $latestNumber = Performa::where('performa_id', 'LIKE', $pattern)
                    ->selectRaw("MAX(CAST(SUBSTRING_INDEX(performa_id, '-', -1) AS UNSIGNED)) as max_number")
                    ->value('max_number');   
            }elseif($type == 'auto-invoice'){
                $latestNumber = AutoInvoice::where('invoice_id', 'LIKE', $pattern)
                    ->selectRaw("MAX(CAST(SUBSTRING_INDEX(invoice_id, '-', -1) AS UNSIGNED)) as max_number")
                    ->value('max_number');   
            }elseif($type == 'delivery-note'){
                $latestNumber = DeliveryNotes::where('delivery_note_id', 'LIKE', $pattern)
                    ->selectRaw("MAX(CAST(SUBSTRING_INDEX(delivery_note_id, '-', -1) AS UNSIGNED)) as max_number")
                    ->value('max_number');   
            }else{
                 $latestNumber = Invoice::where('invoice_id', 'LIKE', $pattern)
                    ->selectRaw("MAX(CAST(SUBSTRING_INDEX(invoice_id, '-', -1) AS UNSIGNED)) as max_number")
                    ->value('max_number');

                if (empty($latestNumber) || $latestNumber == 0) {
                    if (!empty($prefix[1])) {
                        $latestNumber = $prefix[1];
                    } elseif (!empty($invoicePrefix?->series)) {
                        $latestNumber = $invoicePrefix->series;
                    } else {
                        $latestNumber = 0;
                    }
                }
                // if ($type === 'invoice' && !empty($prefix) && ($latestNumber ?? 0) == 0) {
                //     $latestNumber = $prefix[1] ?? 0;
                // } else {
                //     $latestNumber = Invoice::where('invoice_id', 'LIKE', $pattern)
                //         ->selectRaw("MAX(CAST(SUBSTRING_INDEX(invoice_id, '-', -1) AS UNSIGNED)) as max_number")
                //         ->value('max_number')
                //         ?? $invoicePrefix['series']
                //         ?? 0;
                // }
            }
           
            $nextNumber = $latestNumber ? $latestNumber + 1 : 1;

            // dd(sprintf('%s%s-%04d', $year, $suffix, $nextNumber));
            if($type == 'invoice'){
                return sprintf('%s-%04d', $suffix, $nextNumber);
            }else{
                return sprintf('%s%s-%04d', $year, $suffix, $nextNumber);
            }

        } catch (\Exception $e) {
            throw new \Exception('Failed to generate invoice/ticket ID: ' . $e->getMessage());
        }
    }

    public function invoiceItems(array &$items): array
    {
        $normalized = [];

        foreach ($items as $index => $item) {
            // Convert values to clean numeric floats

            // $priceInput    = normalizePrice($item['price'] ?? 0, 6, 'IN');
            // $amount        = normalizePrice($item['amount'] ?? 0, 6, 'IN');
            // $discount      = normalizePrice($item['discount'] ?? 0, 6, 'IN');
            // $quantity      = normalizePrice($item['quantity'] ?? 1, 0, 'IN');
            // $taxPercentage = isset($item['tax_percentage']) ? (float)$item['tax_percentage'] : 0;

            // $basePrice = $amount / (1 + ($taxPercentage / 100));
            // $taxAmount = $amount - $basePrice;
            // $unitPrice = $basePrice + $discount;

            $normalized[$index] = [
                'name'                  => $item['name'] ?? '',
                'quantity'              => $item['quantity'] ?? '0',
                'price'                 => normalizePrice($item['price'], 2, 'IN'),
                'discount'              => normalizePrice($item['discount']??0, 2, 'IN'),
                'use_percentage'        => filter_var($item['use_percentage'] ?? false, FILTER_VALIDATE_BOOLEAN),
                'tax'                   => isset($item['tax_percentage']) ? (float)$item['tax_percentage'] : 0,
                'tax_percentage'        => isset($item['tax_percentage']) ? (float)$item['tax_percentage'] : 0,
                'taxamount'             => normalizePrice($item['tax_percentage'] ?? 0, 2, 'IN'),
                'amount'                => normalizePrice($item['amount'], 2, 'IN'),
                'use_tax_percentage'    => true,
                'tax_type'              => "percentage",
                'additionaltax'         => isset($item['additionaltax']) ? (float)$item['additionaltax'] : 0,
                'additionaltaxvalue'    => isset($item['additionaltaxvalue']) ? (float)$item['additionaltaxvalue'] : 0,
            ];

            if(isset($item['is_shipping']) && !empty($item['is_shipping'])){
                $normalized[$index]['is_shipping'] = $item['is_shipping'];
            }
        }
        return $normalized;
    }


    public function getEnrichmentItems($receipt, $company, $client, $formdata)
    {
        $final = [];
        $invoiceData = [];
        $positiveItems = $receipt->items;
        // $negativeTicket = Receipts::where('reference_id', $receipt->id)->first();
        // if(!empty($negativeTicket)){
        //     $invoiceData['method'] = 'remedy';
        //      $negativeItems = $negativeTicket ? $negativeTicket->items : [];

        //     $negMap = [];
        //     foreach ($negativeItems as $neg) {
        //         $key = $neg['name'] . '-' .  normalizePrice($neg['price'], 6, 'IN'). '-' . normalizePrice($neg['tax'],2,'IN');
        //         $negQty = abs((float)$neg['quantity']);
        //         $negMap[$key] = ($negMap[$key] ?? 0) + $negQty;
        //     }

        //     // Process positive items
        //     foreach ($positiveItems as $item) {
        //         $key = $item['name'] . '-' .  normalizePrice($item['price'], 6, 'IN'). '-' . normalizePrice($item['tax'],2,'IN');
        //         $posQty = (float)$item['quantity'];
        //         if (!isset($negMap[$key])) {
        //             $final[] = $item;
        //             continue;
        //         }

        //         $remainingQty = $posQty - $negMap[$key];

        //        if ($remainingQty > 0) {
        //             $item['quantity'] = $remainingQty;

        //             $price = (float) $item['price'];
        //             $taxPercent = null;
        //             if (isset($item['tax_percentage'])) {
        //                 $taxPercent = (float) $item['tax_percentage'];
        //             } elseif (isset($item['tax']) && (float)$item['tax'] > 0 && (float)$item['tax'] <= 100) {
        //                 $taxPercent = (float) $item['tax'];
        //             } else {
        //                 $taxPercent = 0;
        //             }

        //             $lineSubtotal = $remainingQty * $price;
        //             $taxAmount = $lineSubtotal * ($taxPercent / 100);
        //             $lineTotal = $lineSubtotal + $taxAmount;
        //             $item['price']      = $price;
        //             $item['amount']     = $lineTotal;
        //             $item['taxamount']  = $taxAmount;
        //             $item['tax']        = $taxPercent;
        //             $item['tax_percentage'] = $taxPercent;

        //             $final[] = $item;
        //         }

        //         unset($negMap[$key]);
        //     } 


        // } else {
        //     $final = $this->invoiceItems($positiveItems);
        // }

        $final = $this->invoiceItems($positiveItems);

        $subtotal = 0;
        $totalTax = 0;
        $totalDiscount = 0;
        $grandTotal = 0;

        foreach ($final as $item) {

            $price = (float)$item['price'];
            $qty   = (float)$item['quantity'];
            $lineSubtotal = $qty * $price;

            // Tax
            $taxPercent = isset($item['tax_percentage']) ? (float)$item['tax_percentage'] : 0;
            $lineTax    = $lineSubtotal * ($taxPercent / 100);

            // Add to totals
            $subtotal   += $lineSubtotal;
            $totalTax   += $lineTax;
            $grandTotal += ($lineSubtotal + $lineTax);
        }

        $invoiceData['reference_id'] = $receipt->receipt_id;
        $invoiceData['ref_no'] = $formdata['invoice_number'] ?? null;
        // $invoiceData['invoice_id'] = $formdata['invoice_number'] ?? $this->generateInvoiceId(now(), $company, 'enrichment');
        $invoiceData['invoice_id'] = $this->generateInvoiceId(now(), $company, 'enrichment');
        $invoiceData['issue_date'] = now();
        $invoiceData['due_date'] = now();
        $invoiceData['items'] = $final;
        $invoiceData['subtotal']      = normalizePrice($subtotal, 2, 'IN');
        $invoiceData['totalDiscount'] = normalizePrice($totalDiscount, 2, 'IN');
        $invoiceData['totalTax']      = normalizePrice($totalTax, 2, 'IN');
        $invoiceData['grandTotal']    = normalizePrice($grandTotal, 2, 'IN');
        $invoiceData['client_id'] = $client->id;
        $invoiceData['extra'] = ['note' => $receipt->extra['note']??''];
        $invoiceData['invoice_type'] = 1;
        $invoiceData['status'] = 2;
        $invoiceData['is_verified'] = 0;
        $invoiceData['created_by'] = $company->admin_id;

        return $invoiceData;
    }

    public function invoiceItemsOLD(array &$items): array
    {
        $normalized = [];

        foreach ($items as $index => $item) {
            // Convert values to clean numeric floats

            $priceInput    = normalizePrice($item['price'] ?? 0, 6, 'IN');
            $amount        = normalizePrice($item['amount'] ?? 0, 6, 'IN');
            $discount      = normalizePrice($item['discount'] ?? 0, 6, 'IN');
            $quantity      = normalizePrice($item['quantity'] ?? 1, 0, 'IN');
            $taxPercentage = isset($item['tax_percentage']) ? (float)$item['tax_percentage'] : 0;

            // dd($item);
            // ✔ Price sent from frontend may not be correct → recalculate based ONLY on amount
            // price = (base price + discount)
            // base price = amount / (1 + tax%)
            $basePrice = $amount / (1 + ($taxPercentage / 100));
            $taxAmount = $amount - $basePrice;
            $unitPrice = $basePrice + $discount;

            // Build normalized item
            $normalized[$index] = [
                'name'                  => $item['name'] ?? '',
                'quantity'              => (string)$quantity,
                'price'                 => normalizePrice($item['price'], 6, 'IN'),
                'discount'              => normalizePrice($discount, 2, 'IN'),
                'tax'                   => $taxPercentage,
                'tax_percentage'                   => $taxPercentage,
                'taxamount'             => normalizePrice($taxAmount, 2, 'IN'),
                'amount'                => normalizePrice($amount, 2, 'IN'),
                'use_tax_percentage'    => true,
                'tax_type'              => "percentage",
            ];
        }
        return $normalized;
    }

    public function validateWithOriginalWorking($originalInvoice, array $newInvoiceData, $type = 'invoice'): bool
    {
        $previousNegatives = Invoice::where('status', Invoice::NEGATIVE_INVOICE)
            ->where('ref_invoice_number', $originalInvoice->invoice_id)
            ->get();

        if ($type === 'receipt') {
            if ((float)$originalInvoice->totalDiscount < (float)$newInvoiceData['totalDiscount']) {
                throw ValidationException::withMessages([
                    'receipt' => [__('Your discount is higher than the original receipt.')],
                ]);
            }
        } else {
            if ((float)$originalInvoice->totalDiscount < (float)$newInvoiceData['totalDiscount']) {
                throw ValidationException::withMessages([
                    'invoice' => [__('Your discount is higher than the original invoice.')],
                ]);
            }
        }
        

        if ($method === "DIFFERENCES") {
            $newItems = $newInvoiceData['items'] ?? [];
            $originalItems = $originalInvoice->items;
            $originalNames  = collect($originalItems)->pluck('name')->map('trim')->toArray();

            $alreadyReduced = [];


            foreach ($previousNegatives as $negInv) {
                foreach ($negInv->items as $negItem) {

                    // Items stored as arrays → use array syntax
                    $name = trim($negItem['name'] ?? '');
                    $qty  = abs((float)(abs($negItem['quantity'] ?? 0)));

                    if ($name === '') {
                        continue; // skip invalid row
                    }

                    if (!isset($alreadyReduced[$name])) {
                        $alreadyReduced[$name] = 0;
                    }

                    $alreadyReduced[$name] += $qty;
                }
            }

            foreach ($newItems as $index => $newItem) {
                $name = trim($newItem['name']);

                if (!in_array($name, $originalNames)) {
                    throw ValidationException::withMessages([
                        "invoice.items.$index" => [__("Item '{$name}' is not part of the original invoice.")],
                    ]);
                }

                $originalItem = collect($originalItems)->firstWhere('name', $name);
                $originalQty = (float) $originalItem['quantity'];
                $newQty      = abs((float) ($newItem['quantity'] ?? 0));

                $reducedQty  = $alreadyReduced[$name] ?? 0;

                $remaining = $originalQty - $reducedQty;

                if ($newQty > $remaining) {
                    throw ValidationException::withMessages([
                        "invoice.items.$index" => [
                            __("You cannot reduce quantity more than available. Original: :orig, Already reduced: :used, Remaining: :rem, Attempted: :new", [
                                'orig' => $originalQty,
                                'used' => $reducedQty,
                                'rem'  => $remaining,
                                'new'  => $newQty
                            ])
                        ],
                    ]);
                }

                $differences = $this->compareItemDifferences($originalItem, $newItem, $index, $newInvoiceData['method']);
                if (!empty($differences)) {
                    throw ValidationException::withMessages([
                        $type === 'receipt' ? "receipt.items.$index" : "invoice.items.$index" => $differences,
                    ]);
                }
            }
        }

        return true;
    }

    public function validateWithOriginal1($originalInvoice, array $newInvoiceData, $type = 'invoice'): bool
    {
        // 1️⃣ Get all previous negative invoices for this original invoice
        $previousNegatives = Invoice::where('status', Invoice::NEGATIVE_INVOICE)
            ->where('ref_invoice_number', $originalInvoice->invoice_id)
            ->get();

        $newTotalDiscount = (float) ($newInvoiceData['totalDiscount'] ?? 0);

        if ($type === 'receipt') {
            if ((float) $originalInvoice->totalDiscount < $newTotalDiscount) {
                throw ValidationException::withMessages([
                    'receipt' => [__('Your discount is higher than the original receipt.')],
                ]);
            }
        } else {
            if ((float) $originalInvoice->totalDiscount < $newTotalDiscount) {
                throw ValidationException::withMessages([
                    'invoice' => [__('Your discount is higher than the original invoice.')],
                ]);
            }
        }

        $method = $newInvoiceData['method'] ?? 'DIFFERENCES';

        $newItems      = $newInvoiceData['items'] ?? [];
        $originalItems = $originalInvoice->items ?? [];

        if (empty($newItems)) {
            return true; 
        }

        $originalNames = collect($originalItems)
            ->pluck('name')
            ->map(fn ($n) => trim($n))
            ->toArray();

        $alreadyReduced = [];

        if ($method === 'DIFFERENCES') {
            foreach ($previousNegatives as $negInvoice) {
                foreach ($negInvoice->items as $negItem) {
                    $name = trim($negItem['name'] ?? '');
                    $qty  = abs((float) ($negItem['quantity'] ?? 0));

                    if ($name === '') {
                        continue;
                    }

                    $alreadyReduced[$name] = ($alreadyReduced[$name] ?? 0) + $qty;
                }
            }
        }

        foreach ($newItems as $index => $newItem) {

            $name = trim($newItem['name'] ?? '');

            if ($name === '') {
                throw ValidationException::withMessages([
                    "invoice.items.$index" => [__('Item name is required.')],
                ]);
            }

            if (!in_array($name, $originalNames, true)) {
                throw ValidationException::withMessages([
                    "invoice.items.$index" => [
                        __("Item '{$name}' is not part of the original invoice.")
                    ],
                ]);
            }

            $originalItem = collect($originalItems)->firstWhere('name', $name);

            if (!$originalItem) {
                throw ValidationException::withMessages([
                    "invoice.items.$index" => [__("Original item '{$name}' not found.")],
                ]);
            }

            $originalQty = (float) ($originalItem['quantity'] ?? 0);
            $newQty      = abs((float) ($newItem['quantity'] ?? 0));

            if ($method === 'DIFFERENCES') {
                $reducedQty = $alreadyReduced[$name] ?? 0;
                $remaining  = $originalQty - $reducedQty;

                if ($newQty > $remaining) {
                    throw ValidationException::withMessages([
                        "invoice.items.$index" => [
                            __("You cannot reduce quantity more than available. Original: :orig, Already reduced: :used, Remaining: :rem, Attempted: :new", [
                                'orig' => $originalQty,
                                'used' => $reducedQty,
                                'rem'  => $remaining,
                                'new'  => $newQty,
                            ])
                        ],
                    ]);
                }
            }

           
            $differences = $this->compareItemDifferences(
                $originalItem,
                $newItem,
                $index,
                $method
            );

            if (!empty($differences)) {
                throw ValidationException::withMessages([
                    $type === 'receipt'
                        ? "receipt.items.$index"
                        : "invoice.items.$index" => $differences,
                ]);
            }
        }

        return true;
    }

    public function validateWithOriginal($originalInvoice, array $newInvoiceData, $type = 'invoice'): bool
    {
        /**
         * 1️⃣ Fetch all previous negative invoices linked to this original invoice
         */

        if($type == 'receipt'){
            $previousNegatives = Receipts::where('ref_invoice_number', $originalInvoice->receipt_id)
            ->get();
        }else{
            $previousNegatives = Invoice::where('status', Invoice::NEGATIVE_INVOICE)
            ->where('ref_invoice_number', $originalInvoice->invoice_id)
            ->get();
        }
        

        /**
         * 2️⃣ Validate total discount
         */
        // $newTotalDiscount = (float) ($newInvoiceData['totalDiscount'] ?? 0);
        $newTotalDiscount =
        (float) ($newInvoiceData[$type]['totalDiscount']
        ?? $newInvoiceData['totalDiscount']
        ?? 0);


        if ((float) $originalInvoice->totalDiscount < $newTotalDiscount) {
            throw ValidationException::withMessages([
                $type => [
                    $type === 'receipt'
                        ? __('Your discount is higher than the original receipt.')
                        : __('Your discount is higher than the original invoice.')
                ],
            ]);
        }

        /**
         * 3️⃣ Resolve correction method
         */
        $method = $newInvoiceData['method'] ?? 'DIFFERENCES';

        /**
         * 4️⃣ Resolve items
         */
        $newItems      = $newInvoiceData[$type]['items'] ?? $newInvoiceData['items'] ?? [];
        $originalItems = $originalInvoice->items ?? [];

        if (empty($newItems)) {
            return true; // nothing to validate
        }

        $originalNames = collect($originalItems)
            ->pluck('name')
            ->map(fn ($n) => trim($n))
            ->toArray();

        /**
         * 5️⃣ Calculate cumulative reductions & increases
         */
        $alreadyReduced   = [];
        $alreadyIncreased = [];

        foreach ($previousNegatives as $negInvoice) {
            $negMethod = $negInvoice->method ?? 'DIFFERENCES';

            foreach ($negInvoice->items as $negItem) {
                $name = trim($negItem['name'] ?? '');
                $qty  = (float) ($negItem['quantity'] ?? 0);
                

                if ($name === '') {
                    continue;
                }

                if ($qty > 0) {
                    $alreadyIncreased[$name] = ($alreadyIncreased[$name] ?? 0) + $qty;
                } elseif ($qty < 0) {
                    $alreadyReduced[$name] = ($alreadyReduced[$name] ?? 0) + abs($qty);
                }
            }
        }

        /**
         * 6️⃣ Validate each item
         */
        foreach ($newItems as $index => $newItem) {

            $name = trim($newItem['name'] ?? '');

            if ($name === '') {
                throw ValidationException::withMessages([
                    "{$type}.items.$index" => [__('Item name is required.')],
                ]);
            }

            /**
             * Item must exist in original invoice (both methods)
             */
            if (!in_array($name, $originalNames, true)) {
                throw ValidationException::withMessages([
                    "{$type}.items.$index" => [
                        __("Item '{$name}' is not part of the original invoice.")
                    ],
                ]);
            }

            $originalItem = collect($originalItems)->firstWhere('name', $name);

            if (!$originalItem) {
                throw ValidationException::withMessages([
                    "{$type}.items.$index" => [
                        __("Original item '{$name}' not found.")
                    ],
                ]);
            }

            $originalQty = (float) ($originalItem['quantity'] ?? 0);
            $newQty      = abs((float) ($newItem['quantity'] ?? 0));

            $reducedQty   = $alreadyReduced[$name]   ?? 0;
            $increasedQty = $alreadyIncreased[$name] ?? 0;

            /**
             * Real available quantity
             */
            $availableQty = $originalQty + $increasedQty - $reducedQty;
            // dd($originalQty, $increasedQty, $reducedQty, $availableQty, $newQty);
            /**
             * 7️⃣ DIFFERENCES → quantity restriction applies
             */
            // dd($method);
            if ($method == 'DIFFERENCES') {

                if ($newQty > $availableQty) {
                    throw ValidationException::withMessages([
                        "{$type}.items.$index" => [
                            __(
                                "You cannot reduce quantity more than available. Original: :orig, Increased: :inc, Reduced: :red, Available: :avail, Attempted: :new",
                                [
                                    'orig'  => $originalQty,
                                    'inc'   => $increasedQty,
                                    'red'   => $reducedQty,
                                    'avail' => $availableQty,
                                    'new'   => $newQty,
                                ]
                            )
                        ],
                    ]);
                }
            }

            /**
             * 8️⃣ SUBSTITUTION → quantity increase allowed (no limit)
             */

            /**
             * 9️⃣ Validate price/tax/discount differences
             */
            $differences = $this->compareItemDifferences(
                $originalItem,
                $newItem,
                $index,
                $method
            );

            if (!empty($differences)) {
                throw ValidationException::withMessages([
                    "{$type}.items.$index" => $differences,
                ]);
            }
        }

        return true;
    }


    protected function compareItemDifferences(array $oldItem, array $newItem, int $index, $method = "DIFFERENCES"): array
    {
        $errors = [];
        // Compare name
        if (trim($oldItem['name']) !== trim($newItem['name'])) {
            $errors[] = "Item #{$index}: Name mismatch expected '{$oldItem['name']}', got '{$newItem['name']}'.";
        }

        // Compare price
        if (normalizePrice($oldItem['price']) != normalizePrice($newItem['price'])) {
            $errors[] = "Item #{$index}: Price mismatch expected {$oldItem['price']}, got {$newItem['price']}.";
        }


        $oldQty = floatval($oldItem['quantity']);
        $newQty = floatval($newItem['quantity']);

        if ($method === "DIFFERENCES") {

            // In difference mode, user must NOT increase quantity above original.
            if ($newQty > $oldQty) {
                $errors["items.$index.quantity"] = [
                    "Item #{$index}: Quantity cannot be increased in DIFFERENCES mode. Max allowed is {$oldQty}."
                ];
            }

        } else { // SUBSTITUTION

            // In substitution mode, quantity must be positive.
            if ($newQty < 1) {
                $errors["items.$index.quantity"] = [
                    "Item #{$index}: Quantity must be at least 1 in SUBSTITUTION mode."
                ];
            }
        }

        // -------------------------------
        // 4. TAX CHECK
        // -------------------------------
        if ($oldItem['tax'] != $newItem['tax_percentage']) {
            $errors["items.$index.tax_percentage"] = [
                "Item #{$index}: Tax rate mismatch. Expected {$oldItem['tax']}, got {$newItem['tax_percentage']}."
            ];
        }
        // dd($oldItem, $newItem);
        if(isset($oldItem['additionaltax']) && normalizePrice($oldItem['additionaltax'], 2, 'IN') > 0){
            
            if(!isset($newItem['additionaltax'])){
                $errors["items.$index.additionalTax"] = [
                    "Item #{$index}: Additional Tax rate missing in new item."
                ];
            }else{
                if (normalizePrice($oldItem['additionaltax']) != normalizePrice($newItem['additionaltax'])) {
                    $errors["items.$index.additionalTax"] = [
                        "Item #{$index}: Additional Tax rate mismatch. Expected " . normalizePrice($oldItem['additionaltax']) .", got {$newItem['additionaltax']}."
                    ];
                }
            }
            

            // if ($oldItem['additionaltax'] != $newItem['additionaltax']) {
            //     $errors["items.$index.additionaltax"] = [
            //         "Item #{$index}: Additional Tax rate mismatch. Expected {$oldItem['additionaltax']}, got {$newItem['additionaltax']}."
            //     ];
            // }
        }
        
        if(!isset($oldItem['additionaltax']) || normalizePrice($oldItem['additionaltax'], 2, 'IN') == 0){
            if(isset($newItem['additionalTax']) && normalizePrice($newItem['additionalTax'], 2, 'IN') > 0){
                $errors["items.$index.additionalTax"] = [
                    "Item #{$index}: You can't provide additonal tax on this item as additional tax not provide in old invoice."
                ];
            }
        }

        // dd($oldItem, $newItem);

        if(isset($newItem['discount'])){
            $discount = normalizePrice($oldItem['discount'], 2, 'IN');
            if(isset($oldItem['use_percentage']) && $oldItem['use_percentage']=="true"){
                $discount = $discount * $oldItem['quantity'];

            }
            // $discount = normalizePrice($discount);
            $formattedDiscount = normalizePrice($oldItem['discount']);

            // dd($discount, normalizePrice($newItem['discount'], 2, 'IN'));
            if ($discount < normalizePrice($newItem['discount'], 2, 'IN')) {
                $errors["items.$index.discount"] = [
                    "Item #{$index}: Discount mismatch. Expected {$formattedDiscount}, got {$newItem['discount']}."
                ];
            }
        }

        return $errors;
    }

  

    public function validateWithOriginalOLD( $originalInvoice, array $newInvoiceData, $type = 'invoice'): bool
    {

        $invoices = Invoice::where('status', Invoice::NEGATIVE_INVOICE)->where('ref_invoice_number', $originalInvoice->invoice_id)->get();


        if($type == 'receipt'){
            if (((float) $originalInvoice->totalDiscount) < ((float) $newInvoiceData['totalDiscount'])) {
                throw ValidationException::withMessages([
                    'receipt' => [__('Your discount is higher than the original receipt.')],
                ]);
            }

        }else{

            if (((float) $originalInvoice->totalDiscount )< ((float) $newInvoiceData['totalDiscount'])) {
                throw ValidationException::withMessages([
                    'invoice' => [__('Your discount is higher than the original invoice.')],
                ]);
            }
        }



        $method = $newInvoiceData['method'];

        // dd($newInvoiceData, $method);
        // 2️⃣ Compare items
        $originalItems = $originalInvoice->items; // assuming relation: $invoice->items()
        $oldItems = $originalItems;
        if($type == 'receipt'){
            $newItems = Arr::get($newInvoiceData, 'receipt.items', []);
        }else{
            $newItems = Arr::get($newInvoiceData, 'invoice.items', []);
        }

        $oldNames = collect($oldItems)->pluck('name')->map('trim')->toArray();
        foreach ($newItems as $index => $newItem) {
            // $oldItem = $originalItems[$index] ?? null;

            // if (!$oldItem) {
                // throw ValidationException::withMessages([
                //     'invoice.items' => ["Item #{$index} not found in the original invoice."],
                // ]);
            // }

            $newName = trim($newItem['name']);

            if (!in_array($newName, $oldNames)) {
                throw ValidationException::withMessages([
                    'invoice.items' => ["Item #{$newName} not found in the original invoice."],
                ]);
            }

            $oldItem = collect($oldItems)->firstWhere('name', $newName);
            $differences = $this->compareItemDifferences($oldItem, $newItem, $index, $method);

            if (!empty($differences)) {
                if($type == 'receipt'){
                    throw ValidationException::withMessages([
                        "receipt.items.$index" => $differences,
                    ]);
                }else{
                    throw ValidationException::withMessages([
                        "invoice.items.$index" => $differences,
                    ]);
                }
            }

            // if (!$this->itemsMatch($oldItem, $newItem)) {
            //     throw ValidationException::withMessages([
            //         'invoice.items' => ["Item #{$index} does not match the original invoice data."],
            //     ]);
            // }
        }

        return true;
    }
 


    function generateCorrectedInvoice(array $invoice, string $method = 'DIFFERENCES', $type = 'invoice')
    {
        $items = $invoice['items'];

        $newItems = [];
        $subtotal = 0;
        $totalDiscount = 0;
        $totalTax = 0;
        $totalExtraTax = 0;

        
        $useAdditionalTax = isset($invoice['extraTax']) && is_numeric($invoice['extraTax'])
                        ? floatval($invoice['extraTax']) != 0  
                        : filter_var($invoice['extraTax'] ?? 0, FILTER_VALIDATE_BOOLEAN);
        // $useAdditionalTax = filter_var($invoice['extraTax'] ?? false, FILTER_VALIDATE_BOOLEAN);
        
        // dd($useAdditionalTax, $invoice);



        foreach ($items as $item) {
            $qty  = normalizePrice($item['quantity'], 0, 'IN');
            $price = normalizePrice($item['price'], 6, 'IN');
            $discount = normalizePrice($item['discount'], 2, 'IN'); // ALWAYS POSITIVE
            $taxPercent = normalizePrice($item['tax_percentage'], 2, 'IN');
            $usePercent = filter_var($item['use_percentage'] ?? false, FILTER_VALIDATE_BOOLEAN);
            $additionalTaxPercent = normalizePrice($item['additionaltax'] ?? 0, 2, 'IN');

            if ($method === 'DIFFERENCES') {
                $qty = $qty * -1;
            }

            $rowSubtotal = $qty * $price;

            $rowDiscount = $usePercent
                ? ($rowSubtotal * $discount) / 100
                : $discount;
           

            $rowBase = $rowSubtotal - $rowDiscount;

            $rowTax = ($rowBase * $taxPercent) / 100;
            $rowExtraTax = $useAdditionalTax
                        ? ($rowBase * $additionalTaxPercent) / 100
                        : 0;


            $rowTotal = $rowBase + $rowTax + $rowExtraTax;

            // Accumulate totals
            $subtotal += $rowSubtotal;
            $totalDiscount += $rowDiscount;
            $totalTax += $rowTax;
            $totalExtraTax += $rowExtraTax;

            // Build corrected row
            $newItem = [
                'name'           => $item['name'],
                'quantity'       => $qty,
                'price'          => round($price, 2),
                'discount'       => abs($discount),
                'use_percentage' => $usePercent,
                'tax'            => $taxPercent,
                'amount'         => $rowTotal,
            ];

            // Add additional tax only when enabled
            if ($useAdditionalTax) {
                $newItem['additionaltax']      = $additionalTaxPercent;
                $newItem['additionaltaxvalue'] = $rowExtraTax;
            }
            
            $newItems[] = $newItem;

        }


        // 🧮 Final totals
        $grandTotal = $subtotal - $totalDiscount + $totalTax + $totalExtraTax;

        $idField = $type === 'invoice' ? 'invoice_id' : 'receipt_id';

        return [
            'reference_id'       => $invoice['reference_id'],
            'ref_invoice_number'       => $invoice['ref_invoice_number'],
            $idField             => $invoice[$idField] ?? null,
            'ref_no'             => $invoice['ref_no'],
            'issue_date'         => $invoice['issue_date'],
            'due_date'           => $invoice['due_date'],
            'items'              => $newItems,

            'subtotal'           => normalizePrice($subtotal, 2, 'IN'),
            'extraTax'           => normalizePrice($totalExtraTax, 2, 'IN'),
            'totalDiscount'      => normalizePrice(abs($totalDiscount), 2, 'IN'),
            'totalTax'           => normalizePrice($totalTax, 2, 'IN'),
            'grandTotal'         => normalizePrice($grandTotal, 2, 'IN'),

            'client_id'          => $invoice['client_id'] ?? null,
            'payment_method'     => $invoice['payment_method'] ?? null,
            'extra'              => $invoice['extra'],
            'status'             => $invoice['status'] ?? '',
            'is_verified'        => $invoice['is_verified'],
            'currency'           => $invoice['currency'],
            'invoice_type'       => $invoice['invoice_type'],
            'created_by'         => $invoice['created_by']


        ];
    }


    function generateCorrectedInvoiceOLD(array $invoice, string $method = 'DIFFERENCES', $type = 'invoice')
    {
        $items = $invoice['items'];

        $newItems = [];
        $subtotal = 0;
        $totalDiscount = 0;
        $totalTax = 0;
        $totalExtraTax = 0;

        foreach ($items as $item) {
            $qty = normalizePrice($item['quantity'], 0, 'IN');
            $price = normalizePrice($item['price'], 6, 'IN');
            $discount = normalizePrice($item['discount'], 2, 'IN');
            $taxPercent = normalizePrice($item['tax_percentage'], 2, 'IN');
            $additionaltax = normalizePrice($item['additionaltax']??0, 2, 'IN');
            $additionaltaxvalue = normalizePrice($item['additionaltaxvalue']??0, 2, 'IN');

            // 🔥 METHOD SELECTION
            if ($method === 'DIFFERENCES') {
                $qty = $qty * -1;          // Negative quantity
                $discount = $discount * -1;// Negative discount
            }

            // 🧮 Item amount calculation
            // Original logic: amount = (quantity × price) − discount
            $amount = ($qty * $price) - $discount;

            // 🧮 Tax calculation
            $amountTax = $amount * ($taxPercent / 100);
            $amountAdditionalTax = $amount * ($additionaltax / 100);

            $totalAmountWithTax = $amount + $amountTax + $amountAdditionalTax;
            $totalAmountWithoutTaxAndDiscount = $qty * $price;
            // Add totals
            $subtotal += $totalAmountWithoutTaxAndDiscount;
            $totalDiscount += $discount;
            $totalTax += $amountTax;
            $totalExtraTax += $amountAdditionalTax;

            // dd($amount, $amountTax, $additionaltaxvalue,$totalAmountWithTax);
            // Rebuild item
            $newItems[] = [
                'name'          => $item['name'],
                'quantity'      => $qty,
                'price'         => $price,
                'discount'      => normalizePrice($discount),
                'tax'           => $taxPercent,
                'additionaltax' => $additionaltax,
                'additionaltaxvalue' => $additionaltaxvalue,
                'amount'        => normalizePrice($totalAmountWithTax),
            ];
        }

        // dd($newItems);
        // Final totals
        $grandTotal = $subtotal - $totalDiscount + $totalTax + $totalExtraTax;
        $idField = $type === 'invoice' ? 'invoice_id' : 'receipt_id';

        
        return [
            'reference_id'  => $invoice['reference_id'],
            $idField        => $invoice[$idField] ?? null,
            'ref_no'        => $invoice['ref_no'],
            'issue_date'    => $invoice['issue_date'],
            'due_date'      => $invoice['due_date'],
            'items'         => $newItems,
            'subtotal'      => normalizePrice($subtotal,  2, 'IN'),
            'extraTax'      => normalizePrice($totalExtraTax,  2, 'IN'),
            'totalDiscount' => normalizePrice($totalDiscount,  2, 'IN'),
            'totalTax'      => normalizePrice($totalTax,  2, 'IN'),
            'grandTotal'    => normalizePrice($grandTotal, 2, 'IN'),
            'client_id'     => $invoice['client_id']??null,
            'payment_method'=> $invoice['payment_method']??null,
            'extra'         => $invoice['extra'],
            'status'        => $invoice['status']??'',
            'is_verified'   => $invoice['is_verified'],
            'extra'         => $invoice['extra'],
            'currency'      => $invoice['currency'],
            'invoice_type'  => $invoice['invoice_type'],
            'created_by'    => $invoice['created_by']
        ];
    }

    public function isValidDniNie($value)
    {
        $value = strtoupper(trim($value));
        $lettersMap = "TRWAGMYFPDXBNJZSQVHLCKE";

        // NIF → 8 digits + letter
        if (preg_match('/^[0-9]{8}[A-Z]$/', $value)) {

            $number = substr($value, 0, 8);
            $letter = substr($value, -1);

            return $letter === $lettersMap[$number % 23];
        }

        // NIE → X/Y/Z + 7 digits + letter
        if (preg_match('/^[XYZ][0-9]{7}[A-Z]$/', $value)) {

            $map = ['X' => 0, 'Y' => 1, 'Z' => 2];

            $first = $value[0];
            $number = $map[$first] . substr($value, 1, 7);
            $letter = substr($value, -1);

            return $letter === $lettersMap[$number % 23];
        }

        // Invalid format
        return false;
    }

    public function isValidCif($cif)
    {
        $cif = strtoupper($cif);

        // Must match CIF format
        if (!preg_match('/^[ABCDEFGHJKLMNPQRSUVW][0-9]{7}[0-9A-J]$/', $cif)) {
            return false;
        }

        $letters = 'JABCDEFGHI';
        $control = substr($cif, -1);
        $digits = substr($cif, 1, 7);

        // Sum even positions
        $sumEven = $digits[1] + $digits[3] + $digits[5];

        // Sum odd positions
        $sumOdd = 0;
        foreach ([0, 2, 4, 6] as $i) {
            $n = $digits[$i] * 2;
            $sumOdd += ($n > 9) ? $n - 9 : $n;
        }

        $total = $sumEven + $sumOdd;
        $lastDigit = $total % 10;
        $digitControl = ($lastDigit == 0) ? 0 : 10 - $lastDigit;
        $letterControl = $letters[$digitControl];

        $firstLetter = $cif[0];

        // When control MUST be a letter
        if (in_array($firstLetter, ['P','Q','R','S','W'])) {
            return $control === $letterControl;
        }

        // When control MUST be a number
        if (in_array($firstLetter, ['A','B','E','H'])) {
            return $control == $digitControl;
        }

        // When BOTH are allowed
        return ($control == $digitControl || $control === $letterControl);
    }

    public function saveQrAndVerificationData($response, $company, $model, $number)
    {
        $data = is_array($response) ? $response : $response->json();
        $qrBase64 = $data['content']['compliance']['code']['image']['data'] ?? null;

        if (!$qrBase64) {
            return false;
        }

        $prefix = $model instanceof \App\Models\Invoice ? 'invoice_' : 'receipt_';

        $folderPath = "qrcodes/{$company->company_slug}";
        $fileName   = "{$prefix}{$number}.png";
        $filePath   = "{$folderPath}/{$fileName}";

        // Save QR Code
        Storage::disk('public')->makeDirectory($folderPath);
        Storage::disk('public')->put($filePath, base64_decode($qrBase64));

        // Update model
        $model->verifactu_id = $data['content']['id'] ?? null;
        $model->is_verified  = 1;
        $model->qr_code      = $filePath;

        $model->save();

        return $filePath;
    }

    public function handleVerifactuError($response, $invoiceData, $api = true)
    {
        $status  = $response['content']['status'] ?? null;
        $error   = $response['content']['error'] ?? null;
        $message = $response['content']['message'] ?? null;


        if ($error || ($status !== null && $status >= 400)) {

            $invoiceData->delete();
            // if ($api === true) {
            //     $invoiceData->delete();
            // }
            throw ValidationException::withMessages([
                    'invoice' => [$error ?? 'Bad request'],
                ]);
         
            // return [
            //     'success' => false,
            //     'error'   => $error ?? 'Bad request',
            //     'message' => $message ?? __('Validation Failed'),
            // ];
        }

        return null; // No error
    }
    
    public function createOrGetClient(array $clientData)
    {
        $email  = $clientData['email'];
        $gst_no = $clientData['cif'];

        $existingByGst = Clients::where('gst_no', $gst_no)->first();

        if ($existingByGst && $existingByGst->email !== $email) {
            return [
                'success' => false,
                'message' => __('GST number is already in use with another email.')
            ];
        }

        $companyName = $clientData['company_name'] ?? null;
        // dd($formdata['client']);

        if ($companyName) {
            // $existingCompany = Clients::whereRaw("JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))   LIKE ?", ['%' . $companyName . '%'])->where('gst_no','!=',$gst_no)->first();
            $existingCompany = Clients::whereRaw(
                    "LOWER(JSON_UNQUOTE(JSON_EXTRACT(extra, '$.company_name'))) = ?",
                    [strtolower(trim($companyName))]
                )
                ->where('gst_no', '!=', $gst_no)
                ->exists();
            if ($existingCompany) {
                return [
                    'success' => false,
                    'message' => __('Company name is already in use with another GST Number'),
                ];
            }
        }

        $client = Clients::where('email', $email)
            ->where('gst_no', $gst_no)
            ->first();

        if (!$client) {
            $client = Clients::create([
                "name"      => $clientData['name'],
                "email"     => $email,
                "mobile_no" => $clientData['mobile_no'] ?? null,
                "gst_no"    => $gst_no,
                'isCompany' => $clientData['isCompany'] ?? 0,
                "extra"     => [
                    "company_name" => $clientData['company_name'] ?? null,
                    "address"      => $clientData['address'] ?? null,
                    "locality"     => $clientData['locality'] ?? null,
                    "state_name"   => $clientData['state_name'] ?? null,
                    "country_code" => "ES",
                    "zip_code"     => $clientData['postal_code'] ?? null,
                    "surname"      => $clientData['surname'] ?? null,
                ]
            ]);
        }

        return [
            'success' => true,
            'client' => $client
        ];
    }
    

    public function createInvoiceFromReceipt(Receipts $receipt, $referenceId = null)
    {
        $data = [];

        // Common mapping between receipts and invoices
        $data['reference_id'] = $referenceId;
        $data['invoice_id']   = $receipt->ref_no ?? $receipt->receipt_id;
        $data['verifactu_id'] = $receipt->verifactu_id;
        $data['client_id']    = $receipt->client_id;
        $data['ref_no']       = $receipt->ref_no;

        // Financial fields
        $data['subtotal']      = $receipt->subtotal;
        $data['totalDiscount'] = $receipt->totalDiscount;
        $data['totalTax']      = $receipt->totalTax;
        $data['totalRetencion']= $receipt->totalRetencion;
        $data['grandTotal']    = $receipt->grandTotal;

        // Items & extra
        $data['items'] = $receipt->items;
        $data['extra'] = $receipt->extra;

        // Invoice-only fields (defaults)
        $data['currency']        = '€';
        $data['invoice_type']    = 1;      // 1 = normal, 2 = negative
        $data['payment_method']  = 1;      // default or set dynamically
        $data['issue_date']      = now();
        $data['due_date']        = now();
        $data['status']          = empty($referenceId)? 2 : 4;
        $data['is_verified']     = 1;
        $data['qr_code']         = $receipt->qr_code;
        $data['created_by']      = auth()->id();

        // Remove ID fields that shouldn't be copied
        unset($data['id']);

        // Create invoice record
        return Invoice::create($data);
    }

    public function validateHighValueInvoice($invoice)
    {
        $fullAmount = $invoice->grandTotal;

        if ($fullAmount > 3000) {

            if (empty($invoice->client->gst_no)) {
                return "Invoice amount exceeds 3000€. Client GST number is required.";
            }

            if (empty($invoice->client->extra['company_name'])) {
                return "Invoice amount exceeds 3000€. Company name is required.";
            }

            $required = ['address','locality','zip_code','country_code','state_name'];

            foreach ($required as $field) {
                if (empty($invoice->client->extra[$field])) {
                    return "Invoice amount exceeds 3000€. All address fields must be filled.";
                }
            }
        }

        return null;
    }

    public function getInvoiceTemplateHtml($invoice, $company)
    {
        $prestashopHtml = PrestashopInvoicePdf::emailHtml($invoice, $company);
        if ($prestashopHtml !== null) {
            return $prestashopHtml;
        }

        $user = $company
            ? \App\Models\User::find($company->admin_id)
            : \App\Models\User::find(1);

        // $templateId = $company->extra['favouraite_template']
        //     ?? $user->extra['favouraite_template']
        //     ?? \App\Models\Templates::where('status', 1)->value('id');

        $templateId = getTemplateId(!empty($company) ? $company : $user);
        $template = \App\Models\Templates::find($templateId);

        if (!$template || $template->status != 1) {
            $template = \App\Models\Templates::where('status', 1)->first();
        }

        $html = parseInvoiceSortcodes($template->template_html, $invoice, $company);

        // $storagePath = rtrim(public_path('storage/'), '/') . '/';
        // $baseUrl     = rtrim(asset('storage'), '/') . '/';

        // $html = preg_replace_callback(
        //     '#' . preg_quote($baseUrl, '#') . '([^"\s]+)#',
        //     fn($m) => $storagePath . ltrim($m[1], '/'),
        //     $html
        // );

        return preg_replace('/\s+/', ' ', $html);
    }


}
