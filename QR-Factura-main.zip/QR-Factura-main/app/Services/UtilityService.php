<?php

namespace App\Services;

use Illuminate\Support\Facades\Schema;
use App\Models\TaxRules;

class UtilityService
{
    /* -------------------------
     | Reusable Query Filter
     ------------------------- */
    public static function applyFilters($query, $formdata, $company = null, $options = [])
    {
        $searchFields = $options['search_fields'] ?? [];
        $dateField    = $options['date_field'] ?? 'created_at';

        if (!empty($formdata['search'])) {

            $searchTerm = strtolower($formdata['search']);

            $query->where(function ($q) use ($searchTerm, $searchFields, $company) {

                foreach ($searchFields as $field) {
                    $q->orWhereRaw("LOWER($field) LIKE ?", ["%{$searchTerm}%"]);
                }

                $q->orWhereHas('client', function ($clientQ) use ($searchTerm, $company) {

                    $clientQ->whereRaw('LOWER(name) LIKE ?', ["%{$searchTerm}%"]);
                    $clientQ->orWhereRaw(
                        "JSON_SEARCH(LOWER(JSON_EXTRACT(extra, '$')), 'all', ?) IS NOT NULL",
                        ["%{$searchTerm}%"]
                    );

                    if (empty($company)) {
                        $clientQ->orWhereHas('singleCompany', function ($scQ) use ($searchTerm) {
                            $scQ->whereRaw('LOWER(company_name) LIKE ?', ["%{$searchTerm}%"]);
                        });
                    }
                });

            });
        }

        if(empty(getDomainId())){
            $query->whereNull('domain_id');
        }else{
            $query->where('domain_id',getDomainId());
        }


        if (isset($formdata['status']) && $formdata['status'] !== null) {
            if($formdata['status'] == '5'){
                $query->where('status',$formdata['status'])->orWhere('status',0)->orWhere('status',2);
            }else{
                $query->where('status', $formdata['status']);
            }
        }

        if (isset($formdata['invoice_type']) && $formdata['invoice_type'] !== null) {
            if (self::columnExists($query, 'invoice_type')) {
                $query->where('invoice_type', $formdata['invoice_type']);
            }
        }

        if (!empty($formdata['from_date']) && !empty($formdata['to_date'])) {
            $query->whereBetween($dateField, [
                $formdata['from_date'], 
                $formdata['to_date']
            ]);
        } elseif (!empty($formdata['from_date'])) {
            $query->where($dateField, '>=', $formdata['from_date']);
        } elseif (!empty($formdata['to_date'])) {
            $query->where($dateField, '<=', $formdata['to_date']);
        }

        return $query;
    }

    /* -----------------------------------
     | Column exists check
     ----------------------------------- */
    public static function columnExists($query, $column)
    {
        $table = $query->getModel()->getTable();
        return Schema::hasColumn($table, $column);
    }


    public static function calculate(array $data)
    {
        try {
            // dd($data);
            $authUser = auth()->user();
            $company  = $authUser->company;

            // Handle relation returning collection (multi-company case)
            if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
                $company = $company->first();
            }

            /* --------------------------------------------
             * LOAD DEFAULT TAX SETTINGS
             * --------------------------------------------*/
            $retencionId = $company->extra['retencion']
                ?? TaxRules::where('tax_type', 'retention')->value('id');

            $taxSlabId = $company->extra['tax_slab']
                ?? TaxRules::where('tax_type', 'iva')->value('id');

            // Load rule values only once
            $retencionRate = optional(TaxRules::find($retencionId))->value ?? 0;
            $defaultTax    = optional(TaxRules::find($taxSlabId))->value ?? 0;

            /* --------------------------------------------
             * ADDITIONAL TAX (RE / Equivalence surcharge)
             * --------------------------------------------*/
            $useAdditionalTax = filter_var($data['additionalTax'] ?? false, FILTER_VALIDATE_BOOLEAN);


            $extraTaxRule = $useAdditionalTax
                ? TaxRules::find($data['taxslab'] ?? null)
                : null;

            /* --------------------------------------------
             * INITIALIZE DEFAULTS
             * --------------------------------------------*/
            $items     = $data['items'] ?? [];
            $currency  = $data['currency'] ?? '€';

            $currencyFormat = match ($currency) {
                '€' => 'ES',
                '₹' => 'IN',
                '$' => 'IN',
                default => 'ES',
            };

            $totals = [
                'subtotal'       => 0,
                'discount'       => 0,
                'tax'            => 0,
                'additionalTax'  => 0,
                'retencion'      => 0,
                'tax_groups'    => [],
            ];

            $processedItems = [];

            /* --------------------------------------------
             * PROCESS EACH LINE ITEM
             * --------------------------------------------*/
            foreach ($items as $item) {

                $formatedTax        = normalizePrice($item['tax'], 2, 'IN');
                $qty        = normalizePrice($item['quantity'], 2, 'IN');
                $price      = normalizePrice($item['price'], 6, 'IN');
                $discount   = normalizePrice($item['discount'], 2, 'IN');
                $usePercent = filter_var($item['use_percentage'] ?? false, FILTER_VALIDATE_BOOLEAN);

                // Determine tax values
                $itemTax   = $extraTaxRule?->value     ?? ($formatedTax ?? $defaultTax);
                $extraTax  = $extraTaxRule?->RE_value  ?? 0;

                if ($qty <= 0 || $price <= 0) {
                    $processedItems[] = self::emptyItem($item, $currency);
                    continue;
                }

                /* -------------------------------
                 * Subtotal & Discount calculations
                 * -------------------------------*/
                $rowSubtotal = $qty * $price;

                $rowDiscount = $usePercent
                    ? ($rowSubtotal * $discount) / 100
                    : $discount;

                $rowDiscount = max(0, min($rowDiscount, $rowSubtotal)); // no negative / over-discount

                $rowDiscount = round($rowDiscount, 2);
                /* -------------------------------
                 * Tax Calculations
                 * -------------------------------*/
                $base = ($rowSubtotal - $rowDiscount);

                $rowTax = round(($base * $itemTax) / 100, 2);
                $rowAdditionalTax = round(($base * $extraTax) / 100, 2);

                $rowRetencion = 0;

                $rowTotalBeforeRetention = $base + $rowTax + $rowAdditionalTax;
                $rowTotal = $rowTotalBeforeRetention - $rowRetencion;

                /* -------------------------------
                 * Update Totals
                 * -------------------------------*/
                $totals['subtotal']       += $rowSubtotal;
                $totals['discount']       += $rowDiscount;
                $totals['tax']            += $rowTax;
                $totals['additionalTax']  += $rowAdditionalTax;
                $totals['retencion']      += $rowRetencion;
                if ($itemTax > 0 && $rowTax > 0) {
                    $taxKey = (string) $itemTax;
                    $totals['tax_groups'][$taxKey] = ($totals['tax_groups'][$taxKey] ?? 0) + $rowTax;
                }
                /* -------------------------------
                 * Store processed item
                 * -------------------------------*/
                $processedItems[] = [
                    'quantity'                => $item['quantity'],
                    'price'                   => $item['price'],
                    'discount'                => $item['discount'],
                    'tax'                     => $extraTaxRule?->value ?? $item['tax'],
                    'additionaltax'           => $extraTax,
                    'additionaltaxvalue'      => $rowAdditionalTax,
                    'subtotal'                => $rowSubtotal,
                    'use_percentage'          => $item['use_percentage'] ?? false,
                    'total'                   => $rowTotal,
                    'row_amount'              => $rowTotalBeforeRetention,
                    'row_amount_formatted'    => normalizePrice($rowTotalBeforeRetention, 2, $currencyFormat) . $currency,
                ];
            }
            /* --------------------------------------------
             * GRAND TOTAL
             * --------------------------------------------*/
            $grandTotal = $totals['subtotal']
                        - $totals['discount']
                        + $totals['tax']
                        + $totals['additionalTax']
                        - $totals['retencion'];

            /* --------------------------------------------
             * Format totals
             * --------------------------------------------*/
            $formattedTotals = fn($v) => normalizePrice($v, 2, $currencyFormat) . $currency;

            return [
                'subtotal'                      => $totals['subtotal'],
                'subtotal_formatted'            => $formattedTotals($totals['subtotal']),
                'total_discount'                => $totals['discount'],
                'total_discount_formatted'      => $formattedTotals($totals['discount']),
                'total_tax'                     => $totals['tax'],
                'total_tax_formatted'           => $formattedTotals($totals['tax']),
                'total_additionaltax'           => $totals['additionalTax'],
                'total_additionaltax_formatted' => $formattedTotals($totals['additionalTax']),
                'total_retencion'               => $totals['retencion'],
                'total_retencion_formatted'     => $formattedTotals($totals['retencion']),
                'grand_total'                   => $grandTotal,
                'grand_total_formatted'         => $formattedTotals($grandTotal),
                'items'                         => $processedItems,
                'tax_groups' => collect($totals['tax_groups'])
                    ->map(fn($v) => [
                        'amount'           => $v,
                        'amount_formatted' => $formattedTotals($v),
                    ])
                    ->toArray(),
            ];

        } catch (\Throwable $e) {
            return [
                'success' => false,
                'message' => 'Something went wrong.',
                'error'   => $e->getMessage()
            ];
        }
    }

    /**
     * Standard empty item formatter
     */
    private static function emptyItem($item, $currency)
    {
        return [
            'quantity' => 0,
            'price' => $item['price'] ?? 0,
            'discount' => 0,
            'tax' => $item['tax'] ?? 0,
            'additionaltax' => 0,
            'additionaltaxvalue' => 0,
            'subtotal' => 0,
            'total' => 0,
            'row_amount' => 0,
            'row_amount_formatted' => "0{$currency}",
        ];
    }


    public static function convertItemsToINFormat(array $items)
    {
        $cleaned = [];

        foreach ($items as $item) {

            $row = [
                'name'              => $item['name'] ?? null,
                'item_type'         => $item['item_type'] ?? null,

                // Convert numeric values to database-safe decimal
                'quantity'          => self::toIN($item['quantity'] ?? 0),
                'price'             => self::toIN($item['price'] ?? 0),
                'discount'          => self::toIN($item['discount'] ?? 0),
                'tax'               => self::toIN($item['tax'] ?? 0),
                'additionaltax'     => self::toIN($item['additionaltax'] ?? 0),
                'additionaltaxvalue'=> self::toIN($item['additionaltaxvalue'] ?? 0),
                'amount'            => self::toIN($item['amount'] ?? 0),
                'use_percentage'   => filter_var($item['use_percentage'] ?? false, FILTER_VALIDATE_BOOLEAN),
                'tax_type'          => $item['tax_type'] ?? 'percentage',
            ];

            // Only add new_item if it has value
            if (!empty($item['new_item'])) {
                $row['new_item'] = $item['new_item'];
            }

            $cleaned[] = $row;
        }

        return $cleaned;
    }

    public static function toIN($value)
    {
        if ($value === null || $value === '') {
            return 0;
        }

        $value = trim((string)$value);

        // If both comma and dot exist: determine decimal separator
        if (strpos($value, '.') !== false && strpos($value, ',') !== false) {
            // Decimal is comma → "1.200.000,55"
            if (strrpos($value, ',') > strrpos($value, '.')) {
                $value = str_replace('.', '', $value);   // remove thousand separators
                $value = str_replace(',', '.', $value);  // convert decimal
            }
            // Decimal is dot → "1,200,000.55"
            else {
                $value = str_replace(',', '', $value); // remove thousand separators
            }
        }
        else {
            // Only comma exists → "770,00"
            if (strpos($value, ',') !== false) {
                $value = str_replace('.', '', $value);   // remove thousand separators
                $value = str_replace(',', '.', $value);  // convert decimal
            }
            // Only dot exists → Might be 12.500 or 12.50
            else {
                // If dot is thousand separator (looks like 12.500 or 1.200)
                if (preg_match('/\.\d{3}$/', $value) || preg_match('/\.\d{3}\./', $value)) {
                    $value = str_replace('.', '', $value);
                }
            }
        }

        return round((float)$value, 6);
    }


}
