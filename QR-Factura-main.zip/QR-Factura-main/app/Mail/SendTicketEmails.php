<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class SendTicketEmails extends Mailable
{
    use Queueable, SerializesModels;

    public $viewfile;
    public $subject;
    public $images;
    public $body;

    public function __construct($subject, $viewFile, $body, $images = [])
    {
        $this->viewfile = $viewFile;
        $this->subject = $subject;
        $this->body = $body;
        $this->images = $images;
    }

    public function build()
    {
        $email = $this->subject($this->subject)
                        ->markdown($this->viewfile)
                        ->with([
                            'data' => $this->body,
                            'images' => $this->images
                        ]);

        // Attach multiple images
        foreach ($this->images as $image) {
            $email->attach(public_path($image));
        }

        return $email;
    }
}
