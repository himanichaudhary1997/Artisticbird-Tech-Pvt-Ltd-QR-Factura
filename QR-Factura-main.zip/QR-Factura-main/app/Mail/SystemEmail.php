<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SystemEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $data; // Data to pass to the view
    protected $subjectText; // Dynamic subject
    protected $viewFile; // Dynamic view file
    protected $pdfContent; // PDF content
    protected $pdfFileName; // PDF file name
    protected $fromEmail; // Dynamic from email
    protected $fromName; // Dynamic from name
    protected $pdfPath;
    protected $replyToEmail;
    protected $replyToName;

    /**
     * Create a new message instance.
     *
     * @param string $subject
     * @param string $view
     * @param array $data
     * @param string|null $pdfContent Optional PDF content to attach
     * @param string|null $pdfFileName Optional PDF file name
     * @param array|null $attachments Optional array of attachments
     */
    public function __construct(string $subject, string $view, array $data, string $pdfContent = null, string $pdfFileName = 'attachment.pdf',string $fromEmail = null,string $fromName = null,$pdfPath = null,$replyToEmail = null, $replyToName = null)
    {
        $this->subjectText = $subject;
        $this->viewFile = $view;
        $this->data = $data;
        $this->pdfContent = $pdfContent;
        $this->pdfFileName = $pdfFileName;
        $this->fromEmail = $fromEmail;
        $this->fromName = $fromName;
        $this->pdfPath = $pdfPath;
        $this->replyToEmail = $replyToEmail;
        $this->replyToName = $replyToName;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $email = $this->subject($this->subjectText)
                    ->markdown($this->viewFile)
                    ->with([
                        'data' => $this->data,
                        'images' => $this->attachments
                        ]);
                        
        if ($this->fromEmail) {
            $email->from($this->fromEmail, $this->fromName);
        }
        // Attach PDF if content is provided
        if ($this->pdfContent) {
            // dd('hi');
            $email->attachData($this->pdfContent, $this->pdfFileName, [
                'mime' => 'application/pdf',
            ]);
        }        

        if ($this->pdfPath) {
            $email->attach($this->pdfPath);
        }

        if ($this->replyToEmail) {
            $email->replyTo($this->replyToEmail, $this->replyToName);
        }
        
        return $email;
    }
}
