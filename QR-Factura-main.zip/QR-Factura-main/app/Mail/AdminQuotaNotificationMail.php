<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class AdminQuotaNotificationMail extends Mailable
{
    public function __construct(public array $data)
    {
    }

    public function build()
    {
        return $this->subject(
            "Subscription Usage Alert"
        )->markdown('emails.admin-quota-notification');
    }
}