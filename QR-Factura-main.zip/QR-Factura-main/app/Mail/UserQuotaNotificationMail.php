<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class UserQuotaNotificationMail extends Mailable
{
    public function __construct(public array $data)
    {
    }

    public function build()
    {

        return $this->subject('¡Aviso! Está al '.$this->data['percent'].'% de su límite de '.(strtolower($this->data['type']) == 'invoice' ? 'facturas':'tickets'))
            ->markdown('emails.user-quota-notification');
    }
}