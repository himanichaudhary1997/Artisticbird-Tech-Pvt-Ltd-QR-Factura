<?php
namespace App\Mail;

class MailContext
{
    protected static bool $useAdminBranding = false;

    public static function useAdminBranding(): void
    {
        static::$useAdminBranding = true;
    }

    public static function resetBranding(): void
    {
        static::$useAdminBranding = false;
    }

    public static function isAdminBranding(): bool
    {
        return static::$useAdminBranding;
    }
}