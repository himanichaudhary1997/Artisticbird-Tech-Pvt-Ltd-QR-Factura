<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Jobs\SubscriptionReminderJob;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        \App\Console\Commands\DBUpdateInvoices::class,
    ];


    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // $schedule->command('inspire')->hourly();
        // $schedule->job(new SubscriptionReminderJob)->dailyAt('12:00');
        // $schedule->command('subscription:reminder')->dailyAt('08:00');
        $schedule->command('remove-demo-user')->dailyAt('08:00');
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }

    
}
