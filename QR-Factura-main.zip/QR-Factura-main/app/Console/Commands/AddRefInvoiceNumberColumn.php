<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AddRefInvoiceNumberColumn extends Command
{
    protected $signature = 'db:add-ref-invoice-number';
    protected $description = 'Add ref_invoice_number column to all invoice_* and receipt tables and fill values';

    public function handle()
    {
        $tables = DB::connection()->getDoctrineSchemaManager()->listTableNames();

        // Tables starting with "invoices_" OR named "receipts" OR "receipts_*"
        $targetTables = array_filter($tables, function ($table) {
            return preg_match('/^invoices/i', $table) ||
                   preg_match('/^receipts/i', $table);
        });

        if (empty($targetTables)) {
            $this->warn("No invoice or receipt tables found.");
            return Command::SUCCESS;
        }


        foreach ($targetTables as $table) {
            $this->info("Processing table: {$table}");
            if (!Schema::hasColumn($table, 'ref_invoice_number')) {
                DB::statement("ALTER TABLE `{$table}` ADD `ref_invoice_number` VARCHAR(255) NULL AFTER `reference_id`");
                $this->info(" → Column added.");
            } else {
                $this->info(" → Column already exists.");
            }
        }

        $this->info("All tables processed successfully.");
        return Command::SUCCESS;
    }
}
