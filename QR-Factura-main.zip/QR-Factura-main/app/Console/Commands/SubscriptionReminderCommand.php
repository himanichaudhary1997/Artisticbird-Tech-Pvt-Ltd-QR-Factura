<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\SubscriptionReminderJob;

class SubscriptionReminderCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'subscription:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send subscription reminders to users';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        // Dispatch the job
        dispatch(new SubscriptionReminderJob());

        $this->info('Subscription reminder job dispatched successfully.');
    }
}
