<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class DBUpdateInvoices extends Command
{
   
    protected $signature = 'invoices:add-extra-tax';
    protected $description = 'Add extraTax column to all invoice tables if not exists';

    public function handle()
    {
        $this->info("🚀 Starting extraTax column migration...");

        $tables = ['invoices'];
        $dynamicTables = DB::select("SHOW TABLES LIKE 'invoices_%'");

        foreach ($dynamicTables as $table) {
            $tableName = array_values((array)$table)[0];
            $tables[] = $tableName;
        }

        foreach ($tables as $tableName) {
            $this->addColumnIfMissing($tableName);
        }

        $this->info("🎉 Done! extraTax column added successfully where needed.");
    }

    private function addColumnIfMissing($tableName)
    {
        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table $tableName does not exist, skipping...");
            return;
        }

        if (Schema::hasColumn($tableName, 'extraTax')) {
            $this->line("ℹ Table $tableName already has extraTax column.");
            return;
        }

        try {
            Schema::table($tableName, function ($table) {
                $table->decimal('extraTax', 15, 2)->nullable()->after('totalTax');
            });

            $this->info("✅ Added extraTax column to $tableName");
        } catch (\Throwable $e) {
            $this->error("❌ Error updating $tableName: " . $e->getMessage());
        }
    }
}
