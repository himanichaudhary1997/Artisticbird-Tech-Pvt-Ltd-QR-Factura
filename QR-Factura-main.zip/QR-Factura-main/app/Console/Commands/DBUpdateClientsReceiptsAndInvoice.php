<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;

class DBUpdateClientsReceiptsAndInvoice extends Command
{
    protected $signature = 'db:update-clients-receipts-invoices';
    protected $description = 'Add new column to clients tables and extraTax column to receipts and invoices tables';

    public function handle()
    {
        $this->info('🚀 Starting DB update...');

        $this->updateClientsTables();
        $this->updateReceiptsTables();
        $this->updateInvoicesTables();

        $this->info('✅ DB update completed successfully!');
    }

    /**
     * Add column to clients tables
     */
    protected function updateClientsTables()
    {
        $this->info('🔧 Updating clients tables...');

        $tables = ['clients'];

        $dynamicTables = DB::select("SHOW TABLES LIKE 'clients%'");
        foreach ($dynamicTables as $table) {
            $tables[] = array_values((array)$table)[0];
        }

        foreach ($tables as $tableName) {
            Schema::table($tableName, function (Blueprint $table) use ($tableName) {
                if (!Schema::hasColumn($tableName, 'isCompany')) {
                    $table->boolean('isCompany')->default(false)
                        ->after('gst_no');
                }
            });

            $this->info("✔ Updated: {$tableName}");
        }
    }

    /**
     * Add extraTax column to receipts tables
     */
    protected function updateReceiptsTables()
    {
        $this->info('🔧 Updating receipts tables...');

        $tables = ['receipts'];

        $dynamicTables = DB::select("SHOW TABLES LIKE 'receipts%'");
        foreach ($dynamicTables as $table) {
            $tables[] = array_values((array)$table)[0];
        }

        foreach ($tables as $tableName) {
            Schema::table($tableName, function (Blueprint $table) use ($tableName) {

                if (!Schema::hasColumn($tableName, 'extraTax')) {
                    $table->decimal('extraTax', 10, 2)
                        ->default(0)
                        ->after('totalTax');
                }
            });

            $this->info("✔ Updated: {$tableName}");
        }
    }
    protected function updateInvoicesTables()
    {
        $this->info('🔧 Updating invoices tables...');

        $tables = ['invoices'];
        $dynamicTables = DB::select("SHOW TABLES LIKE 'invoices%'");
        foreach ($dynamicTables as $table) {
            $tables[] = array_values((array)$table)[0];
        }

        foreach ($tables as $tableName) {
            Schema::table($tableName, function (Blueprint $table) use ($tableName) {

                if (!Schema::hasColumn($tableName, 'extraTax')) {
                    $table->decimal('extraTax', 10, 2)
                        ->default(0)
                        ->after('totalTax');
                }
            });

            $this->info("✔ Updated: {$tableName}");
        }
    }
}
