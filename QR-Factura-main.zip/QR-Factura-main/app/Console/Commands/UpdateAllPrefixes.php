<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;


class UpdateAllPrefixes extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:update-all-prefixes';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $year = 'YYYY';

        // -------------------------
        //   Update MAIN TABLE
        // -------------------------
        $mainTable = "invoice_prefix_series";

        if (Schema::hasTable($mainTable)) {

            $rows = DB::table($mainTable)->get();

            foreach ($rows as $row) {

                if (strlen($row->prefix) != 2) {
                    continue;
                }

                $paddedSeries = str_pad($row->series, 4, '0', STR_PAD_LEFT);

                $newPrefix = $year . $row->prefix . '-' . $paddedSeries;

                DB::table($mainTable)
                    ->where('id', $row->id)
                    ->update([
                        'prefix' => $newPrefix
                    ]);
            }

            $this->info("Updated prefixes in MAIN table: $mainTable");
        } else {
            $this->warn("Main table $mainTable does not exist.");
        }


        // -------------------------
        //   Update COMPANY TABLES
        // -------------------------
        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {

            $table = "invoice_prefix_series_" . $company->id;

            if (!Schema::hasTable($table)) {
                $this->warn("Table $table does not exist, skipping...");
                continue;
            }

            $rows = DB::table($table)->get();

            foreach ($rows as $row) {

                if (strlen($row->prefix) != 2) {
                    continue;
                }

                $paddedSeries = str_pad($row->series, 4, '0', STR_PAD_LEFT);

                $newPrefix = $year . $row->prefix . '-' . $paddedSeries;

                DB::table($table)
                    ->where('id', $row->id)
                    ->update([
                        'prefix' => $newPrefix
                    ]);
            }

            $this->info("Updated prefixes in table: $table");
        }

        $this->info("All prefixes updated successfully!");
    }


}
