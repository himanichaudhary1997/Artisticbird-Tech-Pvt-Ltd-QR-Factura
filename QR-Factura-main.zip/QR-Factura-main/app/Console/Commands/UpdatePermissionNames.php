<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

class UpdatePermissionNames extends Command
{
    protected $signature = 'permissions:update {--dry-run}';
    protected $description = 'Update permissions table based on admin prefixed route names';

    public function handle()
    {
        $dryRun = $this->option('dry-run');

        $this->info("🔍 Fetching admin routes...");

        $adminRoutes = collect(Route::getRoutes())->filter(function ($route) {
            return isset($route->action['prefix']) && $route->action['prefix'] === 'admin';
        });

        if ($adminRoutes->isEmpty()) {
            $this->warn("⚠ No admin routes found.");
            return;
        }

        $this->info("📌 Admin routes found: " . $adminRoutes->count());

        foreach ($adminRoutes as $route) {

            $routeName = $route->getName();

            if (!$routeName) {
                continue; // ignore unnamed route
            }

            // Remove admin prefix from name to match old permission name
            $oldName = str_replace("admin.", "", $routeName);

            // Find permission matching either style
            $permission = DB::table('permissions')
                ->where('name', $oldName)
                ->orWhere('name', $routeName)
                ->first();

            if (!$permission) {
                $this->warn("⚠ No permission found for route: $routeName");
                continue;
            }

            if ($permission->name === $routeName) {
                $this->line("✔ Already updated: $routeName");
                continue;
            }

            if ($dryRun) {
                $this->comment("🧪 DRY RUN: Would update '{$permission->name}' → '$routeName'");
                continue;
            }

            DB::table('permissions')
                ->where('id', $permission->id)
                ->update(['name' => $routeName]);

            $this->info("🔄 Updated: {$permission->name} → $routeName");
        }

        $this->info("\n🎉 Completed Permission Update Process");
    }
}
