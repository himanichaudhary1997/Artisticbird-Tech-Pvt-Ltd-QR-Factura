<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Invoice;
use App\Models\User;    
use App\Models\Company;
use App\Models\Clients;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;

class DuplicatePeriodicInvoices extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'invoices:duplicate-periodic {user_id} {issue_date} {due_date}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Duplicate periodic invoices for the given user and dates';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $userId = $this->argument('user_id');
        $issueDate = $this->argument('issue_date');
        $dueDate = $this->argument('due_date');

        $user = User::find($userId);
        $role = $user->roles->pluck('id')->first();

        $company = $user->company;
        
        if ($company instanceof \Illuminate\Database\Eloquent\Collection) {
            $company = $company->first();
        }

        if($company){
            $adminUser = User::where('id', $company->admin_id)->first();
        }else{
            $adminUser = User::where('id', $user->id)->first();
        }
        $companyname = $company->company_name ?? $user->extra['company_name'] ?? null;

        $currentYear = date('Y', strtotime($issueDate));
        $currentMonth = date('m', strtotime($issueDate));
        $companyInitials = strtoupper(substr($companyname, 0, 2));

        $previousDate = now()->subMonthNoOverflow();
        $previousMonth = $previousDate->month;
        $previousYear = $previousDate->year;

        $query = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)
            ->whereMonth('issue_date', $previousMonth)
            ->whereYear('issue_date', $previousYear)
            ->where('status', '!=', Invoice::NEGATIVE_INVOICE);

        // if ($role != 1 && $role != 2) {
        //     $query->where('created_by', $user->id);
        // } 
        \Log::info('Found invoices', ['count' => $query->count()]);
        
        $invoices = $query->get();
        $totalDuplicatedInvoice = 0;
        foreach ($invoices as $invoice) {
            $alreadyExists = Invoice::where('invoice_type', Invoice::INVOICE_TYPE_PERIODIC)
                ->where('reference_id', $invoice->id)
                ->whereMonth('issue_date', $currentMonth)
                ->whereYear('issue_date', $currentYear)
                ->exists();

            if ($alreadyExists) continue;

            $parts = explode('/', $invoice->invoice_id);
            $previousInitials = $parts[1] ?? $companyInitials;
            preg_match('/(\d+)$/', $parts[2] ?? '0000', $matches);
            $lastNumber = isset($matches[1]) ? (int) $matches[1] : 0;

            $nextNumber = $lastNumber + 1;
            do {
                $newId = $currentYear . '/' . $previousInitials . '/' . str_pad($nextNumber++, 4, '0', STR_PAD_LEFT);
            } while (Invoice::where('invoice_id', $newId)->exists());

            $newInvoice = $invoice->replicate();
            $newInvoice->invoice_id = $newId;
            $newInvoice->issue_date = $issueDate;
            $newInvoice->due_date = $dueDate;
            $newInvoice->status = 0;
            $newInvoice->reference_id = $invoice->id;
            $newInvoice->created_by = $user->id;
            $newInvoice->save();
            $totalDuplicatedInvoice++;
        }

        $subject = "Peridoic Invoices Duplicated";
        $view = 'emails.periodic-invoices'; // View file path without .blade.php
        $data = [
            'name' => $adminUser->name,
            'email' => $adminUser->email,
            'totalDuplicatedInvoice' => $totalDuplicatedInvoice,
        ];

        Mail::to($adminUser->email)->send(new SystemEmail($subject, $view, $data));
    }
}
