<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class DatabaseUpdateCommand extends Command
{
    protected $signature = 'system:db-update {--force}';
    protected $description = 'Run database updates across all tenant/website tables';

    public function handle()
    {
        $this->info("🔄 Starting global database updates...");

        DB::beginTransaction();

        try {
            // Example 1: Update invoices table reference_id to VARCHAR(50)
            // $this->updateMainInvoiceTable();
            // $this->renameVerifactuColumn();
            // $this->updateCompanyInvoiceTables();
            // $this->renameReferenceNumberColumn('receipts');
            // $this->addProviderIdColumn();
            // $this->addRefNoColumn();
            // $this->addRejectedStatus('performas');
            // $this->addRejectedStatus('delivery_notes');

            // $this->addDomainIdColumn();
            // $this->addApiKeyIdColumn();
            $this->addPermissions();
            // $this->addColumnsToVerifactuApiKeys();

            DB::commit();
            $this->info("✅ All updates applied successfully.");

        } catch (\Throwable $e) {
            DB::rollBack();
            $this->error("❌ Update failed: " . $e->getMessage());
        }
    }

    protected function addColumnsToVerifactuApiKeys()
    {
        $tableName = 'verifactu_api_keys';

        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table `$tableName` does not exist.");
            return;
        }

        if (!Schema::hasColumn($tableName, 'prefix_id')) {

            DB::statement("
                ALTER TABLE `$tableName`
                ADD COLUMN `prefix_id` BIGINT UNSIGNED NULL
                AFTER `allowed_url`
            ");

            $this->info("✔ Added `prefix_id` column.");
        } else {
            $this->info("✔ `prefix_id` already exists.");
        }

        if (!Schema::hasColumn($tableName, 'extra')) {

            DB::statement("
                ALTER TABLE `$tableName`
                ADD COLUMN `extra` LONGTEXT NULL
                AFTER `prefix_id`
            ");

            $this->info("✔ Added `extra` column.");
        } else {
            $this->info("✔ `extra` already exists.");
        }
    }

    protected function addDomainIdColumn()
    {
        $tables = [
            'auto_invoices',
            'invoices',
            'delivery_notes',
            'receipts',
            'performas',
        ];

        $companies = DB::table('companies')->get();

        foreach ($tables as $table) {

            $this->updateDomainColumnPosition($table);

            foreach ($companies as $company) {
                $this->updateDomainColumnPosition($table . '_' . $company->id);
            }
        }

        $this->info("✔ Completed adding `domain_id` column in all tables.");
    }

    protected function updateDomainColumnPosition($tableName)
    {
        if (!Schema::hasTable($tableName) || !Schema::hasColumn($tableName, 'created_by')) {
            return;
        }

        $columns = DB::select("SHOW COLUMNS FROM `$tableName`");
        $columnNames = collect($columns)->pluck('Field')->values()->toArray();

        $createdByIndex = array_search('created_by', $columnNames);

        if ($createdByIndex === false || $createdByIndex === 0) {
            return;
        }

        // Column immediately before created_by
        $previousColumn = $columnNames[$createdByIndex - 1];

        if (!Schema::hasColumn($tableName, 'domain_id')) {

            DB::statement("
                ALTER TABLE `$tableName`
                ADD COLUMN `domain_id` BIGINT UNSIGNED NULL
                AFTER `$previousColumn`
            ");

            $this->info("✔ Added domain_id before created_by in $tableName");
            return;
        }

        // Refresh columns after add
        $columns = DB::select("SHOW COLUMNS FROM `$tableName`");
        $columnNames = collect($columns)->pluck('Field')->values()->toArray();

        $domainIdIndex = array_search('domain_id', $columnNames);
        $createdByIndex = array_search('created_by', $columnNames);

        // Already immediately before created_by
        if ($domainIdIndex === ($createdByIndex - 1)) {
            $this->info("✔ domain_id already correctly positioned in $tableName");
            return;
        }

        DB::statement("
            ALTER TABLE `$tableName`
            MODIFY COLUMN `domain_id` BIGINT UNSIGNED NULL
            AFTER `$previousColumn`
        ");

        $this->info("✔ Moved domain_id before created_by in $tableName");
    }

    protected function addApiKeyIdColumn()
    {
        $tableName = 'token_origins';

        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table `$tableName` does not exist.");
            return;
        }

        if (!Schema::hasColumn($tableName, 'api_key_id')) {

            $columns = DB::select("SHOW COLUMNS FROM `$tableName`");
            $columnNames = collect($columns)->pluck('Field')->toArray();

            if (in_array('origin', $columnNames)) {

                DB::statement("
                    ALTER TABLE `$tableName`
                    ADD COLUMN `api_key_id` BIGINT UNSIGNED NULL
                    AFTER `origin`
                ");

                $this->info("✔ Added api_key_id after origin.");
            } else {

                Schema::table($tableName, function ($table) {
                    $table->unsignedBigInteger('api_key_id')->nullable();
                });

                $this->info("✔ Added api_key_id.");
            }

        } else {
            $this->info("✔ api_key_id already exists.");
        }
    }

    // protected function addPermissions()
    // {
    //     $permissions = [
    //         ['name' => 'getlogs', 'guard_name' => 'web'],
    //         ['name' => 'generatefakelogs', 'guard_name' => 'web'],
    //         ['name' => 'exportlogs', 'guard_name' => 'web'],
    //         // ['name' => 'editsiteapis', 'guard_name' => 'web'],
    //     ];

    //     foreach ($permissions as $perm) {
    //         if (Permission::where('name', $perm['name'])->doesntExist()) {
    //             Permission::create($perm);
    //             $this->info("✔ Added permission: {$perm['name']}");

    //             $superAdminRole = Role::where('name', 'Admin')->first();
    //             if ($superAdminRole) {
    //                 $superAdminRole->givePermissionTo($perm['name']);
    //             }

    //             $companyRole = Role::where('name', 'Company')->first();
    //             if ($companyRole) {
    //                 $companyRole->givePermissionTo($perm['name']);
    //             }

    //             $companyAdminRole = Role::where('name', 'CompanyAdmin')->first();
    //             if ($companyAdminRole) {
    //                 $companyAdminRole->givePermissionTo($perm['name']);
    //             }
    //         }

            
    //     }
    // }

    protected function addPermissions()
    {
        $permissions = [
            ['name' => 'bulkdownloadsindex', 'guard_name' => 'web'],
            ['name' => 'bulkdownloadregenerate', 'guard_name' => 'web'],
            ['name' => 'bulkdownloadstatus', 'guard_name' => 'web'],
            ['name' => 'invoices.bulk-download.file', 'guard_name' => 'web'],
            // ['name' => 'editsiteapis', 'guard_name' => 'web'],
        ];

        $roleNames = ['Admin', 'Company', 'CompanyAdmin'];

        foreach ($permissions as $perm) {
            $permission = Permission::where('name', $perm['name'])->first();

            if (!$permission) {
                $permission = Permission::create($perm);
                $this->info("✔ Added permission: {$perm['name']}");
            }

            foreach ($roleNames as $roleName) {
                $role = Role::where('name', $roleName)->first();

                if ($role && !$role->hasPermissionTo($permission)) {
                    $role->givePermissionTo($permission);
                    $this->info("✔ Assigned '{$perm['name']}' to role: {$roleName}");
                }
            }
        }
    }
    /**
     * Update column reference_id from bigInt to varchar
     */
    protected function updateMainInvoiceTable()
    {
        $this->info("➡ Updating main `invoices` table...");

        if (!Schema::hasColumn('companies', 'url')) {
            DB::statement("
                ALTER TABLE companies 
                ADD COLUMN url VARCHAR(255) NULL 
                AFTER company_email
            ");
            $this->info("✔ Added companies.url column (nullable) after company_email");
        } else {
            $this->warn("⚠ Column url already exists in companies table.");
        }

        if (!Schema::hasColumn('companies', 'privacy')) {
            DB::statement("
                ALTER TABLE companies 
                ADD COLUMN privacy TEXT NULL 
                AFTER url
            ");
            $this->info("✔ Added companies.url column (nullable) after company_email");
        } else {
            $this->warn("⚠ Column url already exists in companies table.");
        }

        // if (Schema::hasColumn('invoices', 'reference_id')) {
        //     DB::statement("ALTER TABLE invoices MODIFY reference_id VARCHAR(50) NULL");
        //     $this->info("✔ Updated invoices.reference_id → VARCHAR(50)");
        // } else {
        //     $this->warn("⚠ Column reference_id does not exist in invoices table.");
        // }
    }

    protected function updateCompanyInvoiceTables()
    {
        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {

            $tableName = "invoices_" . $company->id;
            $this->info("➡ Updating table: $tableName");

            if (Schema::hasTable($tableName)) {

                if (Schema::hasColumn($tableName, 'reference_id')) {
                    DB::statement("ALTER TABLE $tableName MODIFY reference_id VARCHAR(50) NULL");
                    DB::table($tableName)
                        ->whereNull('currency')
                        ->orWhere('currency', '')
                        ->orWhereRaw("CHAR_LENGTH(currency) > 3")
                        ->update(['currency' => '€']);
                    DB::statement("ALTER TABLE $tableName MODIFY currency VARCHAR(10) NOT NULL DEFAULT '€'");
                    $this->info("   ✔ Updated $tableName.reference_id → VARCHAR(50)");
                } else {
                    $this->warn("   ⚠ Column reference_id does not exist on $tableName");
                }

            } else {
                $this->warn("   ⚠ Table $tableName does NOT exist.");
            }
        }
    }

    protected function renameVerifactuColumn()
    {
        $companies = DB::table('companies')->get();

        /** ---------------------------
         *  Rename Column in Main Table
         * --------------------------- */
        $mainTable = "auto_invoices";

        $this->info("➡ Checking main table: $mainTable");

        if (Schema::hasTable($mainTable)) {

            if (Schema::hasColumn($mainTable, 'verifactu_invoice_id')) {
                Schema::table($mainTable, function ($table) {
                    $table->renameColumn('verifactu_invoice_id', 'verifactu_id');
                });

                $this->info("   ✔ Renamed verifactu_invoice_id → verifactu_id on $mainTable");
            } 
            elseif (Schema::hasColumn($mainTable, 'verifactu_id')) {
                $this->info("   ✔ verifactu_id already exists on $mainTable (no action required)");
            } 
            else {
                $this->warn("   ⚠ No verifactu column found in $mainTable");
            }

        } else {
            $this->warn("   ⚠ Main table $mainTable does NOT exist.");
        }


        /** ---------------------------
         *  Rename Column in Company Tables
         * --------------------------- */
        foreach ($companies as $company) {

            $tableName = "auto_invoices_" . $company->id;
            $this->info("➡ Checking table: $tableName");

            if (!Schema::hasTable($tableName)) {
                $this->warn("   ⚠ Table $tableName does NOT exist.");
                continue;
            }

            if (Schema::hasColumn($tableName, 'verifactu_invoice_id')) {

                Schema::table($tableName, function ($table) {
                    $table->renameColumn('verifactu_invoice_id', 'verifactu_id');
                });

                $this->info("   ✔ Renamed verifactu_invoice_id → verifactu_id");
            } 
            elseif (Schema::hasColumn($tableName, 'verifactu_id')) {
                $this->info("   ✔ verifactu_id already exists (no action needed)");
            } 
            else {
                $this->warn("   ⚠ Column verifactu_invoice_id/verifactu_id not found on $tableName");
            }
        }
    }

    protected function addProviderIdColumn()
    {
        $companies = DB::table('companies')->get();

        /** ---------------------------
         *  Add Column in Main Table
         * --------------------------- */
        $mainTable = "receipts";

        $this->info("➡ Checking main table: $mainTable");

        if (Schema::hasTable($mainTable)) {

            if (!Schema::hasColumn($mainTable, 'provider_id')) {
                Schema::table($mainTable, function ($table) {
                    $table->unsignedBigInteger('provider_id')
                        ->nullable()
                        ->after('client_id');

                    // Foreign key to providers table
                    $table->foreign('provider_id')
                        ->references('id')
                        ->on('providers')
                        ->onDelete('set null');
                });

                $this->info(" ✔ Added provider_id column to $mainTable");
            } else {
                $this->info(" ✔ provider_id already exists on $mainTable (no action required)");
            }

        } else {
            $this->warn(" ⚠ Main table $mainTable does NOT exist.");
        }



        /** ---------------------------
         *  Add Column in Company Tables
         * --------------------------- */
        foreach ($companies as $company) {

            $tableName = "receipts_" . $company->id;
            $providerTableName = "providers_" . $company->id;

            $this->info("➡ Checking table: $tableName");

            if (!Schema::hasTable($tableName)) {
                $this->warn(" ⚠ Table $tableName does NOT exist.");
                continue;
            }

            if (!Schema::hasColumn($tableName, 'provider_id')) {

                Schema::table($tableName, function ($table) use ($providerTableName) {   // <-- FIX HERE
                    $table->unsignedBigInteger('provider_id')
                        ->nullable()
                        ->after('client_id');

                    $table->foreign('provider_id')
                        ->references('id')
                        ->on($providerTableName)
                        ->onDelete('set null');
                });

                $this->info(" ✔ Added provider_id column to $tableName");

            } else {
                $this->info(" ✔ provider_id already exists on $tableName (no action needed)");
            }
        }

    }

    protected function addRefNoColumn()
    {
        $tableName = 'receipts';

        // ---- MAIN TABLE UPDATE ----
        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table `$tableName` does NOT exist.");
            return;
        }

        if (!Schema::hasColumn($tableName, 'ref_no')) {
            Schema::table($tableName, function ($table) {
                $table->string('ref_no', 100)->nullable()->after('verifactu_id');
            });
            $this->info("✔ Added `ref_no` column to `$tableName`.");
        } else {
            $this->info("✔ `$tableName.ref_no` already exists — skipping.");
        }

        // ---- COMPANY-WISE TABLES UPDATE ----
        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {

            $childTable = $tableName . "_" . $company->id;
            $this->info("➡ Checking company table: $childTable");

            if (!Schema::hasTable($childTable)) {
                $this->warn("   ⚠ Table `$childTable` does NOT exist.");
                continue;
            }

            if (!Schema::hasColumn($childTable, 'ref_no')) {
                Schema::table($childTable, function ($table) {
                    $table->string('ref_no', 100)->nullable()->after('verifactu_id');
                });
                $this->info("   ✔ Added `ref_no` to `$childTable`");
            } else {
                $this->info("   ✔ `$childTable.ref_no` already exists — skipping.");
            }
        }

        $this->info("✔ Completed adding `ref_no` column in all receipt tables.");
    }

    protected function addRejectedStatus($tableName)
    {
        // ---- MAIN TABLE ----
        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table `$tableName` does NOT exist.");
            return;
        }

        if (!Schema::hasColumn($tableName, 'status')) {
            $this->warn("⚠ Column `status` does NOT exist on `$tableName`.");
            return;
        }

        $this->info("➡ Updating ENUM status on `$tableName`");

        // Add new ENUM value
        DB::statement("
            ALTER TABLE $tableName 
            MODIFY status ENUM('accepted','sent','draft','rejected') 
            NULL
        ");

        $this->info("✔ Added `rejected` to ENUM in `$tableName.status`");


        // ---- COMPANY-WISE TABLES ----
        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {

            $childTable = $tableName . "_" . $company->id;
            $this->info("➡ Checking company table: $childTable");

            if (!Schema::hasTable($childTable)) {
                $this->warn("   ⚠ Table `$childTable` does NOT exist.");
                continue;
            }

            if (!Schema::hasColumn($childTable, 'status')) {
                $this->warn("   ⚠ Column `status` does NOT exist on `$childTable`.");
                continue;
            }

            DB::statement("
                ALTER TABLE $childTable 
                MODIFY status ENUM('accepted','sent','draft','rejected') 
                NULL
            ");

            $this->info("   ✔ Added `rejected` to `$childTable.status`");
        }

        $this->info("✔ Completed updating ENUM in all tables.");
    }







    protected function renameReferenceNumberColumn($tableName)
    {
        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table $tableName does not exist.");
            return;
        }

        // If new column already exists → skip
        if (Schema::hasColumn($tableName, 'ref_no')) {
            $this->info("✔ `$tableName.ref_no` already exists — skipping rename.");
            return;
        }

        // If old column does not exist → skip
        if (!Schema::hasColumn($tableName, 'reference_number')) {
            $this->warn("⚠ `$tableName.reference_number` does not exist — skipping.");
            return;
        }

        $this->info("➡ Renaming `$tableName.reference_number` → `ref_no`...");

        // Rename column
        DB::statement("ALTER TABLE $tableName CHANGE reference_number ref_no VARCHAR(100) NULL");

        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {
            $tableName = $tableName. $company->id;
            $this->info("➡ Updating table: $tableName");

            if (Schema::hasTable($tableName)) {

                if (Schema::hasColumn($tableName, 'reference_number')) {
                    DB::statement("ALTER TABLE $tableName CHANGE reference_number ref_no VARCHAR(100) NULL");
                    $this->info("   ✔ Updated $tableName.reference_number` renamed to `ref_no`");
                } else {
                    $this->warn("   ⚠ Column reference_id does not exist on $tableName");
                }

            } else {
                $this->warn("   ⚠ Table $tableName does NOT exist.");
            }
        }
        $this->info("✔ `$tableName.reference_number` renamed to `ref_no`.");
    }

    protected function addReferenceIdColumn($tableName)
    {
        if (!Schema::hasTable($tableName)) {
            $this->warn("⚠ Table $tableName does not exist.");
            return;
        }

        // If column already exists → skip base table
        if (Schema::hasColumn($tableName, 'reference_id')) {
            $this->info("✔ `$tableName.reference_id` already exists — skipping base table.");
        } else {
            $this->info("➡ Adding `reference_id` to `$tableName`...");
            DB::statement("ALTER TABLE $tableName ADD reference_id VARCHAR(255) NULL AFTER id");
            $this->info("✔ Added `reference_id` to `$tableName`");
        }

        // Process company tables
        $companies = DB::table('companies')->get();

        foreach ($companies as $company) {

            $companyTable = $tableName .'_'. $company->id;
            $this->info("➡ Checking table: $companyTable");

            if (!Schema::hasTable($companyTable)) {
                $this->warn("   ⚠ Table $companyTable does NOT exist.");
                continue;
            }

            if (Schema::hasColumn($companyTable, 'reference_id')) {
                $this->info("   ✔ `$companyTable.reference_id` already exists — skipping.");
                continue;
            }

            $this->info("   ➡ Adding `reference_id` to `$companyTable`...");
            DB::statement("ALTER TABLE $companyTable ADD reference_id VARCHAR(255) NULL AFTER id");
            $this->info("   ✔ Added `reference_id` to `$companyTable`");
        }

        $this->info("✔ Finished updating reference_id column for `$tableName` and related company tables.");
    }

}
