<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Company;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\UserSubscriptions;
use App\Models\CompanyUsers;
use App\Mail\SystemEmail;
use Illuminate\Support\Facades\Mail;

class RemoveDemoUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'remove-demo-user';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'It removes demo users and their associated data after 5 days.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $users = User::where('extra->is_demo_user', true)->get();

        foreach ($users as $user) {
            if ($user->created_at->diffInDays(now()) >= 15) {
                // Get company
                $company = Company::where('admin_id', $user->id)->first();

                if ($company) {
                    $companyId = $company->id;

                    // Drop dynamic tables (example: clients_20)
                    $tablesToDrop = [
                        "clients_{$companyId}",
                        "documents_{$companyId}",
                        "document_categories_{$companyId}",
                        "document_categories_relation_{$companyId}",
                        "inventories_{$companyId}",
                        "invoices_{$companyId}",
                        "invoice_prefix_series_{$companyId}",
                        "services_{$companyId}",
                        "accountant_clients_{$companyId}",

                        // add more if you have like invoices_{$companyId}, etc.
                    ];

                    foreach ($tablesToDrop as $table) {
                        if (Schema::hasTable($table)) {
                            Schema::drop($table);
                        }
                    }

                    // Delete company
                    $company->delete();
                }
                // Delete user subscriptions
                $userSubscriptions = UserSubscriptions::where('user_id', $user->id)->delete();

                // Delete all staff users associated with the company
                $staffUsers = User::whereHas('roles', function ($query) {
                    $query->where('name', 'CompanyStaff'); // Staff role ID
                })->join('company_users', 'users.id', '=', 'company_users.user_id')
                ->where('company_users.admin_id', $user->id)
                ->select('users.*')
                ->get();
                foreach ($staffUsers as $staffUser) {
                    $staffUser->delete();
                }

                // Delete relation with accountant users 
                $companyUsers = CompanyUsers::where('admin_id', $user->id)->delete();

                $subject = "Your demo account has been deleted";
                $view = 'emails.account-deleted'; // View file path without .blade.php

                $data = [
                    'name' => $user->name,
                    'email' => $user->email,
                ];

                Mail::to($user->email)->send(new SystemEmail($subject, $view, $data));

                // Finally, delete user
                $user->delete();
            }
        }
    }
}
