<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\StateModel;

class ChangeClientStates extends Command
{
    protected $signature = 'app:change-client-states';
    protected $description = 'Replace state_code in client extra with state_name';

    public function handle()
    {
        // ✅ Get all client tables
        $tables = DB::select("SHOW TABLES LIKE 'clients_%'");

        foreach ($tables as $tableObj) {
            $table = collect($tableObj)->first();
            $this->info("Processing table: {$table}");

            // ✅ Get all rows
            $clients = DB::table($table)->get();

            foreach ($clients as $client) {
                $extra = json_decode($client->extra, true);

                if (!is_array($extra)) {
                    continue;
                }

                if (isset($extra['state_code']) && $extra['state_code']) {
                    $state = StateModel::where('state_code', $extra['state_code'])->first();

                    if ($state) {
                        $extra['state_name'] = $state->name;
                    }

                    // Remove state_code
                    unset($extra['state_code']);

                    // ✅ Update row
                    DB::table($table)
                        ->where('id', $client->id)
                        ->update([
                            'extra' => json_encode($extra, JSON_UNESCAPED_UNICODE)
                        ]);

                    $this->line("✔ Updated client {$client->id} in {$table}");
                }
            }
        }

        $this->info("✅ All client tables processed.");
    }
}
