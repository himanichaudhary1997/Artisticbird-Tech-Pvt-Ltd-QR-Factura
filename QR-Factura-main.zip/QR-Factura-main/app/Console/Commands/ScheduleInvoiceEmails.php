<?php

namespace App\Console\Commands;

use App\Jobs\SendBulkInvoiceEmailsJob;
use Illuminate\Console\Command;
use App\Models\Invoice;
use Carbon\Carbon;

class ScheduleInvoiceEmails extends Command
{
    protected $signature = 'schedule:invoice-emails {batch_size=1}';
    protected $description = 'Schedule sending invoice emails in batches';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $batchSize = $this->argument('batch_size');
        $invoices = Invoice::where('status', 1)  // Assuming '1' means pending
                            ->take($batchSize)
                            ->get();

        if ($invoices->isEmpty()) {
            $this->info('No invoices to send.');
            return;
        }

        $user = auth()->user();
        $company = $user->company;
        $comment = 'Invoices scheduled for sending';

        // Dispatch job with delay
        SendBulkInvoiceEmailsJob::dispatch($invoices, $user, $company, $comment)
            ->delay(Carbon::now()->addMinutes(10));

        $this->info("Scheduled batch of {$batchSize} emails.");

        // Check if there are more invoices to schedule
        if (Invoice::where('status', 1)->count() > 0) {
            // Schedule next batch
            $this->call('schedule:invoice-emails', ['batch_size' => $batchSize]);
        }
    }
}
