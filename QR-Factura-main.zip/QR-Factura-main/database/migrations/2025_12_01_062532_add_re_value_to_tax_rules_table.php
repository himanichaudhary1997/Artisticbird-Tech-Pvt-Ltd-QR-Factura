<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tax_rules', function (Blueprint $table) {
            $table->decimal('RE_value', 10, 2)
                ->nullable()
                ->after('value');
            $table->string('country', 5)
                    ->default('es')
                    ->after('RE_value');
            });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tax_rules', function (Blueprint $table) {
            $table->dropColumn('RE_value');
            $table->dropColumn('country');
        });
    }
};
