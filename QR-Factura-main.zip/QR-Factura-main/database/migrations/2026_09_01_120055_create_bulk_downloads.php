<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bulk_downloads', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable(); // null = superadmin
            $table->foreignId('created_by')->constrained('users');
            $table->string('status')->default('processing'); // processing|ready|failed
            $table->string('file_path')->nullable();
            $table->longtext('extra')->nullable();
            $table->text('error')->nullable();
            $table->timestamps();

            $table->index('company_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bulk_downloads');
    }
};
