<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('auto_invoices', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->string('invoice_id')->unique();
            $table->string('verifactu_invoice_id')->nullable();
            $table->foreignId('client_id')->nullable()->constrained('providers')->onDelete('set null');
            $table->string('currency')->nullable();
            $table->dateTime('issue_date')->nullable();
            $table->string('subtotal')->nullable();
            $table->string('totalDiscount')->nullable();
            $table->string('totalTax')->nullable();
            $table->string('grandTotal')->nullable();
            $table->string('qr_code')->nullable();
            $table->json('items')->nullable();
            $table->json('extra')->nullable();
            $table->boolean('status')->default(true);
            $table->boolean('is_verified')->default(false);
            $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('auto_invoices');
    }
};
