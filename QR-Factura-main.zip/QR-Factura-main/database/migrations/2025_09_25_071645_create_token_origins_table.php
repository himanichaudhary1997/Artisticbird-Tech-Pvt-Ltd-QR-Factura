<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('token_origins', function (Blueprint $table) {
            $table->id();
            $table->string('token_id'); // Passport token ID
            $table->string('origin');   // Origin allowed at creation
            $table->timestamps();

            $table->foreign('token_id')
                  ->references('id')
                  ->on('oauth_access_tokens')
                  ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('token_origins');
    }
};
