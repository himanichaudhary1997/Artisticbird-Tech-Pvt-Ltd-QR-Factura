<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('receipts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->string('receipt_id')->unique();
            $table->string('verifactu_receipt_id')->nullable();
            $table->string('ref_no')->unique();
            $table->dateTime('issue_date')->nullable();
            $table->foreignId('client_id')->nullable()->constrained('users')->onDelete('set null');
            $table->string('subtotal')->nullable();
            $table->string('totalDiscount')->nullable();
            $table->string('totalTax')->nullable();
            $table->string('grandTotal')->nullable();
            $table->string('qr_code')->nullable();
            $table->json('items')->nullable();
            $table->json('extra')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('token_origins');
    }
};
