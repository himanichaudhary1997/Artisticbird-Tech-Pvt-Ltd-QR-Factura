<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Menu;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use App\Models\User;

class MenusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $menuData = [
            [
                'name' => 'Dashboard',
                'url' => 'dashboard',
                'parent_id' => 0,
                'icon' => '/uploads/images/icons/layer-plus.svg ',
                'status' => '1',
            ],
            [
                'name' => 'Users',
                'url' => '#',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/1FefSELabWBVx4ops0VB.svg',
                'status' => '1',
                'child' => [
                    [
                        'name' => 'Companies',
                        'url' => 'getAdminUser',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Clients',
                        'url' => 'getClients',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Staffs',
                        'url' => 'allStaffs',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Accountants',
                        'url' => 'allAccountants',
                        'icon' => null,
                        'status' => '1',
                    ],
                ],
            ],
            [
                'name' => 'Subscription',
                'url' => 'getSubscriptions',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/Ikf9xKPefuGaRBhVNR8W.svg',
                'status' => '1'
            ],

            [
                'name' => 'Menu',
                'url' => 'getAllMenus',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/4L58cB4WX9ocTFsjTGdY.svg',
                'status' => '1'
            ],
            [
                'name' => 'Invoices',
                'url' => '#',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/KfvjPcT5c8Q8wAaFdCjR.svg',
                'status' => '1',
                'child' => [
                    [
                        'name' => 'All Invoices',
                        'url' => 'getInvoices',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Negative Invoices',
                        'url' => 'indexNegativeInvoice',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Payment Methods',
                        'url' => 'getPaymentMethods',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Invoice Types',
                        'url' => 'getInvoiceType',
                        'icon' => null,
                        'status' => '1',
                    ],

                    [
                        'name' => 'Templates',
                        'url' => 'getTemplate',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Tax Rules',
                        'url' => 'indexTaxRules',
                        'icon' => null,
                        'status' => '1',
                    ],
                ],

            ],
            [
                'name' => 'Services',
                'url' => 'getServices',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/OFnPtexuqFDAGamlvfsN.svg',
                'status' => '1'
            ],
            [
                'name' => 'Inventories',
                'url' => 'getInventory',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/wrF0WIdGWl5fRi2LvdYR.svg',
                'status' => '1'
            ],
            [
                'name' => 'Documents',
                'url' => 'getDocuments',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/Rp7NwXNH2Z9yKcBCHueO.svg',
                'status' => '1'
            ],
            [
                'name' => 'Documents Categories',
                'url' => 'getDocumentsCategories',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/Rp7NwXNH2Z9yKcBCHueO.svg',
                'status' => '1'
            ],
            [
                'name' => 'Media',
                'url' => 'media.index',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/CEhePg6TtNRY1KKnvVl0graphic-style.svg  ',
                'status' => '1',
            ],
            [
                'name' => 'Security',
                'url' => '#',
                'parent_id' => 0,
                'icon' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/S3bTsdHQnO0O7A7UbqNGshield-check.svg',
                'status' => '1',
                'child' => [
                    [
                        'name' => 'Logs',
                        'url' => 'getLogs',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'roles',
                        'url' => 'roles.index',
                        'icon' => null,
                        'status' => '1',
                    ],
                    [
                        'name' => 'Permissions',
                        'url' => 'getPermissions',
                        'icon' => null,
                        'status' => '1',
                    ]
                ]
            ],

        ];

        if (!empty($menuData)) {
            foreach ($menuData as $data) {
                if (isset($data['child']) && !empty($data['child'])) {
                    $childs = $data['child'];
                    unset($data['child']);
                }

                // if (isset($data['permissions']) && !empty($data['permissions'])) {
                //     $permissions = $data['permissions'];
                //     unset($data['permissions']);
                // }

                $parentMenu = Menu::create($data);

                // Create a permission for the parent menu
                $parentMenuName = strtolower($parentMenu->name);
                // $parentPermission = Permission::firstOrCreate(['name' => $parentMenuName]);

                if (!empty($childs)) {
                    foreach ($childs as $child) {
                        // Add parent ID to child menu
                        $child['parent_id'] = $parentMenu->id;

                        // Create the child menu
                        $childMenu = Menu::create($child);

                        // Create a permission for the child menu
                        $childMenuName = strtolower($childMenu->name);
                        // $childPermission = Permission::firstOrCreate(['name' => $childMenuName]);

                        // // Link the child permission to the parent permission
                        // $childPermission->parent_id = $parentPermission->id; // Assuming you added a `parent_id` column to the permissions table
                        // $childPermission->save();
                    }
                    $childs = [];
                }

                // if (!empty($permissions)) {
                //     foreach ($permissions as $permission) {
                //         $childPermission = Permission::firstOrCreate(['name' => $permission['name']]);

                //         // Link the child permission to the parent permission
                //         $childPermission->parent_id = $parentPermission->id; // Assuming you added a `parent_id` column to the permissions table
                //         $childPermission->save();
                //     }
                //     $permissions = [];
                // }
            }
        }

        $allPermissions = Permission::all();
        $superAdminRole = Role::where('name', 'Admin')->first();
        $superAdminRole->syncPermissions($allPermissions);

        $user = User::whereHas('roles', function ($query) {
            $query->where('name', 'Admin');
        })->first();

        $user->syncPermissions($allPermissions);
    }
}
