<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolesSeeder::class,
            RolePermissionSeeder::class,
            SubscriptionItemsSeeder::class,
            SubscriptionPlansSeeder::class,
            UsersSeeder::class,
            MenusSeeder::class,
            PaymentMethodsSeeder::class,
            InvoiceTypeSeeder::class,
            ServicesSeeder::class,
            InventorySeeder::class,
            ClientsSeeder::class,
            TemplatesSeeder::class,
            CountryStateSeeder::class,
            InvoicesSeeder::class,
        ]);
    }
}
