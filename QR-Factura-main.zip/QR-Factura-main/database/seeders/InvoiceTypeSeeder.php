<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\InvoiceType;

class InvoiceTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $invoiceData = [
            [
                'name'=>'Normal',
                'slug'=>'normal',
                'status'=>1,
                'extra'=>null,
            ],
            [
                'name'=>'Periodic',
                'slug'=>'periodic',
                'status'=>1,
                'extra'=>null,
            ],
            
            
        ];  

        foreach($invoiceData as $invoiceType){
            $invoice = InvoiceType::create($invoiceType);
        }
    }
}
