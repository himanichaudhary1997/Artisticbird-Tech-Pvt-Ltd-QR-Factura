<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Clients;
use Faker\Factory as Faker;

class ClientsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        // Predefined Clients
        $clientData = [
            [
                'name' => 'Aditya Sharma',
                'email' => 'aditya.sharma@entraenlared.com',
                'mobile_no' => '9650647785',
                'gst_no' => '7383',
                'status' => 1,
                'extra' => json_encode(["address" => "Rajasthan"])
            ],
            [
                'name' => 'Poyatas',
                'email' => 'poyatas@gmail.com',
                'mobile_no' => '9650644578',
                'gst_no' => '7343',
                'status' => 1,
                'extra' => json_encode(["address" => "Uttar Pradesh"])
            ],
        ];

        // Generate 100 Fake Clients
        for ($i = 0; $i < 100; $i++) {
            $clientData[] = [
                'name' => $faker->name,
                'email' => $faker->unique()->safeEmail,
                'mobile_no' => $faker->numerify('98########'),
                'gst_no' => $faker->unique()->numerify('####'),
                'status' => 1,
                'extra' => json_encode(["address" => $faker->address])
            ];
        }

        // Insert into the database
        Clients::insert($clientData);
    }
}
