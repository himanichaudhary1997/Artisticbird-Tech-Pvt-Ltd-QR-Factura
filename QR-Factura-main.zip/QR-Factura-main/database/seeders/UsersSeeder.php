<?php

namespace Database\Seeders;

use App\Models\Company;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        $superAdminRole = Role::firstOrCreate(['name' => 'Admin']);
        $adminRole = Role::firstOrCreate(['name' => 'Company']);

        // $userData = [
        //     [
        //         'name'=>'Anurag Saxena',
        //         'phone'=>'9871814060',
        //         'email'=>'info@artisticbird.com',
        //         'email_verified_at'=>NOW(),
        //         'is_email_verified'=>'1',
        //         'status'=>'1',
        //         'password'=>Hash::make('admin@123'),
        //         'extra'=>[
        //             "company_name" => "Artistic Bird", 
        //             "gst_no" => "4569", 
        //             "company_logo" => "https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/ON52eCZNJjiX8q9icg3O.png", 
        //             "profile_picture" => "https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/1uFanFeP0t1KlhOmss1C.jpg", 
        //             "company_address" => "Rajouri Garden" 
        //          ],
        //         'remember_token'=>'',
        //     ],
        //     [
        //         'name'=>'Aditya Sharma',
        //         'phone'=>'9650648834',
        //         'email'=>'aditya.sharma@entraenlared.com',
        //         'email_verified_at'=>NOW(),
        //         'is_email_verified'=>'1',
        //         'status'=>'1',
        //         'password'=>Hash::make('admin@123'),
        //         'extra'=>null,
        //         'remember_token'=>'',
        //         'company'=>[
        //             'company_name'=>'Company',
        //             'company_slug'=>'company',
        //             'company_email'=>'company@gmail.com',
        //             'gst_no'=>'12569',
        //             'extra'=> [
        //                 "country_code" => "ES", 
        //                 "state_code" => "MD", 
        //                 "company_logo" => "https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/4bHGA1L4j463R1jm7dRz.jpeg", 
        //                 "profile_picture" => "https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/company/q8x4jesYA0OJVK0tJZGs.jpeg", 
        //                 "company_address" => "Rajouri" 
        //              ]
        //         ],
        //         'subscription'=>[
        //             'subscription_id'=> 1,
        //             'time'=>1,
        //             'status'=>1
        //         ]
        //     ],
        //     [
        //         'name'=>'Company User 2',
        //         'phone'=>'9650648831',
        //         'email'=>'companyuser2@gmail.com',
        //         'email_verified_at'=>NOW(),
        //         'is_email_verified'=>'1',
        //         'status'=>'1',
        //         'password'=>Hash::make('admin@123'),
        //         'extra'=>null,
        //         'remember_token'=>'',
        //         'company'=>[
        //             'company_name'=>'Company 2',
        //             'company_slug'=>'company_2',
        //             'company_email'=>'company2@gmail.com',
        //             'gst_no'=>'125693',
        //         ],
        //         'subscription'=>[
        //             'subscription_id'=> 2,
        //             'time'=>6,
        //             'status'=>1
        //         ]
        //     ],
        // ];  
        // // $accessdenied = Permission::firstOrCreate(['name' => 'accessdenied']);
        // foreach ($userData as $key=> $data) {
        //     $companyData = '';
        //     $subscriptionData = '';
        //     if(isset($data['company']) && !empty($data['company'])){
        //         $companyData = $data['company'];
        //         unset($data['company']);
        //     }

        //     if(isset($data['subscription']) && !empty($data['subscription'])){
        //         $subscriptionData = $data['subscription'];
        //         unset($data['subscription']);
        //     }
        //     // $data['password'] = Hash::make($data['password']);
        //     // Create the user
        //     $user = User::create($data);

        //     if($key==0){
        //         $user->assignRole('Admin');
        //     }else{
        //         $user->assignRole('Admin');
        //         // $user->givePermissionTo('accessdenied');
        //     }
        //     if(isset($companyData) && !empty($companyData)){
        //         // Create the related company
        //         Company::create(array_merge($companyData, [
        //             'admin_id' => $user->id,
        //         ]));
        //     }

        //     if(isset($subscriptionData) && !empty($subscriptionData)){
        //         // Create the related company
        //         $subscriptionDates = $user->getStartAndEndDate($subscriptionData['time']);
        //         $user->subscriptionDetails()->create(array_merge($subscriptionData, [
        //             'user_id' => $user->id,
        //             'start_date'=>$subscriptionDates['start_date'],
        //             'end_date'=>$subscriptionDates['end_date']
        //         ]));
        //     }
        // }


        $users = [
            [
                'name' => 'Anurag Saxena',
                'phone' => '9871814060',
                'email' => 'info@artisticbird.com',
                'email_verified_at' => now(),
                'is_email_verified' => true,
                'status' => true,
                'password' => Hash::make('admin@123'),
                'extra' => [
                    'company_name' => 'Artistic Bird',
                    'gst_no' => '4569',
                    'company_logo' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/ON52eCZNJjiX8q9icg3O.png',
                    'profile_picture' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/1uFanFeP0t1KlhOmss1C.jpg',
                    'company_address' => 'Rajouri Garden'
                ],
                'role' => 'Admin'
            ],
            [
                'name' => 'Aditya Sharma',
                'phone' => '9650648834',
                'email' => 'aditya.sharma@entraenlared.com',
                'email_verified_at' => now(),
                'is_email_verified' => true,
                'status' => true,
                'password' => Hash::make('admin@123'),
                'extra' => null,
                'role' => 'Company',
                'company' => [
                    'company_name' => 'Company',
                    'company_slug' => 'company',
                    'company_email' => 'company@gmail.com',
                    'gst_no' => '12569',
                    'extra' => [
                        'country_code' => 'ES',
                        'state_code' => 'MD',
                        'company_logo' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/admin/4bHGA1L4j463R1jm7dRz.jpeg',
                        'profile_picture' => 'https://phplaravel-1438367-5377924.cloudwaysapps.com/storage/company/q8x4jesYA0OJVK0tJZGs.jpeg',
                        'company_address' => 'Rajouri'
                    ]
                ],
                'subscription' => [
                    'subscription_id' => 1,
                    'time' => 1,
                    'status' => 1
                ]
            ],
            [
                'name' => 'Test Company',
                'phone' => '9650648831',
                'email' => 'anurag@gmail.com',
                'email_verified_at' => now(),
                'is_email_verified' => true,
                'status' => true,
                'password' => Hash::make('Test@123'),
                'extra' => null,
                'role' => 'Company',
                'company' => [
                    'company_name' => 'Company 2',
                    'company_slug' => 'company_2',
                    'company_email' => 'company2@gmail.com',
                    'gst_no' => '125693'
                ],
                'subscription' => [
                    'subscription_id' => 2,
                    'time' => 6,
                    'status' => 1
                ]
            ]
        ];

        foreach ($users as $key=>$data) {
            $companyData = $data['company'] ?? null;
            $subscriptionData = $data['subscription'] ?? null;
            unset($data['company'], $data['subscription'], $data['role']);

            // Create User
            $user = User::create($data);

            if($key==0){
                $user->assignRole('Admin');
            }else{
                $user->assignRole('Company');
            }
        
            if ($companyData) {
                Company::create(array_merge($companyData, ['admin_id' => $user->id]));
            }

            if ($subscriptionData) {
                $subscriptionDates = $user->getStartAndEndDate($subscriptionData['time']);
                $user->subscriptionDetails()->updateOrCreate(
                    ['user_id' => $user->id],
                    array_merge($subscriptionData, [
                        'start_date' => $subscriptionDates['start_date'],
                        'end_date' => $subscriptionDates['end_date']
                    ])
                );
            }
        }

    }
}
