<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\SubscriptionItems;

class SubscriptionItemsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $subscriptionitemsData = [
            [
                'name'=>'Invoice',
                'slug'=>'invoice',
                'status'=>1,
                'extra'=>null,
            ],
            [
                'name'=>'Inventory',
                'slug'=>'inventory',
                'status'=>1,
                'extra'=>null,
            ],
            [
                'name'=>'Users',
                'slug'=>'users',
                'status'=>1,
                'extra'=>null,
            ],
            
        ];  

        foreach($subscriptionitemsData as $item){
            $subscriptionitem = SubscriptionItems::create($item);
        }
    }
}
