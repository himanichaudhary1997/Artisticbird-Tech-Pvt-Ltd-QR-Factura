<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\PaymentMethods;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class PaymentMethodsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        // Predefined Payment Methods
        $paymentMethods = [
            [
                'name' => 'PayPal',
                'slug' => 'paypal',
                'extra' => json_encode([
                    'website' => 'https://www.paypal.com',
                    'supported_currencies' => ['USD', 'EUR', 'INR'],
                    'transaction_fee' => '2.9% + $0.30'
                ]),
                'status' => true
            ],
            [
                'name' => 'Stripe',
                'slug' => 'stripe',
                'extra' => json_encode([
                    'website' => 'https://www.stripe.com',
                    'supported_currencies' => ['USD', 'EUR', 'GBP'],
                    'transaction_fee' => '2.9% + $0.30'
                ]),
                'status' => true
            ],
            [
                'name' => 'Razorpay',
                'slug' => 'razorpay',
                'extra' => json_encode([
                    'website' => 'https://www.razorpay.com',
                    'supported_currencies' => ['INR'],
                    'transaction_fee' => '2% + GST'
                ]),
                'status' => true
            ],
            [
                'name' => 'Google Pay',
                'slug' => 'google-pay',
                'extra' => json_encode([
                    'website' => 'https://pay.google.com',
                    'supported_currencies' => ['USD', 'INR'],
                    'transaction_fee' => '0%'
                ]),
                'status' => true
            ],
            [
                'name' => 'Apple Pay',
                'slug' => 'apple-pay',
                'extra' => json_encode([
                    'website' => 'https://www.apple.com/apple-pay/',
                    'supported_currencies' => ['USD', 'EUR'],
                    'transaction_fee' => '0%'
                ]),
                'status' => true
            ],
        ];

        // Generate 5-10 additional random payment methods
        $additionalPaymentMethodsCount = rand(5, 10);
        for ($i = 0; $i < $additionalPaymentMethodsCount; $i++) {
            $name = $faker->company . ' Pay';
            $slug = Str::slug($name);

            $paymentMethods[] = [
                'name' => $name,
                'slug' => $slug,
                'extra' => json_encode([
                    'website' => $faker->url,
                    'supported_currencies' => $faker->randomElements(['USD', 'EUR', 'INR', 'GBP', 'AUD', 'CAD'], rand(1, 3)),
                    'transaction_fee' => $faker->randomFloat(2, 0, 5) . '% + $' . $faker->randomFloat(2, 0, 1)
                ]),
                'status' => $faker->boolean(80) // 80% chance of being active
            ];
        }

        // Insert into database
        PaymentMethods::insert($paymentMethods);
    }
}
