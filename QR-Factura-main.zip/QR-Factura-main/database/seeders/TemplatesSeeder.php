<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Templates;

class TemplatesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $Templates = [
            [
                'name' => 'Basic Template',
                'scope' => null,
                'template_html' => '<table align="center" border="0" cellpadding="0" cellspacing="0" style="width:700px; border: 1px solid #ccc; font-size:12px;">
                            <tbody>
                                <tr>
                                    <td style="border-bottom: 1px solid #cccc;">
                                    <table align="center" border="0" cellpadding="15" cellspacing="10" style="width:100%">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:left"><strong style="font-size:20px;">[user_company_name]</strong><br />
                                                <strong>[user_company_address]</strong><br />
                                                <strong>Gst no: [user_company_gst_no]</strong> <strong>[ref_no]</strong></td>
                                                <td style="text-align:right">[companylogo]</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: 1px solid #cccc;">
                                    <table align="right" border="0" cellpadding="10" cellspacing="10" style="width:100%">
                                        <tbody>
                                            <tr>
                                                <td>[invoiceNumber]</td>
                                            </tr>
                                            <tr>
                                                <td>[invoiceDate]</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: 1px solid #cccc;">
                                    <table align="right" border="0" cellpadding="10" cellspacing="10" style="width:100%">
                                        <tbody>
                                            <tr>
                                                <td style="width:128px"><strong>CLIENT:</strong></td>
                                                <td><strong>[customerName]</strong></td>
                                            </tr>
                                            <tr>
                                                <td style="width:128px"><strong>HOME :</strong></td>
                                                <td><strong>[customerAddress]</strong></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="total itemss">[itemList]</td>
                                </tr>
                                <tr>
                                    <td>
                                    <table align="center" border="0" cellpadding="10" cellspacing="10" style="width:100%">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:left; width:25%"> </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="background-color:#f7faff">
                                    <table align="center" border="0" cellpadding="15" cellspacing="10" style="width:600px">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:center">[user_company_name] © 2025 - All rights reserved.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        ',
            ],
            [
                'name' => 'Template One',
                'scope' => null,
                'template_html' => '<table align="center1" border="0" cellpadding="0" cellspacing="0" style="width:700px; border:1px solid #ccc; font-family:Arial, sans-serif; font-size:12px; color:#333; margin:0 auto; padding:0; border-collapse:collapse; table-layout:fixed;">
                            <tbody>
                                <tr>
                                    <td>
                                    <table border="0" cellpadding="10" cellspacing="10" width="100%">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:left; vertical-align:top; padding:5px; width:70%; word-wrap:break-word;"><strong style="font-size:20px">[user_company_name]</strong><br />
                                                [user_company_address]<br />
                                                <strong>Gst no:</strong> [user_company_gst_no]</td>
                                                <td style="text-align:right; vertical-align:top; padding:5px; width:30%; word-wrap:break-word;">[companylogo]</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table border="0" cellpadding="10" cellspacing="10" width="100%">
                                        <tbody>
                                            <tr>
                                                <td style="padding:5px;"><strong>Invoice Number:</strong> [invoiceNumber]</td>
                                                <td style="text-align:right; padding:5px;"><strong>Invoice Date:</strong> [invoiceDate]</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table border="0" cellpadding="10" cellspacing="10" width="100%">
                                        <tbody>
                                            <tr>
                                                <td style="width:150px; padding:5px;"><strong>CLIENT:</strong></td>
                                                <td style="padding:5px;">[customerName]</td>
                                            </tr>
                                            <tr>
                                                <td style="width:150px; padding:5px;"><strong>HOME:</strong></td>
                                                <td style="padding:5px;">[customerAddress]</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table border="0" cellpadding="10" cellspacing="10" width="100%">
                                        <tbody>
                                            <tr>
                                                <td style="padding:5px 0; word-wrap:break-word;">[itemList]</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table border="0" cellpadding="10" cellspacing="10" style="border-collapse:collapse; width:100%;" width="100%">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:center; padding:10px 0; font-size:12px; color:#666;">[user_company_name] © 2025 - All rights reserved.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        ',
            ],
            [
                'name' => 'Template Two',
                'scope' => null,
                'template_html' => '<table align="center" bgcolor="#ffffff" cellpadding="10" cellspacing="0" style=" font-size:12px; border: 1px solid #cccccc; width: 700px; table-layout: fixed; border-collapse: collapse;">
                        <tbody>
                            <tr>
                                <td>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <tbody>
                                        <tr>
                                            <td style="padding: 10px; vertical-align: top;">
                                            <h2 style="text-transform: uppercase; font-size: 20px;">[user_company_name]</h2>

                                            <p style="margin: 0; font-size: 14px;line-height: 12px;"><strong>[user_company_address]</strong><br />
                                            [ref_no]<br />
                                            <strong>Gst no:</strong> [user_company_gst_no]</p>
                                            </td>
                                            <td style="padding: 10px; text-align: right; vertical-align: top;">
                                            <h2 style="font-size: 20px;">CLIENTE</h2>

                                            <p style="margin: 0; font-size: 14px;"><strong>[customerName]</strong><br />
                                            [customerAddress]</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table style="width: 100%; margin: 10px 0; border-collapse: collapse; border: 1px solid #ddd;">
                                    <tbody>
                                        <tr>
                                            <td style="border: 1px solid #ddd; padding: 8px;">[invoiceNumber]</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">[invoiceDate]</td>
                                            <td colspan="3" style="border: 1px solid #ddd; padding: 8px;">[dueDate]</td>
                                        </tr>
                                    </tbody>
                                </table>
                                [itemList]

                                <table style="width: 100%; margin-top: 10px;">
                                    <tbody>
                                        <tr>
                                            <td style="text-align: center; padding: 10px; background-color: #f7faff; font-size: 12px;">[user_company_name] © 2025 - All rights reserved.</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    ',
            ],
            [
                'name' => 'Template Three',
                'scope' => null,
                'template_html' => '<table align="center" bgcolor="#ffffff" cellpadding="0" cellspacing="0" style=" border: 1px solid #cccccc; width: 700px; table-layout: fixed; border-collapse: collapse;">
                    <tbody>
                        <tr>
                            <td>
                            <table border="0" cellpadding="10" cellspacing="0" style="border-collapse: collapse;" width="100%">
                                <tbody>
                                    <tr>
                                        <td colspan="2" style="font-size: 24px; font-weight: bold;">[companylogo]</td>
                                        <td align="right"><strong>[invoiceNumber]</strong><br />
                                        <strong>[invoiceDate]</strong><br />
                                        <strong>[dueDate]</strong></td>
                                    </tr>
                                </tbody>
                            </table>

                            <table border="0" cellpadding="10" cellspacing="0" style="border: 1px solid #ccc; border-collapse: collapse; margin-top: 20px;" width="100%">
                                <tbody>
                                    <tr>
                                        <td style="background: #ddd; font-weight: bold; width: 50%; border-right: 1px solid #ccc;">EMPRESA</td>
                                        <td style="background: #ddd; font-weight: bold;">CLIENTE</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right: 1px solid #ccc;"><strong class="text-transform:uppercase">[user_company_name]</strong><br />
                                        [user_company_address]<br />
                                        <strong>Gst no: </strong>[user_company_gst_no]<br />
                                        [ref_no]</td>
                                        <td style="line-height: 14px;"><strong>[customerName]</strong><br />
                                        <strong>Inicio: </strong>[customerAddress]</td>
                                    </tr>
                                </tbody>
                            </table>

                            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; margin-top: 20px; text-align: left;" width="100%">
                                <tbody>
                                    <tr>
                                        <td>[itemList]</td>
                                    </tr>
                                </tbody>
                            </table>

                            <table border="0" cellpadding="10" cellspacing="0" style="background:#dddddd; border-collapse: collapse; margin-top: 20px; text-align: center;" width="100%">
                                <tbody>
                                    <tr>
                                        <td>[user_company_name] © 2025 - All rights reserved.</td>
                                    </tr>
                                </tbody>
                            </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                ',
            ]
        ];

        foreach ($Templates as $template) {
            // $invoice['items'] = json_encode($invoice['items']);
            Templates::create($template);
        }
    }
}
