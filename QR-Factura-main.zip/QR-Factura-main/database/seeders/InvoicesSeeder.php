<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Invoice;
use App\Models\Clients;
use App\Models\PaymentMethods;
use App\Models\Services;
use App\Models\Inventory;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class InvoicesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();
        $clients = Clients::pluck('id')->toArray();
        $paymentMethods = PaymentMethods::pluck('id')->toArray();
        $services = Services::pluck('id')->toArray();
        $inventories = Inventory::pluck('id')->toArray();

        // Sample Predefined Invoice
        $invoiceData = [
            [
                'invoice_id' => '2025/AR/0001',
                'client_id' => 1,
                'currency' => '€',
                'issue_date' => now(),
                'due_date' => now()->addDays(30),
                'invoice_type' => 2,
                'payment_method' => 2,
                'ref_no' => '23',
                'items' => json_encode([
                    [
                        "item_id" => "5", 
                        "item_type" => "service", 
                        "quantity" => "1", 
                        "price" => "5,000.00", 
                        "discount_percentage" => "35.00", 
                        "use_percentage" => "true", 
                        "tax" => "10.00", 
                        "amount" => "3575" 
                    ], 
                    [
                        "item_id" => "2", 
                        "item_type" => "service", 
                        "quantity" => "1", 
                        "price" => "15.00", 
                        "discount" => "22.00", 
                        "tax" => "22.00", 
                        "amount" => "-8.54" 
                    ] 
                 ]),
                'extra' =>json_encode(["item_type"=>"service"]),
                "subtotal" => "5015",
                "totalDiscount" => "1772",
                "totalTax" => "323.46",
                "totalRetencion"=>null,
                "grandTotal" => "3566.46",
                'created_by' => 1,
                'status' => 1,
            ]
        ];

        // Generate 100 Random Invoices
        // for ($i = 0; $i < 100; $i++) {
        //     $clientId = $faker->randomElement($clients);
        //     $paymentMethod = $faker->randomElement($paymentMethods);
        //     $invoiceType = $faker->numberBetween(1, 3);
        //     $invoiceNumber = '2025/INV/' . str_pad($i + 2, 4, '0', STR_PAD_LEFT);
        //     $issueDate = $faker->dateTimeBetween('-6 months', 'now');
        //     $dueDate = (clone $issueDate)->modify('+30 days');

        //     // Generate Random Items (Services or Inventory)
        //     $items = [];
        //     $totalSubtotal = 0;
        //     $totalDiscount = 0;
        //     $totalTax = 0;

        //     for ($j = 0; $j < rand(1, 5); $j++) {
        //         $isService = $faker->boolean(50); // 50% chance of selecting a service or inventory item
        //         $itemId = $faker->randomElement($isService ? $services : $inventories);
        //         $price = $faker->randomFloat(2, 50, 5000);
        //         $quantity = $faker->numberBetween(1, 5);
        //         $discountPercentage = $faker->optional()->numberBetween(0, 15);
        //         $discount = $discountPercentage ? ($price * $quantity * $discountPercentage / 100) : 0;
        //         $tax = $faker->randomFloat(2, 0, 20);
        //         $amount = ($price * $quantity) - $discount + ($price * $quantity * $tax / 100);

        //         $items[] = [
        //             "item_id" => $itemId,
        //             "new_item" => null,
        //             "quantity" => $quantity,
        //             "price" => $price,
        //             "discount" => $discount,
        //             "discount_percentage" => $discountPercentage,
        //             "use_percentage" => $discountPercentage ? true : false,
        //             "tax" => $tax,
        //             "amount" => $amount
        //         ];

        //         $totalSubtotal += ($price * $quantity);
        //         $totalDiscount += $discount;
        //         $totalTax += ($price * $quantity * $tax / 100);
        //     }

        //     $grandTotal = $totalSubtotal - $totalDiscount + $totalTax;

        //     $invoiceData[] = [
        //         'name' => $faker->name,
        //         'invoice_id' => $invoiceNumber,
        //         'client_id' => $clientId,
        //         'currency' => $faker->randomElement(['$', '€', '₹']),
        //         'issue_date' => $issueDate,
        //         'due_date' => $dueDate,
        //         'invoice_type' => $invoiceType,
        //         'payment_method' => $paymentMethod,
        //         'ref_no' =>null,
        //         'items' => json_encode($items),
        //         'extra' => json_encode([
        //             "template_id" => "1",
        //             "subtotal" => $totalSubtotal,
        //             "totalDiscount" => $totalDiscount,
        //             "totalTax" => $totalTax,
        //             "grandTotal" => $grandTotal
        //         ]),
        //         'created_by' => null,
        //         'status' => 1,
        //     ];
        // }

        // Insert into the database
        Invoice::insert($invoiceData);
    }
}
