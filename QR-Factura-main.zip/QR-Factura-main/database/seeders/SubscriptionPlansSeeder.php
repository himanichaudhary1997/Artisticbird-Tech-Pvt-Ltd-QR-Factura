<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SubscriptionPlans;
use Faker\Factory as Faker;

class SubscriptionPlansSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        // Predefined Plans
        $subscriptionPlansData = [
            [
                'name' => 'Free',
                'price' => 0,
                'time_period' => 1,
            ],
            [
                'name' => 'Premium',
                'price' => 100,
                'time_period' => 3,
            ],
        ];

        // Generate 3 to 8 additional random plans to make total 5-10
        // $additionalPlansCount = rand(3, 8);
        // for ($i = 0; $i < $additionalPlansCount; $i++) {
        //     $subscriptionPlansData[] = [
        //         'name' => $faker->word . ' Plan',
        //         'price_per_month' => $faker->numberBetween(5, 10), // Price range from 5 to 200
        //         'price_per_year' => $faker->numberBetween(50, 200), // Price range from 50 to 2000
        //         'items' => $faker->randomElements([1, 2, 3, 4, 5], rand(1, 4)), // Random items
        //         'status' => 1
        //     ];
        // }

        // Insert into database
        foreach ($subscriptionPlansData as $item) {
            SubscriptionPlans::create($item);
        }
    }
}
