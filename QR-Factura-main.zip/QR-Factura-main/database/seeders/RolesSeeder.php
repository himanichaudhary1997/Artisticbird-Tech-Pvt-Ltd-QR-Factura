<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Role::create(['name' => 'Admin']);
        Role::create(['name' => 'Company']);
        Role::create(['name' => 'Staff']);
        Role::create(['name' => 'Accountant']);
        Role::create(['name' => 'Support']);
        Role::create(['name' => 'CompanyStaff']);
        Role::create(['name' => 'CompanyAccountant']);
    }
}
