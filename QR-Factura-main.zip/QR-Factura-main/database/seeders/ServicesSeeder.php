<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Services;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class ServicesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        // Predefined Services
        $serviceData = [
            [
                'name' => 'Web Development',
                'slug' => 'web-development',
                'desc' =>  $faker->sentence,
                'price' => 7200,
                'tax_rate' => 18,
                'discount' => 5,
            ],
            [
                'name' => 'Digital Marketing',
                'slug' => 'digital-marketing',
                'desc' =>  $faker->sentence,
                'price' => 300,
                'tax_rate' => 18,
                'discount' => 5,
            ],
            [
                'name' => 'Graphic Design',
                'slug' => 'graphic-design',
                'desc' =>  $faker->sentence,
                'price' => 7000,
                'tax_rate' => 18,
                'discount' => 5,
            ],
            [
                'name' => 'Mobile App Development',
                'slug' => 'mobile-app-development',
                'desc' =>  $faker->sentence,
                'price' => 750,
                'tax_rate' => 18,
                'discount' => 5,
            ],
            [
                'name' => 'Content Writing',
                'slug' => 'content-writing',
                'desc' =>  $faker->sentence,
                'price' => 500,
                'tax_rate' => 18,
                'discount' => 5,
            ]
        ];

        // Generate 20 additional random services
        // for ($i = 0; $i < 20; $i++) {
        //     $name = ucfirst($faker->word) . ' ' . $faker->randomElement(['Consulting', 'Development', 'Strategy', 'Analysis', 'Management']);
        //     $slug = Str::slug($name);

        //     $serviceData[] = [
        //         'name' => $name,
        //         'slug' => $slug,
        //         'desc' =>  $faker->sentence,
        //         'price' => 500,
        //         'tax_rate' => 18,
        //         'discount' => 5,
        //     ];
        // }

        // Insert into the database
        Services::insert($serviceData);
    }
}
