<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\CountryModel;
use App\Models\StateModel;

class CountryStateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $countryData = [
            [
                'name' => 'Spain',
                'country_code' => 'ES',
                'states' => [
                    ['name' => 'A Coruña', 'state_code' => 'AC'],
                    ['name' => 'Álava', 'state_code' => 'AL'],
                    ['name' => 'Albacete', 'state_code' => 'AB'],
                    ['name' => 'Alicante', 'state_code' => 'ALC'],
                    ['name' => 'Almería', 'state_code' => 'ALM'],
                    ['name' => 'Asturias', 'state_code' => 'AS'],
                    ['name' => 'Ávila', 'state_code' => 'AV'],
                    ['name' => 'Badajoz', 'state_code' => 'BA'],
                    ['name' => 'Baleares', 'state_code' => 'IB'],
                    ['name' => 'Barcelona', 'state_code' => 'BC'],
                    ['name' => 'Burgos', 'state_code' => 'BU'],
                    ['name' => 'Cáceres', 'state_code' => 'CC'],
                    ['name' => 'Cádiz', 'state_code' => 'CA'],
                    ['name' => 'Cantabria', 'state_code' => 'CB'],
                    ['name' => 'Castellón', 'state_code' => 'CS'],
                    ['name' => 'Ciudad Real', 'state_code' => 'CR'],
                    ['name' => 'Córdoba', 'state_code' => 'CO'],
                    ['name' => 'Cuenca', 'state_code' => 'CU'],
                    ['name' => 'Girona', 'state_code' => 'GI'],
                    ['name' => 'Granada', 'state_code' => 'GR'],
                    ['name' => 'Guadalajara', 'state_code' => 'GU'],
                    ['name' => 'Gipuzkoa', 'state_code' => 'GI'],
                    ['name' => 'Huelva', 'state_code' => 'HU'],
                    ['name' => 'Huesca', 'state_code' => 'HU'],
                    ['name' => 'Jaén', 'state_code' => 'JA'],
                    ['name' => 'La Rioja', 'state_code' => 'LR'],
                    ['name' => 'Las Palmas', 'state_code' => 'LP'],
                    ['name' => 'León', 'state_code' => 'LE'],
                    ['name' => 'Lleida', 'state_code' => 'LL'],
                    ['name' => 'Lugo', 'state_code' => 'LU'],
                    ['name' => 'Madrid', 'state_code' => 'MD'],
                    ['name' => 'Málaga', 'state_code' => 'MA'],
                    ['name' => 'Murcia', 'state_code' => 'MU'],
                    ['name' => 'Navarra', 'state_code' => 'NA'],
                    ['name' => 'Ourense', 'state_code' => 'OR'],
                    ['name' => 'Palencia', 'state_code' => 'PA'],
                    ['name' => 'Pontevedra', 'state_code' => 'PO'],
                    ['name' => 'Salamanca', 'state_code' => 'SA'],
                    ['name' => 'Segovia', 'state_code' => 'SG'],
                    ['name' => 'Sevilla', 'state_code' => 'SE'],
                    ['name' => 'Soria', 'state_code' => 'SO'],
                    ['name' => 'Tarragona', 'state_code' => 'TA'],
                    ['name' => 'Santa Cruz de Tenerife', 'state_code' => 'TF'],
                    ['name' => 'Teruel', 'state_code' => 'TE'],
                    ['name' => 'Toledo', 'state_code' => 'TO'],
                    ['name' => 'Valencia', 'state_code' => 'VA'],
                    ['name' => 'Valladolid', 'state_code' => 'VA'],
                    ['name' => 'Vizcaya', 'state_code' => 'VI'],
                    ['name' => 'Zamora', 'state_code' => 'ZA'],
                    ['name' => 'Zaragoza', 'state_code' => 'ZG'],
                ],
            ],
            [
                'name' => 'India',
                'country_code' => 'IN',
                'states' => [
                    ['name' => 'Andhra Pradesh', 'state_code' => 'AP'],
                    ['name' => 'Arunachal Pradesh', 'state_code' => 'AR'],
                    ['name' => 'Assam', 'state_code' => 'AS'],
                    ['name' => 'Bihar', 'state_code' => 'BR'],
                    ['name' => 'Chhattisgarh', 'state_code' => 'CT'],
                    ['name' => 'Goa', 'state_code' => 'GA'],
                    ['name' => 'Gujarat', 'state_code' => 'GJ'],
                    ['name' => 'Haryana', 'state_code' => 'HR'],
                    ['name' => 'Himachal Pradesh', 'state_code' => 'HP'],
                    ['name' => 'Jharkhand', 'state_code' => 'JH'],
                    ['name' => 'Karnataka', 'state_code' => 'KA'],
                    ['name' => 'Kerala', 'state_code' => 'KL'],
                    ['name' => 'Madhya Pradesh', 'state_code' => 'MP'],
                    ['name' => 'Maharashtra', 'state_code' => 'MH'],
                    ['name' => 'Manipur', 'state_code' => 'MN'],
                    ['name' => 'Meghalaya', 'state_code' => 'ML'],
                    ['name' => 'Mizoram', 'state_code' => 'MZ'],
                    ['name' => 'Nagaland', 'state_code' => 'NL'],
                    ['name' => 'Odisha', 'state_code' => 'OR'],
                    ['name' => 'Punjab', 'state_code' => 'PB'],
                    ['name' => 'Rajasthan', 'state_code' => 'RJ'],
                    ['name' => 'Sikkim', 'state_code' => 'SK'],
                    ['name' => 'Tamil Nadu', 'state_code' => 'TN'],
                    ['name' => 'Telangana', 'state_code' => 'TG'],
                    ['name' => 'Tripura', 'state_code' => 'TR'],
                    ['name' => 'Uttar Pradesh', 'state_code' => 'UP'],
                    ['name' => 'Uttarakhand', 'state_code' => 'UT'],
                    ['name' => 'West Bengal', 'state_code' => 'WB'],
                    ['name' => 'Andaman and Nicobar Islands', 'state_code' => 'AN'],
                    ['name' => 'Chandigarh', 'state_code' => 'CH'],
                    ['name' => 'Dadra and Nagar Haveli and Daman and Diu', 'state_code' => 'DN'],
                    ['name' => 'Delhi', 'state_code' => 'DL'],
                    ['name' => 'Jammu and Kashmir', 'state_code' => 'JK'],
                    ['name' => 'Ladakh', 'state_code' => 'LA'],
                    ['name' => 'Lakshadweep', 'state_code' => 'LD'],
                    ['name' => 'Puducherry', 'state_code' => 'PY'],
                ],
            ]
        ];
        

        foreach($countryData as $country){
            $states = $country['states'];
            
            unset($country['states']);
            
            $country = CountryModel::create($country);

            foreach($states as $state){
                $state['country_id'] = $country->id;
                StateModel::create($state);
            }
        }
    }
}
