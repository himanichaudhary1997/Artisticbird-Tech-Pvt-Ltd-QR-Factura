<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Route;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UpdateAdminPermissionsSeeder extends Seeder
{
    public function run()
    {
        $adminRole = Role::where('name', 'Admin')->first();

        if (!$adminRole) {
            echo "❌ Admin role not found. Please create it first.\n";
            return;
        }

        // ✅ Get all route names
        $routeNames = collect(Route::getRoutes())->map(function ($route) {
            return $route->getName(); // Get route name
        })->filter()->unique(); // Remove null and duplicates

        // ✅ Create missing permissions in DB
        foreach ($routeNames as $routeName) {
            Permission::firstOrCreate(['name' => $routeName, 'guard_name' => 'web']);
        }

        // ✅ Assign all permissions to Admin
        $adminRole->syncPermissions(Permission::all());

        echo "✅ Admin role updated with all route permissions.\n";
    }
}
