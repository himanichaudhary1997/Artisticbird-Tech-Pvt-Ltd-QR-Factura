<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Inventory;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class InventorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        $inventoryItems = [
            [
                'name' => 'Laptop',
                'price' => 75000,
                'quantity' => 20,
                'tax_rate' => 18,
                'discount' => 5,
                'description' => 'High-performance laptop for work and gaming.',
            ],
            [
                'name' => 'Smartphone',
                'price' => 35000,
                'quantity' => 50,
                'tax_rate' => 12,
                'discount' => 3,
                'description' => 'Latest Android smartphone with high-end camera.',
            ],
            [
                'name' => 'Office Chair',
                'price' => 8000,
                'quantity' => 15,
                'tax_rate' => 5,
                'discount' => 2,
                'description' => 'Ergonomic office chair with lumbar support.',
            ],
        ];

        // Generate 20 additional random inventory items
        for ($i = 0; $i < 20; $i++) {
            $name = $faker->word . ' ' . $faker->randomElement(['Gadget', 'Device', 'Accessory', 'Tool', 'Equipment']);
            $inventoryItems[] = [
                'name' => ucfirst($name),
                'price' => $faker->randomFloat(2, 50, 10000),
                'quantity' => $faker->numberBetween(1, 100),
                'tax_rate' => $faker->randomFloat(2, 0, 18),
                'discount' => $faker->randomFloat(2, 0, 10),
                'description' => $faker->sentence,
            ];
        }

        Inventory::insert($inventoryItems);
    }
}
