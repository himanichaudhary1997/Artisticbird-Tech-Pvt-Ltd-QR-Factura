<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Connection Name
    |--------------------------------------------------------------------------
    |
    | Here you may specify which of the connections below you wish to use as
    | your default connection for all work. Of course, you may use many
    | connections at once using the manager class.
    |
    */

    'default' => 'main',

    /*
    |--------------------------------------------------------------------------
    | Hashids Connections
    |--------------------------------------------------------------------------
    |
    | Here are each of the connections setup for your application. Example
    | configuration has been included, but you may add as many connections as
    | you would like.
    |
    */

    'connections' => [

        'main' => [
            'salt' => '',
            'length' => 0,
            'alphabet' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
        ],

        'alternative' => [
            'salt' => 'your-salt-string',
            'length' => 'your-length-integer',
            // 'alphabet' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
        ],
        'company' => [
            'salt' => env('HASHIDS_COMPANY_SALT', 'company-secret'),
            'length' => 10,
        ],
        'invoice' => [
            'salt' => env('HASHIDS_INVOICE_SALT', 'invoice-secret'),
            'length' => 10,
        ],
        'auto-invoice' => [
            'salt' => env('HASHIDS_AUTO_INVOICE_SALT', 'auto-invoice-secret'),
            'length' => 10,
        ],
        'receipt' => [
            'salt' => env('HASHIDS_RECEIPT_INVOICE_SALT', 'receipt-secret'),
            'length' => 10,
        ],

    ],

];
