<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'fiskaly' => [
        'dashboard_url' => env('FISKALY_DASHBOARD_URL', 'https://dashboard.fiskaly.com/api/v0'),
        'managed_id' => env('FISKALY_MANAGED_ID', '7e384e68-4d44-4845-9163-26375fe4713f'),
        'base_url' => env('FISKALY_BASE_URL', 'https://test.es.sign.fiskaly.com/api/v1'),
        'api_key' => env('FISKALY_API_KEY', 'test_7h0e6qvt5525wqc1i4tjncmrj_tech'),
        'api_secret' => env('FISKALY_API_SECRETKEY', 'IZtgv3sZTFHz80jVEVvNf7sHCZH1KNAeuz3kAk7C01N'),
        // 'base_url' => env('FISKALY_BASE_URL', 'https://live.es.sign.fiskaly.com/api/v1'),
        // 'api_key' => env('FISKALY_API_KEY', 'live_7h0e6qvt5525wqc1i4tjncmrj_artisticbird'),
        // 'api_secret' => env('FISKALY_API_SECRETKEY', 'I3LkA9QcqeyQstowiNYmp6mBkfZKmDOsBEoR6vgPD19'),
    ],
];
