/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function(config) {
    // Define changes to default configuration here. For example:
    //config.language = 'es';
    //config.uiColor = '#AADC6E';
    // config.extraPlugins = 'btgrid';
    // config.extraPlugins = 'accordionList';
    // config.extraPlugins = 'bootstrapTable';
    // config.extraPlugins = 'bootstrapTabs';
    // config.extraPlugins = 'bootstrapVisibility';
    // config.extraPlugins = 'bt_table';
    // config.extraPlugins = 'btbutton';
    // config.extraPlugins = 'btquicktable';
    // config.extraPlugins = 'collapsibleItem';
    // config.extraPlugins = 'fontawesome';
    // //config.contentsCss = 'path/to/your/font-awesome.css';
    // config.contentsCss = 'https://use.fontawesome.com/releases/v5.7.2/css/all.css';
    // config.allowedContent = true;
    // config.extraPlugins = 'glyphicons';
    // config.contentsCss = 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css';
    // //config.contentsCss = 'path/to/your/bootstrap.css';
    // config.allowedContent = true;
    // config.extraPlugins = 'youtubebootstrap';
    config.autoParagraph = false;
    config.toolbarCanCollapse = true;
    config.extraPlugins = 'btgrid,  bootstrapTabs, bootstrapVisibility, bt_table, btbutton,  youtubebootstrap';
    // config.contentsCss = '/assets/css/style.css';
    // config.contentsCss = '/css/app.css';
    // config.contentsCss = '/includes/template0/assets/css/style.css';
    config.allowedContent = true;
    config.entities = false;
    config.basicEntities = false;
    

};